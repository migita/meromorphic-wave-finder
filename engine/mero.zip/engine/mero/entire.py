"""Entire solutions of an autonomous polynomial ODE  E(w0, w1, ..., wK) = 0   (worker ENTIRE, 6 Oct 2026).

    entire_solutions(eq, budget_s=30, N_max=4, deg_search=6, max_conds=3, strata_depth=1) -> dict

What it returns (JSON-ready; formulas are exact SymPy strings; Solution objects as in project note section 2):

  constants      the roots of E(c, 0, ..., 0), or the family "every constant"
  polynomials    all polynomial solutions of degree >= 1 (degree bound of lemmas/entire/project note,
                 Lemma P: label `certificate` when the bound is derived, `search` otherwise)
  exponentials   sums sum_{k=-N1..N2} c_k exp(k*lamda*z) with N1 + N2 <= N_max (label `search`;
                 Lemma X), the general solution of a linear equation, and C0*exp(int u) (Lemma H)
  linear         for a linear equation (total degree 1): the general solution (L-LINEAR)
  homogeneous    for an equation homogeneous in the jets whose reduction u = w'/w is linear (L-HOMLIN)
  complete       True only when a theorem gives: every entire solution is in the lists above, for
                 parameter values satisfying `complete_conditions`; `basis` names the theorems:
                 T-CLUNIE, T-WV (registry, used only within their registry hypotheses), L-ENTIRE-WV,
                 L-ENTIRE-FACTOR, L-HOMLIN (lemmas/entire/project note), L-LINEAR (registry)
  growth         what the Wiman-Valiron argument says about transcendental entire solutions
  ruled_out      [{"what", "basis": {"theorem", "label"}, "conditions"}]
  not_decided    ready-to-show sentences
  strata         the same analysis for the parameter values where the leading data degenerate
                 (their solutions are also merged into the lists, with the stratum condition first)
  certificate    tau(t), degree bound, systems solved, searched shapes, rejected candidates
  warnings, elapsed_s

A Solution whose re-verification by substitution fails is never listed (certificate.rejected).
Pure SymPy; the time budget is checked with time.monotonic() between steps.
"""
import itertools
import math
import time

import sympy as sp

z = sp.Symbol("z")
_S = sp.Symbol("s_")          # s = exp(lambda z)
_M = sp.Symbol("_m")          # degree variable in Q_T(m)   (displayed as m)
_T = sp.Symbol("_t")          # variable of tau(t)          (displayed as t)
_CV = sp.Symbol("_cv")        # variable of E(c, 0, ..., 0)  (displayed as c)


def _disp(e, params=()):
    """string of an expression in the private variables, with the display names when free"""
    names = set(str(p) for p in params)
    rep = {}
    for priv, pub in ((_M, "m"), (_T, "t"), (_CV, "c")):
        rep[priv] = sp.Symbol(pub if pub not in names else pub + "_")
    return str(sp.sympify(e).subs(rep))

ENGINE_TAG = "entire/1"


# ----------------------------------------------------------------------------------------------
# input
# ----------------------------------------------------------------------------------------------

class _Data(object):
    """K, w (jets), params, terms {exponent tuple: coeff}, E."""

    def __init__(self, K, w, params, terms, unknown="w", var="z", reserved=None):
        self.K = int(K)
        self.w = tuple(w)
        self.params = list(params)
        self.terms = {}
        for mon, co in terms.items():
            mon = tuple(int(e) for e in mon) + (0,) * (self.K + 1 - len(mon))
            co = sp.sympify(co)
            if sp.expand(co) != 0:
                self.terms[mon] = co
        self.E = sp.Add(*[co * sp.Mul(*[self.w[j] ** e for j, e in enumerate(mon)])
                          for mon, co in self.terms.items()])
        self.unknown, self.var = unknown, var
        # names that an auxiliary symbol must never take: parameters, jets, z (and those of a parent equation)
        self.reserved = set(reserved or ()) | set(str(p) for p in self.params) | set(str(x) for x in self.w) | {"z"}
        for co in self.terms.values():
            self.reserved |= set(str(x) for x in co.free_symbols)


class _Names(object):
    """allocator of fresh symbol names (never a parameter, a jet, z, or a name already given out)"""

    def __init__(self, reserved):
        self.used = set(reserved)

    def one(self, base, numbered=True):
        if not numbered and base not in self.used:
            self.used.add(base)
            return sp.Symbol(base)
        k = 1
        while "%s%d" % (base, k) in self.used:
            k += 1
        name = "%s%d" % (base, k)
        self.used.add(name)
        return sp.Symbol(name)


def _jets(K):
    return sp.symbols("w0:%d" % (K + 1))


def from_expr(E, params=None):
    """Build the internal data from an expression (or string) in the jets w0, w1, ...; every other
    symbol except z is a parameter."""
    loc = dict(("w%d" % j, sp.Symbol("w%d" % j)) for j in range(12))
    if isinstance(E, str):
        import re
        txt = re.sub(r"\blambda\b", "lamda", E.replace("^", "**"))
        for tok in set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", txt)):
            if tok not in loc and tok not in ("exp", "sqrt", "I", "pi", "Rational"):
                loc[tok] = sp.Symbol(tok)
        E = sp.sympify(txt, locals=loc)
    jets = sorted([s for s in E.free_symbols if s.name[:1] == "w" and s.name[1:].isdigit()],
                  key=lambda s: int(s.name[1:]))
    K = max(int(s.name[1:]) for s in jets) if jets else 0
    w = _jets(K)
    if params is None:
        params = sorted([s for s in E.free_symbols if s not in w and s != z], key=lambda s: s.name)
    else:
        params = [sp.Symbol(str(p)) for p in params]
    poly = sp.Poly(sp.expand(E), *w)
    return _Data(K, w, params, dict(poly.terms()))


def _as_data(eq):
    if isinstance(eq, _Data):
        return eq
    if isinstance(eq, (str, sp.Basic)):
        return from_expr(eq)
    K = eq.K
    w = tuple(eq.w)
    params = [sp.Symbol(str(p)) for p in getattr(eq, "params", [])]
    terms = dict(eq.terms)
    # the jets of other modules may be named differently: rename to w0..wK
    std = _jets(K)
    ren = dict(zip(w, std))
    terms = dict((m, sp.sympify(c).subs(ren)) for m, c in terms.items())
    return _Data(K, std, params, terms, getattr(eq, "unknown", "w"), getattr(eq, "var", "z"))


# ----------------------------------------------------------------------------------------------
# small helpers
# ----------------------------------------------------------------------------------------------

def _ff(x, j):
    r = sp.Integer(1)
    for i in range(j):
        r *= (x - i)
    return r


def _s_of(mon):
    """number of differentiations of the monomial prod w_j^e_j"""
    return sum(j * e for j, e in enumerate(mon))


def _deg(mon):
    return sum(mon)


def _simp(e):
    try:
        return sp.cancel(sp.together(e))
    except Exception:
        return e


def _numer(e):
    e = sp.together(sp.expand(e))
    n, _d = sp.fraction(e)
    return sp.expand(n)


def _is_zero(e):
    try:
        return sp.expand(sp.together(e)) == 0 or sp.simplify(e) == 0
    except Exception:
        return False


def _factor_list(e):
    try:
        c, fl = sp.factor_list(e)
        return c, [f for f, _k in fl]
    except Exception:
        return sp.Integer(1), [e]


def _ne(e):
    """'g != 0' with the numerical content of e removed"""
    e = _numer(sp.sympify(e))
    fl = [g for g in _factor_list(e)[1] if not g.is_number]
    if not fl:
        return None
    return "%s != 0" % sp.Mul(*fl)


def _eqz(e):
    e = _numer(sp.sympify(e))
    fl = [g for g in _factor_list(e)[1] if not g.is_number]
    return "%s == 0" % (sp.Mul(*fl) if fl else e)


def _same_up_to_sign(a, b):
    return sp.expand(a - b) == 0 or sp.expand(a + b) == 0


def _str(e):
    return str(e)


def _cond_str(e, rel):
    return "%s %s 0" % (sp.factor(e) if not e.has(sp.sqrt(2) * 0 + sp.I) else e, rel)


class _Budget(object):
    def __init__(self, seconds):
        self.t0 = time.monotonic()
        self.deadline = self.t0 + float(seconds)

    def left(self):
        return self.deadline - time.monotonic()

    def over(self):
        return time.monotonic() > self.deadline

    def sub(self, frac):
        b = _Budget(0)
        b.t0 = time.monotonic()
        b.deadline = min(self.deadline, b.t0 + max(0.0, self.left()) * frac)
        return b


# ----------------------------------------------------------------------------------------------
# a small exact solver for polynomial systems with parameters
# ----------------------------------------------------------------------------------------------

class _Branch(object):
    __slots__ = ("eqs", "subs", "psubs", "pconds", "punsolved", "pne", "une", "notes")

    def __init__(self, eqs):
        self.eqs = list(eqs)
        self.subs = {}        # unknown -> value
        self.psubs = {}       # parameter -> value (from a condition)
        self.pconds = []      # conditions on parameters, expressions that must vanish (display)
        self.punsolved = []   # conditions not solved for a parameter (used in verification)
        self.pne = []         # parameter expressions that must not vanish
        self.une = []         # expressions in the unknowns that must not vanish
        self.notes = []

    def copy(self):
        b = _Branch(self.eqs)
        b.subs = dict(self.subs)
        b.psubs = dict(self.psubs)
        b.pconds = list(self.pconds)
        b.punsolved = list(self.punsolved)
        b.pne = list(self.pne)
        b.une = list(self.une)
        b.notes = list(self.notes)
        return b


class _Solver(object):
    """Branch-and-substitute solver.  Unknowns are solved first; an equation in the parameters
    alone becomes a condition (at most `max_conds` per branch).  Exact: radicals only for
    quadratics with parameters, CRootOf for numerical univariate polynomials."""

    def __init__(self, unknowns, nonzero, params, budget, max_conds=3, max_branches=400, init_pne=None):
        self.init_pne = [g for e in (init_pne or []) for g in _factor_list(_numer(sp.sympify(e)))[1]
                         if not g.is_number]
        self.unknowns = list(unknowns)
        self.uset = set(unknowns)
        self.nonzero = list(nonzero)
        self.params = list(params)
        self.pset = set(params)
        self.budget = budget
        self.max_conds = max_conds
        self.max_branches = max_branches
        self.incomplete = []
        self.truncated_conditions = False

    # -- nonvanishing tests
    def _known_nonzero(self, f, br):
        if f.is_number:
            return f != 0
        if f in self.nonzero:
            return True
        if f.is_Pow and f.base in self.nonzero:
            return True
        for g in br.pne:
            if _same_up_to_sign(f, g):
                return True
        return False

    def _reduce(self, e, br):
        if br.psubs:
            e = e.subs(br.psubs)
        if br.subs:
            e = e.subs(br.subs)
        return _numer(e)

    def _factors(self, e, br):
        """irreducible factors of e that may vanish; None if e cannot vanish"""
        c, fl = _factor_list(e)
        out = []
        for f in fl:
            if self._known_nonzero(f, br):
                continue
            if all(self._known_nonzero(g, br) for g in _factor_list(f)[1]):
                continue
            if not any(_same_up_to_sign(f, g) for g in out):
                out.append(f)
        if not out:
            return None
        return out

    def _unk(self, f, br):
        return [u for u in self.unknowns if u not in br.subs and f.has(u)]

    def _fclass(self, f, br):
        """0 parameters only; 1 linear, safe coefficient; 2 linear, parameter coefficient;
        3 univariate nonlinear; 4 linear with a coefficient in the unknowns; 5 nonlinear in several"""
        us = self._unk(f, br)
        if not us:
            return 0, 0
        fe = sp.expand(f)
        best = None
        for u in us:
            if sp.degree(fe, u) != 1:
                continue
            a = _simp(fe.coeff(u, 1))
            if a.is_number or all(self._known_nonzero(g, br) for g in _factor_list(_numer(a))[1]):
                k = 1
            elif not self._unk(a, br):
                k = 2
            else:
                k = 4
            best = k if best is None else min(best, k)
        if best is None:
            best = 3 if len(us) == 1 else 5
        return best, len(us)

    def _score(self, fl, br):
        """lower is better: the worst factor decides, then the number of factors"""
        cls = [self._fclass(f, br) for f in fl]
        worst = max(c for c, _n in cls)
        nun = max(n for _c, n in cls)
        return (worst, len(fl), nun, sum(len(sp.Add.make_args(f)) for f in fl))

    # -- recording solutions for unknowns and parameters
    def _assign(self, br, x, v):
        v = _simp(v)
        br.subs = dict((k, _simp(val.subs(x, v))) for k, val in br.subs.items())
        br.subs[x] = v
        br.une = [u.subs(x, v) for u in br.une]
        return br

    def _passign(self, br, p, v):
        v = _simp(v)
        br.psubs = dict((k, _simp(val.subs(p, v))) for k, val in br.psubs.items())
        br.psubs[p] = v
        br.subs = dict((k, _simp(val.subs(p, v))) for k, val in br.subs.items())
        new_pne = []
        for g in br.pne:
            g2 = _numer(g.subs(p, v))
            if g2 == 0:
                return None
            if not g2.is_number:
                new_pne.append(g2)
        br.pne = new_pne
        new_un = []
        for g in br.punsolved:
            g2 = _numer(g.subs(p, v))
            if g2 == 0:
                continue
            if g2.is_number:
                return None
            new_un.append(g2)
        br.punsolved = new_un
        return br

    def _add_pne(self, br, a):
        for g in _factor_list(_numer(a))[1]:
            if not g.is_number and not any(_same_up_to_sign(g, h) for h in br.pne):
                br.pne.append(g)

    # -- main loop
    def solve(self, eqs):
        results = []
        b0 = _Branch(eqs)
        b0.pne = list(self.init_pne)
        stack = [b0]
        nb = 0
        while stack:
            if self.budget.over():
                self.incomplete.append("time budget exhausted with %d open branches" % len(stack))
                break
            nb += 1
            if nb > self.max_branches:
                self.incomplete.append("branch limit %d reached" % self.max_branches)
                break
            br = stack.pop()
            pending = []
            dead = False
            for e in br.eqs:
                e2 = self._reduce(e, br)
                if e2 == 0:
                    continue
                pending.append(e2)
            if not pending:
                fin = self._finalize(br)
                if fin is not None:
                    results.append(fin)
                continue
            cand = []
            for e in pending:
                fl = self._factors(e, br)
                if fl is None:
                    dead = True
                    break
                try:
                    sc = self._score(fl, br)
                except Exception as exc:
                    self.incomplete.append("equation not handled (%s)" % type(exc).__name__)
                    dead = True
                    break
                cand.append((sc, e, fl))
            if dead:
                continue
            cand.sort(key=lambda x: x[0])
            _sc, e, fl = cand[0]
            rest = [c[1] for c in cand[1:]]
            if len(fl) > 1:
                for f in fl:
                    nb_ = br.copy()
                    nb_.eqs = [f] + rest
                    stack.append(nb_)
                continue
            f = fl[0]
            try:
                stack.extend(self._step(br, f, rest))
            except Exception as exc:
                self.incomplete.append("step failed on %s = 0 (%s)" % (f, type(exc).__name__))
        return results

    def _step(self, br, f, rest):
        us = self._unk(f, br)
        out = []
        if not us:
            # a condition on the parameters
            if len(br.pconds) >= self.max_conds:
                self.truncated_conditions = True
                return []
            nb_ = br.copy()
            nb_.pconds.append(f)
            nb_.eqs = rest
            ps = [p for p in self.params if f.has(p) and p not in nb_.psubs]
            lin = []
            try:
                _probe = [sp.degree(f, p) for p in ps]
            except Exception:
                nb_.punsolved.append(f)
                return [nb_]
            for p in ps:
                if sp.degree(f, p) == 1:
                    a = _simp(sp.expand(f).coeff(p, 1))
                    b = _simp(sp.expand(f) - sp.expand(f).coeff(p, 1) * p)
                    if a.has(p) or b.has(p):
                        continue
                    rank = 0 if a.is_number else (1 if self._known_nonzero(a, nb_) else 2)
                    lin.append((rank, len(sp.Add.make_args(a)), str(p), p, a, b))
            if lin:
                lin.sort(key=lambda x: x[:3])
                _r, _n, _nm, p, a, b = lin[0]
                if _r == 2:
                    self._add_pne(nb_, a)
                nb2 = self._passign(nb_, p, -b / a)
                if nb2 is not None:
                    out.append(nb2)
                return out
            if len(ps) == 1:
                p = ps[0]
                poly = sp.Poly(f, p)
                rts = self._roots(poly)
                if rts is not None:
                    for r in rts:
                        nb3 = nb_.copy()
                        nb3.pconds[-1] = p - r          # display the root actually used, not the whole polynomial
                        nb2 = self._passign(nb3, p, r)
                        if nb2 is not None:
                            out.append(nb2)
                    return out
            nb_.punsolved.append(f)
            return [nb_]
        # linear in some unknown?
        fe = sp.expand(f)
        lin = []
        for u in us:
            if sp.degree(fe, u) != 1:
                continue
            a = _simp(fe.coeff(u, 1))
            b = _simp(fe - fe.coeff(u, 1) * u)
            ua = self._unk(a, br)
            if a.is_number:
                rank = 0
            elif all(self._known_nonzero(g, br) for g in _factor_list(_numer(a))[1]):
                rank = 1
            elif not ua:
                rank = 2
            else:
                rank = 3
            lin.append((rank, len(sp.Add.make_args(a)), self.unknowns.index(u), u, a, b))
        if lin:
            lin.sort(key=lambda x: x[:3])
            rank, _n, _i, u, a, b = lin[0]
            nb_ = br.copy()
            nb_.eqs = rest
            if rank == 2:
                self._add_pne(nb_, a)
            elif rank == 3:
                nb_.une.append(a)
            out.append(self._assign(nb_, u, -b / a))
            if rank >= 2:
                # the coefficient vanishes: both parts must vanish
                nb3 = br.copy()
                nb3.eqs = [a, b] + rest
                out.append(nb3)
            return out
        if len(us) == 1:
            u = us[0]
            rts = self._roots(sp.Poly(fe, u))
            if rts is not None:
                for r in rts:
                    nb_ = br.copy()
                    nb_.eqs = rest
                    out.append(self._assign(nb_, u, r))
                return out
            self.incomplete.append("not solved: %s = 0 (degree %d in %s)" % (f, sp.degree(fe, u), u))
            return []
        # nonlinear in several unknowns (and so is every pending equation): a lex Groebner basis of
        # the pending equations replaces them (once per branch)
        if "gb" not in br.notes:
            allu = [v for v in self.unknowns if v not in br.subs and any(e.has(v) for e in [f] + rest)]
            if len(allu) <= 6:
                try:
                    G = sp.groebner([f] + rest, *allu, order="lex")
                    nb_ = br.copy()
                    nb_.notes.append("gb")
                    if list(G.exprs) == [1]:
                        return []
                    nb_.eqs = list(G.exprs)
                    return [nb_]
                except Exception as exc:
                    self.incomplete.append("Groebner step failed: %s" % type(exc).__name__)
                    return []
        self.incomplete.append("not solved: %s = 0 (nonlinear in %s)" % (f, us))
        return []

    def _roots(self, poly):
        """exact roots (with multiplicity ignored) of a univariate polynomial, or None"""
        d = poly.degree()
        if d <= 0:
            return []
        numeric = all(c.is_number for c in poly.all_coeffs())
        if d > 2 and not numeric:
            return None
        try:
            r = sp.roots(poly)
        except Exception:
            r = {}
        if sum(r.values()) == d:
            return list(r.keys())
        if numeric:
            try:
                out = list(r.keys())
                for g, _k in sp.factor_list(poly.as_expr())[1]:
                    gp = sp.Poly(g, *poly.gens)
                    if gp.degree() >= 1 and not any(_is_zero(g.subs(poly.gens[0], x)) for x in out):
                        rr = sp.roots(gp)
                        if sum(rr.values()) == gp.degree():
                            out.extend(rr.keys())
                        else:
                            out.extend(sp.CRootOf(gp, i) for i in range(gp.degree()))
                return out
            except Exception:
                return None
        return None

    def _finalize(self, br):
        subs = dict(br.subs)
        for u in self.nonzero:
            v = subs.get(u, u)
            v = _simp(v.subs(br.psubs)) if br.psubs else v
            if _is_zero(v):
                return None
            if not (set(self.unknowns) & v.free_symbols) and not v.is_number:
                self._add_pne(br, v)
        for g in br.une:
            g2 = _simp(g.subs(br.psubs).subs(subs))
            if _is_zero(g2):
                return None
            if not (set(self.unknowns) & g2.free_symbols) and not g2.is_number:
                self._add_pne(br, g2)
        for g in br.pne:
            if _is_zero(g.subs(br.psubs)):
                return None
        free = [u for u in self.unknowns if u not in subs]
        return {"subs": subs, "free": free, "psubs": dict(br.psubs), "pconds": list(br.pconds),
                "punsolved": list(br.punsolved), "pne": list(br.pne), "notes": list(br.notes)}


# ----------------------------------------------------------------------------------------------
# structure of the equation: tau(t), the top part, the Clunie / Wiman-Valiron data
# ----------------------------------------------------------------------------------------------

def _structure(D):
    n = max(_deg(m) for m in D.terms)
    top = dict((m, c) for m, c in D.terms.items() if _deg(m) == n)
    tau = sp.expand(sum(c * _T ** _s_of(m) for m, c in top.items()))
    svals = sorted(set(_s_of(m) for m in top))
    s_lo, s_hi = svals[0], svals[-1]
    b = dict((k, _simp(sum(c for m, c in top.items() if _s_of(m) == k))) for k in svals)
    b_lo, b_hi = b[s_lo], b[s_hi]
    K = D.K
    pure = (n,) + (0,) * K
    lin1 = (n - 1, 1) + (0,) * (K - 1) if K >= 1 else None
    kind = "other"
    c = rho = None
    if set(top) == {pure} and n >= 2:
        kind = "pure-power"
        c = top[pure]
    elif K >= 1 and n >= 2 and lin1 in top and set(top) <= {pure, lin1}:
        kind = "first-order-factor"
        c = top[lin1]
        rho = _simp(-top.get(pure, 0) / c)
    return {"n": n, "top": top, "tau": tau, "s_lo": s_lo, "s_hi": s_hi, "b_lo": b_lo, "b_hi": b_hi,
            "kind": kind, "c": c, "rho": rho}


def _nonzero_roots_tau(tau):
    """nonzero roots of tau (list) or None if not explicit"""
    if tau == 0:
        return None
    p = sp.Poly(tau, _T)
    while p.degree() > 0 and p.eval(0) == 0:
        p = sp.Poly(sp.cancel(p.as_expr() / _T), _T)
    if p.degree() <= 0:
        return []
    try:
        r = sp.roots(p)
        if sum(r.values()) == p.degree():
            return list(r.keys())
    except Exception:
        pass
    return None


def _maybe_vanishing_param_factors(exprs, params):
    out = []
    for e in exprs:
        e = _numer(sp.sympify(e))
        if e.is_number:
            continue
        for g in _factor_list(e)[1]:
            if g.is_number or not (g.free_symbols & set(params)):
                continue
            if not any(_same_up_to_sign(g, h) for h in out):
                out.append(g)
    return out


# ----------------------------------------------------------------------------------------------
# constants
# ----------------------------------------------------------------------------------------------

def _constants(D, sol_id):
    c = _CV
    e0 = sp.expand(sum(co * c ** m[0] for m, co in D.terms.items() if all(e == 0 for e in m[1:])))
    cert = {"polynomial": _disp(e0, D.params), "variable": "c", "_poly": e0}
    sols = []
    if _is_zero(e0):
        C = _Names(D.reserved).one("K")
        sols.append(_solution(sol_id(), "constant", C, [C], [], d=0,
                              cert=_cert_pass("E(c, 0, ..., 0) vanishes identically"),
                              constants={str(C): "free"}))
        cert["all_constants"] = True
        return sols, cert
    cert["all_constants"] = False
    poly = sp.Poly(e0, c)
    numeric = all(x.is_number for x in poly.all_coeffs())
    roots = []
    if poly.degree() >= 1:
        cl, fl = _factor_list(e0)
        for g in fl:
            if not g.has(c):
                continue
            gp = sp.Poly(g, c)
            r = {}
            if gp.degree() <= 2 or numeric:
                try:
                    r = sp.roots(gp)
                except Exception:
                    r = {}
            if sum(r.values()) == gp.degree():
                roots.extend(r.keys())
            elif numeric:
                roots.extend(sp.CRootOf(gp, i) for i in range(gp.degree()))
            else:
                roots.append(sp.CRootOf(gp, 0) if False else sp.Symbol("ROOT"))
                cert.setdefault("unsolved_factors", []).append(_disp(g, D.params))
    lc = poly.LC()
    conds = [] if lc.is_number else [_ne(lc)]
    for r in roots:
        if r == sp.Symbol("ROOT"):
            continue
        sols.append(_solution(sol_id(), "constant", r, [], conds, d=0,
                              cert=_cert_pass("E(c, 0, ..., 0) = 0 at c = %s" % r)))
    if "unsolved_factors" in cert:
        # not a checkable Solution object: reported in `implicit` by the caller
        cert["implicit"] = "every root c of %s is a constant solution" % " * ".join(cert["unsolved_factors"])
    cert["roots"] = [str(r) for r in roots if r != sp.Symbol("ROOT")]
    if not lc.is_number:
        cert["degenerate_if"] = _eqz(lc)
    return sols, cert


# ----------------------------------------------------------------------------------------------
# Solution objects and verification
# ----------------------------------------------------------------------------------------------

def _cert_pass(detail, method="symbolic"):
    return {"type": "substitution", "method": method, "status": "pass", "detail": detail}


def _denominator_conditions(expr, params, conds):
    """parameter factors of denominators of expr must not vanish"""
    out = list(conds)
    ps = set(params)
    for sub in sp.preorder_traversal(sp.sympify(expr)):
        if isinstance(sub, sp.Pow) and sub.exp.is_negative:
            base = sub.base
            if base.free_symbols and base.free_symbols <= ps:
                x = _ne(base)
                if x and x not in out:
                    out.append(x)
    return out


def _bad(expr):
    expr = sp.sympify(expr)
    return expr.has(sp.nan) or expr.has(sp.zoo) or expr.has(sp.oo) or expr.has(-sp.oo)


def _solution(sid, kind, expr, free, conditions, d=1, cert=None, constants=None, extra=None):
    expr = sp.sympify(expr)
    out = {"id": sid, "kind": kind, "d": d, "expr": str(expr), "latex": sp.latex(expr),
           "constants": constants or {}, "free": [str(f) for f in free], "conditions": list(conditions),
           "poles_per_period": 0, "pole_orders": [],
           "certificate": cert or {"type": "substitution", "method": "symbolic", "status": "not-run",
                                   "detail": ""},
           "origin": "live:entire", "citations": []}
    if extra:
        out.update(extra)
    return out


def _verify_coeffs(coeffs, psubs, punsolved, params, lcs=None):
    """all coefficients vanish after the parameter substitution, modulo unsolved conditions (pseudo-remainder;
    the leading coefficients used are appended to `lcs`: they must not vanish)"""
    for co in coeffs:
        co = _numer(co.subs(psubs)) if psubs else _numer(co)
        if co == 0:
            continue
        ok = False
        for g in punsolved:
            for p in params:
                try:
                    if g.has(p) and sp.degree(g, p) >= 1:
                        r = sp.prem(co, g, p)
                        if sp.expand(r) == 0:
                            ok = True
                            if lcs is not None:
                                lc = sp.Poly(g, p).LC()
                                if not sp.sympify(lc).is_number:
                                    lcs.append(lc)
                            break
                except Exception:
                    pass
            if ok:
                break
        if not ok:
            return False, str(co)
    return True, ""


def _E_on_s(D, cvals, lam):
    """E[w] for w = sum_i cvals[i] s^i, s = exp(lam z): list of coefficients of s^k"""
    N = len(cvals) - 1
    wj = [sp.Add(*[cvals[i] * (i * lam) ** j * _S ** i for i in range(N + 1)]) if j > 0
          else sp.Add(*[cvals[i] * _S ** i for i in range(N + 1)]) for j in range(D.K + 1)]
    Es = sp.expand(sp.Add(*[co * sp.Mul(*[wj[j] ** e for j, e in enumerate(m)]) for m, co in D.terms.items()]))
    if Es == 0:
        return []
    return sp.Poly(Es, _S).all_coeffs()


def _E_on_poly(D, cvals):
    w = sp.Add(*[cvals[k] * z ** k for k in range(len(cvals))])
    wj = [sp.diff(w, z, j) for j in range(D.K + 1)]
    Ez = sp.expand(sp.Add(*[co * sp.Mul(*[wj[j] ** e for j, e in enumerate(m)]) for m, co in D.terms.items()]))
    if Ez == 0:
        return []
    return sp.Poly(Ez, z).all_coeffs()


def _conditions_display(r):
    """conditions in the form `name == value` (the parameter substitutions used by the check), then the
    conditions kept as polynomials (`poly == 0`), then `expr != 0`"""
    out = []
    for p_, v in r["psubs"].items():
        out.append("%s == %s" % (p_, v))
    for g in r["punsolved"]:
        out.append(_eqz(g))
    for g in r["pne"]:
        x = _ne(g)
        if x and x not in out:
            out.append(x)
    return out


def _conditions_polynomial(r):
    """the same equalities as polynomials in the parameters (for display)"""
    return [_eqz(g) for g in r["pconds"]]


# ----------------------------------------------------------------------------------------------
# polynomial solutions (Lemma P)
# ----------------------------------------------------------------------------------------------

def _poly_degree_bound(D, st):
    n = st["n"]
    top = st["top"]
    s_min = min(_s_of(m) for m in top)
    T = dict((m, c) for m, c in top.items() if _s_of(m) == s_min)
    QT = sp.expand(sum(c * sp.Mul(*[_ff(_M, j) ** e for j, e in enumerate(m)]) for m, c in T.items()))
    QT = _simp(QT)
    ratios = [sp.Rational(s_min - _s_of(m), n - _deg(m)) for m in D.terms if _deg(m) < n]
    mstar = max(ratios) if ratios else None
    floor_mstar = int(math.floor(mstar)) if mstar is not None else 0
    info = {"s_min": s_min, "T": [str(sp.Mul(*[D.w[j] ** e for j, e in enumerate(m)])) for m in T],
            "Q_T": _disp(sp.factor(QT), D.params), "m_star": str(mstar) if mstar is not None else None}
    if _is_zero(QT):
        info["derived"] = False
        info["note"] = "Q_T vanishes identically: no degree bound from Lemma P"
        return None, info
    num = _numer(QT)
    int_roots, param_roots, param_factors = [], [], []
    for g in _factor_list(num)[1]:
        if not g.has(_M):
            continue
        gp = sp.Poly(g, _M)
        if gp.degree() == 1:
            r = _simp(-gp.all_coeffs()[1] / gp.all_coeffs()[0])
            if r.is_number:
                if r.is_integer and r > 0:
                    int_roots.append(int(r))
            else:
                param_roots.append(r)
        elif not all(x.is_number for x in gp.all_coeffs()):
            param_factors.append(g)
    M = max([floor_mstar] + int_roots + [0])
    info.update({"derived": True, "bound": M, "positive_integer_roots": int_roots,
                 "parameter_dependent_roots": [str(r) for r in param_roots],
                 "parameter_dependent_factors": [str(g) for g in param_factors]})
    coefT = [c for c in T.values() if not c.is_number]
    if coefT:
        info["assumes"] = [x for x in (_ne(c) for c in coefT) if x]
    return M, info


def _poly_solutions(D, st, budget, sol_id, max_conds, deg_search):
    M, info = _poly_degree_bound(D, st)
    label = "certificate" if M is not None else "search"
    Mrun = M if M is not None else deg_search
    sols, systems, notes = [], [], []
    done = 0
    for m in range(1, Mrun + 1):
        if budget.over():
            notes.append("time budget exhausted before degree %d" % m)
            break
        cs = sp.symbols("_p0:%d" % (m + 1))
        eqs = _E_on_poly(D, list(cs))
        solver = _Solver(list(cs), [cs[m]], D.params, budget, max_conds=max_conds)
        res = solver.solve(eqs)
        systems.append({"degree": m, "unknowns": [str(c) for c in cs], "equations": len(eqs),
                        "branches": len(res), "incomplete": solver.incomplete,
                        "conditions_truncated": solver.truncated_conditions})
        if solver.incomplete:
            notes.append("degree %d: %s" % (m, "; ".join(solver.incomplete)))
        done = m
        for r in res:
            try:
                sol = _poly_solution_object(D, cs, r, sol_id)
            except Exception as exc:
                notes.append("a branch of degree %d was not converted (%s)" % (m, type(exc).__name__))
                systems[-1]["incomplete"] = list(systems[-1]["incomplete"]) + ["conversion failed"]
                sol = None
            if sol is not None:
                sols.append(sol)
    info["searched_up_to"] = done
    info["label"] = label
    return _dedupe(sols), info, systems, notes


def _rename_free(free, names, base="K"):
    return dict((f, names.one(base)) for f in free)


def _poly_solution_object(D, cs, r, sol_id):
    vals = [r["subs"].get(c, c) for c in cs]
    if r["psubs"]:
        vals = [_simp(v.subs(r["psubs"])) for v in vals]
    ren = _rename_free(r["free"], _Names(D.reserved))
    vals = [v.subs(ren) for v in vals]
    expr = sp.Add(*[vals[k] * z ** k for k in range(len(vals))])
    expr = sp.collect(sp.expand(expr), z)
    if not expr.has(z) or _bad(expr):
        return None
    lcs = []
    ok, bad = _verify_coeffs(_E_on_poly(D, vals), r["psubs"], r["punsolved"], D.params, lcs)
    detail = "E[w] expanded in powers of z: all coefficients vanish"
    if r["psubs"]:
        detail += " after %s" % ", ".join("%s = %s" % (k, v) for k, v in r["psubs"].items())
    if r["punsolved"]:
        detail += " modulo %s" % ", ".join(str(g) for g in r["punsolved"])
    cert = {"type": "substitution", "method": "symbolic", "status": "pass" if ok else "fail",
            "detail": detail if ok else "nonzero coefficient: " + bad}
    return _solution(sol_id(), "polynomial", expr, [ren[f] for f in r["free"]],
                     _denominator_conditions(expr, D.params, _conditions_display(r) +
                                             [x for x in (_ne(l) for l in lcs) if x]),
                     cert=cert, constants=dict((str(ren[f]), "free") for f in r["free"]),
                     extra={"parameter_values": dict((str(k), str(v)) for k, v in r["psubs"].items()),
                            "conditions_polynomial": _conditions_polynomial(r)})


# ----------------------------------------------------------------------------------------------
# exponential sums  c0 + sum c_i exp(i lambda z)   (Lemma X)
# ----------------------------------------------------------------------------------------------

def _E_on_laurent(D, cvals, lo, lam):
    """E[w] for w = sum_k cvals[k - lo] s^k (k = lo..hi), s = exp(lam z), multiplied by s^(-n lo):
    list of coefficients of a polynomial in s"""
    hi = lo + len(cvals) - 1
    ks = range(lo, hi + 1)
    wj = []
    for j in range(D.K + 1):
        wj.append(sp.Add(*[cvals[k - lo] * ((k * lam) ** j if j > 0 else 1) * _S ** (k - lo) for k in ks]))
    n = max(_deg(m) for m in D.terms)
    # w = s^lo * (polynomial in s); monomial of degree d gets s^(d lo); multiply by s^(-n lo)
    Es = sp.expand(sp.Add(*[co * _S ** ((n - _deg(m)) * (-lo)) * sp.Mul(*[wj[j] ** e for j, e in enumerate(m)])
                            for m, co in D.terms.items()]))
    if Es == 0:
        return []
    return sp.Poly(Es, _S).all_coeffs()


def _exp_shapes(N_max, two_sided=True):
    """(lo, hi): one-sided c_0 + ... + c_N s^N first, then two-sided c_{-N1} s^{-N1} + ... + c_{N2} s^{N2}"""
    shapes = [(0, N) for N in range(1, N_max + 1)]
    if two_sided:
        for tot in range(2, N_max + 1):
            for N1 in range(1, tot // 2 + 1):
                shapes.append((-N1, tot - N1))
    return shapes


def _exp_solutions(D, st, budget, sol_id, max_conds, N_max, only_lambda=None, two_sided=True):
    sols, systems, notes = [], [], []
    done = []
    for lo, hi in _exp_shapes(N_max, two_sided and only_lambda is None):
        if budget.over():
            notes.append("time budget exhausted before the shape (%d, %d)" % (lo, hi))
            break
        lam = sp.Symbol("_lam")
        cs = [sp.Symbol("_c%s%d" % ("m" if k < 0 else "", abs(k))) for k in range(lo, hi + 1)]
        eqs = _E_on_laurent(D, cs, lo, lam)
        unknowns = [lam] + cs
        nonzero = [cs[-1]] + ([cs[0]] if lo < 0 else [])
        if only_lambda is not None:
            eqs = [e.subs(lam, only_lambda) for e in eqs]
            unknowns = list(cs)
        else:
            nonzero.append(lam)
        solver = _Solver(unknowns, nonzero, D.params, budget, max_conds=max_conds,
                         init_pne=[only_lambda] if only_lambda is not None else None)
        res = solver.solve(eqs)
        systems.append({"exponents": "%d..%d" % (lo, hi), "unknowns": [str(u) for u in unknowns],
                        "equations": len(eqs), "branches": len(res), "incomplete": solver.incomplete,
                        "conditions_truncated": solver.truncated_conditions})
        if solver.incomplete:
            notes.append("exponents %d..%d: %s" % (lo, hi, "; ".join(solver.incomplete)))
        else:
            done.append([lo, hi])
        for r in res:
            try:
                sol = _exp_solution_object(D, cs, lo, lam, r, sol_id, only_lambda)
            except Exception as exc:
                notes.append("a branch of %d..%d was not converted (%s)" % (lo, hi, type(exc).__name__))
                systems[-1]["incomplete"] = list(systems[-1]["incomplete"]) + ["conversion failed"]
                if [lo, hi] in done:
                    done.remove([lo, hi])
                sol = None
            if sol is not None:
                sols.append(sol)
    one = max([h for l, h in done if l == 0] + [0])
    return _dedupe(sols), {"searched_shapes": done, "searched_up_to_N": one, "N_max": N_max,
                           "label": "search"}, systems, notes


def _safe_exp(D, st, budget, sol_id, max_conds, N_max, only_lambda=None):
    try:
        return _exp_solutions(D, st, budget, sol_id, max_conds, N_max, only_lambda=only_lambda)
    except Exception as exc:
        return [], {"searched_shapes": [], "searched_up_to_N": 0, "N_max": N_max, "label": "search",
                    "error": "%s: %s" % (type(exc).__name__, str(exc)[:200])}, \
            [{"exponents": "?", "incomplete": ["search failed (%s)" % type(exc).__name__],
              "conditions_truncated": False}], ["exponential search failed (%s)" % type(exc).__name__]


def _exp_solution_object(D, cs, lo, lam, r, sol_id, only_lambda):
    subs = dict(r["subs"])
    vals = [subs.get(c, c) for c in cs]
    lv = only_lambda if only_lambda is not None else subs.get(lam, lam)
    if r["psubs"]:
        vals = [_simp(v.subs(r["psubs"])) for v in vals]
        lv = _simp(sp.sympify(lv).subs(r["psubs"]))
    if _is_zero(lv):
        return None
    hi = lo + len(cs) - 1
    support = [k for k in range(lo, hi + 1) if k != 0 and not _is_zero(vals[k - lo])]
    if not support:
        return None
    g = 0
    for k in support:
        g = math.gcd(g, abs(k))
    if g > 1:
        return None          # the same function is found with the exponents divided by g
    if lo < 0 and max(support) < -min(support):
        return None          # mirror image of a shape with lo' = -hi (lambda -> -lambda)
    if lo < 0 and max(support) == -min(support) and lv.is_number and str(lv) > str(-lv):
        return None          # symmetric support: lambda and -lambda give the same family
    free = list(r["free"])
    names = _Names(D.reserved)
    lam_name = names.one("lamda", numbered=False)
    ren = _rename_free([f for f in free if f != lam], names)
    if lam in free:
        ren[lam] = lam_name
    vals = [v.subs(ren) for v in vals]
    lv = sp.sympify(lv).subs(ren)
    lcs = []
    ok, bad = _verify_coeffs(_E_on_laurent(D, vals, lo, lv), r["psubs"], r["punsolved"], D.params, lcs)
    expr = sp.Add(*[vals[k - lo] * (sp.exp(k * lv * z) if k != 0 else 1) for k in range(lo, hi + 1)])
    if _bad(expr) or _bad(lv):
        return None
    detail = "E[w] written as a Laurent polynomial in s = exp(%s*z) (d/dz = %s*s*d/ds): all coefficients vanish" \
             % (lv, lv)
    if r["psubs"]:
        detail += " after %s" % ", ".join("%s = %s" % (k, v) for k, v in r["psubs"].items())
    if r["punsolved"]:
        detail += " modulo %s" % ", ".join(str(gg) for gg in r["punsolved"])
    cert = {"type": "substitution", "method": "symbolic", "status": "pass" if ok else "fail",
            "detail": detail if ok else "nonzero coefficient: " + bad}
    conds = _denominator_conditions(expr, D.params, _conditions_display(r) + [x for x in (_ne(l) for l in lcs) if x])
    for k in support:
        v = vals[k - lo]
        if v in ren.values():
            conds.append("%s != 0" % v)
    if lv in ren.values():
        conds.append("%s != 0" % lv)
    return _solution(sol_id(), "simply-periodic", expr, [ren[f] for f in free], conds, cert=cert,
                     constants=dict((str(ren[f]), "free") for f in free),
                     extra={"exponent": str(lv), "exponents": [lo, hi], "support": support,
                            "parameter_values": dict((str(k), str(v)) for k, v in r["psubs"].items()),
                            "conditions_polynomial": _conditions_polynomial(r)})


def _dedupe(sols):
    seen, out = set(), []
    for s in sols:
        key = (s["expr"], tuple(sorted(s["conditions"])))
        if key in seen:
            continue
        seen.add(key)
        out.append(s)
    return out


# ----------------------------------------------------------------------------------------------
# linear equations (classical) and homogeneous equations with a linear reduction (Lemma H)
# ----------------------------------------------------------------------------------------------

def _linear_general(D, coeffs, const, var=z, prefix="K", names=None):
    """general solution of sum_j coeffs[j] D^j y + const = 0 (constant coefficients).
    Returns (expr, free symbols, info) or None if the characteristic roots are not explicit."""
    chi = sp.expand(sum(coeffs[j] * _T ** j for j in range(len(coeffs))))
    if chi == 0:
        return None
    j0 = min(j for j in range(len(coeffs)) if not _is_zero(coeffs[j]))
    poly = sp.Poly(chi, _T)
    numeric = all(x.is_number for x in poly.all_coeffs())
    names = names if names is not None else _Names(D.reserved)
    named = {}            # symbol r_k -> its irreducible polynomial (parameter-dependent, degree >= 3)
    rts = {}
    if not numeric:
        _c, fl = sp.factor_list(chi, _T)
        kk = 1
        for g, mult in fl:
            gp = sp.Poly(g, _T)
            if gp.degree() <= 0:
                continue
            even = gp.degree() == 4 and all(gp.coeff_monomial(_T ** j) == 0 for j in (1, 3))
            if gp.degree() <= 2:
                rr = sp.roots(gp)
            elif even:
                # biquadratic: roots +-sqrt(q), q the roots of the quadratic in t**2
                q_ = sp.Symbol("_q")
                hq = sp.Poly(sp.expand(g).subs(_T ** 2, q_), q_)
                rr = {}
                for qv, mq in sp.roots(hq).items():
                    for sg in (1, -1):
                        rv = sg * sp.sqrt(qv)
                        rr[rv] = rr.get(rv, 0) + mq
            else:
                rr = {}
                for i in range(gp.degree()):
                    rsym = names.one("r")
                    kk += 1
                    named[rsym] = g
                    rr[rsym] = 1
            for x, m in rr.items():
                rts[x] = rts.get(x, 0) + m * mult
    else:
        try:
            rts = sp.roots(poly)
        except Exception:
            rts = {}
    if sum(rts.values()) != poly.degree():
        if numeric:
            rts = {}
            for g, k in sp.factor_list(chi)[1]:
                gp = sp.Poly(g, _T)
                rr = sp.roots(gp)
                if sum(rr.values()) != gp.degree():
                    rr = dict((sp.CRootOf(gp, i), 1) for i in range(gp.degree()))
                for x, mlt in rr.items():
                    rts[x] = rts.get(x, 0) + mlt * k
        else:
            return None
    free, terms, k = [], [], 1
    for r0, mult in rts.items():
        for i in range(mult):
            C = names.one(prefix)
            k += 1
            free.append(C)
            terms.append(C * var ** i * sp.exp(r0 * var))
    part = sp.Integer(0)
    if not _is_zero(const):
        # particular solution  -const * z^j0 / (a_j0 j0!)
        part = -const * var ** j0 / (coeffs[j0] * sp.factorial(j0))
    expr = part + sp.Add(*terms)
    conds = []
    for e in (poly.LC(), coeffs[j0]):
        if not sp.sympify(e).is_number:
            x = _ne(e)
            if x and x not in conds:
                conds.append(x)
    rl = list(rts.keys())
    for i in range(len(rl)):
        for j in range(i + 1, len(rl)):
            if rl[i] in named or rl[j] in named:
                continue
            dif = _simp(rl[i] - rl[j])
            if not dif.is_number:
                x = _ne(dif) if not dif.has(sp.sqrt(2) * 0 + sp.I) else None
                if x and x not in conds:
                    conds.append(x)
    if named:
        conds.append("the roots %s of %s are distinct" % (", ".join(str(r) for r in named),
                                                          " * ".join(sorted(set(_disp(g, D.params) for g in named.values())))))
    return expr, free, {"characteristic_polynomial": _disp(chi, D.params), "conditions": conds,
                        "named_roots": dict((str(r), _disp(g, D.params)) for r, g in named.items()), "_named": named,
                        "roots": dict((str(r0), m) for r0, m in rts.items())}


def _verify_linear(D, expr, named):
    """E[expr] == 0, reducing modulo the polynomials of the named roots"""
    res = sp.expand(D.E.subs(dict((D.w[j], sp.diff(expr, z, j)) for j in range(D.K + 1))))
    if not named:
        return _is_zero(sp.simplify(res))
    # coefficients of the exponentials exp(r z), then reduce each modulo the polynomial of r
    xs = {}
    for r in named:
        X = sp.Symbol("X_" + str(r))
        xs[r] = X
        res = res.subs(sp.exp(r * z), X)
    res = sp.expand(sp.powsimp(res))
    for r, X in xs.items():
        res = res.subs(sp.exp(z * r), X)
    try:
        P = sp.Poly(res, *xs.values())
    except Exception:
        return False
    for mon, co in P.terms():
        co = _numer(co)
        if co == 0:
            continue
        rs = [r for r in named if co.has(r)]
        if not rs:
            if not _is_zero(sp.simplify(co)):
                return False
            continue
        for r in rs:
            co = sp.rem(co, sp.Poly(named[r].subs(_T, r), r).as_expr(), r)
        if not _is_zero(sp.expand(co)):
            return False
    return True


def _homogeneous_reduction(D):
    """If every monomial has the same degree n: E = w^n R(u, u', ...), u = w'/w.  Returns R."""
    degs = set(_deg(m) for m in D.terms)
    if len(degs) != 1:
        return None
    K = D.K
    u = sp.symbols("u0:%d" % (K + 1))
    B = [sp.Integer(1)]
    for j in range(K):
        prev = B[-1]
        d = sum(sp.diff(prev, u[i]) * u[i + 1] for i in range(K))
        B.append(sp.expand(u[0] * prev + d))
    R = sp.expand(sum(c * sp.Mul(*[B[j] ** e for j, e in enumerate(m)]) for m, c in D.terms.items()))
    return R, u


# ----------------------------------------------------------------------------------------------
# main entry
# ----------------------------------------------------------------------------------------------

def _jsonable(x):
    if isinstance(x, dict):
        return dict((str(k), _jsonable(v)) for k, v in x.items() if not str(k).startswith("_"))
    if isinstance(x, (list, tuple)):
        return [_jsonable(v) for v in x]
    if isinstance(x, (str, bool, int, float)) or x is None:
        return x
    return str(x)


def entire_solutions(eq, budget_s=30, N_max=4, deg_search=6, max_conds=3, strata_depth=1):
    """Entire solutions of E = 0: constants, polynomials, exponential sums, completeness.

    eq        : an Equation (CORE or bootstrap), a SymPy expression or a string in the jets w0, w1, ...
    budget_s  : time budget in seconds (time.monotonic(); a single SymPy call is not interrupted)
    N_max     : exponential sums sum_{k=-N1..N2} c_k exp(k lamda z) are searched for N1 + N2 <= N_max
    deg_search: polynomial degree searched when no degree bound is derived
    max_conds : parameter conditions per branch of the polynomial systems
    strata_depth: depth of the recursion into parameter values where the leading data degenerate
    Returns a JSON-ready dict (see the module docstring and lemmas/entire/project note)."""
    out = _jsonable(_entire(eq, budget_s, N_max, deg_search, max_conds, strata_depth))
    _final_check(_as_data(eq), out)
    return out


def _final_check(D, out):
    """Re-check every listed Solution from its strings alone: parse `expr`, substitute `constants` (other
    than "free"), apply the conditions `name == value` in order, substitute into E, simplify.  A Solution
    with a condition that is not of that form goes to `implicit`; one that does not reduce to 0 goes to
    certificate.rejected.  Also: no free symbol may coincide with a symbol of the equation."""
    reserved = set(str(p) for p in D.params) | set(str(x) for x in D.w) | {"z"}
    rej = out["certificate"].setdefault("rejected", [])
    for key in ("constants", "polynomials", "exponentials"):
        keep = []
        for sol in out[key]:
            verdict = _check_strings(D, sol, reserved)
            if verdict == "pass":
                keep.append(sol)
            elif verdict == "implicit":
                out["implicit"].append(sol)
            else:
                rej.append({"expr": sol["expr"], "conditions": sol["conditions"], "detail": "final check: " + verdict})
        out[key] = keep
    if rej:
        out["warnings"].append("%d candidate(s) failed a substitution check and are not listed" % len(rej))
        out["not_decided"].append("%d candidate solution(s) of the search failed the substitution check and were "
                                  "dropped (certificate.rejected); for the parameter values in their conditions the "
                                  "lists above may be incomplete." % len(rej))


def _check_strings(D, sol, reserved):
    import re
    if set(sol.get("free", [])) & reserved:
        return "a free symbol coincides with a symbol of the equation"
    loc = dict((str(p), p) for p in D.params)
    for f in sol.get("free", []):
        loc[f] = sp.Symbol(f)
    loc["z"] = z
    try:
        expr = sp.sympify(sol["expr"], locals=loc)
        for name, val in (sol.get("constants") or {}).items():
            if val == "free":
                continue
            if str(val).startswith("root of"):
                return "implicit"
            expr = expr.subs(sp.Symbol(name), sp.sympify(val, locals=loc))
        subs = []
        for c in sol.get("conditions", []):
            if "!=" in c or "distinct" in c:
                continue
            lhs, rhs = [x.strip() for x in c.split("==")]
            if not re.match(r"^[A-Za-z_][A-Za-z_0-9]*$", lhs):
                return "implicit"
            subs.append((loc.get(lhs, sp.Symbol(lhs)), sp.sympify(rhs, locals=loc)))
        E = D.E
        for a_, b_ in subs:
            expr = expr.subs(a_, b_)
            E = E.subs(a_, b_)
        res = E.subs(dict((D.w[j], sp.diff(expr, z, j)) for j in range(D.K + 1)))
        if sp.count_ops(res) <= 400:
            res = sp.expand(res)
            if res == 0:
                sol["certificate"]["string_check"] = "exact"
                return "pass"
            res = sp.expand(sp.powsimp(res))
            if res == 0 or sp.simplify(res) == 0:
                sol["certificate"]["string_check"] = "exact"
                return "pass"
            return "residual does not simplify to 0"
        # large residual: the exact certificate is the internal one (status pass); here only the string form
        # is checked, at random rational points with 60 digits
        return _numeric_spot_check(res, sol)
    except Exception as exc:
        return "not parsed (%s)" % type(exc).__name__


def _numeric_spot_check(res, sol, points=3):
    import random
    rnd = random.Random(20261006)
    syms = sorted(res.free_symbols - {z}, key=str)
    worst = 0
    for _ in range(points):
        vals = dict((x, sp.Rational(rnd.randint(-97, 97) or 1, rnd.randint(1, 13))) for x in syms)
        vals[z] = sp.Rational(rnd.randint(-30, 30), 17)
        try:
            v = sp.N(res.subs(vals), 60)
            scale = 1 + max([abs(sp.N(t.subs(vals), 30)) for t in sp.Add.make_args(sp.expand(res, deep=False))][:50])
        except Exception:
            return "numeric spot check failed to evaluate"
        if v.has(sp.zoo, sp.nan):
            continue
        worst = max(worst, abs(v) / scale)
    if worst < sp.Float("1e-40"):
        sol["certificate"]["string_check"] = "numeric spot check of the string form (60 digits, %d points)" % points
        return "pass"
    return "numeric spot check of the string form failed"


def _entire(eq, budget_s=30, N_max=4, deg_search=6, max_conds=3, strata_depth=1, _depth=0, _ids=None):
    budget = _Budget(budget_s)
    D = _as_data(eq)
    counter = _ids if _ids is not None else [0]

    def sol_id():
        counter[0] += 1
        return "e%d" % counter[0]

    out = {"schema": "mero-entire/1", "engine": ENGINE_TAG, "equation": str(D.E), "params": [str(p) for p in D.params],
           "constants": [], "polynomials": [], "exponentials": [], "linear": None, "homogeneous": None,
           "complete": False, "complete_conditions": [], "basis": [], "growth": {}, "ruled_out": [],
           "not_decided": [], "strata": [], "implicit": [], "certificate": {}, "warnings": []}
    if not D.terms:
        out["warnings"].append("E is identically zero")
        return out
    st = _structure(D)
    n = st["n"]
    cert = out["certificate"]
    cert["degree_n"] = n
    cert["tau"] = _disp(sp.factor(st["tau"]), D.params) if st["tau"] != 0 else "0"
    cert["s_lo"], cert["s_hi"] = st["s_lo"], st["s_hi"]
    cert["b_lo"], cert["b_hi"] = str(st["b_lo"]), str(st["b_hi"])
    cert["top_part"] = str(sp.Add(*[c * sp.Mul(*[D.w[j] ** e for j, e in enumerate(m)]) for m, c in st["top"].items()]))
    cert["top_kind"] = st["kind"]

    # (i) constants
    out["constants"], cert["constants"] = _constants(D, sol_id)

    # linear equations: the general solution (classical)
    if n == 1:
        coeffs = [D.terms.get(tuple(1 if i == j else 0 for i in range(D.K + 1)), sp.Integer(0))
                  for j in range(D.K + 1)]
        const = D.terms.get((0,) * (D.K + 1), sp.Integer(0))
        g = _linear_general(D, coeffs, const)
        if g is not None:
            expr, free, info = g
            ok = _verify_linear(D, expr, info.get("_named", {}))
            lkind = "entire" if expr.has(sp.exp) else ("polynomial" if expr.has(z) else "constant")
            sol = _solution(sol_id(), lkind, expr, free, _denominator_conditions(expr, D.params, info["conditions"]),
                            d=None, constants=dict([(str(f), "free") for f in free] +
                                                   [(r, "root of " + gg) for r, gg in info.get("named_roots", {}).items()]),
                            cert={"type": "substitution", "method": "symbolic", "status": "pass" if ok else "not-run",
                                  "detail": "general solution of a linear equation with constant coefficients"
                                            + ("; residual simplifies to 0" if ok else "")})
            out["linear"] = {"general_solution": sol, "info": info}
            if info.get("_named"):
                out["implicit"].append(sol)       # roots of chi not explicit: not a checkable Solution
            elif lkind != "constant" or not any(c["free"] for c in out["constants"]):
                out["exponentials" if lkind == "entire" else
                    ("polynomials" if lkind == "polynomial" else "constants")].append(sol)
            out["complete"] = True
            out["basis"] = ["L-LINEAR"]
            cert["linear"] = info
            out["ruled_out"].append({"what": "solutions other than the general solution",
                                     "basis": {"theorem": "L-LINEAR", "label": "certificate"}})
            nz = [c for c in coeffs if not c.is_number]
            if nz:
                out["complete_conditions"] = ["characteristic roots as computed (generic parameters)"]
        else:
            out["not_decided"].append("Linear equation: the characteristic roots are not explicit for symbolic "
                                      "parameters; the general solution is sum P_i(z) exp(lambda_i z) over the roots "
                                      "of %s." % _disp(sp.factor(sum(coeffs[j] * _T ** j for j in range(D.K + 1))), D.params))
        out["elapsed_s"] = round(time.monotonic() - budget.t0, 3)
        return out

    # homogeneous in the jets with a linear reduction: Lemma H
    hom = _homogeneous_reduction(D)
    hom_done = False
    if hom is not None:
        R, u = hom
        if R != 0 and sp.Poly(R, *u).total_degree() <= 1:
            Kr = max([j for j in range(D.K + 1) if R.has(u[j])] + [0])
            coeffs = [R.coeff(u[j], 1) for j in range(Kr + 1)]
            const = _simp(R - sum(coeffs[j] * u[j] for j in range(Kr + 1)))
            if all(c.is_number or not (c.free_symbols & set(u)) for c in coeffs):
                hnames = _Names(D.reserved)
                C0 = hnames.one("K")
                g = _linear_general(D, coeffs, const, prefix="K", names=hnames)
                if g is not None:
                    uexpr, ufree, info = g
                    if len(ufree) == 1 and uexpr == ufree[0]:
                        lam_name = hnames.one("lamda", numbered=False)
                        uexpr, ufree = lam_name, [lam_name]
                    Iu = sp.integrate(uexpr, z, conds="none")
                    wexpr = C0 * sp.exp(Iu)
                    res = sp.simplify(D.E.subs(dict((D.w[j], sp.diff(wexpr, z, j)) for j in range(D.K + 1)))
                                      / sp.exp(n * Iu))
                    ok = _is_zero(res) and not wexpr.has(sp.Piecewise)
                    kind = "simply-periodic" if not uexpr.has(z) else "entire"
                    sol = _solution(sol_id(), kind, wexpr, [C0] + ufree,
                                    _denominator_conditions(wexpr, D.params, info.get("conditions", []) + ["%s != 0" % C0]),
                                    d=1 if not (uexpr.free_symbols & {z}) and not uexpr.has(sp.exp) else None,
                                    constants=dict([(str(f), "free") for f in [C0] + ufree] +
                                                   [(r, "root of " + gg) for r, gg in info.get("named_roots", {}).items()]),
                                    cert={"type": "substitution", "method": "symbolic",
                                          "status": "pass" if ok else "not-run",
                                          "detail": "E[w] = w^%d R[u], u = w'/w = %s solves the linear equation R = %s = 0"
                                                    % (n, uexpr, R)})
                    out["homogeneous"] = {"reduced": str(R), "u": str(uexpr), "general_solution": sol}
                    if info.get("_named"):
                        out["implicit"].append(sol)
                    else:
                        out["exponentials"].append(sol)
                    out["complete"] = True
                    out["basis"] = ["L-HOMLIN"]
                    out["ruled_out"].append({"what": "meromorphic solutions other than w = 0 and w = %s*exp(int u)" % C0,
                                             "basis": {"theorem": "L-HOMLIN (lemmas/entire/project note, Lemma H)",
                                                       "label": "agent-proof"}})
                    cert["homogeneous_reduction"] = {"R": str(R), "u_general": str(uexpr), "info": info}
                    hom_done = True
                    # cross-check: the exponential-sum search on its own
                    eb = budget.sub(0.5)
                    ex, einfo, esys, enotes = _safe_exp(D, _structure(D), eb, lambda: "x", max_conds, min(N_max, 2))
                    cert["exponential_search_crosscheck"] = {"found": [x["expr"] for x in ex],
                                                             "free": [x["free"] for x in ex], "info": einfo}

    # growth: Wiman-Valiron (T-WV)
    growth = {"theorem": "T-WV", "tau": cert["tau"]}
    roots = _nonzero_roots_tau(st["tau"]) if st["tau"] != 0 else None
    hi_ok = not _is_zero(st["b_hi"])
    lo_ok = not _is_zero(st["b_lo"])
    wv_conditions = []
    for bb in (st["b_hi"], st["b_lo"]):
        if not _is_zero(bb) and not bb.is_number:
            wv_conditions.append(_ne(bb))
    if hi_ok and lo_ok and st["s_lo"] == st["s_hi"]:
        growth["conclusion"] = "no transcendental entire solution"
        growth["applies"] = True
    elif hi_ok and lo_ok:
        growth["conclusion"] = "every transcendental entire solution has order 1; log M(r,w)/r has its limit points " \
                               "between the smallest and the largest modulus of the nonzero roots of tau"
        growth["nonzero_roots"] = [str(r) for r in roots] if roots is not None else "not explicit"
        growth["applies"] = True
    elif hi_ok:
        growth["conclusion"] = "every transcendental entire solution has order at most 1 and finite type " \
                               "(type at most the largest modulus of a root of tau)"
        growth["applies"] = True
    else:
        growth["conclusion"] = "no information (the monomials of the top degree with the most derivatives cancel in tau)"
        growth["applies"] = False
    growth["conditions"] = list(dict.fromkeys(x for x in wv_conditions if x))
    # the registry entry T-WV covers exactly one monomial of top degree; the rest is L-ENTIRE-WV (project note section 2)
    growth["theorem"] = "T-WV" if (len(st["top"]) == 1 and growth["conclusion"] == "no transcendental entire solution") \
        else "L-ENTIRE-WV"
    out["growth"] = growth

    # Clunie (T-CLUNIE)
    trans_excluded = False
    clunie_family = None
    cl_conditions = []
    if st["kind"] in ("pure-power", "first-order-factor"):
        if not st["c"].is_number:
            cl_conditions.append(_ne(st["c"]))
        if st["kind"] == "pure-power":
            trans_excluded = True
        else:
            rho = st["rho"]
            if _is_zero(rho):
                trans_excluded = True
            else:
                clunie_family = rho
                if not rho.is_number:
                    cl_conditions.append(_ne(rho))
    if growth.get("conclusion") == "no transcendental entire solution":
        trans_excluded = True
    cl_conditions = [x for x in cl_conditions if x]

    # (ii) polynomials
    pb = budget.sub(0.4)
    try:
        polys, pinfo, psys, pnotes = _poly_solutions(D, st, pb, sol_id, max_conds, deg_search)
    except Exception as exc:
        polys, pinfo, psys = [], {"derived": False, "error": "%s: %s" % (type(exc).__name__, str(exc)[:200])}, []
        pnotes = ["polynomial search failed (%s)" % type(exc).__name__]
    out["polynomials"] = polys
    cert["polynomial_degree_bound"] = pinfo
    cert["polynomial_systems"] = psys
    poly_complete = pinfo.get("derived", False) and pinfo.get("searched_up_to", -1) >= pinfo.get("bound", 0) \
        and not any(s["incomplete"] or s["conditions_truncated"] for s in psys)
    if pnotes:
        out["warnings"].extend(pnotes)

    # (iii) exponential sums
    if not hom_done:
        if trans_excluded:
            cert["exponential_search"] = {"skipped": "no transcendental entire solution (theorem)"}
        elif clunie_family is not None:
            eb = budget.sub(0.6)
            ex, einfo, esys, enotes = _safe_exp(D, st, eb, sol_id, max_conds, 1, only_lambda=clunie_family)
            einfo["label"] = "certificate"
            einfo["note"] = "T-CLUNIE: every transcendental entire solution is C*exp(rho*z) + c0 with rho = %s" % clunie_family
            out["exponentials"] = ex
            cert["exponential_search"] = einfo
            cert["exponential_systems"] = esys
            out["warnings"].extend(enotes)
        elif st["tau"] != 0 and roots == []:
            cert["exponential_search"] = {"skipped": "tau has no nonzero root: no exponential sum (Lemma X)"}
        else:
            eb = budget.sub(0.8)
            ex, einfo, esys, enotes = _safe_exp(D, st, eb, sol_id, max_conds, N_max)
            out["exponentials"] = ex
            cert["exponential_search"] = einfo
            cert["exponential_systems"] = esys
            out["warnings"].extend(enotes)

    # completeness
    if hom_done:
        pass
    elif trans_excluded or clunie_family is not None:
        exp_ok = True
        if clunie_family is not None:
            esys = cert.get("exponential_systems", [])
            exp_ok = bool(esys) and not any(s["incomplete"] or s["conditions_truncated"] for s in esys)
        if poly_complete and exp_ok:
            out["complete"] = True
            if st["kind"] == "pure-power":
                out["basis"].append("T-CLUNIE")
            elif st["kind"] == "first-order-factor":
                out["basis"].append("L-ENTIRE-FACTOR")
            if growth.get("conclusion") == "no transcendental entire solution":
                out["basis"].append(growth["theorem"])
            out["complete_conditions"] = sorted(set(x for x in cl_conditions + (wv_conditions if growth["theorem"] in
                                                                                out["basis"] else [])
                                                    + pinfo.get("assumes", []) if x))
        if st["kind"] in ("pure-power", "first-order-factor"):
            what_m = "transcendental meromorphic solutions with finitely many poles" if trans_excluded else \
                "transcendental meromorphic solutions with finitely many poles other than C*exp(%s*z) + c0" % clunie_family
            # T-CLUNIE: Clunie's lemma plus one line (registry, published); L-ENTIRE-FACTOR: project note section 3(b)
            if st["kind"] == "pure-power":
                out["ruled_out"].append({"what": what_m, "basis": {"theorem": "T-CLUNIE", "label": "published"},
                                         "conditions": cl_conditions})
            else:
                out["ruled_out"].append({"what": what_m, "basis": {"theorem": "L-ENTIRE-FACTOR", "label": "agent-proof",
                                         "source": "lemmas/entire/project note, section 3(b)"},
                                         "conditions": cl_conditions})
        if growth.get("conclusion") == "no transcendental entire solution":
            out["ruled_out"].append({"what": "transcendental entire solutions",
                                     "basis": {"theorem": growth["theorem"],
                                               "label": "published" if growth["theorem"] == "T-WV" else "agent-proof"},
                                     "conditions": growth["conditions"]})
        if not poly_complete:
            out["not_decided"].append(_poly_not_decided(pinfo))
    else:
        g = growth["conclusion"]
        sent = "Transcendental entire solutions other than those listed are not decided."
        if growth["applies"]:
            if "order 1;" in g:
                mods = None
                if roots and all(sp.sympify(x).is_number for x in roots):
                    try:
                        mods = sorted(set(sp.nsimplify(sp.Abs(sp.sympify(x))) for x in roots), key=lambda v: float(v))
                    except Exception:
                        mods = None
                if mods and len(mods) == 1:
                    sent += " Any such solution has order 1 and type %s, the modulus of the nonzero roots of " \
                            "tau(t) = %s (%s)." % (mods[0], cert["tau"], growth["theorem"])
                elif mods:
                    sent += " Any such solution has order 1, and log M(r,w)/r has its limit points between %s and %s, " \
                            "the smallest and the largest modulus of the nonzero roots of tau(t) = %s (%s)." \
                            % (mods[0], mods[-1], cert["tau"], growth["theorem"])
                else:
                    sent += " Any such solution has order 1, and log M(r,w)/r has its limit points between the " \
                            "smallest and the largest modulus of the nonzero roots of tau(t) = %s (%s)." \
                            % (cert["tau"], growth["theorem"])
            else:
                sent += " Any such solution has order at most 1 and finite type (%s)." % growth["theorem"]
        else:
            sent += " The Wiman-Valiron argument gives no information here: the monomials of degree %d with the " \
                    "most derivatives cancel in tau(t) = %s." % (n, cert["tau"])
        out["not_decided"].append(sent)
        if cert.get("exponential_search", {}).get("searched_shapes"):
            sh = cert["exponential_search"]["searched_shapes"]
            allsh = [x["exponents"] for x in cert.get("exponential_systems", [])]
            missing = [x for x in _exp_shapes(cert["exponential_search"]["N_max"])
                       if [x[0], x[1]] not in sh]
            out["not_decided"].append("Sums of c_k*exp(k*lamda*z) over k = -N1..N2 with constant coefficients were "
                                      "searched completely for the shapes (-N1, N2) in %s (search); %s"
                                      "sums with exponents outside one arithmetic progression, or with polynomial "
                                      "coefficients, were not searched."
                                      % ([(-l, h) for l, h in sh],
                                         ("the shapes %s were not completed (time budget); " % [(-l, h) for l, h in missing])
                                         if missing else ""))
        if not poly_complete:
            out["not_decided"].append(_poly_not_decided(pinfo))
    if pinfo.get("parameter_dependent_roots") or pinfo.get("parameter_dependent_factors"):
        out["not_decided"].append("Polynomial solutions of degree m > %s can exist only for parameter values at which "
                                  "Q_T(m) = %s has the positive integer root m; these values are not searched."
                                  % (pinfo.get("bound"), pinfo.get("Q_T")))
        if out["complete"]:
            out["complete_conditions"].append("Q_T(m) = %s has no positive integer root m > %s"
                                              % (pinfo.get("Q_T"), pinfo.get("bound")))

    # strata: parameter values at which the leading data degenerate
    if _depth < strata_depth and D.params and not budget.over():
        crit = list(st["top"].values()) + [st["b_lo"], st["b_hi"]]
        if st["c"] is not None:
            crit.append(st["c"])
        if st["rho"] is not None:
            crit.append(st["rho"])
        crit.append(sp.Poly(cert["constants"]["_poly"], _CV).LC()
                    if not cert["constants"].get("all_constants") else sp.Integer(1))
        facs = _maybe_vanishing_param_factors(crit, D.params)
        for g in facs[:4]:
            if budget.left() < 0.5:
                out["warnings"].append("strata not explored: time budget")
                break
            ps = [p for p in D.params if g.has(p) and sp.degree(g, p) == 1]
            if not ps:
                continue
            p = sorted(ps, key=lambda q: (not sp.expand(g).coeff(q, 1).is_number, str(q)))[0]
            a = sp.expand(g).coeff(p, 1)
            val = _simp(-(sp.expand(g) - a * p) / a)
            terms2 = dict((m, _simp(c.subs(p, val))) for m, c in D.terms.items())
            D2 = _Data(D.K, D.w, [q for q in D.params if q != p], terms2, reserved=D.reserved)
            try:
                sub = _entire(D2, budget_s=max(0.5, budget.left() / (len(facs) + 1)), N_max=N_max,
                              deg_search=deg_search, max_conds=max_conds, strata_depth=strata_depth,
                              _depth=_depth + 1, _ids=counter)
            except Exception as exc:
                out["warnings"].append("stratum %s not analysed (%s)" % (_eqz(g), type(exc).__name__))
                continue
            cond = "%s == %s" % (p, val)          # the stratum, in the form name == value
            extra_ne = [] if a.is_number else [x for x in [_ne(a)] if x]
            for key in ("constants", "polynomials", "exponentials", "implicit"):
                generic = [(x["expr"], set(x["conditions"])) for x in out[key]]
                for s in sub[key]:
                    if any(e == s["expr"] and cs <= set(s["conditions"]) for e, cs in generic):
                        continue
                    s = dict(s)
                    s["conditions"] = [cond] + extra_ne + list(s["conditions"])
                    s["conditions_polynomial"] = [_eqz(g)] + list(s.get("conditions_polynomial", []))
                    s["stratum"] = cond
                    out[key].append(s)
            out["strata"].append({"conditions": [cond] + extra_ne, "substitution": {str(p): str(val)},
                                  "equation": sub["equation"], "complete": sub["complete"], "basis": sub["basis"],
                                  "constants": sub["constants"], "polynomials": sub["polynomials"],
                                  "exponentials": sub["exponentials"], "linear": sub["linear"],
                                  "not_decided": sub["not_decided"], "growth": sub["growth"]})
    _drop_failed(out)
    out["elapsed_s"] = round(time.monotonic() - budget.t0, 3)
    return out


def _drop_failed(out):
    """a Solution whose re-verification failed is never listed as found"""
    rej = out["certificate"].setdefault("rejected", [])
    for key in ("constants", "polynomials", "exponentials"):
        keep = []
        for s in out[key]:
            if s.get("certificate", {}).get("status") == "fail":
                rej.append({"expr": s["expr"], "conditions": s["conditions"], "detail": s["certificate"]["detail"]})
            else:
                keep.append(s)
        out[key] = keep
    if rej:
        out["warnings"].append("%d candidate(s) failed the substitution check and are not listed" % len(rej))


def _poly_not_decided(pinfo):
    if not pinfo.get("derived"):
        return "Polynomial solutions: no degree bound (Q_T vanishes identically); searched up to degree %s (search)." \
               % pinfo.get("searched_up_to")
    return "Polynomial solutions of degree %s..%s were not searched (time budget)." \
           % (pinfo.get("searched_up_to", 0) + 1, pinfo.get("bound"))


if __name__ == "__main__":
    import json
    r = entire_solutions("w3 - 12*w0*w1 - alpha*w2 + 6*mu*w0**2 - gamma*w1 - delta*w0 - epsilon")
    print(json.dumps(r, indent=1, default=str)[:6000])
