"""Entire solutions of an autonomous polynomial ODE  E(w0, w1, ..., wK) = 0   (worker ENTIRE, 6 Oct 2026).

    entire_solutions(eq, budget_s=30, N_max=4, deg_search=6, max_conds=3, strata_depth=1) -> dict

What it returns (JSON-ready; formulas are exact SymPy strings; Solution objects as in project note section 2):

  constants      the roots of E(c, 0, ..., 0), or the family "every constant"
  polynomials    all polynomial solutions of degree >= 1 (degree bound of lemmas/entire/project note,
                 Lemma P: label `certificate` when the bound is derived, `search` otherwise)
  exponentials   sums sum_{k=-N1..N2} c_k exp(k*lamda*z) with N1 + N2 <= N_max (label `search`;
                 Lemma X), the general solution of a linear equation, and C0*exp(int u) (Lemma H)
  linear         for a linear equation (total degree 1): the general solution (L-LINEAR)
  homogeneous    for an equation homogeneous in the jets whose reduction u = w'/w is linear (L-HOMLIN)
  complete       True only when a theorem gives: every entire solution is in the lists above, for
                 parameter values satisfying `complete_conditions`; `basis` names the theorems:
                 T-CLUNIE, T-WV (registry, used only within their registry hypotheses), L-ENTIRE-WV,
                 L-ENTIRE-FACTOR, L-HOMLIN (lemmas/entire/project note), L-LINEAR (registry),
                 L-ENTIRE-LINRED (lemmas/entire/project note: top part w0^(n-1) * (linear form of order >= 2);
                 every transcendental entire solution solves a linear equation P = 0; certificate.linear_reduction),
                 L-ENTIRE-FI (project note section 7: E = F(w0) D(P) + r F'(w0) w1 P, first integral F^r P),
                 L-ENTIRE-ROSSLER (project note section 5, Proposition R: the y-equation of the Roessler system,
                 generic parameter values)
  growth         what the Wiman-Valiron argument says about transcendental entire solutions
  ruled_out      [{"what", "basis": {"theorem", "label"}, "conditions"}]
  not_decided    ready-to-show sentences
  strata         the same analysis for the parameter values where the leading data degenerate
                 (their solutions are also merged into the lists, with the stratum condition first)
  certificate    tau(t), degree bound, systems solved, searched shapes, rejected candidates
  warnings, elapsed_s

A Solution whose re-verification by substitution fails is never listed (certificate.rejected).
Pure SymPy; the time budget is checked with time.monotonic() between steps, and the long phases run under a
watchdog (_Guard: a signal timer in the main thread, otherwise a garbage-collector callback; see
lemmas/entire/project note, "Time budget") that stops a single SymPy call at the deadline of its phase.
"""
import itertools
import math
import sys
import time

import sympy as sp

z = sp.Symbol("z")
_S = sp.Symbol("s_")          # s = exp(lambda z)
_M = sp.Symbol("_m")          # degree variable in Q_T(m)   (displayed as m)
_T = sp.Symbol("_t")          # variable of tau(t)          (displayed as t)
_CV = sp.Symbol("_cv")        # variable of E(c, 0, ..., 0)  (displayed as c)


def _disp(e, params=()):
    """string of an expression in the private variables, with the display names when free"""
    names = set(str(p) for p in params)
    rep = {}
    for priv, pub in ((_M, "m"), (_T, "t"), (_CV, "c")):
        rep[priv] = sp.Symbol(pub if pub not in names else pub + "_")
    return str(sp.sympify(e).subs(rep))

ENGINE_TAG = "entire/1"


# ----------------------------------------------------------------------------------------------
# input
# ----------------------------------------------------------------------------------------------

class _Data(object):
    """K, w (jets), params, terms {exponent tuple: coeff}, E."""

    def __init__(self, K, w, params, terms, unknown="w", var="z", reserved=None):
        self.K = int(K)
        self.w = tuple(w)
        self.params = list(params)
        self.terms = {}
        for mon, co in terms.items():
            mon = tuple(int(e) for e in mon) + (0,) * (self.K + 1 - len(mon))
            co = sp.sympify(co)
            if sp.expand(co) != 0:
                self.terms[mon] = co
        self.E = sp.Add(*[co * sp.Mul(*[self.w[j] ** e for j, e in enumerate(mon)])
                          for mon, co in self.terms.items()])
        self.unknown, self.var = unknown, var
        # names that an auxiliary symbol must never take: parameters, jets, z (and those of a parent equation)
        self.reserved = set(reserved or ()) | set(str(p) for p in self.params) | set(str(x) for x in self.w) | {"z"}
        for co in self.terms.values():
            self.reserved |= set(str(x) for x in co.free_symbols)


class _Names(object):
    """allocator of fresh symbol names (never a parameter, a jet, z, or a name already given out)"""

    def __init__(self, reserved):
        self.used = set(reserved)

    def one(self, base, numbered=True):
        if not numbered and base not in self.used:
            self.used.add(base)
            return sp.Symbol(base)
        k = 1
        while "%s%d" % (base, k) in self.used:
            k += 1
        name = "%s%d" % (base, k)
        self.used.add(name)
        return sp.Symbol(name)


def _jets(K):
    return sp.symbols("w0:%d" % (K + 1))


def from_expr(E, params=None):
    """Build the internal data from an expression (or string) in the jets w0, w1, ...; every other
    symbol except z is a parameter."""
    loc = dict(("w%d" % j, sp.Symbol("w%d" % j)) for j in range(12))
    if isinstance(E, str):
        import re
        txt = re.sub(r"\blambda\b", "lamda", E.replace("^", "**"))
        for tok in set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", txt)):
            if tok not in loc and tok not in ("exp", "sqrt", "I", "pi", "Rational"):
                loc[tok] = sp.Symbol(tok)
        E = sp.sympify(txt, locals=loc)
    jets = sorted([s for s in E.free_symbols if s.name[:1] == "w" and s.name[1:].isdigit()],
                  key=lambda s: int(s.name[1:]))
    K = max(int(s.name[1:]) for s in jets) if jets else 0
    w = _jets(K)
    if params is None:
        params = sorted([s for s in E.free_symbols if s not in w and s != z], key=lambda s: s.name)
    else:
        params = [sp.Symbol(str(p)) for p in params]
    poly = sp.Poly(sp.expand(E), *w)
    return _Data(K, w, params, dict(poly.terms()))


def _as_data(eq):
    if isinstance(eq, _Data):
        return eq
    if isinstance(eq, (str, sp.Basic)):
        return from_expr(eq)
    K = eq.K
    w = tuple(eq.w)
    params = [sp.Symbol(str(p)) for p in getattr(eq, "params", [])]
    terms = dict(eq.terms)
    # the jets of other modules may be named differently: rename to w0..wK
    std = _jets(K)
    ren = dict(zip(w, std))
    terms = dict((m, sp.sympify(c).subs(ren)) for m, c in terms.items())
    return _Data(K, std, params, terms, getattr(eq, "unknown", "w"), getattr(eq, "var", "z"))


# ----------------------------------------------------------------------------------------------
# small helpers
# ----------------------------------------------------------------------------------------------

def _ff(x, j):
    r = sp.Integer(1)
    for i in range(j):
        r *= (x - i)
    return r


def _s_of(mon):
    """number of differentiations of the monomial prod w_j^e_j"""
    return sum(j * e for j, e in enumerate(mon))


def _deg(mon):
    return sum(mon)


def _simp(e):
    try:
        return sp.cancel(sp.together(e))
    except Exception:
        return e


def _numer(e):
    e = sp.together(sp.expand(e))
    n, _d = sp.fraction(e)
    return sp.expand(n)


def _is_zero(e):
    try:
        return sp.expand(sp.together(e)) == 0 or sp.simplify(e) == 0
    except Exception:
        return False


def _factor_list(e):
    try:
        c, fl = sp.factor_list(e)
        return c, [f for f, _k in fl]
    except Exception:
        return sp.Integer(1), [e]


def _ne(e):
    """'g != 0' with the numerical content of e removed"""
    e = _numer(sp.sympify(e))
    fl = [g for g in _factor_list(e)[1] if not g.is_number]
    if not fl:
        return None
    return "%s != 0" % sp.Mul(*fl)


def _eqz(e):
    e = _numer(sp.sympify(e))
    fl = [g for g in _factor_list(e)[1] if not g.is_number]
    return "%s == 0" % (sp.Mul(*fl) if fl else e)


def _same_up_to_sign(a, b):
    return sp.expand(a - b) == 0 or sp.expand(a + b) == 0


def _str(e):
    return str(e)


def _cond_str(e, rel):
    return "%s %s 0" % (sp.factor(e) if not e.has(sp.sqrt(2) * 0 + sp.I) else e, rel)


class _Budget(object):
    def __init__(self, seconds):
        self.t0 = time.monotonic()
        self.deadline = self.t0 + float(seconds)

    def left(self):
        return self.deadline - time.monotonic()

    def over(self):
        return time.monotonic() > self.deadline

    def sub(self, frac):
        b = _Budget(0)
        b.t0 = time.monotonic()
        b.deadline = min(self.deadline, b.t0 + max(0.0, self.left()) * frac)
        return b


class _Timeout(BaseException):
    """raised by the watchdog inside a SymPy call when the deadline has passed (not an Exception, so that
    `except Exception` clauses inside SymPy do not swallow it)"""


# watchdog settings: "fallback" is the mechanism used where no signal timer is available (browser, worker
# thread): "gc" (default), "trace", or "off"; "force" (for tests) skips the signal timer.
_GUARD_STATE = {"fallback": "gc", "force": None}


class _GuardFlag(object):
    """per-thread flag "a guard is active" (threading.local where the module exists)"""

    def __init__(self):
        try:
            import threading
            self._loc = threading.local()
        except Exception:
            self._loc = type("_L", (), {})()

    def get(self):
        return getattr(self._loc, "active", False)

    def set(self, v):
        self._loc.active = bool(v)


_GUARD_ACTIVE = _GuardFlag()


class _Guard(object):
    """Watchdog for one phase (worker ENTIRE-2).  A single SymPy call is not interrupted by the cooperative
    budget checks; this context manager makes the running pure-Python code raise _Timeout once
    time.monotonic() has passed `deadline`.  Mechanisms:

    1. "signal": a real timer (signal.setitimer + SIGALRM), used in the main thread of a process when no other
       timer is running -- no overhead (the heavy server runs every step in a child process; tests and the
       command line run in the main thread);
    2. where there are no signals (the browser) or the code runs in a worker thread, the fallback named in
       _GUARD_STATE["fallback"]:
       "gc"    a callback of the garbage collector (gc.callbacks; called at every collection, which heavy
               symbolic code triggers many times per second) reads the clock; once the deadline has passed it
               installs a trace function (sys.settrace) that raises _Timeout at the next function call.  No
               overhead before the deadline.  It depends on collections taking place; a computation that
               allocates no containers for a long time is not interrupted.
       "trace" a trace function from the start (it returns None: function calls only, no lines) reads the clock
               once in `every` calls: independent of the collector, but it slows the phase down by a factor
               2.5 (CPython 3.11) to 4 (3.12);
       "off"   nothing (cooperative checks only).
       Neither is installed when another trace function is active (debugger, coverage).

    A guard inside an active guard does nothing (the outer deadline protects)."""

    def __init__(self, deadline, every=256):
        self.deadline = deadline
        self.every = every
        self.n = 0
        self.mode = None
        self.armed = False
        self._old = None
        self._tid = None

    def _trace(self, frame, event, arg):
        self.n += 1
        if self.n >= self.every:
            self.n = 0
            if self.armed and time.monotonic() > self.deadline:
                raise _Timeout()
        return None

    def _trace_now(self, frame, event, arg):
        if self.armed:
            raise _Timeout()
        return None

    def _on_gc(self, phase, info):
        if self.armed and phase == "stop" and time.monotonic() > self.deadline:
            try:
                import threading
                if threading.get_ident() == self._tid and sys.gettrace() is None:
                    sys.settrace(self._trace_now)
            except Exception:
                pass

    def _on_alarm(self, signum, frame):
        if self.armed:
            raise _Timeout()

    def __enter__(self):
        if _GUARD_ACTIVE.get():
            return self
        force = _GUARD_STATE.get("force")
        if force is None:
            try:
                import signal
                import threading
                if threading.current_thread() is threading.main_thread() and hasattr(signal, "setitimer") \
                        and hasattr(signal, "SIGALRM") and signal.getitimer(signal.ITIMER_REAL)[0] == 0:
                    self._old = signal.signal(signal.SIGALRM, self._on_alarm)
                    self.mode = "signal"
                    self.armed = True
                    _GUARD_ACTIVE.set(True)
                    signal.setitimer(signal.ITIMER_REAL, max(0.01, self.deadline - time.monotonic()))
                    return self
            except Exception:
                self.mode = None
                self.armed = False
        fb = force or _GUARD_STATE.get("fallback", "gc")
        if fb == "trace" and sys.gettrace() is None:
            self.mode = "trace"
            self.armed = True
            _GUARD_ACTIVE.set(True)
            sys.settrace(self._trace)
        elif fb == "gc" and sys.gettrace() is None:
            try:
                import gc
                import threading
                self._tid = threading.get_ident()
                self.mode = "gc"
                self.armed = True
                _GUARD_ACTIVE.set(True)
                gc.callbacks.append(self._on_gc)
            except Exception:
                self.mode = None
                self.armed = False
                _GUARD_ACTIVE.set(False)
        return self

    def __exit__(self, et, ev, tb):
        self.armed = False
        if self.mode == "signal":
            try:
                import signal
                signal.setitimer(signal.ITIMER_REAL, 0)
                signal.signal(signal.SIGALRM, self._old if self._old is not None else signal.SIG_DFL)
            except Exception:
                pass
            _GUARD_ACTIVE.set(False)
        elif self.mode == "trace":
            sys.settrace(None)
            _GUARD_ACTIVE.set(False)
        elif self.mode == "gc":
            try:
                import gc
                if self._on_gc in gc.callbacks:
                    gc.callbacks.remove(self._on_gc)
            except Exception:
                pass
            if sys.gettrace() == self._trace_now:
                sys.settrace(None)
            _GUARD_ACTIVE.set(False)
        self.mode = None
        return False


# ----------------------------------------------------------------------------------------------
# a small exact solver for polynomial systems with parameters
# ----------------------------------------------------------------------------------------------

class _Branch(object):
    __slots__ = ("eqs", "subs", "psubs", "pconds", "punsolved", "pne", "une", "notes")

    def __init__(self, eqs):
        self.eqs = list(eqs)
        self.subs = {}        # unknown -> value
        self.psubs = {}       # parameter -> value (from a condition)
        self.pconds = []      # conditions on parameters, expressions that must vanish (display)
        self.punsolved = []   # conditions not solved for a parameter (used in verification)
        self.pne = []         # parameter expressions that must not vanish
        self.une = []         # expressions in the unknowns that must not vanish
        self.notes = []

    def copy(self):
        b = _Branch(self.eqs)
        b.subs = dict(self.subs)
        b.psubs = dict(self.psubs)
        b.pconds = list(self.pconds)
        b.punsolved = list(self.punsolved)
        b.pne = list(self.pne)
        b.une = list(self.une)
        b.notes = list(self.notes)
        return b


class _Solver(object):
    """Branch-and-substitute solver.  Unknowns are solved first; an equation in the parameters
    alone becomes a condition (at most `max_conds` per branch).  Exact: radicals only for
    quadratics with parameters, CRootOf for numerical univariate polynomials."""

    def __init__(self, unknowns, nonzero, params, budget, max_conds=3, max_branches=400, init_pne=None):
        self.init_pne = [g for e in (init_pne or []) for g in _factor_list(_numer(sp.sympify(e)))[1]
                         if not g.is_number]
        self.unknowns = list(unknowns)
        self.uset = set(unknowns)
        self.nonzero = list(nonzero)
        self.params = list(params)
        self.pset = set(params)
        self.budget = budget
        self.max_conds = max_conds
        self.max_branches = max_branches
        self.incomplete = []
        self.truncated_conditions = False

    # -- nonvanishing tests
    def _known_nonzero(self, f, br):
        if f.is_number:
            return f != 0
        if f in self.nonzero:
            return True
        if f.is_Pow and f.base in self.nonzero:
            return True
        for g in br.pne:
            if _same_up_to_sign(f, g):
                return True
        return False

    def _reduce(self, e, br):
        if br.psubs:
            e = e.subs(br.psubs)
        if br.subs:
            e = e.subs(br.subs)
        return _numer(e)

    def _factors(self, e, br):
        """irreducible factors of e that may vanish; None if e cannot vanish"""
        c, fl = _factor_list(e)
        out = []
        for f in fl:
            if self._known_nonzero(f, br):
                continue
            if all(self._known_nonzero(g, br) for g in _factor_list(f)[1]):
                continue
            if not any(_same_up_to_sign(f, g) for g in out):
                out.append(f)
        if not out:
            return None
        return out

    def _unk(self, f, br):
        return [u for u in self.unknowns if u not in br.subs and f.has(u)]

    def _fclass(self, f, br):
        """0 parameters only; 1 linear, safe coefficient; 2 linear, parameter coefficient;
        3 univariate nonlinear; 4 linear with a coefficient in the unknowns; 5 nonlinear in several"""
        us = self._unk(f, br)
        if not us:
            return 0, 0
        fe = sp.expand(f)
        best = None
        for u in us:
            if sp.degree(fe, u) != 1:
                continue
            a = _simp(fe.coeff(u, 1))
            if a.is_number or all(self._known_nonzero(g, br) for g in _factor_list(_numer(a))[1]):
                k = 1
            elif not self._unk(a, br):
                k = 2
            else:
                k = 4
            best = k if best is None else min(best, k)
        if best is None:
            best = 3 if len(us) == 1 else 5
        return best, len(us)

    def _score(self, fl, br):
        """lower is better: the worst factor decides, then the number of factors"""
        cls = [self._fclass(f, br) for f in fl]
        worst = max(c for c, _n in cls)
        nun = max(n for _c, n in cls)
        return (worst, len(fl), nun, sum(len(sp.Add.make_args(f)) for f in fl))

    # -- recording solutions for unknowns and parameters
    def _assign(self, br, x, v):
        v = _simp(v)
        br.subs = dict((k, _simp(val.subs(x, v))) for k, val in br.subs.items())
        br.subs[x] = v
        br.une = [u.subs(x, v) for u in br.une]
        return br

    def _passign(self, br, p, v):
        v = _simp(v)
        br.psubs = dict((k, _simp(val.subs(p, v))) for k, val in br.psubs.items())
        br.psubs[p] = v
        br.subs = dict((k, _simp(val.subs(p, v))) for k, val in br.subs.items())
        new_pne = []
        for g in br.pne:
            g2 = _numer(g.subs(p, v))
            if g2 == 0:
                return None
            if not g2.is_number:
                new_pne.append(g2)
        br.pne = new_pne
        new_un = []
        for g in br.punsolved:
            g2 = _numer(g.subs(p, v))
            if g2 == 0:
                continue
            if g2.is_number:
                return None
            new_un.append(g2)
        br.punsolved = new_un
        return br

    def _add_pne(self, br, a):
        for g in _factor_list(_numer(a))[1]:
            if not g.is_number and not any(_same_up_to_sign(g, h) for h in br.pne):
                br.pne.append(g)

    # -- main loop
    def solve(self, eqs):
        results = []
        b0 = _Branch(eqs)
        b0.pne = list(self.init_pne)
        stack = [b0]
        nb = 0
        while stack:
            if self.budget.over():
                self.incomplete.append("time budget exhausted with %d open branches" % len(stack))
                break
            nb += 1
            if nb > self.max_branches:
                self.incomplete.append("branch limit %d reached" % self.max_branches)
                break
            br = stack.pop()
            pending = []
            dead = False
            for e in br.eqs:
                e2 = self._reduce(e, br)
                if e2 == 0:
                    continue
                pending.append(e2)
            if not pending:
                fin = self._finalize(br)
                if fin is not None:
                    results.append(fin)
                continue
            cand = []
            for e in pending:
                fl = self._factors(e, br)
                if fl is None:
                    dead = True
                    break
                try:
                    sc = self._score(fl, br)
                except Exception as exc:
                    self.incomplete.append("equation not handled (%s)" % type(exc).__name__)
                    dead = True
                    break
                cand.append((sc, e, fl))
            if dead:
                continue
            cand.sort(key=lambda x: x[0])
            _sc, e, fl = cand[0]
            rest = [c[1] for c in cand[1:]]
            if len(fl) > 1:
                for f in fl:
                    nb_ = br.copy()
                    nb_.eqs = [f] + rest
                    stack.append(nb_)
                continue
            f = fl[0]
            try:
                stack.extend(self._step(br, f, rest))
            except Exception as exc:
                self.incomplete.append("step failed on %s = 0 (%s)" % (f, type(exc).__name__))
        return results

    def _step(self, br, f, rest):
        us = self._unk(f, br)
        out = []
        if not us:
            # a condition on the parameters
            if len(br.pconds) >= self.max_conds:
                self.truncated_conditions = True
                return []
            nb_ = br.copy()
            nb_.pconds.append(f)
            nb_.eqs = rest
            ps = [p for p in self.params if f.has(p) and p not in nb_.psubs]
            lin = []
            try:
                _probe = [sp.degree(f, p) for p in ps]
            except Exception:
                nb_.punsolved.append(f)
                return [nb_]
            for p in ps:
                if sp.degree(f, p) == 1:
                    a = _simp(sp.expand(f).coeff(p, 1))
                    b = _simp(sp.expand(f) - sp.expand(f).coeff(p, 1) * p)
                    if a.has(p) or b.has(p):
                        continue
                    rank = 0 if a.is_number else (1 if self._known_nonzero(a, nb_) else 2)
                    lin.append((rank, len(sp.Add.make_args(a)), str(p), p, a, b))
            if lin:
                lin.sort(key=lambda x: x[:3])
                _r, _n, _nm, p, a, b = lin[0]
                if _r == 2:
                    self._add_pne(nb_, a)
                    nb3 = br.copy()                    # the coefficient vanishes: a = 0 and b = 0
                    nb3.eqs = [a, b] + rest
                    out.append(nb3)
                nb2 = self._passign(nb_, p, -b / a)
                if nb2 is not None:
                    out.append(nb2)
                return out
            if len(ps) == 1:
                p = ps[0]
                poly = sp.Poly(f, p)
                rts = self._roots(poly)
                if rts is not None:
                    for r in rts:
                        nb3 = nb_.copy()
                        nb3.pconds[-1] = p - r          # display the root actually used, not the whole polynomial
                        nb2 = self._passign(nb3, p, r)
                        if nb2 is not None:
                            out.append(nb2)
                    return out
            nb_.punsolved.append(f)
            return [nb_]
        # linear in some unknown?
        fe = sp.expand(f)
        lin = []
        for u in us:
            if sp.degree(fe, u) != 1:
                continue
            a = _simp(fe.coeff(u, 1))
            b = _simp(fe - fe.coeff(u, 1) * u)
            ua = self._unk(a, br)
            if a.is_number:
                rank = 0
            elif all(self._known_nonzero(g, br) for g in _factor_list(_numer(a))[1]):
                rank = 1
            elif not ua:
                rank = 2
            else:
                rank = 3
            lin.append((rank, len(sp.Add.make_args(a)), self.unknowns.index(u), u, a, b))
        if lin:
            lin.sort(key=lambda x: x[:3])
            rank, _n, _i, u, a, b = lin[0]
            nb_ = br.copy()
            nb_.eqs = rest
            if rank == 2:
                self._add_pne(nb_, a)
            elif rank == 3:
                nb_.une.append(a)
            out.append(self._assign(nb_, u, -b / a))
            if rank >= 2:
                # the coefficient vanishes: both parts must vanish
                nb3 = br.copy()
                nb3.eqs = [a, b] + rest
                out.append(nb3)
            return out
        if len(us) == 1:
            u = us[0]
            rts = self._roots(sp.Poly(fe, u))
            if rts is not None:
                for r in rts:
                    nb_ = br.copy()
                    nb_.eqs = rest
                    out.append(self._assign(nb_, u, r))
                return out
            self.incomplete.append("not solved: %s = 0 (degree %d in %s)" % (f, sp.degree(fe, u), u))
            return []
        # nonlinear in several unknowns (and so is every pending equation): a lex Groebner basis of
        # the pending equations replaces them (once per branch)
        if "gb" not in br.notes:
            allu = [v for v in self.unknowns if v not in br.subs and any(e.has(v) for e in [f] + rest)]
            if len(allu) <= 6:
                try:
                    G = sp.groebner([f] + rest, *allu, order="lex")
                    if any(e.free_symbols & self.pset for e in [f] + rest):
                        self.incomplete.append("Groebner step over Q(parameters): special parameter values not covered")
                    nb_ = br.copy()
                    nb_.notes.append("gb")
                    if list(G.exprs) == [1]:
                        return []
                    nb_.eqs = list(G.exprs)
                    return [nb_]
                except Exception as exc:
                    self.incomplete.append("Groebner step failed: %s" % type(exc).__name__)
                    return []
        self.incomplete.append("not solved: %s = 0 (nonlinear in %s)" % (f, us))
        return []

    def _roots(self, poly):
        """exact roots (with multiplicity ignored) of a univariate polynomial, or None"""
        d = poly.degree()
        if d <= 0:
            return []
        numeric = all(c.is_number for c in poly.all_coeffs())
        if d > 2 and not numeric:
            return None
        try:
            r = sp.roots(poly)
        except Exception:
            r = {}
        if sum(r.values()) == d:
            return list(r.keys())
        if numeric:
            try:
                out = list(r.keys())
                for g, _k in sp.factor_list(poly.as_expr())[1]:
                    gp = sp.Poly(g, *poly.gens)
                    if gp.degree() >= 1 and not any(_is_zero(g.subs(poly.gens[0], x)) for x in out):
                        rr = sp.roots(gp)
                        if sum(rr.values()) == gp.degree():
                            out.extend(rr.keys())
                        else:
                            out.extend(sp.CRootOf(gp, i) for i in range(gp.degree()))
                return out
            except Exception:
                return None
        return None

    def _finalize(self, br):
        subs = dict(br.subs)
        for u in self.nonzero:
            v = subs.get(u, u)
            v = _simp(v.subs(br.psubs)) if br.psubs else v
            if _is_zero(v):
                return None
            if not (set(self.unknowns) & v.free_symbols) and not v.is_number:
                self._add_pne(br, v)
        for g in br.une:
            g2 = _simp(g.subs(br.psubs).subs(subs))
            if _is_zero(g2):
                return None
            if not (set(self.unknowns) & g2.free_symbols) and not g2.is_number:
                self._add_pne(br, g2)
        for g in br.pne:
            if _is_zero(g.subs(br.psubs)):
                return None
        for g in br.punsolved:
            if any(_same_up_to_sign(g, h) for h in br.pne):
                return None
        free = [u for u in self.unknowns if u not in subs]
        return {"subs": subs, "free": free, "psubs": dict(br.psubs), "pconds": list(br.pconds),
                "punsolved": list(br.punsolved), "pne": list(br.pne), "notes": list(br.notes)}


# ----------------------------------------------------------------------------------------------
# structure of the equation: tau(t), the top part, the Clunie / Wiman-Valiron data
# ----------------------------------------------------------------------------------------------

def _structure(D):
    n = max(_deg(m) for m in D.terms)
    top = dict((m, c) for m, c in D.terms.items() if _deg(m) == n)
    tau = sp.expand(sum(c * _T ** _s_of(m) for m, c in top.items()))
    svals = sorted(set(_s_of(m) for m in top))
    s_lo, s_hi = svals[0], svals[-1]
    b = dict((k, _simp(sum(c for m, c in top.items() if _s_of(m) == k))) for k in svals)
    b_lo, b_hi = b[s_lo], b[s_hi]
    K = D.K
    pure = (n,) + (0,) * K
    lin1 = (n - 1, 1) + (0,) * (K - 1) if K >= 1 else None
    kind = "other"
    c = rho = None
    if set(top) == {pure} and n >= 2:
        kind = "pure-power"
        c = top[pure]
    elif K >= 1 and n >= 2 and lin1 in top and set(top) <= {pure, lin1}:
        kind = "first-order-factor"
        c = top[lin1]
        rho = _simp(-top.get(pure, 0) / c)
    return {"n": n, "top": top, "tau": tau, "s_lo": s_lo, "s_hi": s_hi, "b_lo": b_lo, "b_hi": b_hi,
            "kind": kind, "c": c, "rho": rho}


def _nonzero_roots_tau(tau):
    """nonzero roots of tau (list) or None if not explicit"""
    if tau == 0:
        return None
    p = sp.Poly(tau, _T)
    while p.degree() > 0 and p.eval(0) == 0:
        p = sp.Poly(sp.cancel(p.as_expr() / _T), _T)
    if p.degree() <= 0:
        return []
    try:
        r = sp.roots(p)
        if sum(r.values()) == p.degree():
            return list(r.keys())
    except Exception:
        pass
    return None


def _maybe_vanishing_param_factors(exprs, params):
    out = []
    for e in exprs:
        e = _numer(sp.sympify(e))
        if e.is_number:
            continue
        for g in _factor_list(e)[1]:
            if g.is_number or not (g.free_symbols & set(params)):
                continue
            if not any(_same_up_to_sign(g, h) for h in out):
                out.append(g)
    return out


# ----------------------------------------------------------------------------------------------
# constants
# ----------------------------------------------------------------------------------------------

def _constants(D, sol_id):
    c = _CV
    e0 = sp.expand(sum(co * c ** m[0] for m, co in D.terms.items() if all(e == 0 for e in m[1:])))
    cert = {"polynomial": _disp(e0, D.params), "variable": "c", "_poly": e0}
    sols = []
    if _is_zero(e0):
        C = _Names(D.reserved).one("K")
        sols.append(_solution(sol_id(), "constant", C, [C], [], d=0,
                              cert=_cert_pass("E(c, 0, ..., 0) vanishes identically"),
                              constants={str(C): "free"}))
        cert["all_constants"] = True
        return sols, cert
    cert["all_constants"] = False
    poly = sp.Poly(e0, c)
    numeric = all(x.is_number for x in poly.all_coeffs())
    roots = []
    if poly.degree() >= 1:
        cl, fl = _factor_list(e0)
        for g in fl:
            if not g.has(c):
                continue
            gp = sp.Poly(g, c)
            r = {}
            if gp.degree() <= 2 or numeric:
                try:
                    r = sp.roots(gp)
                except Exception:
                    r = {}
            if sum(r.values()) == gp.degree():
                roots.extend(r.keys())
            elif numeric:
                roots.extend(sp.CRootOf(gp, i) for i in range(gp.degree()))
            else:
                roots.append(sp.CRootOf(gp, 0) if False else sp.Symbol("ROOT"))
                cert.setdefault("unsolved_factors", []).append(_disp(g, D.params))
    lc = poly.LC()
    conds = [] if lc.is_number else [_ne(lc)]
    for r in roots:
        if r == sp.Symbol("ROOT"):
            continue
        sols.append(_solution(sol_id(), "constant", r, [], conds, d=0,
                              cert=_cert_pass("E(c, 0, ..., 0) = 0 at c = %s" % r)))
    implicit = []
    if "unsolved_factors" in cert:
        nm = _Names(D.reserved)
        for g in [x for x in _factor_list(e0)[1] if x.has(c) and _disp(x, D.params) in cert["unsolved_factors"]]:
            cs_ = nm.one("c")
            gd = _disp(g, D.params)
            implicit.append(_solution(sol_id(), "constant", cs_, [], conds, d=0,
                                      cert=_cert_pass("E(c, 0, ..., 0) vanishes at every root of %s = 0" % gd),
                                      constants={str(cs_): "root of " + gd},
                                      extra={"note": "any root of %s = 0" % gd}))
    cert["_implicit"] = implicit
    cert["roots"] = [str(r) for r in roots if r != sp.Symbol("ROOT")]
    if not lc.is_number:
        cert["degenerate_if"] = _eqz(lc)
    return sols, cert


# ----------------------------------------------------------------------------------------------
# Solution objects and verification
# ----------------------------------------------------------------------------------------------

def _cert_pass(detail, method="symbolic"):
    return {"type": "substitution", "method": method, "status": "pass", "detail": detail}


def _denominator_conditions(expr, params, conds):
    """parameter factors of denominators of expr must not vanish"""
    out = list(conds)
    ps = set(params)
    for sub in sp.preorder_traversal(sp.sympify(expr)):
        if isinstance(sub, sp.Pow) and sub.exp.is_negative:
            base = sub.base
            if base.free_symbols and base.free_symbols <= ps:
                x = _ne(base)
                if x and x not in out:
                    out.append(x)
    return out


def _bad(expr):
    expr = sp.sympify(expr)
    return expr.has(sp.nan) or expr.has(sp.zoo) or expr.has(sp.oo) or expr.has(-sp.oo)


def _solution(sid, kind, expr, free, conditions, d=1, cert=None, constants=None, extra=None):
    expr = sp.sympify(expr)
    out = {"id": sid, "kind": kind, "d": d, "expr": str(expr), "latex": sp.latex(expr),
           "constants": constants or {}, "free": [str(f) for f in free], "conditions": list(conditions),
           "poles_per_period": 0, "pole_orders": [],
           "certificate": cert or {"type": "substitution", "method": "symbolic", "status": "not-run",
                                   "detail": ""},
           "origin": "live:entire", "citations": []}
    if extra:
        out.update(extra)
    return out


def _verify_coeffs(coeffs, psubs, punsolved, params, lcs=None):
    """all coefficients vanish after the parameter substitution, modulo unsolved conditions (pseudo-remainder;
    the leading coefficients used are appended to `lcs`: they must not vanish)"""
    for co in coeffs:
        co = _numer(co.subs(psubs)) if psubs else _numer(co)
        if co == 0:
            continue
        ok = False
        for g in punsolved:
            for p in params:
                try:
                    if g.has(p) and sp.degree(g, p) >= 1:
                        r = sp.prem(co, g, p)
                        if sp.expand(r) == 0:
                            ok = True
                            if lcs is not None:
                                lc = sp.Poly(g, p).LC()
                                if not sp.sympify(lc).is_number:
                                    lcs.append(lc)
                            break
                except Exception:
                    pass
            if ok:
                break
        if not ok:
            return False, str(co)
    return True, ""


def _E_on_s(D, cvals, lam):
    """E[w] for w = sum_i cvals[i] s^i, s = exp(lam z): list of coefficients of s^k"""
    N = len(cvals) - 1
    wj = [sp.Add(*[cvals[i] * (i * lam) ** j * _S ** i for i in range(N + 1)]) if j > 0
          else sp.Add(*[cvals[i] * _S ** i for i in range(N + 1)]) for j in range(D.K + 1)]
    Es = sp.expand(sp.Add(*[co * sp.Mul(*[wj[j] ** e for j, e in enumerate(m)]) for m, co in D.terms.items()]))
    if Es == 0:
        return []
    return sp.Poly(Es, _S).all_coeffs()


def _E_on_poly(D, cvals):
    w = sp.Add(*[cvals[k] * z ** k for k in range(len(cvals))])
    wj = [sp.diff(w, z, j) for j in range(D.K + 1)]
    Ez = sp.expand(sp.Add(*[co * sp.Mul(*[wj[j] ** e for j, e in enumerate(m)]) for m, co in D.terms.items()]))
    if Ez == 0:
        return []
    return sp.Poly(Ez, z).all_coeffs()


def _conditions_display(r):
    """conditions in the form `name == value` (the parameter substitutions used by the check), then the
    conditions kept as polynomials (`poly == 0`), then `expr != 0`"""
    out = []
    for p_, v in r["psubs"].items():
        out.append("%s == %s" % (p_, v))
    for g in r["punsolved"]:
        out.append(_eqz(g))
    for g in r["pne"]:
        x = _ne(g)
        if x and x not in out:
            out.append(x)
    return out


def _conditions_polynomial(r):
    """the same equalities as polynomials in the parameters (for display)"""
    return [_eqz(g) for g in r["pconds"]]


# ----------------------------------------------------------------------------------------------
# polynomial solutions (Lemma P)
# ----------------------------------------------------------------------------------------------

def _poly_degree_bound(D, st):
    n = st["n"]
    top = st["top"]
    s_min = min(_s_of(m) for m in top)
    T = dict((m, c) for m, c in top.items() if _s_of(m) == s_min)
    QT = sp.expand(sum(c * sp.Mul(*[_ff(_M, j) ** e for j, e in enumerate(m)]) for m, c in T.items()))
    QT = _simp(QT)
    ratios = [sp.Rational(s_min - _s_of(m), n - _deg(m)) for m in D.terms if _deg(m) < n]
    mstar = max(ratios) if ratios else None
    floor_mstar = int(math.floor(mstar)) if mstar is not None else 0
    info = {"s_min": s_min, "T": [str(sp.Mul(*[D.w[j] ** e for j, e in enumerate(m)])) for m in T],
            "Q_T": _disp(sp.factor(QT), D.params), "m_star": str(mstar) if mstar is not None else None}
    if _is_zero(QT):
        info["derived"] = False
        info["note"] = "Q_T vanishes identically: no degree bound from Lemma P"
        return None, info
    num = _numer(QT)
    int_roots, param_roots, param_factors = [], [], []
    for g in _factor_list(num)[1]:
        if not g.has(_M):
            continue
        gp = sp.Poly(g, _M)
        if gp.degree() == 1:
            r = _simp(-gp.all_coeffs()[1] / gp.all_coeffs()[0])
            if r.is_number:
                if r.is_integer and r > 0:
                    int_roots.append(int(r))
            else:
                param_roots.append(r)
        elif not all(x.is_number for x in gp.all_coeffs()):
            param_factors.append(g)
    M = max([floor_mstar] + int_roots + [0])
    info.update({"derived": True, "bound": M, "positive_integer_roots": int_roots,
                 "parameter_dependent_roots": [str(r) for r in param_roots],
                 "parameter_dependent_factors": [str(g) for g in param_factors]})
    coefT = [c for c in T.values() if not c.is_number]
    if coefT:
        info["assumes"] = [x for x in (_ne(c) for c in coefT) if x]
    return M, info


def _poly_solutions(D, st, budget, sol_id, max_conds, deg_search):
    M, info = _poly_degree_bound(D, st)
    label = "certificate" if M is not None else "search"
    Mrun = M if M is not None else deg_search
    sols, systems, notes = [], [], []
    done = 0
    for m in range(1, Mrun + 1):
        if budget.over():
            notes.append("time budget exhausted before degree %d" % m)
            break
        cs = sp.symbols("_p0:%d" % (m + 1))
        try:
            with _Guard(budget.deadline):
                eqs = _E_on_poly(D, list(cs))
                solver = _Solver(list(cs), [cs[m]], D.params, budget, max_conds=max_conds)
                res = solver.solve(eqs)
        except _Timeout:
            systems.append({"degree": m, "unknowns": [str(c) for c in cs], "equations": None, "branches": 0,
                            "incomplete": ["time budget exhausted inside a step (watchdog)"],
                            "conditions_truncated": False})
            notes.append("degree %d: time budget exhausted inside a step" % m)
            break
        systems.append({"degree": m, "unknowns": [str(c) for c in cs], "equations": len(eqs),
                        "branches": len(res), "incomplete": solver.incomplete,
                        "conditions_truncated": solver.truncated_conditions})
        if solver.incomplete:
            notes.append("degree %d: %s" % (m, "; ".join(solver.incomplete)))
        done = m
        for r in res:
            try:
                with _Guard(budget.deadline + 2.0):
                    sol = _poly_solution_object(D, cs, r, sol_id)
            except _Timeout:
                notes.append("a branch of degree %d was not converted (time budget)" % m)
                systems[-1]["incomplete"] = list(systems[-1]["incomplete"]) + ["conversion not finished (time budget)"]
                sol = None
            except Exception as exc:
                notes.append("a branch of degree %d was not converted (%s)" % (m, type(exc).__name__))
                systems[-1]["incomplete"] = list(systems[-1]["incomplete"]) + ["conversion failed"]
                sol = None
            if sol is not None:
                sols.append(sol)
    info["searched_up_to"] = done
    info["label"] = label
    return _dedupe(sols), info, systems, notes


def _rename_free(free, names, base="K"):
    return dict((f, names.one(base)) for f in free)


def _poly_solution_object(D, cs, r, sol_id):
    vals = [r["subs"].get(c, c) for c in cs]
    if r["psubs"]:
        vals = [_simp(v.subs(r["psubs"])) for v in vals]
    ren = _rename_free(r["free"], _Names(D.reserved))
    vals = [v.subs(ren) for v in vals]
    expr = sp.Add(*[vals[k] * z ** k for k in range(len(vals))])
    expr = sp.collect(sp.expand(expr), z)
    if not expr.has(z) or _bad(expr):
        return None
    lcs = []
    ok, bad = _verify_coeffs(_E_on_poly(D, vals), r["psubs"], r["punsolved"], D.params, lcs)
    detail = "E[w] expanded in powers of z: all coefficients vanish"
    if r["psubs"]:
        detail += " after %s" % ", ".join("%s = %s" % (k, v) for k, v in r["psubs"].items())
    if r["punsolved"]:
        detail += " modulo %s" % ", ".join(str(g) for g in r["punsolved"])
    cert = {"type": "substitution", "method": "symbolic", "status": "pass" if ok else "fail",
            "detail": detail if ok else "nonzero coefficient: " + bad}
    return _solution(sol_id(), "polynomial", expr, [ren[f] for f in r["free"]],
                     _denominator_conditions(expr, D.params, _conditions_display(r) +
                                             [x for x in (_ne(l) for l in lcs) if x]),
                     cert=cert, constants=dict((str(ren[f]), "free") for f in r["free"]),
                     extra={"parameter_values": dict((str(k), str(v)) for k, v in r["psubs"].items()),
                            "conditions_polynomial": _conditions_polynomial(r)})


# ----------------------------------------------------------------------------------------------
# exponential sums  c0 + sum c_i exp(i lambda z)   (Lemma X)
# ----------------------------------------------------------------------------------------------

def _E_on_laurent(D, cvals, lo, lam):
    """E[w] for w = sum_k cvals[k - lo] s^k (k = lo..hi), s = exp(lam z), multiplied by s^(-n lo):
    list of coefficients of a polynomial in s"""
    hi = lo + len(cvals) - 1
    ks = range(lo, hi + 1)
    wj = []
    for j in range(D.K + 1):
        wj.append(sp.Add(*[cvals[k - lo] * ((k * lam) ** j if j > 0 else 1) * _S ** (k - lo) for k in ks]))
    n = max(_deg(m) for m in D.terms)
    # w = s^lo * (polynomial in s); monomial of degree d gets s^(d lo); multiply by s^(-n lo)
    Es = sp.expand(sp.Add(*[co * _S ** ((n - _deg(m)) * (-lo)) * sp.Mul(*[wj[j] ** e for j, e in enumerate(m)])
                            for m, co in D.terms.items()]))
    if Es == 0:
        return []
    return sp.Poly(Es, _S).all_coeffs()


def _exp_shapes(N_max, two_sided=True):
    """(lo, hi): one-sided c_0 + ... + c_N s^N first, then two-sided c_{-N1} s^{-N1} + ... + c_{N2} s^{N2}"""
    shapes = [(0, N) for N in range(1, N_max + 1)]
    if two_sided:
        for tot in range(2, N_max + 1):
            for N1 in range(1, tot // 2 + 1):
                shapes.append((-N1, tot - N1))
    return shapes


def _exp_solutions(D, st, budget, sol_id, max_conds, N_max, only_lambda=None, two_sided=True):
    sols, systems, notes = [], [], []
    done = []
    for lo, hi in _exp_shapes(N_max, two_sided and only_lambda is None):
        if budget.over():
            notes.append("time budget exhausted before the shape (%d, %d)" % (lo, hi))
            break
        lam = sp.Symbol("_lam")
        cs = [sp.Symbol("_c%s%d" % ("m" if k < 0 else "", abs(k))) for k in range(lo, hi + 1)]
        try:
            with _Guard(budget.deadline):
                eqs = _E_on_laurent(D, cs, lo, lam)
                unknowns = [lam] + cs
                nonzero = [cs[-1]] + ([cs[0]] if lo < 0 else [])
                if only_lambda is not None:
                    eqs = [e.subs(lam, only_lambda) for e in eqs]
                    unknowns = list(cs)
                else:
                    nonzero.append(lam)
                solver = _Solver(unknowns, nonzero, D.params, budget, max_conds=max_conds,
                                 init_pne=[only_lambda] if only_lambda is not None else None)
                res = solver.solve(eqs)
        except _Timeout:
            systems.append({"exponents": "%d..%d" % (lo, hi), "unknowns": None, "equations": None, "branches": 0,
                            "incomplete": ["time budget exhausted inside a step (watchdog)"],
                            "conditions_truncated": False})
            notes.append("exponents %d..%d: time budget exhausted inside a step" % (lo, hi))
            break
        systems.append({"exponents": "%d..%d" % (lo, hi), "unknowns": [str(u) for u in unknowns],
                        "equations": len(eqs), "branches": len(res), "incomplete": solver.incomplete,
                        "conditions_truncated": solver.truncated_conditions})
        if solver.incomplete:
            notes.append("exponents %d..%d: %s" % (lo, hi, "; ".join(solver.incomplete)))
        else:
            done.append([lo, hi])
        for r in res:
            try:
                with _Guard(budget.deadline + 2.0):
                    sol = _exp_solution_object(D, cs, lo, lam, r, sol_id, only_lambda)
            except _Timeout:
                notes.append("a branch of %d..%d was not converted (time budget)" % (lo, hi))
                systems[-1]["incomplete"] = list(systems[-1]["incomplete"]) + ["conversion not finished (time budget)"]
                if [lo, hi] in done:
                    done.remove([lo, hi])
                sol = None
            except Exception as exc:
                notes.append("a branch of %d..%d was not converted (%s)" % (lo, hi, type(exc).__name__))
                systems[-1]["incomplete"] = list(systems[-1]["incomplete"]) + ["conversion failed"]
                if [lo, hi] in done:
                    done.remove([lo, hi])
                sol = None
            if sol is not None:
                sols.append(sol)
    one = max([h for l, h in done if l == 0] + [0])
    return _dedupe(sols), {"searched_shapes": done, "searched_up_to_N": one, "N_max": N_max,
                           "label": "search"}, systems, notes


def _safe_exp(D, st, budget, sol_id, max_conds, N_max, only_lambda=None):
    try:
        return _exp_solutions(D, st, budget, sol_id, max_conds, N_max, only_lambda=only_lambda)
    except Exception as exc:
        return [], {"searched_shapes": [], "searched_up_to_N": 0, "N_max": N_max, "label": "search",
                    "error": "%s: %s" % (type(exc).__name__, str(exc)[:200])}, \
            [{"exponents": "?", "incomplete": ["search failed (%s)" % type(exc).__name__],
              "conditions_truncated": False}], ["exponential search failed (%s)" % type(exc).__name__]


def _exp_solution_object(D, cs, lo, lam, r, sol_id, only_lambda):
    subs = dict(r["subs"])
    vals = [subs.get(c, c) for c in cs]
    lv = only_lambda if only_lambda is not None else subs.get(lam, lam)
    if r["psubs"]:
        vals = [_simp(v.subs(r["psubs"])) for v in vals]
        lv = _simp(sp.sympify(lv).subs(r["psubs"]))
    if _is_zero(lv):
        return None
    hi = lo + len(cs) - 1
    support = [k for k in range(lo, hi + 1) if k != 0 and not _is_zero(vals[k - lo])]
    if not support:
        return None
    g = 0
    for k in support:
        g = math.gcd(g, abs(k))
    if g > 1:
        return None          # the same function is found with the exponents divided by g
    if lo < 0 and max(support) < -min(support):
        return None          # mirror image of a shape with lo' = -hi (lambda -> -lambda)
    if lo < 0 and max(support) == -min(support) and lv.is_number and str(lv) > str(-lv):
        return None          # symmetric support: lambda and -lambda give the same family
    free = list(r["free"])
    names = _Names(D.reserved)
    lam_name = names.one("lamda", numbered=False)
    ren = _rename_free([f for f in free if f != lam], names)
    if lam in free:
        ren[lam] = lam_name
    vals = [v.subs(ren) for v in vals]
    lv = sp.sympify(lv).subs(ren)
    lcs = []
    ok, bad = _verify_coeffs(_E_on_laurent(D, vals, lo, lv), r["psubs"], r["punsolved"], D.params, lcs)
    expr = sp.Add(*[vals[k - lo] * (sp.exp(k * lv * z) if k != 0 else 1) for k in range(lo, hi + 1)])
    if _bad(expr) or _bad(lv):
        return None
    detail = "E[w] written as a Laurent polynomial in s = exp(%s*z) (d/dz = %s*s*d/ds): all coefficients vanish" \
             % (lv, lv)
    if r["psubs"]:
        detail += " after %s" % ", ".join("%s = %s" % (k, v) for k, v in r["psubs"].items())
    if r["punsolved"]:
        detail += " modulo %s" % ", ".join(str(gg) for gg in r["punsolved"])
    cert = {"type": "substitution", "method": "symbolic", "status": "pass" if ok else "fail",
            "detail": detail if ok else "nonzero coefficient: " + bad}
    conds = _denominator_conditions(expr, D.params, _conditions_display(r) + [x for x in (_ne(l) for l in lcs) if x])
    for k in support:
        v = vals[k - lo]
        if v in ren.values():
            conds.append("%s != 0" % v)
    if lv in ren.values():
        conds.append("%s != 0" % lv)
    return _solution(sol_id(), "simply-periodic", expr, [ren[f] for f in free], conds, cert=cert,
                     constants=dict((str(ren[f]), "free") for f in free),
                     extra={"exponent": str(lv), "exponents": [lo, hi], "support": support,
                            "parameter_values": dict((str(k), str(v)) for k, v in r["psubs"].items()),
                            "conditions_polynomial": _conditions_polynomial(r)})


def _dedupe(sols):
    seen, out = set(), []
    for s in sols:
        key = (s["expr"], tuple(sorted(s["conditions"])))
        if key in seen:
            continue
        seen.add(key)
        out.append(s)
    return out


# ----------------------------------------------------------------------------------------------
# linear equations (classical) and homogeneous equations with a linear reduction (Lemma H)
# ----------------------------------------------------------------------------------------------

def _linear_general(D, coeffs, const, var=z, prefix="K", names=None):
    """general solution of sum_j coeffs[j] D^j y + const = 0 (constant coefficients).
    Roots: explicit for irreducible factors of degree <= 2 and for biquadratics, otherwise named symbols r1, r2, ...
    (key "_named": symbol -> its irreducible polynomial in _T).  `conditions`: the relations among the
    parameters under which the formula is the general solution (leading coefficient, the coefficient used for the
    particular solution, discriminant of the squarefree part).  Returns (expr, free symbols, info) or None."""
    chi = sp.expand(sum(coeffs[j] * _T ** j for j in range(len(coeffs))))
    if chi == 0 or sp.Poly(chi, _T).degree() < 0:
        return None
    j0 = min(j for j in range(len(coeffs)) if not _is_zero(coeffs[j]))
    poly = sp.Poly(chi, _T)
    names = names if names is not None else _Names(D.reserved)
    named, rts = {}, {}
    sqf = sp.Integer(1)
    _c, fl = sp.factor_list(chi, _T)
    for g, mult in fl:
        gp = sp.Poly(g, _T)
        if gp.degree() <= 0:
            continue
        sqf *= g
        rr = {}
        even = gp.degree() == 4 and all(gp.coeff_monomial(_T ** j) == 0 for j in (1, 3))
        if gp.degree() <= 2:
            rr = sp.roots(gp)
        elif even:
            q_ = sp.Symbol("_q")
            hq = sp.Poly(sp.expand(g).subs(_T ** 2, q_), q_)
            for qv, mq in sp.roots(hq).items():
                for sg in (1, -1):
                    rv = sg * sp.sqrt(qv)
                    rr[rv] = rr.get(rv, 0) + mq
        if sum(rr.values()) != gp.degree():
            rr = {}
            for i in range(gp.degree()):
                rsym = names.one("r")
                named[rsym] = g
                rr[rsym] = 1
        for x, m in rr.items():
            rts[x] = rts.get(x, 0) + m * mult
    free, terms = [], []
    for r0, mult in rts.items():
        for i in range(mult):
            C = names.one(prefix)
            free.append(C)
            terms.append(C * var ** i * sp.exp(r0 * var))
    part = sp.Integer(0)
    if not _is_zero(const):
        part = -const * var ** j0 / (coeffs[j0] * sp.factorial(j0))
    expr = part + sp.Add(*terms)
    conds = []
    for e in (poly.LC(), coeffs[j0]):
        if not sp.sympify(e).is_number:
            x = _ne(e)
            if x and x not in conds:
                conds.append(x)
    sqp = sp.Poly(sqf, _T)
    if sqp.degree() >= 2 and not all(c_.is_number for c_ in sqp.all_coeffs()):
        disc = _numer(sp.discriminant(sqf, _T))
        x = _ne(disc)
        if x and x not in conds:
            conds.append(x)                     # no two characteristic roots coincide
    return expr, free, {"characteristic_polynomial": _disp(chi, D.params), "conditions": conds,
                        "named_roots": dict((str(r), _disp(g, D.params)) for r, g in named.items()), "_named": named,
                        "roots": dict((str(r0), m) for r0, m in rts.items()), "_rts": rts, "_chi": chi,
                        "_part": part, "_const": const, "_coeffs": list(coeffs)}


def _verify_linear(D, info, budget=None):
    """exact check of the general solution of a linear equation with constant coefficients:
    chi^(k)(r) = 0 for k < multiplicity(r) (named roots: remainder modulo their polynomial), and the particular
    solution solves the inhomogeneous equation.  Returns True, False, or None (not run: time budget)."""
    chi, rts, named = info["_chi"], info["_rts"], info["_named"]
    for r0, mult in rts.items():
        if budget is not None and budget.over():
            return None
        for k in range(mult):
            d = sp.diff(chi, _T, k)
            if r0 in named:
                val = sp.rem(sp.expand(d.subs(_T, r0)), sp.expand(named[r0].subs(_T, r0)), r0)
            else:
                val = sp.expand(d.subs(_T, r0))
                if val != 0 and sp.count_ops(val) < 300:
                    val = sp.simplify(val)
            if not _is_zero(val):
                return False
    part, const, coeffs = info["_part"], info["_const"], info["_coeffs"]
    res = sp.expand(sum(coeffs[j] * sp.diff(part, z, j) for j in range(len(coeffs))) + const)
    return _is_zero(res)


def _bell_like(K, u):
    """B_0 = 1, B_{j+1} = u0 B_j + D(B_j), D u_i = u_{i+1}:  w^(j) = w B_j(u, u', ...) for u = w'/w"""
    B = [sp.Integer(1)]
    for j in range(K):
        prev = B[-1]
        d = sum(sp.diff(prev, u[i]) * u[i + 1] for i in range(K))
        B.append(sp.expand(u[0] * prev + d))
    return B


def _homogeneous_reduction(D):
    """If every monomial has the same degree n: E = w^n R(u, u', ...), u = w'/w.  Returns R."""
    degs = set(_deg(m) for m in D.terms)
    if len(degs) != 1:
        return None
    K = D.K
    u = sp.symbols("u0:%d" % (K + 1))
    B = [sp.Integer(1)]
    for j in range(K):
        prev = B[-1]
        d = sum(sp.diff(prev, u[i]) * u[i + 1] for i in range(K))
        B.append(sp.expand(u[0] * prev + d))
    R = sp.expand(sum(c * sp.Mul(*[B[j] ** e for j, e in enumerate(m)]) for m, c in D.terms.items()))
    return R, u


# ----------------------------------------------------------------------------------------------
# reduction to a linear equation (worker ENTIRE-2; lemmas/entire/project note, Lemmas LR and L)
# code basis: L-ENTIRE-LINRED
# ----------------------------------------------------------------------------------------------

_KAPPA = sp.Symbol("_kappa")


def _linred_shape(D, st):
    """Hypothesis (H0): n >= 2 and E_n = w0^(n-1) * Lambda, Lambda = sum_{j<=l} p_j w_j, l >= 2, p_l != 0
    (as an expression).  Returns the list [p_0, ..., p_l] or None.  (l = 0 is the pure power, l = 1 the
    first-order factor: both are treated by T-CLUNIE / L-ENTIRE-FACTOR.)"""
    n, K = st["n"], D.K
    if n < 2 or st["kind"] != "other":
        return None
    p = [sp.Integer(0)] * (K + 1)
    for m, c in st["top"].items():
        if m[0] == n and sum(m[1:]) == 0:
            p[0] = c
        elif m[0] == n - 1 and sum(m[1:]) == 1:
            p[list(m[1:]).index(1) + 1] = c
        else:
            return None
    l = max(j for j in range(K + 1) if p[j] != 0)
    if l < 2:
        return None
    return p[:l + 1]


def _linred_reduce(D, p, kappa, budget):
    """E modulo the linear equation P = sum_j p_j w_j + kappa = 0, cleared of the denominator p_l:
    returns (xs, S, W, Ered) with xs = (w0..w_{l-1}) the phase coordinates, S = sum_{j<l} p_j x_j + kappa,
    W = p_l * (derivative along P = 0) acting on polynomials in xs, and Ered = p_l^A * E|_{P = 0} (expanded
    polynomial in xs, kappa and the parameters).  Only ring operations: valid for all parameter values."""
    l = len(p) - 1
    xs = list(D.w[:l])
    pl = p[l]
    S = sum(p[j] * xs[j] for j in range(l)) + kappa

    def W(f):
        return sp.expand(pl * sum(sp.diff(f, xs[i]) * xs[i + 1] for i in range(l - 1)) - sp.diff(f, xs[l - 1]) * S)

    # w_j = N_j / p_l^{a_j}:  a_j = 0, N_j = x_j (j < l);  N_l = -S, a_l = 1;  N_{j+1} = W(N_j), a_{j+1} = a_j + 1
    N = list(xs) + [sp.expand(-S)]
    a = [0] * l + [1]
    for j in range(l + 1, D.K + 1):
        N.append(W(N[-1]))
        a.append(a[-1] + 1)
    A = max(sum(e * a[j] for j, e in enumerate(m)) for m in D.terms)
    Ered = sp.Integer(0)
    for m, c in D.terms.items():
        if budget is not None and budget.over():
            return None
        am = sum(e * a[j] for j, e in enumerate(m))
        Ered += c * pl ** (A - am) * sp.Mul(*[N[j] ** e for j, e in enumerate(m) if e])
    Ered = sp.expand(Ered)
    return xs, S, W, Ered, A


def _orbit_certificate(f, xs, W, budget):
    """f: a polynomial in xs = (x_0..x_{l-1}) with coefficients in Q[parameters].  Returns (g, j): a nonzero
    polynomial g in the single variable x_j (and the parameters) that lies in the ideal generated by
    f, W f, ..., W^{l-1} f over Q[parameters][xs] (resultants), or (None, None).  On a solution curve of the
    linear system inside {f = 0}, g(w^(j)(z)) = 0 identically, so w^(j) is constant and w is a polynomial.
    j = 0 is tried first."""
    l = len(xs)
    base = [sp.expand(f)]
    for _i in range(1, l):
        base.append(W(base[-1]))
    for target in range(l):
        polys = [q for q in base if q != 0]
        for j in range(l - 1, -1, -1):
            if j == target:
                continue
            x = xs[j]
            wx = [q for q in polys if q.has(x)]
            rest = [q for q in polys if not q.has(x)]
            if wx:
                wx.sort(key=lambda q: (sp.degree(q, x), sp.count_ops(q)))
                piv = wx[0]
                for q in wx[1:]:
                    if budget is not None and budget.over():
                        return None, None
                    rest.append(sp.expand(sp.resultant(piv, q, x)))
            polys = [q for q in rest if q != 0]
            if not polys:
                break
        if polys:
            polys.sort(key=sp.count_ops)
            return polys[0], target
    return None, None


def _simplest_coefficient(g, x, params):
    """a coefficient of g (as a polynomial in x) that is not identically zero, with the fewest parameter factors;
    returns (coefficient, list of its irreducible parameter factors)"""
    best = None
    for co in sp.Poly(g, x).coeffs():
        co = sp.expand(co)
        if co == 0:
            continue
        if co.is_number:
            return co, []
        fl = _maybe_vanishing_param_factors([co], params)
        key = (len(fl), sum(len(str(h)) for h in fl))
        if best is None or key < best[0]:
            best = (key, co, fl)
    if best is None:
        return None, None
    return best[1], best[2]


def _linear_reduction(D, st, budget):
    """Lemmas LR and L of project note.  Hypotheses: (H0) E_n = w0^(n-1)*Lambda, Lambda = sum_{j<=l} p_j w_j,
    l >= 2; (H1) for a constant kappa, E modulo P = Lambda + kappa (a polynomial R in w0..w_{l-1}) has total
    degree <= n-2.  Returns None when (H0) or (H1) fails; otherwise a dict with p, kappa, P, info and mode:
       "all"       R = 0: the transcendental entire solutions of E = 0 are those of P = 0
       "none"      no transcendental common solution of P = 0 and R = 0 (certificate: for every irreducible
                   factor f of R a nonzero polynomial g in one jet variable w_j in the ideal of f, Wf, W^2 f, ...),
                   under `nonzero`
       "undecided" every transcendental entire solution solves P = 0; which ones solve E = 0 is not decided
    `nonzero`: parameter expressions that must not vanish for the statement of `mode`."""
    p = _linred_shape(D, st)
    if p is None:
        return None
    n, l = st["n"], len(p) - 1
    info = {"p": [str(x) for x in p], "order": l, "n": n}
    nonzero = [p[l]] if not p[l].is_number else []
    red = _linred_reduce(D, p, _KAPPA, budget)
    if red is None:
        return None
    xs, _S0, _W0, E0, A = red
    if E0 == 0:
        return None
    terms0 = sp.Poly(E0, *xs).terms()
    topc = [sp.expand(c) for mon, c in terms0 if sum(mon) >= n - 1]
    kappa = None
    for c in topc:
        if c.has(_KAPPA):
            if sp.degree(c, _KAPPA) != 1:
                return None
            a1 = c.coeff(_KAPPA, 1)
            a0 = sp.expand(c - a1 * _KAPPA)
            kappa = _simp(-a0 / a1)
            for h in _maybe_vanishing_param_factors([a1], D.params):
                if not any(_same_up_to_sign(h, x) for x in nonzero):
                    nonzero.append(h)
            break
    if kappa is None:
        return None
    if not all(_is_zero(c.subs(_KAPPA, kappa)) for c in topc):
        return None                           # (H1) fails: E mod P has degree n-1 for every kappa
    kn, kd = sp.fraction(sp.together(kappa))
    kn, kd = sp.expand(kn), sp.expand(kd)
    R = sp.expand(_numer(E0.subs(_KAPPA, kappa)))
    if R != 0 and sp.Poly(R, *xs).total_degree() > n - 2:
        return None
    pl = p[l]
    S1 = sp.expand(kd * sum(p[j] * xs[j] for j in range(l)) + kn)

    def W(f):
        # kd * p_l * (derivative of f along the solutions of P = 0): a polynomial
        return sp.expand(kd * pl * sum(sp.diff(f, xs[i]) * xs[i + 1] for i in range(l - 1)) - sp.diff(f, xs[l - 1]) * S1)

    P = sum(p[j] * D.w[j] for j in range(l + 1)) + kappa
    sR = str(R)
    info.update({"lemma": "LR", "kappa": str(kappa), "P": str(P),
                 "hypothesis": "(H0) E_n = w0^(n-1)*Lambda with Lambda linear of order l >= 2; (H1) R = E modulo P "
                               "(a polynomial in w0..w_{l-1}) has total degree <= n-2",
                 "R": sR if len(sR) <= 4000 else sR[:4000] + " ...",
                 "R_degree": int(sp.Poly(R, *xs).total_degree()) if R != 0 else None,
                 "R_is": "numerator of p_l^A * E with w_l, w_{l+1}, ... eliminated by P = 0 (A = %d)" % A})
    out = {"lemma": "LR", "p": p, "kappa": kappa, "P": P, "info": info, "nonzero": nonzero, "mode": "undecided"}
    if R == 0:
        out["mode"] = "all"
        return out
    try:
        content, fl = sp.factor_list(R)
    except Exception:
        return out
    certs, extra = [], []
    for f, _mult in fl:
        if budget.over():
            return out
        if not (f.free_symbols & set(xs)):
            extra.append(f)                   # parameter factor of the content: R vanishes where it does
            continue
        g, jv = _orbit_certificate(f, xs, W, budget)
        co = cfl = None
        if g is not None:
            co, cfl = _simplest_coefficient(g, xs[jv], D.params)
        if g is None or co is None:
            info["factors"] = certs + [{"factor": str(f), "g": None}]
            return out
        sg = str(g)
        certs.append({"factor": str(f), "g": sg if len(sg) <= 4000 else sg[:4000] + " ...",
                      "g_variable": str(xs[jv]),
                      "g_degree": int(sp.degree(g, xs[jv])) if g.has(xs[jv]) else 0,
                      "nonzero_coefficient": str(sp.factor(co))})
        extra.extend(cfl)
    info["factors"] = certs
    info["content"] = str(content)
    for e in extra:
        if not any(_same_up_to_sign(e, h) for h in nonzero):
            nonzero.append(e)
    out["mode"] = "none"
    return out


def _first_integral_reduction(D, st, budget):
    """Lemma FI of project note (section 7).  Hypothesis: E = F(w0)*D(P) + r*F'(w0)*w1*P identically, with
    P = w_{K-1} + sum_{j<K-1} p_j w_j + kappa linear with constant coefficients, F a nonconstant polynomial in
    w0 alone and r a positive rational number.  Then F(w)^r * P[w] is constant along every solution, and every
    nonconstant entire solution satisfies P = 0 (all constants and all solutions of P = 0 are solutions).
    Returns None or a dict in the format of _linear_reduction with mode "all" (basis L-ENTIRE-FI)."""
    K, w = D.K, D.w
    if K < 2 or st["n"] < 2:
        return None
    E = sp.expand(D.E)
    if sp.degree(E, w[K]) != 1:
        return None
    F = sp.expand(E.coeff(w[K], 1))                      # normalisation: the coefficient of w_{K-1} in P is 1
    if (F.free_symbols & set(w[1:])) or not F.has(w[0]):
        return None
    dF = sp.diff(F, w[0])
    rest = sp.expand(E - F * w[K])
    if K >= 3:
        cf = sp.Poly(rest, w[1], w[K - 1]).coeff_monomial(w[1] * w[K - 1])
    else:
        cf = sp.Poly(rest, w[1]).coeff_monomial(w[1] ** 2)
    cf = sp.expand(cf)
    if cf == 0 or (cf.free_symbols & set(w[1:])):
        return None
    r = sp.cancel(cf / dF)
    if not (r.is_Rational and r > 0):
        return None
    if budget.over():
        return None
    qs = list(sp.symbols("_q0:%d" % (K - 1))) + [sp.Symbol("_qk")]         # p_0..p_{K-2}, kappa
    Psym = w[K - 1] + sum(qs[j] * w[j] for j in range(K - 1)) + qs[-1]
    DP = w[K] + sum(qs[j] * w[j + 1] for j in range(K - 1))
    resid = sp.expand(E - F * DP - r * dF * w[1] * Psym)
    eqs = [c for c in sp.Poly(resid, *w).coeffs() if c != 0] if resid != 0 else []
    try:
        sols = sp.solve(eqs, qs, dict=True) if eqs else [{}]
    except Exception:
        return None
    if not sols:
        return None
    sol = dict((q, _simp(sols[0].get(q, sp.Integer(0)))) for q in qs)
    p = [sol[qs[j]] for j in range(K - 1)] + [sp.Integer(1)]
    kappa = sol[qs[-1]]
    P = sum(p[j] * w[j] for j in range(K)) + kappa
    DPv = sum(p[j] * w[j + 1] for j in range(K))
    if not _is_zero(E - F * DPv - r * dF * w[1] * P):                         # the exact identity of the lemma
        return None
    nonzero = []
    lcF = sp.Poly(F, w[0]).LC()
    if not lcF.is_number:
        nonzero.append(lcF)
    for v in list(p) + [kappa]:
        den = sp.fraction(sp.together(v))[1]
        for h in _maybe_vanishing_param_factors([den], D.params):
            if not any(_same_up_to_sign(h, x) for x in nonzero):
                nonzero.append(h)
    info = {"lemma": "FI", "n": st["n"], "order": K - 1, "p": [str(x) for x in p], "kappa": str(kappa),
            "P": str(P), "F": str(F), "r": str(r), "R": "0",
            "first_integral": "(%s)**(%s) * (%s)**(%s)" % (F, r.p, P, r.q),
            "hypothesis": "E = F(w0)*D(P) + r*F'(w0)*w1*P identically (checked by expansion), F a nonconstant "
                          "polynomial in w0, r a positive rational number, P linear"}
    return {"lemma": "FI", "basis_id": "L-ENTIRE-FI", "p": p, "kappa": kappa, "P": P, "info": info,
            "nonzero": nonzero, "mode": "all"}


def _rossler_type(D, st):
    """Proposition R of project note (section 5).  Hypothesis: E = s*[D(U) + (c - M)*U + b] identically, with
    U = w2 - a*w1 + w0, M = w1 - a*w0 and s, a, b, c free of the jets (the equation of the component y of the
    Roessler system x' = -y - z, y' = x + a*y, z' = b + z*(x - c)).  Then the transcendental entire solutions
    are: the solutions of U = 0 if b = 0; C*exp(a*z) + b/a if a + b + c = 0 and a != 0;
    (b/K)*exp(a*z) + a*K*exp(-a*z) if 2*a^2 + 1 = 0, c = -a, b != 0; no others.
    The code uses the generic case only: returns {"a", "b", "c", "nonzero"} when b, a + b + c and 2*a^2 + 1 are
    not identically zero (then there is no transcendental entire solution where the three do not vanish),
    otherwise None."""
    if D.K != 3 or st["n"] != 2:
        return None
    w = D.w
    E = sp.expand(D.E)
    if sp.degree(E, w[3]) != 1:
        return None
    s_ = sp.expand(E.coeff(w[3], 1))
    if s_ == 0 or (s_.free_symbols & set(w)):
        return None
    PE = sp.Poly(E, *w)
    a = _simp(PE.coeff_monomial(w[0] ** 2) / s_)
    c = _simp(PE.coeff_monomial(w[0]) / s_)
    b = _simp(PE.coeff_monomial(1) / s_)
    U = w[2] - a * w[1] + w[0]
    model = s_ * (w[3] - a * w[2] + w[1] + (c - (w[1] - a * w[0])) * U + b)
    if not _is_zero(E - model):
        return None
    crit = [b, a + b + c, 2 * a ** 2 + 1]
    if any(_is_zero(x) for x in crit):
        return None
    nonzero = []
    for x in crit + [s_]:
        num, den = sp.fraction(sp.together(x))
        for h in _maybe_vanishing_param_factors([num, den], D.params):
            if not any(_same_up_to_sign(h, y) for y in nonzero):
                nonzero.append(h)
    return {"a": a, "b": b, "c": c, "s": s_, "nonzero": nonzero}


# ----------------------------------------------------------------------------------------------
# main entry
# ----------------------------------------------------------------------------------------------

def _jsonable(x):
    if isinstance(x, dict):
        return dict((str(k), _jsonable(v)) for k, v in x.items() if not str(k).startswith("_"))
    if isinstance(x, (list, tuple)):
        return [_jsonable(v) for v in x]
    if isinstance(x, (str, bool, int, float)) or x is None:
        return x
    return str(x)


def entire_solutions(eq, budget_s=30, N_max=4, deg_search=6, max_conds=3, strata_depth=1):
    """Entire solutions of E = 0: constants, polynomials, exponential sums, completeness.

    eq        : an Equation (CORE or bootstrap), a SymPy expression or a string in the jets w0, w1, ...
    budget_s  : time budget in seconds (time.monotonic(); a single SymPy call is not interrupted)
    N_max     : exponential sums sum_{k=-N1..N2} c_k exp(k lamda z) are searched for N1 + N2 <= N_max
    deg_search: polynomial degree searched when no degree bound is derived
    max_conds : parameter conditions per branch of the polynomial systems
    strata_depth: depth of the recursion into parameter values where the leading data degenerate
    Returns a JSON-ready dict (see the module docstring and lemmas/entire/project note)."""
    t_start = time.monotonic()
    D = _as_data(eq)
    var = sp.Symbol(getattr(D, "var", "z") or "z")
    if any(co.has(z) or co.has(var) for co in D.terms.values()):
        return {"schema": "mero-entire/1", "engine": ENGINE_TAG, "equation": str(D.E), "params": [str(p) for p in D.params],
                "constants": [], "polynomials": [], "exponentials": [], "implicit": [], "linear": None,
                "homogeneous": None, "complete": False, "complete_conditions": [], "basis": [], "growth": {},
                "ruled_out": [], "strata": [], "certificate": {},
                "not_decided": ["The equation contains the independent variable explicitly (not autonomous); "
                                "entire solutions are not treated."],
                "warnings": ["not autonomous: the coefficients contain %s" % var], "unsupported": "not autonomous",
                "elapsed_s": 0.0}
    out = _jsonable(_entire(D, budget_s, N_max, deg_search, max_conds, strata_depth))
    _final_check(D, out, deadline=t_start + 1.25 * float(budget_s) + 2.0)
    return out


def _final_check(D, out, deadline=None):
    """Re-check every listed Solution from its strings alone: parse `expr`, substitute `constants` (other
    than "free"), apply the conditions `name == value` in order, substitute into E, simplify.  A Solution
    with a condition that is not of that form goes to `implicit`; one that does not reduce to 0 goes to
    certificate.rejected.  Also: no free symbol may coincide with a symbol of the equation."""
    reserved = set(str(p) for p in D.params) | set(str(x) for x in D.w) | {"z"}
    rej = out["certificate"].setdefault("rejected", [])
    for key in ("constants", "polynomials", "exponentials"):
        keep = []
        for sol in out[key]:
            if deadline is not None and time.monotonic() > deadline:
                sol["certificate"]["string_check"] = "not run (time budget)"
                keep.append(sol)
                continue
            try:
                with _Guard(deadline if deadline is not None else time.monotonic() + 3600.0):
                    verdict = _check_strings(D, sol, reserved)
            except _Timeout:
                sol["certificate"]["string_check"] = "not run (time budget)"
                keep.append(sol)
                continue
            if verdict == "pass":
                keep.append(sol)
            elif verdict == "implicit":
                out["implicit"].append(sol)
            else:
                rej.append({"expr": sol["expr"], "conditions": sol["conditions"], "detail": "final check: " + verdict})
        out[key] = keep
    if rej:
        out["complete"] = False
        out["warnings"].append("%d candidate(s) failed a substitution check and are not listed" % len(rej))
        out["not_decided"].append("%d candidate solution(s) of the search failed the substitution check and were "
                                  "dropped (certificate.rejected); for the parameter values in their conditions the "
                                  "lists above may be incomplete." % len(rej))


def _check_strings(D, sol, reserved):
    import re
    if set(sol.get("free", [])) & reserved:
        return "a free symbol coincides with a symbol of the equation"
    loc = dict((str(p), p) for p in D.params)
    for f in sol.get("free", []):
        loc[f] = sp.Symbol(f)
    loc["z"] = z
    try:
        expr = sp.sympify(sol["expr"], locals=loc)
        for name, val in (sol.get("constants") or {}).items():
            if val == "free":
                continue
            if str(val).startswith("root of"):
                return "implicit"
            expr = expr.subs(sp.Symbol(name), sp.sympify(val, locals=loc))
        subs = []
        for c in sol.get("conditions", []):
            if "!=" in c or "distinct" in c:
                continue
            lhs, rhs = [x.strip() for x in c.split("==")]
            if not re.match(r"^[A-Za-z_][A-Za-z_0-9]*$", lhs):
                return "implicit"
            subs.append((loc.get(lhs, sp.Symbol(lhs)), sp.sympify(rhs, locals=loc)))
        E = D.E
        for a_, b_ in subs:
            expr = expr.subs(a_, b_)
            E = E.subs(a_, b_)
        res = E.subs(dict((D.w[j], sp.diff(expr, z, j)) for j in range(D.K + 1)))
        if sp.count_ops(res) <= 400:
            res = sp.expand(res)
            if res == 0:
                sol["certificate"]["string_check"] = "exact"
                return "pass"
            res = sp.expand(sp.powsimp(res))
            if res == 0 or sp.simplify(res) == 0:
                sol["certificate"]["string_check"] = "exact"
                return "pass"
            return "residual does not simplify to 0"
        # large residual: the exact certificate is the internal one (status pass); here only the string form
        # is checked, at random rational points with 60 digits
        return _numeric_spot_check(res, sol)
    except Exception as exc:
        return "not parsed (%s)" % type(exc).__name__


def _numeric_spot_check(res, sol, points=3):
    import random
    rnd = random.Random(20261006)
    syms = sorted(res.free_symbols - {z}, key=str)
    worst = 0
    for _ in range(points):
        vals = dict((x, sp.Rational(rnd.randint(-97, 97) or 1, rnd.randint(1, 13))) for x in syms)
        vals[z] = sp.Rational(rnd.randint(-30, 30), 17)
        try:
            v = sp.N(res.subs(vals), 60)
            scale = 1 + max([abs(sp.N(t.subs(vals), 30)) for t in sp.Add.make_args(sp.expand(res, deep=False))][:50])
        except Exception:
            return "numeric spot check failed to evaluate"
        if v.has(sp.zoo, sp.nan):
            continue
        worst = max(worst, abs(v) / scale)
    if worst < sp.Float("1e-40"):
        sol["certificate"]["string_check"] = "numeric spot check of the string form (60 digits, %d points)" % points
        return "pass"
    return "numeric spot check of the string form failed"


def _entire(eq, budget_s=30, N_max=4, deg_search=6, max_conds=3, strata_depth=1, _depth=0, _ids=None):
    budget = _Budget(budget_s)
    D = _as_data(eq)
    counter = _ids if _ids is not None else [0]

    def sol_id():
        counter[0] += 1
        return "e%d" % counter[0]

    out = {"schema": "mero-entire/1", "engine": ENGINE_TAG, "equation": str(D.E), "params": [str(p) for p in D.params],
           "constants": [], "polynomials": [], "exponentials": [], "linear": None, "homogeneous": None,
           "complete": False, "complete_conditions": [], "basis": [], "growth": {}, "ruled_out": [],
           "not_decided": [], "strata": [], "implicit": [], "certificate": {}, "warnings": []}
    if not D.terms:
        out["warnings"].append("E is identically zero")
        return out
    st = _structure(D)
    n = st["n"]
    cert = out["certificate"]
    cert["degree_n"] = n
    cert["tau"] = _disp(sp.factor(st["tau"]), D.params) if st["tau"] != 0 else "0"
    cert["s_lo"], cert["s_hi"] = st["s_lo"], st["s_hi"]
    cert["b_lo"], cert["b_hi"] = str(st["b_lo"]), str(st["b_hi"])
    cert["top_part"] = str(sp.Add(*[c * sp.Mul(*[D.w[j] ** e for j, e in enumerate(m)]) for m, c in st["top"].items()]))
    cert["top_kind"] = st["kind"]

    # (i) constants
    out["constants"], cert["constants"] = _constants(D, sol_id)
    out["implicit"].extend(cert["constants"].pop("_implicit", []))

    # linear equations: the general solution (classical)
    if n == 1:
        coeffs = [D.terms.get(tuple(1 if i == j else 0 for i in range(D.K + 1)), sp.Integer(0))
                  for j in range(D.K + 1)]
        const = D.terms.get((0,) * (D.K + 1), sp.Integer(0))
        g = _linear_general(D, coeffs, const)
        if g is not None:
            expr, free, info = g
            ok = _verify_linear(D, info, budget)
            lkind = "entire" if expr.has(sp.exp) else ("polynomial" if expr.has(z) else "constant")
            sol = _solution(sol_id(), lkind, expr, free, _denominator_conditions(expr, D.params, info["conditions"]),
                            d=None, constants=dict([(str(f), "free") for f in free] +
                                                   [(r, "root of " + gg) for r, gg in info.get("named_roots", {}).items()]),
                            cert={"type": "substitution", "method": "symbolic",
                                  "status": "pass" if ok else ("not-run" if ok is None else "fail"),
                                  "detail": "general solution of a linear equation with constant coefficients: "
                                            "chi^(k)(r) = 0 for k < multiplicity of each root r"
                                            + (" (modulo the polynomial of each named root)" if info["_named"] else "")
                                            + "; the particular solution checked by substitution"})
            out["linear"] = {"general_solution": sol, "info": info}
            if info.get("_named"):
                out["implicit"].append(sol)       # roots of chi not explicit: not a string-checkable Solution
            elif lkind == "constant":
                if not any(c["expr"] == sol["expr"] or c["free"] for c in out["constants"]):
                    out["constants"].append(sol)
            else:
                out["exponentials" if lkind == "entire" else "polynomials"].append(sol)
            out["complete"] = ok is True
            out["basis"] = ["L-LINEAR"]
            cert["linear"] = info
            out["ruled_out"].append({"what": "solutions other than the general solution",
                                     "basis": {"theorem": "L-LINEAR", "label": "certificate"},
                                     "conditions": list(info["conditions"])})
            out["complete_conditions"] = list(info["conditions"])
        else:
            out["not_decided"].append("Linear equation: the general solution is sum P_i(z) exp(lambda_i z) over the "
                                      "roots of %s." % _disp(sp.factor(sum(coeffs[j] * _T ** j for j in range(D.K + 1))),
                                                            D.params))
        _drop_failed(out)
        _dedupe_all(out)
        out["elapsed_s"] = round(time.monotonic() - budget.t0, 3)
        return out

    # homogeneous in the jets with a linear reduction: Lemma H
    hom = _homogeneous_reduction(D)
    hom_done = False
    if hom is not None:
        R, u = hom
        if R != 0 and sp.Poly(R, *u).total_degree() <= 1:
            Kr = max([j for j in range(D.K + 1) if R.has(u[j])] + [0])
            coeffs = [R.coeff(u[j], 1) for j in range(Kr + 1)]
            const = _simp(R - sum(coeffs[j] * u[j] for j in range(Kr + 1)))
            if all(c.is_number or not (c.free_symbols & set(u)) for c in coeffs):
                hnames = _Names(D.reserved)
                C0 = hnames.one("K")
                g = _linear_general(D, coeffs, const, prefix="K", names=hnames) if not budget.over() else None
                if g is not None:
                    uexpr, ufree, info = g
                    if len(ufree) == 1 and uexpr == ufree[0]:
                        lam_name = hnames.one("lamda", numbered=False)
                        uexpr, ufree = lam_name, [lam_name]
                    Iu = sp.integrate(uexpr, z, conds="none")
                    wexpr = C0 * sp.exp(Iu)
                    # exact certificate: (1) E(w B_0, ..., w B_K) = w^n R identically, (2) u solves R = 0,
                    # (3) d/dz Iu = u
                    W_ = sp.Symbol("_W")
                    Bs = _bell_like(D.K, u)
                    ident = sp.expand(D.E.subs(dict((D.w[j], W_ * Bs[j]) for j in range(D.K + 1))) - W_ ** n * R)
                    okl = _verify_linear(D, info, budget)
                    okd = _is_zero(sp.expand(sp.diff(Iu, z) - uexpr))
                    ok = (ident == 0) and okl and okd and not wexpr.has(sp.Piecewise)
                    if okl is None:
                        ok = None
                    kind = "constant" if not Iu.has(z) else ("simply-periodic" if not uexpr.has(z) else "entire")
                    sol = _solution(sol_id(), kind, wexpr, [C0] + ufree,
                                    _denominator_conditions(wexpr, D.params, info.get("conditions", []) + ["%s != 0" % C0]),
                                    d=1 if not (uexpr.free_symbols & {z}) and not uexpr.has(sp.exp) else None,
                                    constants=dict([(str(f), "free") for f in [C0] + ufree] +
                                                   [(r, "root of " + gg) for r, gg in info.get("named_roots", {}).items()]),
                                    cert={"type": "substitution", "method": "symbolic",
                                          "status": "pass" if ok else ("not-run" if ok is None else "fail"),
                                          "detail": "E = w^%d R(u) with u = w'/w (identity checked), and u = %s solves "
                                                    "the linear equation R = %s = 0" % (n, uexpr, R)})
                    out["homogeneous"] = {"reduced": str(R), "u": str(uexpr), "general_solution": sol}
                    if info.get("_named"):
                        out["implicit"].append(sol)
                    elif kind == "constant":
                        if not any(c["free"] for c in out["constants"]):
                            out["constants"].append(sol)
                    else:
                        out["exponentials"].append(sol)
                    out["complete"] = ok is True
                    out["basis"] = ["L-HOMLIN"]
                    out["complete_conditions"] = list(info["conditions"])
                    out["ruled_out"].append({"what": "meromorphic solutions other than w = 0 and w = %s*exp(int u)" % C0,
                                             "basis": {"theorem": "L-HOMLIN", "label": "agent-proof",
                                                       "source": "lemmas/entire/project note, Lemma H"},
                                             "conditions": list(info["conditions"])})
                    cert["homogeneous_reduction"] = {"R": str(R), "u_general": str(uexpr), "info": info}
                    hom_done = True
                    # cross-check: the exponential-sum search on its own
                    if not budget.over():
                        eb = budget.sub(0.5)
                        ex, einfo, esys, enotes = _safe_exp(D, _structure(D), eb, lambda: "x", max_conds, min(N_max, 2))
                        cert["exponential_search_crosscheck"] = {"found": [x["expr"] for x in ex],
                                                                 "free": [x["free"] for x in ex], "info": einfo}

    # growth: Wiman-Valiron (T-WV)
    growth = {"theorem": "T-WV", "tau": cert["tau"]}
    roots = None
    if st["tau"] != 0:
        try:
            with _Guard(min(budget.deadline, time.monotonic() + 0.1 * max(0.0, budget.left()) + 0.5)):
                roots = _nonzero_roots_tau(st["tau"])
        except _Timeout:
            roots = None                         # "not explicit"
    hi_ok = not _is_zero(st["b_hi"])
    lo_ok = not _is_zero(st["b_lo"])
    wv_conditions = []
    for bb in (st["b_hi"], st["b_lo"]):
        if not _is_zero(bb) and not bb.is_number:
            wv_conditions.append(_ne(bb))
    if hi_ok and lo_ok and st["s_lo"] == st["s_hi"]:
        growth["conclusion"] = "no transcendental entire solution"
        growth["applies"] = True
    elif hi_ok and lo_ok:
        growth["conclusion"] = "every transcendental entire solution has order 1; log M(r,w)/r has its limit points " \
                               "between the smallest and the largest modulus of the nonzero roots of tau"
        growth["nonzero_roots"] = [str(r) for r in roots] if roots is not None else "not explicit"
        growth["applies"] = True
    elif hi_ok:
        growth["conclusion"] = "every transcendental entire solution has order at most 1 and finite type " \
                               "(type at most the largest modulus of a root of tau)"
        growth["applies"] = True
    else:
        growth["conclusion"] = "no information (the monomials of the top degree with the most derivatives cancel in tau)"
        growth["applies"] = False
    growth["conditions"] = list(dict.fromkeys(x for x in wv_conditions if x))
    # the registry entry T-WV covers exactly one monomial of top degree; the rest is L-ENTIRE-WV (project note section 2)
    growth["theorem"] = "T-WV" if (len(st["top"]) == 1 and growth["conclusion"] == "no transcendental entire solution") \
        else "L-ENTIRE-WV"
    out["growth"] = growth

    # Clunie (T-CLUNIE)
    trans_excluded = False
    clunie_family = None
    cl_conditions = []
    if st["kind"] in ("pure-power", "first-order-factor"):
        if not st["c"].is_number:
            cl_conditions.append(_ne(st["c"]))
        if st["kind"] == "pure-power":
            trans_excluded = True
        else:
            rho = st["rho"]
            if _is_zero(rho):
                trans_excluded = True
            else:
                clunie_family = rho
                if not rho.is_number:
                    cl_conditions.append(_ne(rho))
    if growth.get("conclusion") == "no transcendental entire solution":
        trans_excluded = True
    cl_conditions = [x for x in cl_conditions if x]

    # reduction to a linear equation (project note, Lemmas LR and L; basis L-ENTIRE-LINRED)
    lin = None
    lin_mode = None
    lin_conditions = []
    lin_ok = False
    lin_src = {"theorem": "L-ENTIRE-LINRED", "label": "agent-proof", "source": "lemmas/entire/project note"}
    if not hom_done and not trans_excluded and clunie_family is None:
        lb = budget.sub(0.3)
        try:
            with _Guard(lb.deadline):
                lin = _linear_reduction(D, st, lb)
        except _Timeout:
            out["warnings"].append("reduction to a linear equation: time budget")
        except Exception as exc:
            out["warnings"].append("reduction to a linear equation failed (%s)" % type(exc).__name__)
        if lin is None and st["kind"] == "other":
            try:
                with _Guard(lb.deadline):
                    lin = _first_integral_reduction(D, st, lb)
            except _Timeout:
                out["warnings"].append("first-integral reduction: time budget")
            except Exception as exc:
                out["warnings"].append("first-integral reduction failed (%s)" % type(exc).__name__)
    # the Roessler-type equation (project note, Proposition R): generic case only
    ros = None
    ros_conditions = []
    if lin is None and not hom_done and not trans_excluded and clunie_family is None and st["kind"] == "other":
        try:
            ros = _rossler_type(D, st)
        except Exception as exc:
            out["warnings"].append("Roessler-type check failed (%s)" % type(exc).__name__)
        if ros is not None:
            ros_conditions = [x for x in (_ne(e) for e in ros["nonzero"]) if x]
            cert["rossler_type"] = {"a": str(ros["a"]), "b": str(ros["b"]), "c": str(ros["c"]), "s": str(ros["s"]),
                                    "identity": "E = s*[D(U) + (c - M)*U + b], U = w2 - a*w1 + w0, M = w1 - a*w0 "
                                                "(checked by expansion)",
                                    "conditions": list(ros_conditions),
                                    "statement": "no transcendental entire solution when b, a + b + c and "
                                                 "2*a**2 + 1 do not vanish (Proposition R)"}
            trans_excluded = True
    lin_id = "L-ENTIRE-LINRED"
    if lin is not None:
        lin_id = lin.get("basis_id", "L-ENTIRE-LINRED")
        lin_src = {"theorem": lin_id, "label": "agent-proof", "source": "lemmas/entire/project note"}
        cert["linear_reduction"] = lin["info"]
        lin_mode = lin["mode"]
        lin_conditions = [x for x in (_ne(e) for e in lin["nonzero"]) if x]
        lin["info"]["mode"] = lin_mode
        lin["info"]["conditions"] = list(lin_conditions)
        if lin_mode == "none":
            trans_excluded = True
        elif lin_mode == "all":
            g = None
            try:
                with _Guard(budget.deadline):
                    g = _linear_general(D, lin["p"], lin["kappa"])
                    okl = _verify_linear(D, g[2], budget) if g is not None else None
            except _Timeout:
                g = None
                out["warnings"].append("general solution of the linear equation P = 0: time budget")
            if g is not None:
                lexpr, lfree, linfo = g
                lkind = "entire" if lexpr.has(sp.exp) else ("polynomial" if lexpr.has(z) else "constant")
                lconds = _denominator_conditions(lexpr, D.params,
                                                 list(dict.fromkeys(list(linfo["conditions"]) + lin_conditions)))
                lsol = _solution(sol_id(), lkind, lexpr, lfree, lconds, d=None,
                                 constants=dict([(str(f), "free") for f in lfree] +
                                                [(r, "root of " + gg) for r, gg in linfo.get("named_roots", {}).items()]),
                                 cert={"type": "substitution", "method": "symbolic",
                                       "status": "pass" if okl else ("not-run" if okl is None else "fail"),
                                       "detail": "general solution of the linear equation P = %s = 0 (chi^(k)(r) = 0 for "
                                                 "k < multiplicity of each root r; particular solution substituted), "
                                                 "and E vanishes modulo P (certificate.linear_reduction.E_mod_P = 0)"
                                                 % lin["P"]})
                lin["info"]["general_solution"] = {"characteristic_polynomial": linfo["characteristic_polynomial"],
                                                   "roots": linfo["roots"], "named_roots": linfo["named_roots"],
                                                   "conditions": list(linfo["conditions"])}
                lin_conditions = list(dict.fromkeys(lin_conditions + list(linfo["conditions"])))
                if linfo.get("_named"):
                    out["implicit"].append(lsol)
                elif lkind == "entire":
                    out["exponentials"].append(lsol)
                elif lkind == "polynomial":
                    out["polynomials"].append(lsol)
                lin_ok = okl is True

    # (ii) polynomials
    pb = budget.sub(0.4)
    try:
        polys, pinfo, psys, pnotes = _poly_solutions(D, st, pb, sol_id, max_conds, deg_search)
    except Exception as exc:
        polys, pinfo, psys = [], {"derived": False, "error": "%s: %s" % (type(exc).__name__, str(exc)[:200])}, []
        pnotes = ["polynomial search failed (%s)" % type(exc).__name__]
    out["polynomials"] = list(out["polynomials"]) + polys
    cert["polynomial_degree_bound"] = pinfo
    cert["polynomial_systems"] = psys
    poly_complete = pinfo.get("derived", False) and pinfo.get("searched_up_to", -1) >= pinfo.get("bound", 0) \
        and not any(s["incomplete"] or s["conditions_truncated"] for s in psys)
    if pnotes:
        out["warnings"].extend(pnotes)

    # (iii) exponential sums
    if not hom_done:
        if trans_excluded:
            cert["exponential_search"] = {"skipped": "no transcendental entire solution (theorem)"}
        elif lin_mode == "all":
            cert["exponential_search"] = {"skipped": "%s: every transcendental entire solution solves "
                                                     "the linear equation P = %s = 0, and every solution of P = 0 "
                                                     "solves E = 0" % (lin_id, lin["P"])}
        elif clunie_family is not None:
            eb = budget.sub(0.6)
            ex, einfo, esys, enotes = _safe_exp(D, st, eb, sol_id, max_conds, 1, only_lambda=clunie_family)
            einfo["label"] = "certificate"
            einfo["note"] = "T-CLUNIE: every transcendental entire solution is C*exp(rho*z) + c0 with rho = %s" % clunie_family
            out["exponentials"] = ex
            cert["exponential_search"] = einfo
            cert["exponential_systems"] = esys
            out["warnings"].extend(enotes)
        elif st["tau"] != 0 and roots == []:
            cert["exponential_search"] = {"skipped": "tau has no nonzero root: no exponential sum (Lemma X)"}
        else:
            eb = budget.sub(0.8)
            ex, einfo, esys, enotes = _safe_exp(D, st, eb, sol_id, max_conds, N_max)
            out["exponentials"] = list(out["exponentials"]) + ex
            cert["exponential_search"] = einfo
            cert["exponential_systems"] = esys
            out["warnings"].extend(enotes)

    # completeness
    if hom_done:
        pass
    elif trans_excluded or clunie_family is not None:
        exp_ok = True
        if clunie_family is not None:
            esys = cert.get("exponential_systems", [])
            exp_ok = bool(esys) and not any(s["incomplete"] or s["conditions_truncated"] for s in esys)
        if poly_complete and exp_ok:
            out["complete"] = True
            if st["kind"] == "pure-power":
                out["basis"].append("T-CLUNIE")
            elif st["kind"] == "first-order-factor":
                out["basis"].append("L-ENTIRE-FACTOR")
            if growth.get("conclusion") == "no transcendental entire solution":
                out["basis"].append(growth["theorem"])
            if lin_mode == "none":
                out["basis"].append(lin_id)
            if ros is not None:
                out["basis"].append("L-ENTIRE-ROSSLER")
            out["complete_conditions"] = sorted(set(x for x in cl_conditions + (wv_conditions if growth["theorem"] in
                                                                                out["basis"] else [])
                                                    + (lin_conditions if lin_mode == "none" else [])
                                                    + ros_conditions
                                                    + pinfo.get("assumes", []) if x))
        if st["kind"] in ("pure-power", "first-order-factor"):
            what_m = "transcendental meromorphic solutions with finitely many poles" if trans_excluded else \
                "transcendental meromorphic solutions with finitely many poles other than C*exp(%s*z) + c0" % clunie_family
            # T-CLUNIE: Clunie's lemma plus one line (registry, published); L-ENTIRE-FACTOR: project note section 3(b)
            if st["kind"] == "pure-power":
                out["ruled_out"].append({"what": what_m, "basis": {"theorem": "T-CLUNIE", "label": "published"},
                                         "conditions": cl_conditions})
            else:
                out["ruled_out"].append({"what": what_m, "basis": {"theorem": "L-ENTIRE-FACTOR", "label": "agent-proof",
                                         "source": "lemmas/entire/project note, section 3(b)"},
                                         "conditions": cl_conditions})
        if growth.get("conclusion") == "no transcendental entire solution":
            out["ruled_out"].append({"what": "transcendental entire solutions",
                                     "basis": {"theorem": growth["theorem"],
                                               "label": "published" if growth["theorem"] == "T-WV" else "agent-proof"},
                                     "conditions": growth["conditions"]})
        if lin_mode == "none":
            out["ruled_out"].append({"what": "transcendental entire solutions (each of them would solve the linear "
                                             "equation %s = 0, and this equation has no transcendental solution "
                                             "in common with E = 0)" % lin["P"],
                                     "basis": dict(lin_src), "conditions": list(lin_conditions)})
        if ros is not None:
            out["ruled_out"].append({"what": "transcendental entire solutions",
                                     "basis": {"theorem": "L-ENTIRE-ROSSLER", "label": "agent-proof",
                                               "source": "lemmas/entire/project note, Proposition R"},
                                     "conditions": list(ros_conditions)})
        if not poly_complete:
            out["not_decided"].append(_poly_not_decided(pinfo))
    elif lin_mode == "all":
        if poly_complete and lin_ok:
            out["complete"] = True
            out["basis"].append(lin_id)
            out["complete_conditions"] = sorted(set(x for x in lin_conditions + pinfo.get("assumes", []) if x))
        out["ruled_out"].append({"what": "transcendental entire solutions other than the solutions of the linear "
                                         "equation %s = 0" % lin["P"],
                                 "basis": dict(lin_src), "conditions": [x for x in (_ne(e) for e in lin["nonzero"]) if x]})
        if not lin_ok:
            out["not_decided"].append("Every transcendental entire solution solves the linear equation %s = 0, and "
                                      "every solution of that equation solves E = 0 (%s); its general "
                                      "solution was not written out or not checked within the time budget."
                                      % (lin["P"], lin_id))
        if not poly_complete:
            out["not_decided"].append(_poly_not_decided(pinfo))
    else:
        g = growth["conclusion"]
        sent = "Transcendental entire solutions other than those listed are not decided."
        if growth["applies"]:
            if "order 1;" in g:
                mods = None
                if roots and all(sp.sympify(x).is_number for x in roots):
                    try:
                        mods = sorted(set(sp.nsimplify(sp.Abs(sp.sympify(x))) for x in roots), key=lambda v: float(v))
                    except Exception:
                        mods = None
                if mods and len(mods) == 1:
                    sent += " Any such solution has order 1 and type %s, the modulus of the nonzero roots of " \
                            "tau(t) = %s (%s)." % (mods[0], cert["tau"], growth["theorem"])
                elif mods:
                    sent += " Any such solution has order 1, and log M(r,w)/r has its limit points between %s and %s, " \
                            "the smallest and the largest modulus of the nonzero roots of tau(t) = %s (%s)." \
                            % (mods[0], mods[-1], cert["tau"], growth["theorem"])
                else:
                    sent += " Any such solution has order 1, and log M(r,w)/r has its limit points between the " \
                            "smallest and the largest modulus of the nonzero roots of tau(t) = %s (%s)." \
                            % (cert["tau"], growth["theorem"])
            else:
                sent += " Any such solution has order at most 1 and finite type (%s)." % growth["theorem"]
        else:
            sent += " The Wiman-Valiron argument gives no information here: the monomials of degree %d with the " \
                    "most derivatives cancel in tau(t) = %s." % (n, cert["tau"])
        if lin_mode == "undecided":
            sent += " Every transcendental entire solution solves the linear equation %s = 0 (L-ENTIRE-LINRED%s), " \
                    "hence is a sum of polynomials times exp(r*z) over the roots r of its characteristic polynomial; " \
                    "which of these solve E = 0 was not decided beyond the search below." \
                    % (lin["P"], "; conditions: " + ", ".join(lin_conditions) if lin_conditions else "")
        out["not_decided"].append(sent)
        if cert.get("exponential_search", {}).get("searched_shapes"):
            sh = cert["exponential_search"]["searched_shapes"]
            allsh = [x["exponents"] for x in cert.get("exponential_systems", [])]
            missing = [x for x in _exp_shapes(cert["exponential_search"]["N_max"])
                       if [x[0], x[1]] not in sh]
            out["not_decided"].append("Sums of c_k*exp(k*lamda*z) over k = -N1..N2 with constant coefficients were "
                                      "searched completely for the shapes (-N1, N2) in %s (search); %s"
                                      "sums with exponents outside one arithmetic progression, or with polynomial "
                                      "coefficients, were not searched."
                                      % ([(-l, h) for l, h in sh],
                                         ("the shapes %s were not completed (time budget); " % [(-l, h) for l, h in missing])
                                         if missing else ""))
        if not poly_complete:
            out["not_decided"].append(_poly_not_decided(pinfo))
    if pinfo.get("parameter_dependent_roots") or pinfo.get("parameter_dependent_factors"):
        out["not_decided"].append("Polynomial solutions of degree m > %s can exist only for parameter values at which "
                                  "Q_T(m) = %s has the positive integer root m; these values are not searched."
                                  % (pinfo.get("bound"), pinfo.get("Q_T")))
        if out["complete"]:
            out["complete_conditions"].append("Q_T(m) = %s has no positive integer root m > %s"
                                              % (pinfo.get("Q_T"), pinfo.get("bound")))

    # strata: parameter values at which the leading data degenerate.  The main record makes no claim on them
    # (factor != 0 goes to complete_conditions); each explored stratum carries its own verdict.
    facs = []
    if D.params:
        crit = list(st["top"].values()) + [st["b_lo"], st["b_hi"]]
        if st["c"] is not None:
            crit.append(st["c"])
        if st["rho"] is not None:
            crit.append(st["rho"])
        crit.append(sp.Poly(cert["constants"]["_poly"], _CV).LC()
                    if not cert["constants"].get("all_constants") else sp.Integer(1))
        if lin is not None and lin_mode in ("none", "all"):
            crit.extend(lin["nonzero"])
        if ros is not None:
            crit.extend(ros["nonzero"])
        facs = _maybe_vanishing_param_factors(crit, D.params)
        for g in facs:
            x = _ne(g)
            if x and x not in out["complete_conditions"]:
                out["complete_conditions"].append(x)
    if _depth < strata_depth and facs and not budget.over():
        for g in facs[:4]:
            if budget.left() < 0.5:
                out["warnings"].append("strata not explored: time budget")
                break
            ps = [p for p in D.params if g.has(p) and sp.degree(g, p) == 1]
            if not ps:
                continue
            p = sorted(ps, key=lambda q: (not sp.expand(g).coeff(q, 1).is_number, str(q)))[0]
            a = sp.expand(g).coeff(p, 1)
            val = _simp(-(sp.expand(g) - a * p) / a)
            terms2 = dict((m, _simp(c.subs(p, val))) for m, c in D.terms.items())
            D2 = _Data(D.K, D.w, [q for q in D.params if q != p], terms2, reserved=D.reserved)
            try:
                sub = _entire(D2, budget_s=max(0.5, budget.left() / (len(facs) + 1)), N_max=N_max,
                              deg_search=deg_search, max_conds=max_conds, strata_depth=strata_depth,
                              _depth=_depth + 1, _ids=counter)
            except Exception as exc:
                out["warnings"].append("stratum %s not analysed (%s)" % (_eqz(g), type(exc).__name__))
                continue
            cond = "%s == %s" % (p, val)          # the stratum, in the form name == value
            extra_ne = [] if a.is_number else [x for x in [_ne(a)] if x]
            for key in ("constants", "polynomials", "exponentials", "implicit"):
                generic = [(x["expr"], set(x["conditions"])) for x in out[key]]
                for s in sub[key]:
                    if any(e == s["expr"] and cs <= set(s["conditions"]) for e, cs in generic):
                        continue
                    s = dict(s)
                    s["conditions"] = [cond] + extra_ne + list(s["conditions"])
                    s["conditions_polynomial"] = [_eqz(g)] + list(s.get("conditions_polynomial", []))
                    s["stratum"] = cond
                    out[key].append(s)
            out["strata"].append({"conditions": [cond] + extra_ne, "substitution": {str(p): str(val)},
                                  "equation": sub["equation"], "complete": sub["complete"], "basis": sub["basis"],
                                  "complete_conditions": sub["complete_conditions"], "implicit": sub["implicit"],
                                  "constants": sub["constants"], "polynomials": sub["polynomials"],
                                  "exponentials": sub["exponentials"], "linear": sub["linear"],
                                  "not_decided": sub["not_decided"], "growth": sub["growth"]})
    _drop_failed(out)
    _dedupe_all(out)
    out["elapsed_s"] = round(time.monotonic() - budget.t0, 3)
    return out


def _dedupe_all(out):
    """the same expression with conditions that include those of an earlier item is dropped"""
    for key in ("constants", "polynomials", "exponentials", "implicit"):
        kept = []
        for sol in sorted(out[key], key=lambda x: len(x["conditions"])):
            if any(k["expr"] == sol["expr"] and set(k["conditions"]) <= set(sol["conditions"]) for k in kept):
                continue
            kept.append(sol)
        order = dict((id(x), i) for i, x in enumerate(out[key]))
        out[key] = sorted(kept, key=lambda x: order[id(x)])


def _drop_failed(out):
    """a Solution whose re-verification failed is never listed as found"""
    rej = out["certificate"].setdefault("rejected", [])
    for key in ("constants", "polynomials", "exponentials"):
        keep = []
        for s in out[key]:
            if s.get("certificate", {}).get("status") == "fail":
                rej.append({"expr": s["expr"], "conditions": s["conditions"], "detail": s["certificate"]["detail"]})
            else:
                keep.append(s)
        out[key] = keep
    if rej:
        out["complete"] = False
        out["warnings"].append("%d candidate(s) failed the substitution check and are not listed" % len(rej))
        out["not_decided"].append("%d candidate solution(s) of the search failed the substitution check and were "
                                  "dropped (certificate.rejected); the lists may be incomplete for the parameter "
                                  "values in their conditions." % len(rej))


def _poly_not_decided(pinfo):
    if not pinfo.get("derived"):
        return "Polynomial solutions: no degree bound (Q_T vanishes identically); searched up to degree %s (search)." \
               % pinfo.get("searched_up_to")
    return "Polynomial solutions of degree %s..%s were not searched (time budget)." \
           % (pinfo.get("searched_up_to", 0) + 1, pinfo.get("bound"))


if __name__ == "__main__":
    import json
    r = entire_solutions("w3 - 12*w0*w1 - alpha*w2 + 6*mu*w0**2 - gamma*w1 - delta*w0 - epsilon")
    print(json.dumps(r, indent=1, default=str)[:6000])
