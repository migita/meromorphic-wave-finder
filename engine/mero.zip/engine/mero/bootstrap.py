"""Reference implementation of the local (Laurent) analysis.  Small, slow, exact; SymPy only.

It fixes the data model and the function names that the rest of the engine uses.  The module
`mero.laurent` replaces it with a faster and more complete version and must keep these
names and return types.

Conventions (those of a project note): unknown w(z); the equation is solved for the highest
derivative,
        w_K = Phi(w0, ..., w_{K-1}),          w_j = d^j w / dz^j,
Phi a polynomial whose coefficients are rational numbers or symbolic parameters.  At a pole of order p,
        w = sum_{k>=0} c_k (z - z0)^(k-p),    c_0 = a0 != 0.
"""
import itertools
import sympy as sp

z = sp.Symbol("z")


def jet(K):
    """the symbols w0, ..., wK"""
    return sp.symbols("w0:%d" % (K + 1))


class Equation(object):
    """w_K = rhs(w0..w_{K-1}; parameters)."""

    def __init__(self, order, rhs, parameters=(), name=""):
        self.K = int(order)
        self.w = jet(self.K)
        loc = dict((str(s), s) for s in self.w)
        self.params = [sp.Symbol(str(q)) for q in parameters]
        loc.update(dict((str(s), s) for s in self.params))
        self.rhs = sp.expand(sp.sympify(rhs, locals=loc))
        self.name = name
        # E = w_K - rhs as a dict  monomial exponents (e_0..e_K) -> coefficient
        poly = sp.Poly(self.w[self.K] - self.rhs, *self.w)
        self.terms = dict((mon, sp.factor(co)) for mon, co in poly.terms())

    def __repr__(self):
        return "Equation(w%d = %s)" % (self.K, self.rhs)

    def residual(self, expr, var=z):
        """E[expr] for an explicit SymPy expression in `var` (not simplified)."""
        subs = dict((self.w[j], sp.diff(expr, var, j)) for j in range(self.K + 1))
        return (self.w[self.K] - self.rhs).subs(subs)


def ff(x, j):
    """falling factorial x (x-1) ... (x-j+1)"""
    r = sp.Integer(1)
    for i in range(j):
        r *= (x - i)
    return r


def weight(mon, p):
    """pole order of the monomial prod w_j^e_j on a pole of order p"""
    return sum(e * (p + j) for j, e in enumerate(mon))


def balances(eq, pmax=None):
    """Pole orders p = 1, 2, ... (integers) at which a pole is possible for generic parameters.

    Returns a list of dicts {p, W, top, leading_poly, a0}: W is the top weight, `top` the monomials of
    weight W, `leading_poly` the polynomial in a0 that must vanish (a0 != 0), `a0` its nonzero roots
    (a list of SymPy expressions, possibly RootOf / radicals).
    """
    a0 = sp.Symbol("a0")
    pmax = pmax or 2 * eq.K + 2
    out = []
    for p in range(1, pmax + 1):
        W = max(weight(m, p) for m in eq.terms)
        top = [m for m in eq.terms if weight(m, p) == W]
        if len(top) < 2:
            continue
        lead = sp.Integer(0)
        for m in top:
            term = eq.terms[m] * a0 ** sum(m)
            for j, e in enumerate(m):
                term *= ff(-p, j) ** e
            lead += term
        lead = sp.expand(lead)
        if len(sp.Add.make_args(lead)) <= 60 and len(str(lead)) <= 4000:   # a large factorisation can run for minutes
            lead = sp.factor(lead)
        red = sp.cancel(lead / a0 ** min(sum(m) for m in top))
        if red.is_number and red != 0:
            continue
        roots = [r for r in sp.roots(sp.Poly(sp.numer(sp.together(red)), a0), multiple=True)] \
            if sp.Poly(sp.numer(sp.together(red)), a0).degree() > 0 else []
        roots = [r for r in roots if r != 0]
        if not roots and sp.Poly(sp.numer(sp.together(red)), a0).degree() > 0:
            roots = [sp.CRootOf(sp.Poly(sp.numer(sp.together(red)), a0), i)
                     for i in range(sp.Poly(sp.numer(sp.together(red)), a0).degree())] \
                if not sp.Poly(sp.numer(sp.together(red)), a0).free_symbols - {a0} else []
        out.append({"p": p, "W": W, "top": top, "leading_poly": red, "a0": roots})
    return out


def _series_of_monomial(mon, coeffs, p, N):
    """coefficients (index 0..N) of z^(k - weight) in prod (d^j w)^e_j, w = sum coeffs[k] z^(k-p)."""
    res = [sp.Integer(1)] + [sp.Integer(0)] * N
    for j, e in enumerate(mon):
        if e == 0:
            continue
        dj = [ff(k - p, j) * coeffs[k] for k in range(N + 1)]
        for _ in range(e):
            new = [sp.Integer(0)] * (N + 1)
            for i1, c1 in enumerate(res):
                if c1 == 0:
                    continue
                for i2 in range(N + 1 - i1):
                    if dj[i2] != 0:
                        new[i1 + i2] += c1 * dj[i2]
            res = [sp.expand(c) for c in new]
    return res


def laurent(eq, p, a0, N, free_prefix="h"):
    """Formal Laurent series at a pole of order p with leading coefficient a0, up to index N.

    Returns a dict
      coeffs      : [c_0, ..., c_N]  (expressions in the parameters and in the free symbols h_k)
      indices     : the Fuchs indices that are integers in [-1, N] found on the way (k with no c_k)
      free        : {k: h_k} symbols introduced at those indices (k >= 1)
      conditions  : {k: expression} compatibility condition at each such index (must vanish)
      indicial    : the indicial polynomial I(k) (SymPy expression in the symbol k)
    Parameters are treated as generic; a coefficient that vanishes identically at a step marks a
    Fuchs index.
    """
    W = max(weight(m, p) for m in eq.terms)
    ck = sp.Symbol("c_k_unknown")
    coeffs = [sp.sympify(a0)] + [sp.Integer(0)] * N
    free, conds, idx = {}, {}, []
    for k in range(1, N + 1):
        trial = list(coeffs)
        trial[k] = ck
        tot = sp.Integer(0)
        for m, co in eq.terms.items():
            shift = W - weight(m, p)          # the monomial contributes z^(i - weight(m)) = z^((i+shift) - W)
            if k - shift < 0:
                continue
            ser = _series_of_monomial(m, trial, p, k - shift)
            tot += co * ser[k - shift]
        tot = sp.expand(tot)
        lin = sp.simplify(tot.coeff(ck, 1))
        rest = sp.simplify(tot.coeff(ck, 0))
        if lin == 0:
            idx.append(k)
            conds[k] = sp.factor(rest)
            h = sp.Symbol("%s%d" % (free_prefix, k))
            free[k] = h
            coeffs[k] = h
        else:
            coeffs[k] = sp.factor(sp.cancel(-rest / lin))
    kk = sp.Symbol("k")
    return {"coeffs": coeffs, "indices": idx, "free": free, "conditions": conds,
            "indicial": indicial(eq, p, a0, kk)}


def indicial(eq, p, a0, k=None):
    """Indicial polynomial of the top-weight part on a0 z^-p: its roots are the Fuchs indices."""
    k = k or sp.Symbol("k")
    W = max(weight(m, p) for m in eq.terms)
    I = sp.Integer(0)
    for m, co in eq.terms.items():
        if weight(m, p) != W:
            continue
        base = co * sp.sympify(a0) ** (sum(m) - 1)
        full = sp.Integer(1)
        for j, e in enumerate(m):
            full *= ff(-p, j) ** e
        for j, e in enumerate(m):
            if e == 0:
                continue
            I += base * e * full / ff(-p, j) * ff(k - p, j)
    return sp.factor(sp.expand(I))


if __name__ == "__main__":
    # self-test on the family (F) of a project note and on the Kuramoto-Sivashinsky reduction
    F = Equation(3, "12*w0*w1 + alpha*w2 - 6*mu*w0**2 + gamma*w1 + delta*w0 + epsilon",
                 ["alpha", "mu", "gamma", "delta", "epsilon"], "F")
    b = balances(F)
    assert [x["p"] for x in b] == [2] and b[0]["a0"] == [1], b
    L = laurent(F, 2, 1, 7)
    al, mu = sp.symbols("alpha mu")
    assert sp.simplify(L["coeffs"][1] - (al - mu) / 5) == 0
    assert L["indices"] == [4, 6], L["indices"]
    kk = sp.Symbol("k")
    assert sp.simplify(L["indicial"] / ((kk + 1) * (kk - 4) * (kk - 6))).is_number
    KS = Equation(3, "-a2*w2 - a1*w1 - a0*w0 - w0**2/2", ["a2", "a1", "a0"], "KS")
    bk = balances(KS)
    assert [x["p"] for x in bk] == [3] and bk[0]["a0"] == [120], bk
    Lk = laurent(KS, 3, 120, 8)
    assert Lk["indices"] == [], Lk["indices"]
    print("bootstrap self-test passed:", F, "| conditions at 4, 6:", L["conditions"][4], "...")
