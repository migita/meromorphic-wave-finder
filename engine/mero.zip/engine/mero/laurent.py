"""mero.laurent -- local analysis at a movable pole of an autonomous polynomial ODE  E(w0, ..., wK) = 0.

Public functions (project note section 1; the names and return conventions of mero.bootstrap are kept)

    balances(eq, pmax=None)            dominant balances with an integer pole order p >= 1
    all_balances(eq)                   the same together with the non-integer ones and the special cases
    indicial(eq, p, a0, k=None)        indicial polynomial of the dominant part (SymPy expression in k)
    laurent(eq, p, a0, N)              formal Laurent series: dict with coeffs, indices, free, conditions, indicial
    LaurentSeries(eq, p, a0)           the object behind `laurent`: .extend(N), .subs(params), .as_dict()
    local_analysis(eq, N=None)         the JSON-ready summary of project note
    series_count(L)                    number of series of a LaurentSeries object (generic parameters)

Conventions: w = sum_{k>=0} c_k z^(k-p), c_0 = a0 != 0.  The weight of a monomial prod w_j^e_j at pole order p is
sum e_j (p + j); W is the largest weight; the monomials of weight W are the dominant part.  The coefficient of
z^(k-W) in E[w] is   I(k) c_k + Q_k(c_0, ..., c_{k-1}),   I = the indicial polynomial.  If I(k) != 0 then
c_k = -Q_k / I(k).  If k is a positive integer root of I (a Fuchs index) then Q_k is the compatibility condition
(reported with the sign and normalisation it has as a coefficient of E) and c_k = h_k is a free symbol.

Parameters are treated as generic: "index" means a root of I for all parameter values, and a condition is
called identically zero if it vanishes as a polynomial in the parameters and the earlier free symbols.  What
changes on special parameter values is listed in `strata` by `local_analysis`.

Exact arithmetic.  All series coefficients, all values I(k) and all conditions live in a SymPy polynomial ring
(sympy.polys.rings) and every zero test is a test "this ring element is 0":
  * ground field K0 = QQ, or the number field QQ.algebraic_field(...) of the algebraic numbers that occur in
    the equation or in a0 (sqrt(6), I, ...: see mero.equation.algebraic_atoms);
  * mode 'polynomial' (equation polynomial in the parameters, indicial polynomial free of them):
    ring K0[a0?, h.., parameters] -- no fractions at all;
  * mode 'fraction-field': ring K0(parameters)[a0?, h..];
  * a leading coefficient that is algebraic over K0(parameters) is the ring generator a0 and everything is
    reduced modulo its minimal polynomial (one computation for all conjugate roots).

Only SymPy is used; no threads, signals or processes.

Time budget (`budget_s`).  Before every ring operation of the series engine (products, reductions modulo the
minimal polynomial, the rows of the inversion of I(k)) the deadline is checked and the cost of the operation
is estimated from the sizes of the operands; an operation that is predicted not to fit into the remaining time
is not started.  The computation then stops cleanly: what was computed stays valid, `truncated` /
`stopped_by` say so, and `extend` can be called again.  A single SymPy gcd cannot be interrupted, so the
budget can be exceeded by the duration of one operation (measured on the 47 symbolic type families of
project file: at most 3 % over a budget of 10 s).  The set-up (balances, indicial polynomial) and the
factorisations for display are bounded by size rules, not by the clock.
"""
import itertools
import json
import random
import sys
import time

import sympy as sp
from sympy.polys.rings import ring
from sympy.polys.domains import QQ
from sympy.polys.orderings import grevlex

from .equation import (Equation, jet, z, algebraic_atoms, algebraic_domain, check_algebraic,  # noqa: F401
                       exact_zero, exact_canonical, exact_ring)

__all__ = ["Equation", "jet", "z", "ff", "weight", "balances", "all_balances", "indicial", "laurent",
           "LaurentSeries", "DegenerateIndicial", "local_analysis", "series_count", "lead_symbol",
           "index_symbol"]


# ------------------------------------------------------------------------------------------ helpers
def ff(x, j):
    """falling factorial x (x-1) ... (x-j+1)"""
    r = sp.Integer(1)
    for i in range(j):
        r *= (x - i)
    return r


def weight(mon, p):
    """pole order of the monomial prod w_j^e_j on a pole of order p"""
    return sum(e * (p + j) for j, e in enumerate(mon))


def _fresh(candidates, taken):
    for c in candidates:
        if c not in taken:
            return sp.Symbol(c)
    c = candidates[0]
    while c in taken:
        c += "_"
    return sp.Symbol(c)


def lead_symbol(eq):
    """the symbol used for the leading coefficient (a0; A0 if a parameter is called a0)"""
    return _fresh(["a0", "A0", "a0_"], set(s.name for s in eq.params))


def index_symbol(eq):
    """the symbol used for the index in the indicial polynomial (k; kk if a parameter is called k)"""
    return _fresh(["k", "kk", "k_"], set(s.name for s in eq.params))


def _pstr(p):
    return str(p)


def _pval(p):
    """pole order as int if it is an integer, else a SymPy Rational"""
    p = sp.Rational(p) if not isinstance(p, sp.Basic) else p
    return int(p) if p.is_Integer else p


class _fixed_seed(object):
    """SymPy's multivariate factorisation draws random evaluation points, so its running time varies from
    run to run (occasionally by a factor of 100).  Inside this context the generator is seeded with a fixed
    value, and the caller's random state is restored afterwards."""

    def __enter__(self):
        self.state = random.getstate()
        random.seed(20261006)

    def __exit__(self, *exc):
        random.setstate(self.state)
        return False


def _factor(expr, atoms=(), limit=8000):
    """sp.factor for display, with guards on the size (over the number field of `atoms` if there are any):
    an expression that is large, or of moderate size with many symbols, is returned as it is"""
    try:
        ops = sp.count_ops(expr)
        if ops > limit or (ops > 250 and len(expr.free_symbols) > 6):
            return expr
        ats = set(atoms) | algebraic_atoms(expr)
        with _fixed_seed():
            if ats:
                if ops > 400:
                    return expr
                return sp.factor(expr, extension=list(ats))
            return sp.factor(expr)
    except Exception:
        return expr


def _factor_list(expr, atoms=(), gens=()):
    """(content, [(factor, multiplicity)]) over QQ or over the number field of the algebraic numbers present"""
    ats = set(atoms) | algebraic_atoms(expr)
    try:
        with _fixed_seed():
            if ats:
                return sp.factor_list(expr, extension=list(ats))
            return sp.factor_list(expr, *gens)
    except Exception:
        return sp.Integer(1), [(expr, 1)]


def _irreducible_by_specialisation(num, a0s):
    """True if the polynomial num (in a0s, integer polynomial coefficients in the parameters, primitive in
    a0s) is certainly irreducible over QQ(parameters): a specialisation of the parameters to integers that
    keeps the degree and is irreducible over QQ proves it.  False means "not decided".  Deterministic."""
    try:
        params = sorted(num.free_symbols - {a0s}, key=lambda s_: s_.name)
        deg = sp.Poly(num, a0s).degree()
        primes = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
        for shift in (0, 5):
            vals = dict((q, primes[(i + shift) % len(primes)] + (i // len(primes)) * 100)
                        for i, q in enumerate(params))
            spec = sp.Poly(num.subs(vals), a0s, domain="QQ")
            if spec.degree() == deg and deg >= 1:
                with _fixed_seed():
                    if spec.is_irreducible:
                        return True
    except Exception:
        pass
    return False


def _monomial_expr(eq, mon):
    r = sp.Integer(1)
    for j, e in enumerate(mon):
        if e:
            r *= eq.w[j] ** e
    return r


def _cancel(expr, atoms=()):
    """normal form of a rational function (exact over the number field if algebraic numbers occur)"""
    expr = sp.sympify(expr)
    if atoms or algebraic_atoms(expr):
        return exact_canonical(expr, atoms)
    return sp.cancel(expr)


def _expired(deadline):
    return deadline is not None and time.monotonic() > deadline


def _to_rational(q):
    """SymPy Rational from an element of the domain QQ (python, gmpy or flint ground types)"""
    return QQ.to_sympy(q)


def _qq_parts(c, dom0):
    """the coordinates of an element of the ground field in a QQ-basis: [(t, rational)] with rational != 0"""
    if dom0.is_QQ:
        return [(0, c)] if c else []
    try:
        lst = list(c.to_list())
    except AttributeError:               # older SymPy: ANP.rep is a list
        lst = list(c.rep)
    n = len(lst)
    return [(n - 1 - i, v) for i, v in enumerate(lst) if v]


def _qq_gcd_roots(polys, var, positive_integer=True):
    """common roots of polynomials in QQ[var] given as SymPy Poly objects: dict root -> multiplicity,
    restricted to positive integers (or to positive rationals)"""
    g = None
    for q in polys:
        if q.is_zero:
            continue
        g = q if g is None else sp.gcd(g, q)
        if g.degree() <= 0:
            return {}
    out = {}
    if g is None or g.degree() <= 0:
        return out
    for fac, mult in g.factor_list()[1]:
        if fac.degree() == 1:
            c1, c0 = fac.all_coeffs()
            r = -c0 / c1
            if r > 0 and (r.is_Integer or not positive_integer):
                key = int(r) if r.is_Integer else r
                out[key] = out.get(key, 0) + mult
    return out


# ------------------------------------------------------------------------------------------ balances
def _points(eq):
    """Newton points (degree, number of derivatives) -> monomials"""
    pts = {}
    for m in eq.terms:
        pts.setdefault((sum(m), sum(j * e for j, e in enumerate(m))), []).append(m)
    return pts


def _critical_orders(pts):
    """all p > 0 at which two distinct Newton points have the largest weight: [(p, W, [points])]"""
    P = list(pts)
    cands = set()
    for (d1, D1), (d2, D2) in itertools.combinations(P, 2):
        if d1 != d2:
            p = sp.Rational(D2 - D1, d1 - d2)
            if p > 0:
                cands.add(p)
    out = []
    for p in sorted(cands):
        W = max(p * d + D for d, D in P)
        top = [pt for pt in P if p * pt[0] + pt[1] == W]
        if len(top) >= 2:
            out.append((p, W, top))
    return out


def _leading(eq, p, tops, a0s):
    L = sp.Integer(0)
    for m in tops:
        t = eq.terms[m] * a0s ** sum(m)
        for j, e in enumerate(m):
            if e:
                t *= ff(-p, j) ** e
        L += t
    return L


def _root_classes(red, a0s, atoms=()):
    """classes of nonzero roots of the reduced leading polynomial `red` (a polynomial in a0s whose
    coefficients are rational functions of the parameters, possibly with algebraic numbers).

    Returns (classes, lead_factors): each class is a dict
        a0        the root (a number or a rational function of the parameters), or the symbol a0s
        minpoly   None, or the polynomial in a0s, irreducible over K0(parameters), of which a0s is a root
        degree    number of roots in the class        multiplicity   multiplicity as a root of `red`
        values    the roots written explicitly (radicals, CRootOf) or None
    lead_factors: the factors free of a0s (their vanishing changes the picture).
    classes is None if `red` vanishes identically."""
    num = sp.numer(sp.together(red))
    atoms = set(atoms) | algebraic_atoms(num)
    if atoms:
        if exact_zero(num, atoms):
            return None, []
        num = sp.numer(sp.together(exact_canonical(num, atoms)))
    else:
        num = sp.expand(num)
        if num == 0:
            return None, []
    P = sp.Poly(num, a0s)
    if P.degree() <= 0:
        return [], []
    facs = None
    if not atoms and P.degree() >= 2 and len(num.free_symbols) >= 4 and not P.eval(0) == 0:
        # many parameters: a multivariate factorisation is slow and of varying duration; a polynomial that
        # is irreducible after a specialisation of the parameters is irreducible, and that is the usual case
        try:
            content, prim = P.primitive()
            if _irreducible_by_specialisation(prim.as_expr(), a0s):
                facs = [(prim.as_expr(), 1)] + ([(sp.sympify(content), 1)] if sp.sympify(content).free_symbols
                                               else [])
        except Exception:
            facs = None
    if facs is None:
        cont, facs = _factor_list(num, atoms, gens=(a0s,))
    classes, lead = [], []
    for fac, mult in facs:
        if not fac.has(a0s):
            lead.append(fac)
            continue
        Pf = sp.Poly(fac, a0s)
        d = Pf.degree()
        if Pf.is_monomial:           # the root a0 = 0 is excluded
            continue
        if d == 1:
            c1, c0 = Pf.all_coeffs()
            root = _cancel(-c0 / c1, atoms)
            classes.append({"a0": root, "minpoly": None, "degree": 1, "multiplicity": mult,
                            "values": [root]})
            continue
        values = None
        try:
            if d == 2:
                rs = sp.roots(Pf)
                values = []
                for r, mm in rs.items():
                    values.extend([r] * mm)
                if len(values) != 2:
                    values = None
            elif not (fac.free_symbols - {a0s}) and not atoms:
                values = [sp.CRootOf(Pf, i) for i in range(d)]
        except Exception:
            values = None
        lc = Pf.LC()
        if lc.is_number and lc.is_real and lc < 0:
            fac = -fac
        classes.append({"a0": a0s, "minpoly": sp.expand(fac), "degree": d, "multiplicity": mult,
                        "values": values})
    if P.LC().free_symbols:
        lead.append(_factor(P.LC(), atoms))
    return classes, lead


def _leading_reduced(eq, p, tops, a0s):
    """the leading polynomial divided by the lowest power of a0, in normal form"""
    L = _leading(eq, p, tops, a0s)
    dmin = min(sum(m) for m in tops)
    return _cancel(sp.expand(L) / a0s ** dmin, eq.alg_numbers)


def _balance_record(eq, p, W, tops, a0s, kind):
    red = _leading_reduced(eq, p, tops, a0s)
    classes, lead = _root_classes(red, a0s, eq.alg_numbers)
    rec = {"p": _pval(p), "W": _pval(W), "top": sorted(tops, reverse=True),
           "leading_poly": _factor(red, eq.alg_numbers), "a0_symbol": a0s, "kind": kind,
           "degenerate": classes is None, "lead_factors": lead}
    if classes is None:
        # the leading polynomial vanishes identically: the dominant terms do not determine a0
        rec["classes"] = [{"a0": a0s, "minpoly": None, "degree": None, "multiplicity": None, "values": None,
                           "free": True}]
        rec["a0"] = []
    else:
        rec["classes"] = classes
        vals = []
        for c in classes:
            if c["values"]:
                vals.extend(c["values"])
        rec["a0"] = vals
    return rec


def _vertex_roots(cV, psym, atoms):
    """positive rational roots p of a polynomial in p with numerical (rational or algebraic) coefficients,
    and its other positive real roots when the coefficients are rational: (rational roots, irrational roots)"""
    if not atoms:
        try:
            rts = sp.roots(sp.Poly(cV, psym))
        except Exception:
            rts = {}
        rat = [r for r in rts if r.is_Rational and r > 0]
        irr = [r for r in rts if not r.is_Rational and r.is_real and r > 0]
        return rat, irr
    R = exact_ring([psym], atoms)
    P = R.from_expr(sp.expand(cV))
    comps = {}
    for mon, co in P.terms():
        for t, v in _qq_parts(co, R.domain):
            comps.setdefault(t, sp.Integer(0))
            comps[t] += _to_rational(v) * psym ** mon[0]
    polys = [sp.Poly(c, psym, domain="QQ") for c in comps.values()]
    return list(_qq_gcd_roots(polys, psym, positive_integer=False)), []


def all_balances(eq, pmax=None):
    """Every dominant balance with pole order p > 0.

    Returns a dict
      'poles'        balances with integer p that have a nonzero leading coefficient (list of records)
      'branches'     balances with non-integer p (algebraic branch points, not poles)
      'empty'        orders p at which two or more monomials have the largest weight but the leading polynomial
                     has no nonzero root (no pole of that order)
      'special'      conditions on the parameters under which a further balance appears (cancellation inside
                     one Newton point):  {'p': integer, 'condition': expression that must vanish, 'terms': ...}
    A record has the keys p, W, top (monomials of weight W), leading_poly (in the symbol a0_symbol, divided by
    the lowest power of a0), a0 (the nonzero roots that can be written explicitly), classes (see
    _root_classes), degenerate (True if the leading polynomial vanishes identically: a0 is not determined
    by the dominant terms and is kept as a free symbol)."""
    a0s = lead_symbol(eq)
    pts = _points(eq)
    pmax = pmax or 2 * eq.K + 2
    atoms = eq.alg_numbers
    out = {"poles": [], "branches": [], "empty": [], "special": []}
    if not pts:
        return out
    crit = _critical_orders(pts)
    for p, W, top_pts in crit:
        tops = [m for pt in top_pts for m in pts[pt]]
        rec = _balance_record(eq, p, W, tops, a0s, "edge")
        if not rec["degenerate"] and not rec["classes"]:
            out["empty"].append(rec)
        elif p.is_Integer:
            out["poles"].append(rec)
        else:
            out["branches"].append(rec)
    # cancellation inside a single Newton point (a vertex of the polygon) at a non-critical order
    ps = [c[0] for c in crit]
    bounds = [sp.Integer(0)] + ps + [None]
    psym = sp.Symbol("p", positive=True)
    for i in range(len(bounds) - 1):
        lo, hi = bounds[i], bounds[i + 1]
        sample = (lo + hi) / 2 if hi is not None else lo + 1
        Wm = max(sample * d + D for d, D in pts)
        top = [pt for pt in pts if sample * pt[0] + pt[1] == Wm]
        if len(top) != 1 or len(pts[top[0]]) < 2:
            continue
        mons = pts[top[0]]
        if top[0][0] == 0:
            continue
        cV = sp.Integer(0)
        for m in mons:
            t = eq.terms[m]
            for j, e in enumerate(m):
                if e:
                    t *= ff(-psym, j) ** e
            cV += t
        cV = sp.expand(cV)
        if exact_zero(cV, atoms):
            out["special"].append({"p": None, "condition": sp.Integer(0), "terms": mons,
                                   "note": "the terms cancel at leading order for every pole order in (%s, %s)"
                                           % (lo, "oo" if hi is None else hi)})
            continue
        in_range = lambda r: r > lo and (hi is None or r < hi)
        if not (cV.free_symbols - {psym}):
            rat, irr = _vertex_roots(cV, psym, atoms)
            for r in irr:
                if in_range(r):
                    out["branches"].append({"p": r, "W": r * top[0][0] + top[0][1], "top": mons,
                                            "leading_poly": sp.Integer(0), "a0_symbol": a0s, "kind": "vertex",
                                            "degenerate": True, "classes": [], "a0": [], "lead_factors": []})
            for r in rat:
                if not in_range(r):
                    continue
                r = sp.Rational(r)
                rec = {"p": _pval(r), "W": _pval(r * top[0][0] + top[0][1]), "top": sorted(mons, reverse=True),
                       "leading_poly": sp.Integer(0), "a0_symbol": a0s, "kind": "vertex", "degenerate": True,
                       "lead_factors": [],
                       "classes": [{"a0": a0s, "minpoly": None, "degree": None, "multiplicity": None,
                                    "values": None, "free": True}], "a0": []}
                (out["poles"] if r.is_Integer else out["branches"]).append(rec)
        else:
            q = int(sp.floor(lo)) + 1
            while q <= pmax and (hi is None or q < hi):
                cond = cV.subs(psym, q)
                if not exact_zero(cond, atoms) and cond.free_symbols:
                    out["special"].append({"p": q, "condition": _factor(cond, atoms), "terms": mons,
                                           "condition_in_p": _factor(cV, atoms)})
                q += 1
    out["poles"].sort(key=lambda r: r["p"])
    return out


def balances(eq, pmax=None):
    """Pole orders p = 1, 2, ... at which a pole is possible for generic parameters.

    Returns a list of dicts with the keys of mero.bootstrap.balances
        p, W, top, leading_poly, a0 (list of the nonzero roots, SymPy expressions)
    and, in addition, a0_symbol, classes, degenerate, kind (see all_balances).  Balances with non-integer p
    (branch points) are not in this list; use all_balances or local_analysis for them."""
    res = all_balances(eq, pmax)["poles"]
    if pmax:
        res = [r for r in res if r["p"] <= pmax]
    return res


# ------------------------------------------------------------------------------------------ indicial polynomial
def indicial(eq, p, a0, k=None, minpoly=None, factor=True):
    """Indicial polynomial of the top-weight part on a0 z^-p: its roots are the Fuchs indices.

    a0 may be a number, an expression in the parameters or the symbol of the leading coefficient; with
    `minpoly` (a polynomial in that symbol) the result is reduced modulo it."""
    k = k or index_symbol(eq)
    a0 = sp.sympify(a0)
    W = max(weight(m, p) for m in eq.terms)
    I = sp.Integer(0)
    for m, co in eq.terms.items():
        if weight(m, p) != W:
            continue
        base = co * a0 ** (sum(m) - 1)
        for j, e in enumerate(m):
            if e == 0:
                continue
            full = sp.Integer(1)
            for i, ei in enumerate(m):
                full *= ff(-p, i) ** (ei - (1 if i == j else 0))
            I += base * e * full * ff(k - p, j)
    I = sp.expand(I)
    if minpoly is not None and isinstance(a0, sp.Symbol):
        I = sp.expand(sp.rem(sp.together(I), minpoly, a0)) if I != 0 else I
    if not factor:
        return I
    return _factor(I, eq.alg_numbers)


def _index_roots(I_expr, ksym, params, positive, values, depends, a0s=None, minpoly=None, atoms=(), degree=0):
    """what is shown about the roots of the indicial polynomial.  The positive integer roots (`positive`),
    the values I(j) at the integers that are not roots (`values`) and the flag `depends` come from exact ring
    arithmetic; this function only factorises for the display.  I_expr is None when the polynomial is too
    large to factorise.  Returns a dict with
       roots (list of SymPy expressions or strings, with multiplicity), positive, depends (True if a root
       depends on the parameters), special (list of {'k', 'condition'}: parameter conditions under which the
       integer k becomes an index), degree."""
    out = {"roots": [], "positive": dict(positive), "depends": bool(depends), "special": [], "degree": degree}
    pos_list = []
    for r in sorted(positive):
        pos_list.extend([sp.Integer(r)] * positive[r])
    try:
        if I_expr is None:
            raise ValueError("the indicial polynomial is large")
        num = sp.expand(sp.numer(sp.together(I_expr)))
        Pk = sp.Poly(num, ksym)
        out["degree"] = Pk.degree()
        roots = []
        cont, facs = _factor_list(num, atoms, gens=(ksym,))
        for fac, mult in facs:
            if not fac.has(ksym):
                continue
            Pf = sp.Poly(fac, ksym)
            d = Pf.degree()
            if d == 1:
                c1, c0 = Pf.all_coeffs()
                roots.extend([_cancel(-c0 / c1, atoms)] * mult)
            elif d == 2:
                try:
                    rs = sp.roots(Pf)
                except Exception:
                    rs = {}
                got = []
                for r, mm in rs.items():
                    got.extend([r] * mm)
                if len(got) == 2:
                    roots.extend(got * mult)
                else:
                    roots.extend(["RootOf(%s, %s)" % (fac, ksym)] * (2 * mult))
            elif not (fac.free_symbols - {ksym}) and not algebraic_atoms(fac):
                roots.extend([sp.CRootOf(Pf, i) for i in range(d)] * mult)
            else:
                roots.extend(["RootOf(%s, %s)" % (fac, ksym)] * (d * mult))

        def keyf(r):
            if isinstance(r, str):
                return (3, 0, r)
            if r.is_Rational:
                return (0, r, "")
            if r.is_number:
                try:
                    c = complex(r)
                    return (1, c.real, "%+.12f" % c.imag)
                except Exception:
                    return (2, 0, str(r))
            return (2, 0, str(r))
        roots.sort(key=keyf)
        out["roots"] = roots
    except Exception as err:          # the display data are not essential
        out["roots"] = [sp.Integer(-1)] + pos_list
        rest = out["degree"] - len(out["roots"])
        if rest > 0:
            out["roots"] += ["%d further root(s) of the indicial polynomial (not factorised)" % rest]
        out["note"] = "roots not listed in closed form (%s)" % err
    pset = set(params)
    for j, val in sorted(values.items()):
        try:
            val = sp.numer(sp.together(val))
            if a0s is not None and minpoly is not None and val.has(a0s):
                if len(val.free_symbols | minpoly.free_symbols) > 5 or sp.count_ops(val) > 200:
                    continue
                val = sp.resultant(val, minpoly, a0s)
            ops = sp.count_ops(val)
            if val == 0 or not (val.free_symbols & pset) or ops > 1500 \
                    or (ops > 250 and len(val.free_symbols) > 6):
                continue
            fl = [f for f, _ in _factor_list(val, atoms)[1] if f.free_symbols & pset]
            cond = sp.Mul(*[(-f if f.could_extract_minus_sign() else f) for f in fl])
            out["special"].append({"k": j, "condition": cond})
        except Exception:
            continue
    return out


# ------------------------------------------------------------------------------------------ the series
class DegenerateIndicial(ValueError):
    """the indicial polynomial vanishes identically at this (p, a0): the linear recursion does not apply"""


class _Stop(Exception):
    """internal: the time budget or the size limit stops the computation of the current coefficient"""

    def __init__(self, reason):
        Exception.__init__(self, reason)
        self.reason = reason


# cost of one ring operation, in "pairs of terms" (see LaurentSeries._esize), and what it means in seconds
_UNIT_POLY = 2e-6          # polynomial arithmetic: predictable
_UNIT_FRAC = 5e-5          # arithmetic in a fraction field (a gcd at every operation): a rough upper estimate
SOFT_COST_POLY = 200000    # largest single operation accepted for the coefficients beyond the last index
SOFT_COST_FRAC = 3000
ELIMINATION_LIMIT = 600    # total size of the conditions above which no Groebner basis is attempted


class LaurentSeries(object):
    """Formal Laurent series of E = 0 at a pole of integer order p with leading coefficient a0.

    a0: a rational or algebraic number (radicals, I), an expression in the parameters, or the symbol of the
    leading coefficient (see lead_symbol) together with `minpoly` (if `minpoly` is omitted and the leading
    polynomial has exactly one irreducible factor of degree >= 2, that factor is used; if the leading polynomial
    vanishes identically, a0 stays a free symbol).

    Attributes after extend(N):
      N           last index computed            truncated   True if extend() stopped before the requested
                                                             index (time budget or size limit; see stopped_by)
      coeffs      [c_0, ..., c_N] SymPy expressions in the parameters, the free symbols h_k (and the a0 symbol)
      free        {k: h_k}                       conditions  {k: Q_k}: each must vanish for the series to exist
      indices     positive integer Fuchs indices <= N (generic parameters)
      indicial    the indicial polynomial (factorised), index_data: its roots and what depends on the parameters
      mode        'polynomial' or 'fraction-field';   ground   the ground field (QQ or a number field)
    """

    def __init__(self, eq, p, a0, minpoly=None, free_prefix="h", budget_s=None, factor=True,
                 index_bound=12):
        p = sp.Rational(p) if not isinstance(p, int) else sp.Integer(p)
        if not (p.is_Integer and p > 0):
            raise ValueError("LaurentSeries: the pole order must be a positive integer (got %s)" % p)
        self.eq = eq
        self.p = int(p)
        self.free_prefix = free_prefix
        self.factor = factor
        self.params = list(eq.params)
        self.atoms = set(eq.alg_numbers)
        self.a0_symbol = lead_symbol(eq)
        self.k_symbol = index_symbol(eq)
        self.W = max(weight(m, self.p) for m in eq.terms)
        self.tops = [m for m in eq.terms if weight(m, self.p) == self.W]
        self.truncated = False
        self.stopped_by = None
        self.N = 0
        self.a0_value = None
        deadline = None if budget_s is None else time.monotonic() + budget_s
        self._deadline = None          # the set-up is not interrupted; the budget applies to extend()
        self._cost_limit = None
        self._classify_a0(a0, minpoly)
        self._setup(index_bound)
        self._deadline = deadline
        self._expr_cache = {}
        self._cond_cache = {}

    # ---------------------------------------------------------------- the leading coefficient
    def _classify_a0(self, a0, minpoly):
        a0s = self.a0_symbol
        red = _leading_reduced(self.eq, self.p, self.tops, a0s)
        self.leading_poly = red
        self.a0_free = False
        self.minpoly = None
        if isinstance(a0, str):
            if a0 == a0s.name:
                a0 = a0s
            else:
                from .parse import parse_jet_expression
                a0 = parse_jet_expression(a0)
        a0 = sp.sympify(a0)
        if a0.has(sp.Float):
            raise ValueError("LaurentSeries: a0 must be exact")
        if isinstance(minpoly, str):
            from .parse import parse_jet_expression
            minpoly = parse_jet_expression(minpoly)
        pset = set(self.params)
        if a0 == a0s or minpoly is not None:
            classes, _ = _root_classes(red, a0s, self.atoms)
            if classes is None:
                self.a0, self.a0_free = a0s, True
                return
            if minpoly is None:
                nonlin = [c for c in classes if c["minpoly"] is not None]
                if len(nonlin) != 1:
                    raise ValueError("LaurentSeries: the leading polynomial %s does not have exactly one "
                                     "irreducible factor of degree >= 2; pass minpoly=" % red)
                minpoly = nonlin[0]["minpoly"]
            minpoly = sp.sympify(minpoly)
            if isinstance(minpoly, sp.Poly):
                minpoly = minpoly.as_expr()
            self.a0, self.minpoly = a0s, sp.expand(minpoly)
            self.atoms |= algebraic_atoms(self.minpoly)
            if not exact_zero(sp.rem(sp.numer(sp.together(red)), self.minpoly, a0s), self.atoms):
                raise ValueError("LaurentSeries: %s does not divide the leading polynomial %s"
                                 % (self.minpoly, red))
            return
        if a0 == 0:
            raise ValueError("LaurentSeries: a0 must be nonzero")
        if not (a0.free_symbols <= pset):
            raise ValueError("LaurentSeries: a0 = %s contains symbols that are not parameters" % a0)
        check_algebraic(a0)
        self.atoms |= algebraic_atoms(a0)
        if not exact_zero(red.subs(a0s, a0), self.atoms):
            raise ValueError("LaurentSeries: a0 = %s is not a root of the leading polynomial %s (p = %d)"
                             % (a0, red, self.p))
        self.a0 = _cancel(a0, self.atoms)

    # ---------------------------------------------------------------- rings
    def _make_ring(self, hs):
        a0s = self.a0_symbol
        gens = []
        if self._a0_gen:
            gens.append(a0s)
        gens += hs
        gens += self.poly_params
        fld = list(self.field_params) + ([a0s] if self.a0_free else [])
        dom = self.ground.frac_field(*fld) if fld else self.ground
        if not gens:
            gens = [sp.Symbol("_unit_")]
        R = ring(gens, dom)[0]
        self.R = R
        self._frac = bool(getattr(dom, "is_FractionField", False))
        self._unit = _UNIT_FRAC if self._frac else _UNIT_POLY
        self._gens = dict((g, R.gens[i]) for i, g in enumerate(gens))
        self._gen_order = list(gens)
        self._fring = None
        self._jet, self._prod, self._inv, self._cond, self._Ik_cache = {}, {}, {}, {}, {}
        if self._a0_gen:
            f = R.from_expr(self.minpoly)
            # make it monic in a0 (a0 is the first generator: its leading term carries the highest power)
            deg = max(m[0] for m in f.keys())
            lead = [(m, c) for m, c in f.terms() if m[0] == deg]
            if len(lead) != 1 or any(lead[0][0][1:]):
                raise ValueError("LaurentSeries: the minimal polynomial %s is not monic in %s over the "
                                 "coefficient field (mode %s)" % (self.minpoly, a0s, self.mode))
            self._fring = f.mul_ground(dom.quo(dom.one, lead[0][1]))
            self._fdeg = deg
            self._fsize = len(self._fring) if not getattr(dom, "is_FractionField", False) else \
                sum(len(c_.numer) + len(c_.denom) for c_ in self._fring.values())
        self._c = [R.from_expr(self.a0)]
        self._a0pow = {0: R.one, 1: self._c[0]}
        # coefficients A_j of the indicial polynomial  I(k) = sum_j A_j ff(k - p, j)
        self._mons, need, A = [], set(), {}
        p = self.p
        for m, co in self.eq.terms.items():
            T = tuple(j for j, e in enumerate(m) for _ in range(e))
            shift = self.W - weight(m, p)
            cr = R.from_expr(co)
            self._mons.append((m, cr, int(shift), T))
            if shift == 0 and T:
                for L in range(2, len(T) + 1):
                    need.add(T[:L])
                for j in set(T):
                    num = m[j]
                    for i, ei in enumerate(m):
                        num *= self._ff(-p, i) ** (ei - (1 if i == j else 0))
                    A[j] = A.get(j, R.zero) + cr * self._a0power(len(T) - 1) * num
        self._A = dict((j, self._red(v)) for j, v in A.items())
        self._top_keys = sorted(need, key=lambda t: (len(t), t))

    def _setup(self, index_bound):
        eq = self.eq
        a0s, k = self.a0_symbol, self.k_symbol
        pset = set(self.params)
        self._ffp = {}
        symbolic_a0 = (self.a0 == a0s)
        self._a0_gen = symbolic_a0 and not self.a0_free
        # parameters that must be invertible (they occur in a denominator, in the dominant terms -- hence in
        # the indicial polynomial -- in a0 or in its minimal polynomial) go to the fraction field; the others
        # are polynomial generators
        fset = set()
        for co in eq.terms.values():
            fset |= sp.denom(sp.together(co)).free_symbols & pset
        for m in self.tops:
            fset |= eq.terms[m].free_symbols & pset
        if self._a0_gen:
            fset |= self.minpoly.free_symbols & pset
        elif not symbolic_a0:
            fset |= self.a0.free_symbols & pset
        if len(fset) >= 2 and len(pset) <= 5:
            # with two or more parameters in the fraction field and few parameters in all, measured timings
            # are better when all parameters are coefficients (few ring terms with large fractions) than
            # when the ring has many terms with small fractions; with many parameters the gcd in the large
            # fraction field is prohibitive, and only the parameters that must be inverted go there
            fset = set(pset)
        self.field_params = [q for q in self.params if q in fset]
        self.poly_params = [q for q in self.params if q not in fset]
        if not self.field_params and not self.a0_free:
            self.mode = "polynomial"
        elif not self.poly_params:
            self.mode = "fraction-field"
        else:
            self.mode = "mixed"
        self.ground = algebraic_domain(self.atoms)
        # positive integer Fuchs indices for generic parameters: exact, from the ring without free symbols
        self._make_ring([])
        if not any(self._A.values()):
            raise DegenerateIndicial(
                "the indicial polynomial vanishes identically at p = %d, a0 = %s: the linearisation of the "
                "dominant terms is zero there (a0 is a multiple root of the leading polynomial %s), so the "
                "coefficients are not determined by a linear recursion" % (self.p, self.a0, self.leading_poly))
        self.positive_indices = self._positive_indices()
        taken = set(s.name for s in self.params) | {a0s.name, k.name}
        self.free = {}
        for kk in sorted(self.positive_indices):
            self.free[kk] = _fresh(["%s%d" % (self.free_prefix, kk), "%s%d" % (self.free_prefix.upper(), kk),
                                    "%s%d_" % (self.free_prefix, kk)], taken)
        if self.free:
            self._make_ring([self.free[kk] for kk in sorted(self.free)])
        self._free_idx = [i for i, g in enumerate(self._gen_order) if g in set(self.free.values())]
        # the indicial polynomial as an expression: its coefficients come from the ring (exact, reduced
        # modulo the minimal polynomial of a0)
        R = self.R
        ks = sp.Symbol("k_")
        C = {}
        for j, Aj in self._A.items():
            for i, sji in enumerate(reversed(sp.Poly(ff(ks - self.p, j), ks).all_coeffs())):
                if sji:
                    C[i] = C.get(i, R.zero) + Aj * int(sji)
        C = dict((i, v) for i, v in C.items() if v)
        deg = max(C) if C else 0
        I = sp.Add(*[v.as_expr() * k ** i for i, v in sorted(C.items())])
        self._I = I
        small = sp.count_ops(I) <= 600
        self.indicial = _factor(I, self.atoms) if (self.factor and small) else I
        # does a root depend on the parameters?  (is some coefficient not a constant multiple of the leading one)
        depends = False
        if self.params and C:
            lead = C[deg]
            mon0, c0 = next(iter(lead.terms()))
            for i, v in C.items():
                if i == deg:
                    continue
                q = v.get(mon0, R.domain.zero) / c0 if c0 else None
                isnum = q is not None and (not getattr(R.domain, "is_FractionField", False)
                                           or (q.numer.is_ground and q.denom.is_ground))
                if not isnum or (v - lead.mul_ground(q)):
                    depends = True
                    break
        values = {}
        if depends:
            for j in range(1, index_bound + 1):
                if j not in self.positive_indices:
                    values[j] = self._Ik(j).as_expr()
        self.index_data = _index_roots(I if small else None, k, self.params, self.positive_indices, values,
                                       depends, a0s if self.minpoly is not None else None, self.minpoly,
                                       self.atoms, deg)

    def _positive_indices(self):
        """{k: multiplicity} for the positive integers k with I(k) = 0 identically.  The coefficients A_j are
        expanded in a QQ-basis (monomials in the ring generators and in the parameters, powers of the
        primitive element of the number field); k is a root iff it is a root of every coordinate, which is
        a polynomial in QQ[k]."""
        dom = self.R.domain
        dom0 = self.ground
        entries = [(j, mon, co) for j, Aj in self._A.items() for mon, co in Aj.terms()]
        if not entries:
            return {}
        comps = {}
        if dom is not dom0 and getattr(dom, "is_FractionField", False):
            dens = []
            for _, _, co in entries:
                if co.denom not in dens:
                    dens.append(co.denom)
            for j, mon, co in entries:
                n = co.numer
                for d_ in dens:
                    if d_ != co.denom:
                        n = n * d_
                for nu, c0 in n.terms():
                    for t, v in _qq_parts(c0, dom0):
                        key = (mon, nu, t)
                        comps.setdefault(key, {})
                        comps[key][j] = comps[key].get(j, 0) + v
        else:
            for j, mon, co in entries:
                for t, v in _qq_parts(co, dom0):
                    comps.setdefault((mon, (), t), {})[j] = v
        ks = sp.Symbol("k")
        polys = []
        seen = set()
        for comp in comps.values():
            expr = sp.Integer(0)
            for j, v in comp.items():
                expr += _to_rational(v) * ff(ks - self.p, j)
            expr = sp.expand(expr)
            if expr != 0 and expr not in seen:
                seen.add(expr)
                polys.append(sp.Poly(expr, ks, domain="QQ"))
        return _qq_gcd_roots(polys, ks)

    def indicial_value(self, kval):
        """I(k) at an integer k (SymPy expression in the parameters and, possibly, the a0 symbol); exact"""
        return self._Ik(int(kval)).as_expr()

    # ---------------------------------------------------------------- ring arithmetic
    def _conv(self, expr):
        return self.R.from_expr(sp.sympify(expr))

    def _esize(self, x):
        """size of a ring element: its number of terms; over a fraction field, the number of terms of all
        numerators and denominators"""
        if not self._frac:
            return len(x)
        n = 0
        for co in x.values():
            n += len(co.numer) + len(co.denom)
        return n

    def _guard(self, cost=0):
        """called before every ring operation that can be expensive: stops (exception _Stop) if the time
        budget is used up, if the operation is predicted not to fit into what is left of it, or if it is
        larger than the size limit in force"""
        lim = self._cost_limit
        if lim is not None and cost > lim:
            raise _Stop("size")
        dl = self._deadline
        if dl is not None:
            left = dl - time.monotonic()
            if left < 0 or cost * self._unit > left:
                raise _Stop("time")

    def _mul(self, a, b):
        """a*b with the guard"""
        if self._deadline is not None or self._cost_limit is not None:
            self._guard(self._esize(a) * self._esize(b))
        return a * b

    def _red(self, x):
        if self._fring is not None and x:
            if self._deadline is not None or self._cost_limit is not None:
                self._guard(self._esize(x) * self._fsize)
            return x.rem(self._fring)
        return x

    def _a0power(self, n):
        if n not in self._a0pow:
            self._a0pow[n] = self._red(self._a0power(n - 1) * self._c[0])
        return self._a0pow[n]

    def _ff(self, x, j):
        key = (x, j)
        if key not in self._ffp:
            r = 1
            for i in range(j):
                r *= (x - i)
            self._ffp[key] = r
        return self._ffp[key]

    def _jetc(self, j, i):
        """coefficient of z^(i-p-j) in the j-th derivative"""
        key = (j, i)
        v = self._jet.get(key)
        if v is None:
            f = self._ff(i - self.p, j)
            v = self._c[i] * f if f != 1 else self._c[i]
            self._jet[key] = v
        return v

    def _final(self, T, n):
        """coefficient of index n of the product of the jets in T (all c_0..c_n known)"""
        if len(T) == 1:
            return self._jetc(T[0], n)
        d = self._prod.setdefault(T, {})
        v = d.get(n)
        if v is None:
            A, jl = T[:-1], T[-1]
            s = self.R.zero
            for i in range(n + 1):
                a = self._final(A, i)
                if not a:
                    continue
                b = self._jetc(jl, n - i)
                if not b:
                    continue
                s += self._mul(a, b)
            v = self._red(s)
            d[n] = v
        return v

    def _lin_number(self, T, k):
        """the integer lam with  [c_k] (prod of the jets in T)_k = lam * a0^(len(T)-1)"""
        p = self.p
        tot = 0
        for i, ji in enumerate(T):
            t = self._ff(k - p, ji)
            for l, jl in enumerate(T):
                if l != i:
                    t *= self._ff(-p, jl)
            tot += t
        return tot

    def _Ik(self, k):
        """I(k) as a ring element (exact)"""
        v = self._Ik_cache.get(k)
        if v is None:
            v = self.R.zero
            for j, Aj in self._A.items():
                f = self._ff(k - self.p, j)
                if f:
                    v += Aj * f
            v = self._red(v)
            self._Ik_cache[k] = v
        return v

    def _ring_inverse(self, u):
        """1/u for an element u of the coefficient field of the series: the ground field of the ring, or
        that field extended by a0 (linear algebra on the basis 1, a0, ..., a0^(d-1))"""
        R = self.R
        dom = R.domain
        zero_mon = R.zero_monom
        if self._fring is None:
            terms = list(u.terms())
            if len(terms) != 1 or terms[0][0] != zero_mon:
                raise ArithmeticError("the element %s is not in the coefficient field" % u.as_expr())
            return R.ground_new(dom.quo(dom.one, terms[0][1]))
        D = self._fdeg
        a0g = R.gens[0]
        frac = self._frac
        guarded = self._deadline is not None or self._cost_limit is not None

        def fs(c):
            return (len(c.numer) + len(c.denom)) if frac else 1

        def check(x, y):
            if guarded:
                self._guard(fs(x) * fs(y))

        def vec(x):
            v = [dom.zero] * D
            for mon, co in x.terms():
                if any(mon[1:]):
                    raise ArithmeticError("the element %s is not in the coefficient field" % x.as_expr())
                v[mon[0]] = co
            return v
        cols = []
        b = u
        for _ in range(D):
            cols.append(vec(b))
            b = self._red(self._mul(b, a0g))
        M = [[cols[i][r] for i in range(D)] + [dom.one if r == 0 else dom.zero] for r in range(D)]
        for col in range(D):
            piv = None
            for r in range(col, D):
                if M[r][col]:
                    piv = r
                    break
            if piv is None:
                raise ArithmeticError("the element %s is not invertible modulo %s" % (u.as_expr(), self.minpoly))
            M[col], M[piv] = M[piv], M[col]
            inv = dom.quo(dom.one, M[col][col])
            row = []
            for x in M[col]:
                if x:
                    check(x, inv)
                    x = x * inv
                row.append(x)
            M[col] = row
            for r in range(D):
                if r != col and M[r][col]:
                    fct = M[r][col]
                    new_row = []
                    for x, y in zip(M[r], M[col]):
                        if y:
                            check(fct, y)
                            t = fct * y
                            check(x, t)
                            x = x - t
                        new_row.append(x)
                    M[r] = new_row
        res = R.zero
        for i in range(D):
            if M[i][D]:
                res += R.ground_new(M[i][D]) * a0g ** i
        return res

    def _inverse(self, k):
        v = self._inv.get(k)
        if v is None:
            v = self._ring_inverse(self._Ik(k))
            self._inv[k] = v
        return v

    # ---------------------------------------------------------------- the recursion
    def _step(self, k):
        """computes c_k (and the condition Q_k at an index); nothing is stored before the step is complete,
        so that a stop (time or size) leaves the series as it was"""
        R = self.R
        mul = self._mul
        pend = {}
        for T in self._top_keys:
            A, jl = T[:-1], T[-1]
            s = R.zero
            for i in range(1, k):
                a = self._final(A, i)
                if not a:
                    continue
                b = self._jetc(jl, k - i)
                if not b:
                    continue
                s += mul(a, b)
            if len(A) >= 2:
                pa = pend[A]
                if pa:
                    s += mul(pa, self._jetc(jl, 0))
            pend[T] = self._red(s)
        Q = R.zero
        for m, co, shift, T in self._mons:
            n = k - shift
            if n < 0:
                continue
            d = len(T)
            if d == 0:
                if n == 0:
                    Q += co
            elif shift == 0:
                if d >= 2:
                    v = pend[T]
                    if v:
                        Q += mul(co, v)
            else:
                v = self._final(T, n)
                if v:
                    Q += mul(co, v)
        Q = self._red(Q)
        is_index = k in self.positive_indices
        if is_index:
            ck = self._gens[self.free[k]]
        else:
            if not self._Ik(k):          # cannot happen: the positive integer roots were found exactly
                raise ArithmeticError("indicial polynomial vanishes at k = %d" % k)
            ck = self._red(mul(-Q, self._inverse(k))) if Q else R.zero
        newprod = {}
        for T in self._top_keys:
            lam = self._lin_number(T, k)
            v = pend[T]
            if lam and ck:
                v = self._red(v + mul(self._a0power(len(T) - 1), ck) * lam)
            newprod[T] = v
        # commit
        if is_index:
            self._cond[k] = Q
        self._c.append(ck)
        for T, v in newprod.items():
            self._prod.setdefault(T, {})[k] = v
        return True

    def step_cost(self, k):
        """a deterministic estimate (in pairs of terms) of the largest operation of the step k"""
        worst = 0
        c = self._c
        sizes = [self._esize(x) for x in c]
        big = max(sizes) if sizes else 1
        for T in self._top_keys:
            worst = max(worst, big * big * max(1, len(T) - 1))
        if not worst:
            worst = big
        if self._fring is not None and self._frac:
            worst = max(worst, (self._fdeg ** 2) * self._esize(self._Ik(k)) ** 2)
        return worst

    def extend(self, N, budget_s=None, cost_limit=None):
        """compute the coefficients up to index N (keeps what is already known); returns self.

        budget_s    time budget for this call (replaces the budget given to the constructor)
        cost_limit  largest single ring operation accepted, in pairs of terms (None: no limit)
        If the computation stops early, truncated is True, stopped_by is 'time' or 'size', N is the last
        index that was completed, and everything computed so far stays valid."""
        if budget_s is not None:
            self._deadline = time.monotonic() + budget_s
        self._cost_limit = cost_limit
        self.truncated = False
        self.stopped_by = None
        try:
            while self.N < N:
                self._guard(0)
                if cost_limit is not None and self.step_cost(self.N + 1) > cost_limit:
                    raise _Stop("size")
                self._step(self.N + 1)
                self.N += 1
        except _Stop as stop:
            self.truncated = True
            self.stopped_by = stop.reason
        finally:
            self._cost_limit = None
        return self

    # ---------------------------------------------------------------- output
    def _to_expr(self, x, pretty=True):
        """SymPy expression of a ring element.  In the polynomial mode the whole polynomial is factorised
        (when that is cheap); otherwise the expression is a polynomial in the ring generators whose
        coefficients (elements of the fraction field, in lowest terms) are factorised one by one."""
        if not (pretty and self.factor) or _expired(self._deadline):
            return x.as_expr()
        # factorisation is for display: only for expressions of moderate size (a deterministic rule)
        if self.mode == "polynomial":
            return _factor(x.as_expr(), self.atoms) if len(x) <= 150 else x.as_expr()
        if len(x) > 40:
            return x.as_expr()
        if len(x) == 1 and not self.atoms:
            e = x.as_expr()
            return _factor(e) if sp.count_ops(e) < 1500 else e
        dom = self.R.domain
        frac = getattr(dom, "is_FractionField", False)
        syms = self._gen_order
        out = []
        for mon, co in x.terms():
            mono = sp.Mul(*[g ** e for g, e in zip(syms, mon) if e])
            if frac:
                num, den = co.numer.as_expr(), co.denom.as_expr()
                if not self.atoms:
                    if sp.count_ops(num) < 250:
                        num = sp.factor(num)
                    if sp.count_ops(den) < 250:
                        den = sp.factor(den)
                out.append(num / den * mono)
            else:
                out.append(dom.to_sympy(co) * mono)
        return sp.Add(*out)

    def coeff(self, k):
        """c_k as a SymPy expression"""
        if k not in self._expr_cache:
            self._expr_cache[k] = self._to_expr(self._c[k], pretty=(k > 0))
        return self._expr_cache[k]

    def condition(self, k):
        """the compatibility condition Q_k as a SymPy expression (factorised when that is cheap)"""
        if k not in self._cond_cache:
            self._cond_cache[k] = self._to_expr(self._cond[k])
        return self._cond_cache[k]

    @property
    def coeffs(self):
        return [self.coeff(k) for k in range(self.N + 1)]

    @property
    def conditions(self):
        return dict((k, self.condition(k)) for k in sorted(self._cond))

    @property
    def indices(self):
        return sorted(k for k in self.positive_indices if k <= self.N)

    def condition_is_zero(self, k):
        """True if Q_k vanishes identically (in the parameters and the free symbols); exact"""
        return not self._cond[k]

    def condition_involves_free(self, k):
        """True if Q_k contains one of the free symbols h_j"""
        return any(mon[i] for mon in self._cond[k].keys() for i in self._free_idx)

    def as_dict(self):
        """the dict returned by `laurent` (keys of mero.bootstrap.laurent and more)"""
        return {"coeffs": self.coeffs, "indices": self.indices,
                "free": dict((k, h) for k, h in self.free.items() if k <= self.N),
                "conditions": self.conditions, "indicial": self.indicial,
                "p": self.p, "a0": self.a0,
                "a0_symbol": self.a0_symbol, "a0_minpoly": self.minpoly, "W": self.W, "N": self.N,
                "truncated": self.truncated, "all_indices": list(self.index_data["roots"]),
                "index_multiplicities": dict(self.positive_indices), "mode": self.mode,
                "ground": self.ground, "series": self}

    def series(self, var=z, N=None):
        """the truncated series as a SymPy expression in `var`"""
        N = self.N if N is None else min(N, self.N)
        return sp.Add(*[self.coeff(k) * var ** (k - self.p) for k in range(N + 1)])

    def subs(self, params_dict, N=None, budget_s=None):
        """the series of the specialised equation eq.subs(params_dict) at the same pole order and the
        specialised leading coefficient (recomputed: a specialisation can create new indices)"""
        eq2 = self.eq.subs(params_dict)
        d = dict((sp.Symbol(str(kk)), sp.sympify(v)) for kk, v in params_dict.items())
        if self.minpoly is not None:
            a0, mp = lead_symbol(eq2), sp.expand(self.minpoly.subs(d)).subs(self.a0_symbol, lead_symbol(eq2))
        elif self.a0_free:
            a0, mp = lead_symbol(eq2), None
        else:
            a0, mp = self.a0.subs(d), None
        L = LaurentSeries(eq2, self.p, a0, minpoly=mp, free_prefix=self.free_prefix, budget_s=budget_s,
                          factor=self.factor)
        return L.extend(self.N if N is None else N)

    def residual_check(self, N=None):
        """independent check: the coefficients of z^(k-W), k = 0..N, of E[series] computed by plain
        polynomial arithmetic on the truncated series; returns the list of the nonzero ones as (k, value)
        after the conditions are taken into account (a condition index contributes its condition)."""
        N = self.N if N is None else min(N, self.N)
        bad = []
        R = self.R
        saved, self._deadline = self._deadline, None       # a check is not subject to the time budget
        try:
            return self._residual_check(N, bad, R)
        finally:
            self._deadline = saved

    def _residual_check(self, N, bad, R):
        for k in range(N + 1):
            tot = R.zero
            for m, co, shift, T in self._mons:
                n = k - shift
                if n < 0:
                    continue
                if len(T) == 0:
                    if n == 0:
                        tot += co
                    continue
                ser = [self._jetc(T[0], i) for i in range(n + 1)]
                for jl in T[1:]:
                    new = [R.zero] * (n + 1)
                    for i1, c1 in enumerate(ser):
                        if not c1:
                            continue
                        for i2 in range(n + 1 - i1):
                            c2 = self._jetc(jl, i2)
                            if c2:
                                new[i1 + i2] += c1 * c2
                    ser = [self._red(x) for x in new]
                tot += co * ser[n]
            tot = self._red(tot)
            if k in self._cond:
                tot = tot - self._cond[k]
            if tot:
                bad.append((k, tot.as_expr()))
        return bad


def laurent(eq, p, a0, N, free_prefix="h", minpoly=None, budget_s=None, factor=True):
    """Formal Laurent series at a pole of order p with leading coefficient a0, up to index N.

    Returns a dict (keys of mero.bootstrap.laurent)
      coeffs      : [c_0, ..., c_N]  (expressions in the parameters and in the free symbols h_k)
      indices     : the positive integer Fuchs indices <= N (k with no equation for c_k)
      free        : {k: h_k} symbols introduced at those indices
      conditions  : {k: expression} compatibility condition at each such index (must vanish)
      indicial    : the indicial polynomial I(k) (SymPy expression in the symbol k)
    and in addition p, a0, a0_symbol, a0_minpoly, W, N (smaller than requested if the time budget ran out:
    then truncated is True), all_indices, index_multiplicities, mode, ground, series (the LaurentSeries
    object).  Parameters are treated as generic."""
    L = LaurentSeries(eq, p, a0, minpoly=minpoly, free_prefix=free_prefix, budget_s=budget_s, factor=factor)
    L.extend(N)
    return L.as_dict()


# ------------------------------------------------------------------------------------------ counting
def _dimension(lead_monomials, nvars):
    """dimension of a monomial ideal given by exponent tuples: the largest set of variables that contains
    the support of no generator"""
    for r in range(nvars, 0, -1):
        for S in itertools.combinations(range(nvars), r):
            Sset = set(S)
            if all(any(e and (i not in Sset) for i, e in enumerate(m)) for m in lead_monomials):
                return r
    return 0


def _standard_monomials(lead_monomials, nvars, cap=10000):
    """number of monomials outside a zero-dimensional monomial ideal"""
    bound = [None] * nvars
    for m in lead_monomials:
        sup = [i for i, e in enumerate(m) if e]
        if len(sup) == 1:
            i = sup[0]
            bound[i] = m[i] if bound[i] is None else min(bound[i], m[i])
    if any(b is None for b in bound):
        return None
    cnt = 0
    for mon in itertools.product(*[range(b) for b in bound]):
        if not any(all(mon[i] >= m[i] for i in range(nvars)) for m in lead_monomials):
            cnt += 1
            if cnt > cap:
                return None
    return cnt


def series_count(L):
    """How many Laurent series belong to the class of L (all roots a0 of its minimal polynomial together), for
    generic parameters.  L must be extended beyond its largest positive integer index.

    Returns (text, detail): text is one of
        '0'                                   a compatibility condition is a nonzero expression in the parameters
        'finite: n'                           n series (counted with multiplicity when the conditions fix
                                              the free coefficients)
        'family: r free coefficient(s)'       the conditions leave r coefficients free
        'not determined'                      (N too small, or the elimination did not finish)
    detail is a dict: nonzero (indices whose condition is not identically zero), decided_by, note.
    All zero tests are exact (ring elements); the elimination is a Groebner basis over the coefficient field."""
    idx = sorted(L.positive_indices)
    ncls = 1 if L.minpoly is None else sp.Poly(L.minpoly, L.a0_symbol).degree()
    extra = 1 if L.a0_free else 0
    detail = {"nonzero": [], "decided_by": None, "note": ""}
    if L.a0_free:
        detail["note"] = "the leading coefficient is one of the free coefficients"
    if not idx:
        if L.a0_free:
            return "family: 1 free coefficient(s)", detail
        return "finite: %d" % ncls, detail
    if L.N < max(idx):
        detail["note"] = "the series was computed to index %d only; the largest index is %d" % (L.N, max(idx))
        return "not determined", detail
    nonzero = [k for k in idx if not L.condition_is_zero(k)]
    detail["nonzero"] = nonzero
    if not nonzero:
        return "family: %d free coefficient(s)" % (len(idx) + extra), detail
    for k in nonzero:
        if not L.condition_involves_free(k):
            if L.a0_free:
                detail["note"] = ("the condition at the index %d does not hold for a general leading "
                                  "coefficient; it may hold for special values of it" % k)
                return "not determined", detail
            detail["decided_by"] = k
            return "0", detail
    # the remaining conditions involve free coefficients: dimension of their zero set over the coefficient field
    size = sum(L._esize(L._cond[k]) for k in nonzero)
    if size > ELIMINATION_LIMIT:
        detail["note"] = ("the conditions %s involve free coefficients and are too large for the elimination "
                          "(size %d)" % (", ".join("Q%d" % k for k in nonzero), size))
        return "not determined", detail
    a0s = L.a0_symbol
    hs = [L.free[k] for k in idx]
    gens = ([a0s] if L.minpoly is not None else []) + hs
    fld_syms = list(L.params) + ([a0s] if L.a0_free else [])      # all parameters are coefficients here
    try:
        from sympy.polys.groebnertools import groebner as _groebner
        fld = L.ground.frac_field(*fld_syms) if fld_syms else L.ground
        Rg = ring(gens, fld, order=grevlex)[0]
        polys = [Rg.from_expr(L._cond[k].as_expr()) for k in nonzero]
        if L.minpoly is not None:
            polys.append(Rg.from_expr(L.minpoly))
        G = _groebner([q for q in polys if q], Rg)
        if any(g.is_ground for g in G):
            detail["decided_by"] = "elimination"
            return "0", detail
        lms = [g.LM for g in G]
        dim = _dimension(lms, len(gens))
        cn = ", ".join("Q%d" % k for k in nonzero)
        if dim == 0:
            n = _standard_monomials(lms, len(gens))
            if n is None:
                return "not determined", detail
            if extra:
                detail["note"] += "; the conditions %s fix the other free coefficients" % cn
                return "family: 1 free coefficient(s)", detail
            detail["note"] = "the conditions %s fix the free coefficients (count with multiplicity)" % cn
            return "finite: %d" % n, detail
        detail["note"] = (detail["note"] + "; " if detail["note"] else "") + \
            "the conditions %s restrict the free coefficients" % cn
        return "family: %d free coefficient(s)" % (dim + extra), detail
    except Exception as err:          # pragma: no cover
        detail["note"] = "elimination failed: %s" % err
        return "not determined", detail


# ------------------------------------------------------------------------------------------ local analysis
class _TooLarge(Exception):
    """internal: an expression is too large to be factorised for the list of strata"""


def _param_factors(expr, pset, atoms=()):
    """the distinct irreducible factors of the numerator of expr that contain a parameter"""
    expr = sp.sympify(expr)
    ops = sp.count_ops(expr)
    if ops > 1500 or (ops > 250 and len(expr.free_symbols) > 6):
        raise _TooLarge()                 # too large to factorise in reasonable time: not listed
    num = sp.numer(sp.together(expr))
    if num == 0:
        return []
    cont, facs = _factor_list(num, atoms)
    out = []
    for f, _ in facs:
        if f.free_symbols & set(pset):
            if f.could_extract_minus_sign():
                f = -f
            out.append(sp.expand(f))
    return out


def _linear_solution(g, params):
    """(x, value, c1): the polynomial g is linear in the parameter x, g = c1*x + c0, value = -c0/c1; a
    parameter with a constant c1 is preferred (then c1 is returned as None).  None if g is linear in no
    parameter."""
    best = None
    for x in params:
        if not g.has(x):
            continue
        try:
            P = sp.Poly(g, x)
        except Exception:
            continue
        if P.degree() != 1:
            continue
        c1, c0 = P.all_coeffs()
        val = _cancel(-c0 / c1)
        if c1.is_number:
            return x, val, None
        if best is None:
            best = (x, val, c1)
    return best


def _analyse_class(eq, rec, cls, N, deadline, index_bound=12, extension_budget_s=2.0):
    """series and count for one class of leading coefficients; returns (dict for JSON, LaurentSeries, detail).

    Two stages.  (1) The series up to the largest positive integer Fuchs index: this gives every
    compatibility condition, hence series_count; only the caller's time budget can stop it, and then
    truncated is True.  (2) A few more coefficients for display (to index max(6, largest index + 2), or to N
    if N is given): attempted only while the operations are small (a deterministic size rule) and within
    extension_budget_s; if it is cut, extra_coefficients_cut is True and nothing else changes."""
    a0s = rec["a0_symbol"]
    p = rec["p"]
    budget = None if deadline is None else max(0.05, deadline - time.monotonic())
    L = LaurentSeries(eq, p, cls["a0"], minpoly=cls["minpoly"], budget_s=budget, index_bound=index_bound)
    idx = sorted(L.positive_indices)
    kmax = max(idx) if idx else 0
    L.extend(kmax)
    essential_cut = L.N < kmax
    essential_stop = L.stopped_by
    target = max(6, kmax + 2) if N is None else max(N, kmax)
    extra_cut, extra_stop = False, None
    if not essential_cut and L.N < target:
        soft = extension_budget_s
        if deadline is not None:
            soft = min(soft, deadline - time.monotonic())
        if soft is not None and soft > 0.05:       # skipped entirely when (almost) no time is left
            L.extend(target, budget_s=soft, cost_limit=SOFT_COST_FRAC if L._frac else SOFT_COST_POLY)
        extra_cut = L.N < target
        extra_stop = L.stopped_by or "time"
    L._deadline = deadline
    L.truncated = essential_cut
    count, detail = series_count(L)
    d = {"p": p,
         "a0": str(cls["a0"]),
         "a0_minpoly": None if cls["minpoly"] is None else str(cls["minpoly"]),
         "a0_degree": cls.get("degree"),
         "a0_values": None if not cls.get("values") else [str(v) for v in cls["values"]],
         "a0_free": bool(cls.get("free")),
         "a0_symbol": a0s.name,
         "weight": rec["W"],
         "dominant": [str(eq.terms[m] * _monomial_expr(eq, m)) for m in rec["top"]],
         "leading_poly": str(rec["leading_poly"]),
         "indicial": str(L.indicial),
         "index_symbol": L.k_symbol.name,
         "indices": [str(r) for r in L.index_data["roots"]],
         "positive_integer_indices": idx,
         "index_multiplicities": dict((str(k), m) for k, m in sorted(L.positive_indices.items())),
         "indices_depend_on_parameters": bool(L.index_data["depends"]),
         "parameter_dependent_indices": [{"k": s["k"], "condition": str(s["condition"])}
                                         for s in L.index_data["special"]],
         "index_bound": index_bound,
         "N": L.N, "N_target": target,
         # truncated: a compatibility condition at a positive integer Fuchs index was NOT reached (then
         # series_count is 'not determined'); extra_coefficients_cut: only the coefficients beyond the last
         # index, computed for display, were cut -- series_count, conditions and finiteness are not affected
         "truncated": bool(essential_cut), "stopped_by": essential_stop,
         "extra_coefficients_cut": bool(extra_cut), "extra_coefficients_stopped_by": extra_stop if extra_cut else None,
         "coeffs": [str(c) for c in L.coeffs],
         "free": dict((str(k), str(h)) for k, h in sorted(L.free.items()) if k <= L.N),
         "conditions": dict((str(k), str(c)) for k, c in L.conditions.items()),
         "conditions_identically_zero": dict((str(k), bool(L.condition_is_zero(k))) for k in sorted(L._cond)),
         "series_count": count,
         "series_count_note": detail["note"],
         "mode": L.mode,
         "ground_field": str(L.ground)}
    # LaTeX of what the site shows (None for an expression that is too long to typeset, or when the time
    # budget is used up)
    def tex(expr, text=None):
        if _expired(deadline) or len(text if text is not None else str(expr)) > 3000:
            return None
        return sp.latex(expr)
    try:
        d["a0_latex"] = tex(cls["a0"])
        d["a0_minpoly_latex"] = None if cls["minpoly"] is None or tex(cls["minpoly"]) is None \
            else tex(cls["minpoly"]) + " = 0"
        d["leading_poly_latex"] = tex(rec["leading_poly"])
        d["dominant_latex"] = [_term_latex(eq, m) for m in rec["top"]]
        d["indicial_latex"] = tex(L.indicial)
        d["indices_latex"] = [r if isinstance(r, str) else tex(r) for r in L.index_data["roots"]]
        d["coeffs_latex"] = [tex(c, t) for c, t in zip(L.coeffs, d["coeffs"])]
        d["conditions_latex"] = dict((str(k), tex(c, d["conditions"][str(k)])) for k, c in L.conditions.items())
    except Exception:                 # pragma: no cover
        pass
    return d, L, detail


def _term_latex(eq, mon):
    """LaTeX of one term of E with its sign, in the visitor's letters"""
    try:
        sign, body = eq._term_latex(mon, eq.terms[mon])
        return ("-" if sign == "-" else "") + body
    except Exception:
        return sp.latex(eq.terms[mon] * _monomial_expr(eq, mon))


def _stratum(eq, ident, g, note, state, deadline, depth, N):
    """one entry of `strata`: the parameter condition g == 0 and, when g can be solved for a parameter, the
    analysis of the specialised equation at the same pole order"""
    entry = dict(ident)
    entry["conditions"] = ["%s == 0" % g]
    entry["conditions_latex"] = [sp.latex(g) + " = 0"]
    entry["series_count"] = "depends on parameters"
    entry["note"] = note
    root_note = ""
    pset = set(eq.params)
    if g.free_symbols - pset or sp.count_ops(g) > 400:
        return entry
    sol = _linear_solution(g, eq.params)
    if sol is None and len(g.free_symbols) == 1 and not algebraic_atoms(g):
        # a polynomial in one parameter, irreducible over QQ: its roots are conjugate algebraic numbers and
        # the specialised equations are conjugate too, so one root is analysed
        x = list(g.free_symbols)[0]
        try:
            P = sp.Poly(g, x, domain="QQ")
            if P.degree() == 2:
                root = sorted(sp.roots(P), key=sp.default_sort_key)[-1]
            elif 3 <= P.degree() <= 4:
                root = sp.CRootOf(P, 0)
            else:
                root = None
            if root is not None:
                sol = (x, root, None)
                root_note = "; analysed at the root %s = %s (the other roots of the condition are " \
                            "conjugate to it)" % (x, root)
        except Exception:
            sol = None
    if sol is None or depth <= 0 or _expired(deadline) or state["calls"] >= state["max_calls"] \
            or _expired(state.get("strata_deadline")):
        if sol is not None and depth > 0:
            entry["note"] += "; not analysed (limit of time or of the number of cases)"
            state["skipped"] = state.get("skipped", 0) + 1
        return entry
    x, val, c1 = sol
    state["calls"] += 1
    try:
        eq2 = eq.subs({x: val})
        limits = [t for t in (deadline, state.get("strata_deadline")) if t is not None]
        sub = _local(eq2, N, min(limits) if limits else None, depth - 1, only_p=ident["p"], state=state)
    except Exception as err:
        entry["note"] += "; not analysed (%s)" % err
        return entry
    entry["substitution"] = {str(x): str(val)}
    entry["note"] += root_note
    if c1 is not None:
        try:
            c1f = _param_factors(c1, pset)
        except _TooLarge:
            c1f = [c1]
        for f in c1f:
            entry["conditions"].append("%s != 0" % f)
            entry["conditions_latex"].append(sp.latex(f) + r" \neq 0")
    cc = [(b["a0"], b["series_count"]) for b in sub["balances"]]
    if len(cc) == 1:
        entry["series_count"] = cc[0][1]
    elif cc:
        entry["series_count"] = "; ".join("a0 = %s: %s" % t for t in cc)
    else:
        entry["series_count"] = "0"
        entry["note"] += "; no pole of order %s on this stratum" % ident["p"]
    entry["balances"] = [dict((key, b[key]) for key in ("a0", "a0_minpoly", "a0_free", "positive_integer_indices",
                                                        "conditions", "series_count"))
                         for b in sub["balances"]]
    entry["pole_orders_on_stratum"] = sub.get("pole_orders")
    entry["strata"] = [s for s in sub["strata"] if s.get("note") != "generic parameters"]
    return entry


def _strata_for_class(eq, rec, cls, L, count, detail, deadline, depth, N, state):
    """parameter conditions that change the count of the class (as far as this can be told reliably):
    the first entry is the generic stratum, the others are the hypersurfaces g == 0 that were removed"""
    if not eq.params:
        return []
    pset = set(eq.params)
    atoms = L.atoms
    a0s = rec["a0_symbol"]
    ident = {"p": rec["p"], "a0": str(cls["a0"])}
    special = []          # factors in the order of discovery, without repetitions
    seen = {}
    dropped = [0]
    limits = [t for t in (deadline, state.get("strata_deadline")) if t is not None]
    stop_at = min(limits) if limits else None
    _pf = _param_factors

    def _param_factors_guarded(expr, pset_, atoms_=()):
        """factors of a condition; nothing (and a count) if it is too large or the time is over"""
        if _expired(stop_at):
            dropped[0] += 1
            return []
        try:
            if callable(expr):
                expr = expr()
            return _pf(expr, pset_, atoms_)
        except _TooLarge:
            dropped[0] += 1
            return []

    def add(g, note):
        key = str(g)
        if key in seen:
            if note not in seen[key]:
                seen[key].append(note)
            return
        seen[key] = [note]
        special.append(g)

    def norm(expr):
        """an expression in the parameters only (the a0 symbol is eliminated)"""
        if sp.count_ops(expr) > 1500:
            return expr
        expr = sp.numer(sp.together(expr))
        if expr.has(a0s) and L.minpoly is not None:
            if sp.count_ops(expr) > 200 or len(expr.free_symbols | L.minpoly.free_symbols) > 5:
                raise _TooLarge()         # the resultant would be too large: the condition is not listed
            expr = sp.resultant(expr, L.minpoly, a0s)
        return expr

    hs = set(L.free.values())
    # 1. compatibility conditions
    k = detail.get("decided_by")
    if count == "0" and isinstance(k, int):
        for g in _param_factors_guarded(lambda: norm(L.condition(k)), pset, atoms):
            add(g, "the compatibility condition at the index %d holds" % k)
    else:
        for kk in detail.get("nonzero") or []:
            if _expired(stop_at):
                dropped[0] += 1
                break
            Qc = L.condition(kk)
            if sp.count_ops(Qc) > 1500:
                dropped[0] += 1
                continue
            Q = sp.numer(sp.together(Qc))
            inv = sorted(Q.free_symbols & hs, key=lambda s_: s_.name)
            if not inv:
                continue
            try:
                lc = sp.Poly(Q, *inv).LC()
            except Exception:
                continue
            for g in _param_factors_guarded(lambda: norm(lc), pset, atoms):
                add(g, "the leading coefficient of the condition at the index %d (in %s) vanishes"
                    % (kk, ", ".join(str(h) for h in inv)))
    # 2. a further positive integer index
    for s_ in L.index_data["special"]:
        for g in _param_factors_guarded(s_["condition"], pset, atoms):
            add(g, "%d becomes a Fuchs index" % s_["k"])
    # 3. the dominant part or the leading coefficient degenerates
    for f in rec.get("lead_factors") or []:
        for g in _param_factors_guarded(f, pset, atoms):
            add(g, "the leading polynomial %s changes degree" % rec["leading_poly"])
    if cls["minpoly"] is None and not cls.get("free"):
        num, den = sp.fraction(sp.together(cls["a0"]))
        for g in _param_factors_guarded(num, pset, atoms):
            add(g, "the leading coefficient vanishes: the balance disappears")
        for g in _param_factors_guarded(den, pset, atoms):
            add(g, "the leading coefficient becomes infinite: the balance disappears")
    elif cls["minpoly"] is not None:
        Pm = sp.Poly(cls["minpoly"], a0s)
        for g in _param_factors_guarded(Pm.LC(), pset, atoms) + _param_factors_guarded(Pm.all_coeffs()[-1], pset, atoms):
            add(g, "a root of the leading polynomial vanishes or becomes infinite")
        try:
            if (Pm.degree() == 2 and len(cls["minpoly"].free_symbols) <= 8) or \
                    (Pm.degree() <= 4 and len(cls["minpoly"].free_symbols) <= 3):
                for g in _param_factors_guarded(sp.discriminant(cls["minpoly"], a0s), pset, atoms):
                    add(g, "two leading coefficients coincide")
        except Exception:
            pass
    for m in rec["top"]:
        for g in _param_factors_guarded(eq.terms[m], pset, atoms):
            add(g, "the dominant term %s vanishes" % (eq.terms[m] * _monomial_expr(eq, m)))
    out = []
    for g in special:
        out.append(_stratum(eq, ident, g, "; ".join(seen[str(g)]), state, deadline, depth, N))
    head = dict(ident)
    head["conditions"] = ["%s != 0" % g for g in special]
    head["conditions_latex"] = [sp.latex(g) + r" \neq 0" for g in special]
    head["series_count"] = count
    head["note"] = "generic parameters"
    if dropped[0]:
        head["incomplete"] = True
        head["incomplete_note"] = ("%d condition(s) that define special parameter values are not listed "
                                   "(too large to factorise, or the time for the strata was used up)" % dropped[0])
        state["skipped"] = state.get("skipped", 0) + 1
    return [head] + out


def _stub_balance(eq, rec, cls, note, stopped_by):
    """entry of 'balances' for a class whose series was not computed (error, or no time left): the balance
    itself is known, the count is not determined, truncated is True"""
    return {"p": rec["p"], "a0": str(cls["a0"]),
            "a0_minpoly": None if cls["minpoly"] is None else str(cls["minpoly"]),
            "a0_degree": cls.get("degree"), "a0_free": bool(cls.get("free")),
            "a0_values": None if not cls.get("values") else [str(v) for v in cls["values"]],
            "a0_symbol": rec["a0_symbol"].name, "weight": rec["W"],
            "dominant": [str(eq.terms[m] * _monomial_expr(eq, m)) for m in rec["top"]],
            "leading_poly": str(rec["leading_poly"]), "indicial": None, "degenerate_indicial": False,
            "indices": [], "positive_integer_indices": [], "coeffs": [str(cls["a0"])], "free": {},
            "conditions": {}, "series_count": "not determined", "series_count_note": note,
            "N": 0, "N_target": None, "truncated": True, "stopped_by": stopped_by,
            "extra_coefficients_cut": False, "extra_coefficients_stopped_by": None}


def _local(eq, N, deadline, depth, only_p=None, index_bound=12, state=None):
    state = state if state is not None else {"calls": 0, "max_calls": 24, "strata_deadline": None,
                                             "extension_budget_s": 2.0}
    ab = all_balances(eq)
    res = {"balances": [], "non_integer_balances": [], "finiteness": None, "no_pole_possible": None,
           "strata": [], "notes": []}
    res["pole_orders"] = sorted(set(rec["p"] for rec in ab["poles"]))
    counts = []
    seen_strata = set()
    for rec in ab["poles"]:
        if only_p is not None and rec["p"] != only_p:
            continue
        for cls in rec["classes"]:
            if _expired(deadline):
                res["notes"].append("time budget exhausted: p = %s, a0 = %s not analysed" % (rec["p"], cls["a0"]))
                counts.append("not determined")
                res["balances"].append(_stub_balance(eq, rec, cls, "time budget exhausted before this class",
                                                     "time"))
                continue
            try:
                d, L, detail = _analyse_class(eq, rec, cls, N, deadline, index_bound,
                                              state.get("extension_budget_s", 2.0))
                if d["truncated"]:
                    res["notes"].append("p = %s, a0 = %s: stopped by the %s limit at index %d before the "
                                        "Fuchs index %d: the count is not determined"
                                        % (rec["p"], cls["a0"], d["stopped_by"], d["N"],
                                           max(d["positive_integer_indices"])))
            except Exception as err:
                res["notes"].append("p = %s, a0 = %s: series not computed (%s)" % (rec["p"], cls["a0"], err))
                counts.append("not determined")
                stub = _stub_balance(eq, rec, cls, str(err), "error")
                stub["indicial"] = "0" if isinstance(err, DegenerateIndicial) else None
                stub["degenerate_indicial"] = isinstance(err, DegenerateIndicial)
                res["balances"].append(stub)
                continue
            res["balances"].append(d)
            counts.append(d["series_count"])
            if depth < 0:
                continue
            if _expired(deadline):
                if eq.params:
                    res["notes"].append("strata not computed for p = %s, a0 = %s: time budget exhausted"
                                        % (rec["p"], cls["a0"]))
                    state["skipped"] = state.get("skipped", 0) + 1
                continue
            try:
                for st in _strata_for_class(eq, rec, cls, L, d["series_count"], detail, deadline,
                                            depth, N, state):
                    # a stratum of another class of the same order with the same conditions and the same
                    # answer is not repeated (an analysed stratum reports all classes of that order)
                    key = (st["p"], tuple(st["conditions"]), st["series_count"])
                    if st.get("note") != "generic parameters" and key in seen_strata:
                        continue
                    seen_strata.add(key)
                    res["strata"].append(st)
            except Exception as err:      # pragma: no cover
                res["notes"].append("strata not computed for p = %s: %s" % (rec["p"], err))
    for rec in ab["branches"]:
        res["non_integer_balances"].append({
            "p": _pstr(rec["p"]), "note": "algebraic branch point: not a pole",
            "weight": _pstr(rec["W"]),
            "dominant": [str(eq.terms[m] * _monomial_expr(eq, m)) for m in rec["top"]],
            "leading_poly": str(rec["leading_poly"]), "a0": [str(v) for v in rec["a0"]],
            "a0_minpoly": [str(c["minpoly"]) for c in rec["classes"] if c.get("minpoly") is not None]})
    res["empty_balances"] = [{"p": _pstr(rec["p"]), "leading_poly": str(rec["leading_poly"]),
                              "dominant": [str(eq.terms[m] * _monomial_expr(eq, m)) for m in rec["top"]],
                              "note": "the leading polynomial has no nonzero root: no pole of this order"}
                             for rec in ab["empty"]]
    res["special_balances"] = []
    pset = set(eq.params)
    for s in ab["special"]:
        terms = [str(eq.terms[m] * _monomial_expr(eq, m)) for m in s["terms"]]
        try:
            facs = _param_factors(s["condition"], pset, eq.alg_numbers) or [s["condition"]]
        except _TooLarge:
            facs = [s["condition"]]
        for g in facs:
            res["special_balances"].append({
                "p": s["p"], "condition": "%s == 0" % g, "terms": terms,
                "note": s.get("note") or "for these parameter values the listed terms cancel at leading order: "
                                         "a pole of order %s whose leading coefficient is not fixed by the "
                                         "dominant terms becomes possible" % s["p"]})
            if depth >= 0 and s["p"] is not None and (only_p is None or s["p"] == only_p):
                ident = {"p": s["p"], "a0": "free"}
                res["strata"].append(_stratum(eq, ident, g, "a balance of order %s inside the terms %s appears"
                                              % (s["p"], ", ".join(terms)), state, deadline, depth, N))
    if eq.params:
        res["notes"].append("strata: parameter values at which an integer larger than %d becomes a Fuchs index, "
                            "or at which a balance inside one group of terms appears at a pole order larger than "
                            "%d, are not listed" % (index_bound, 2 * eq.K + 2))
    if not counts:
        res["no_pole_possible"] = True
        res["finiteness"] = True
        res["notes"].append("no dominant balance with an integer pole order and a nonzero leading coefficient"
                            + (" (generic parameters)" if eq.params else ""))
    else:
        res["no_pole_possible"] = all(c == "0" for c in counts)
        if any(c.startswith("family") for c in counts):
            res["finiteness"] = False
        elif all(c == "0" or c.startswith("finite") for c in counts):
            res["finiteness"] = True
        else:
            res["finiteness"] = None
    return res


def local_analysis(eq, N=None, budget_s=None, depth=2, index_bound=12, strata_budget_s=5.0, max_strata=24,
                   extension_budget_s=2.0):
    """Local analysis at a movable pole: the dict of project note section 1 (all values JSON-serialisable).

    N        number of series coefficients; default max(6, largest positive integer index + 2) per balance
    budget_s time budget in seconds (checked inside the loops; what was not done is listed in 'notes')
    depth    how many successive parameter conditions are followed in 'strata' (0: the conditions are listed
             but the specialised equations are not analysed; -1: no strata at all)
    strata_budget_s, max_strata   time and number of specialised equations spent on 'strata' (a stratum that
             was not analysed keeps the count 'depends on parameters'; 'strata_complete' says whether any was)
    extension_budget_s   time for the coefficients beyond the last positive integer Fuchs index (display only)

    What does not depend on any timer unless budget_s itself runs out: balances, indices, conditions,
    series_count, finiteness, no_pole_possible.  Per balance, 'truncated' is True only if a compatibility
    condition was not reached (the count is then 'not determined'); 'extra_coefficients_cut' reports that fewer
    display coefficients than N_target were computed.
    With symbolic parameters the answer describes generic values; 'strata' lists the conditions that change
    it.  'finiteness' is True if, for generic parameters, only finitely many Laurent series with a pole
    satisfy the equation; 'no_pole_possible' is True if there is none (then every meromorphic solution is
    entire), again for generic parameters."""
    t0 = time.monotonic()
    deadline = None if budget_s is None else t0 + budget_s
    if strata_budget_s is not None and budget_s is not None:
        strata_budget_s = min(strata_budget_s, budget_s / 2.0)
    state = {"calls": 0, "max_calls": max_strata, "extension_budget_s": extension_budget_s,
             "strata_deadline": None if strata_budget_s is None else t0 + strata_budget_s, "skipped": 0}
    res = _local(eq, N, deadline, depth, index_bound=index_bound, state=state)
    res["strata_complete"] = state["skipped"] == 0
    res["budget_exhausted"] = bool(deadline is not None and time.monotonic() > deadline)
    res["generic"] = bool(eq.params)
    res["parameters"] = [s.name for s in eq.params]
    res["algebraic_numbers"] = [str(x) for x in eq.alg_numbers]
    res["elapsed_s"] = round(time.monotonic() - t0, 3)
    return res


# ------------------------------------------------------------------------------------------ command line
def main(argv=None):
    """python -m mero.laurent "<equation text>" [N] [--budget seconds]  -> local analysis as JSON"""
    argv = list(sys.argv[1:] if argv is None else argv)
    budget = None
    if "--budget" in argv:
        i = argv.index("--budget")
        budget = float(argv[i + 1])
        del argv[i:i + 2]
    if not argv:
        print("usage: python -m mero.laurent \"w''' = 12 w w' + a w''\" [N] [--budget seconds]")
        return 2
    from .parse import parse_ode
    try:
        eq = parse_ode(argv[0])
    except ValueError as err:
        print(json.dumps({"error": str(err)}, indent=1))
        return 1
    N = int(argv[1]) if len(argv) > 1 else None
    res = local_analysis(eq, N=N, budget_s=budget)
    res = dict([("equation", eq.to_dict())] + list(res.items()))
    print(json.dumps(res, indent=1, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
