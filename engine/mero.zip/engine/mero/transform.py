"""mero.transform -- exact changes of variables for autonomous polynomial ODEs  E(w0, ..., wK) = 0.

    affine_group(eq)                       the action of  w = alpha*W + beta,  z = gamma*Z  on E (symbolic)
    affine_transform(eq, alpha, beta, gamma, lam=None)   E' = lam * E(alpha W + beta, alpha/gamma W1, ...)
    normalise(eq)            -> (eq_normal, map)       deterministic normal form under that group (see NORMAL FORM)
    transport_solution(expr, map, var='z')            a solution W(z) of the normal form -> w(z) of the original
    transport_to_normal(expr, map, var='z')           a solution w(z) of the original -> W(z) of the normal form
    power_change(eq, s)      -> (Equation for u, info)  w = u**s  (s rational), cleared of denominators
    power_substitution(eq)   -> list                    u = w**m when the pole order is r/m (m > 1)
    first_integral_reduction(eq) -> list                E = D F  ->  F + C = 0 ;   w'' = F(w)  ->  w'^2 = 2 int F + C
    exponential_twist(eq)    -> list                    w = c + (kappa s)^p Y(s), s = exp(kappa z)  ->  Y^(K) + b Y^n = 0
    substitutions(eq)        -> list of {"name", "map", "equation", "conditions", "note"}

NORMAL FORM (convention; generic parameters).  The group acts by  w = alpha W + beta,  z = gamma Z  (z-translations
do not change an autonomous equation) and E may be multiplied by a nonzero constant.  Write o(m) = sum j e_j and
d(m) = sum e_j for a monomial m = prod w_j^e_j.
  1. scale: E solved (E = lead*wK - Phi) -> divide by lead (condition lead != 0 when lead is symbolic).
     E not solved -> divide by the coefficient of the first monomial in the order (o, d, exponents) descending;
     no further step is made for unsolved equations.
  2. dominant nonlinear monomial m*: among the monomials with d >= 2 the one with the smallest
     p(m) = (K - o(m)) / (d(m) - 1)   (the pole order at which m balances wK);  ties: e0(m) >= 1 first, then larger
     d, then larger exponent tuple read from wK down to w0.  Requires K - o(m) > 0 for every nonlinear m (else
     only step 1 is made).  p* = p(m*), W = p* + K = the top weight.
  3. shift: if e0(m*) >= 1, beta kills the coefficient of m*/w0  (beta = -c(m*/w0) / (e0(m*) c(m*)); this is exact
     because m* w0 has weight above W and does not occur).
  4. scalings: c(m*) is set to  T(m*) = -ff(-p*, K) / prod_j ff(-p*, j)^e_j  (ff = falling factorial), the value for
     which a0 = 1 solves the two-term balance  wK + T m* = 0  (w ~ z^-p*); e.g. w'' - 6 w^2, w''' + 60 w^2,
     w'' - 2 w^3.  The second normalised coefficient is m1 = the monomial of smallest positive weight gap
     W - weight(m) (ties: larger d, then larger exponent tuple from wK down), set to 1.  (alpha, gamma) solve
          alpha^(d*-1) gamma^(K-o*) = T / c(m*),    alpha^(d1-1) gamma^(K-o1) = 1 / c(m1);
     the determinant is D = (d*-1) * gap(m1) != 0; the solution is rational when D divides the exponents, else it
     uses principal radicals.  If no such m1 exists only c(m*) is normalised (gamma = 1).
  5. residual finite group: the solutions of the two equations above with right-hand sides 1 (|D| elements) act on
     the other coefficients by roots of unity; the representative whose coefficient vector, evaluated at a fixed
     complex parameter point, is lexicographically smallest is chosen (floating point is used only to make this
     choice; every reported formula is exact).
  6. radicals: a root of an expression in the parameters that remains in the normal form is written as a new
     parameter rho1, rho2, ... (rho = b^(1/Q), deterministic order), and so are numeric radicals when they would
     generate a number field of degree > 4; the definitions are in map["radicals"] (mero.equation does not accept
     roots of symbolic expressions).  normal_form_expr(eq_normal, map) substitutes them back.
The map records alpha, beta, gamma, lam with  E_normal(W) = lam * E(alpha W + beta, alpha gamma^-1 W1, ...),
the conditions used (nonvanishing of the coefficients divided by), and the residual group order.
field="R" (numeric real coefficients only): real alpha, gamma; c(m*) = +-T, c(m1) = +-1, signs chosen as stated in
normalise.  The complex convention (default) may need complex alpha, gamma even for a real equation.
Deterministic = two equations related by the group (and a factor on E) have the same normal form, as functions of
the parameters (tested: 13 equations x 2 random rational changes, and 6 x 2 for field="R").
Not normalised beyond step 1: unsolved equations (lead depends on the jets, e.g. after power_substitution) and
solved equations in which some nonlinear monomial has o(m) >= K (no balance of wK at a pole).
"""
import itertools
import time
import sympy as sp

from .pde import (antiderivative, total_derivative, make_equation, _E_of, _fresh)

__all__ = ["affine_group", "affine_transform", "normalise", "normal_form_block", "normal_form_expr",
           "transport_solution",
           "transport_to_normal", "newton_balances",
           "power_change", "power_substitution", "first_integral_reduction", "exponential_twist",
           "substitutions", "dominant_monomial", "check_transformation"]

z = sp.Symbol("z")


# ---------------------------------------------------------------------------------------------- helpers

def _w(j):
    return sp.Symbol("w%d" % j)


def _jets(K):
    return [_w(j) for j in range(K + 1)]


def _terms(E, K):
    P = sp.Poly(sp.expand(E), *_jets(K))
    out = {}
    for m, c in P.terms():
        c = sp.cancel(c)
        if c != 0:
            out[tuple(int(e) for e in m)] = c
    return out


def _mono(m):
    r = sp.Integer(1)
    for j, e in enumerate(m):
        if e:
            r *= _w(j) ** e
    return r


def _from_terms(terms):
    return sp.Add(*[c * _mono(m) for m, c in terms.items()])


def _deg(m):
    return sum(m)


def _ord(m):
    return sum(j * e for j, e in enumerate(m))


def _ff(x, j):
    r = sp.Integer(1)
    for i in range(j):
        r *= (x - i)
    return r


def _is_zero(e):
    e = sp.sympify(e)
    if e == 0:
        return True
    try:
        return sp.simplify(e) == 0
    except Exception:          # pragma: no cover
        return False


def _cond(e):
    """'expr != 0' for a symbolic expression (numerator, numeric factors removed), None for a nonzero number"""
    e = sp.factor(sp.together(sp.sympify(e)))
    if e.is_number:
        return None
    num = sp.numer(e)
    c, rest = sp.factor_terms(num).as_coeff_Mul()
    if rest.is_number:
        return None
    if rest.could_extract_minus_sign():
        rest = -rest
    return "%s != 0" % sp.sstr(rest)


def _params_of(eq):
    return list(getattr(eq, "params", []) or [])


def _new_eq(E, eq, params=None, unknown=None):
    ps = list(params) if params is not None else _params_of(eq)
    for s in sorted(sp.sympify(E).free_symbols, key=str):
        if s.name.startswith("w") and s.name[1:].isdigit():
            continue
        if s not in ps:
            ps.append(s)
    return make_equation(E, ps, unknown=unknown or getattr(eq, "unknown", "w"), var=getattr(eq, "var", "z"))


def _as_eq(eq):
    if isinstance(eq, str):
        try:
            from .parse import parse_ode
            return parse_ode(eq)
        except ImportError:        # pragma: no cover
            return make_equation(sp.sympify(eq))
    return eq


def _simp(e, deadline=None):
    e = sp.sympify(e)
    if e.is_number and e.is_Rational:
        return e
    try:
        r = sp.factor(sp.cancel(sp.powsimp(e)))
    except Exception:          # pragma: no cover
        r = e
    if (deadline is None or time.monotonic() < deadline) and r.has(sp.Pow) \
            and any(not a.exp.is_integer for a in r.atoms(sp.Pow)) and sp.count_ops(r) < 80:
        r2 = sp.simplify(r)
        if sp.count_ops(r2) <= sp.count_ops(r):
            r = r2
    return r


# ---------------------------------------------------------------------------------------------- affine group

def affine_transform(eq, alpha, beta, gamma, lam=None):
    """E'(W) = lam * E(alpha W0 + beta, alpha gamma^-1 W1, ..., alpha gamma^-K WK), in the jets w0..wK.
    lam defaults to 1.  Returns the expanded expression."""
    eq = _as_eq(eq)
    E = _E_of(eq)
    K = eq.K
    rep = {_w(0): alpha * _w(0) + beta}
    for j in range(1, K + 1):
        rep[_w(j)] = alpha * gamma ** (-j) * _w(j)
    out = sp.expand(E.subs(rep, simultaneous=True))
    if lam is not None:
        out = sp.expand(lam * out)
    return out


def affine_group(eq):
    """Symbolic action of w = alpha W + beta, z = gamma Z on E:
    {"symbols": [alpha, beta, gamma], "E": E(alpha W + beta, ...), "characters": {monomial: [d-1, K-o]},
     "note": ...}.  After the shift, the coefficient of a monomial m of E made monic in wK is multiplied by
    alpha^(d-1) gamma^(K-o)."""
    eq = _as_eq(eq)
    a, b, g = sp.symbols("alpha beta gamma")
    E2 = affine_transform(eq, a, b, g)
    chars = {}
    for m in _terms(_E_of(eq), eq.K):
        chars[str(_mono(m))] = [_deg(m) - 1, eq.K - _ord(m)]
    return {"symbols": [a, b, g], "E": E2, "characters": chars,
            "note": "w = alpha*W + beta, z = gamma*Z; for beta = 0 and E monic in wK the coefficient of "
                    "prod w_j^e_j is multiplied by alpha^(d-1)*gamma^(K-o), d = sum e_j, o = sum j*e_j"}


def dominant_monomial(terms, K):
    """(m*, p*) of NORMAL FORM step 2, or (None, None)"""
    best, bkey = None, None
    for m in terms:
        d = _deg(m)
        if d < 2:
            continue
        o = _ord(m)
        if K - o <= 0:
            return None, None
        p = sp.Rational(K - o, d - 1)
        key = (p, 0 if m[0] >= 1 else 1, -d, tuple(-e for e in reversed(m)))
        if bkey is None or key < bkey:
            best, bkey = m, key
    if best is None:
        return None, None
    return best, bkey[0]


def _target(mstar, p, K):
    num = _ff(-p, K)
    den = sp.Integer(1)
    for j, e in enumerate(mstar):
        den *= _ff(-p, j) ** e
    return sp.Rational(-1) * num / den


def _eval_point(params):
    pt = {}
    for i, s in enumerate(sorted(params, key=lambda x: x.name)):
        pt[s] = sp.Rational(2 * i + 3, 7) + sp.I * sp.Rational(i + 2, 13)
    return pt


def _root_of_unity(u):
    u = sp.Rational(u) % 1
    if u == 0:
        return sp.Integer(1)
    return sp.nsimplify(sp.cos(2 * sp.pi * u) + sp.I * sp.sin(2 * sp.pi * u))


def _residual_group(M):
    """elements (alpha, gamma) (roots of unity) with alpha^a gamma^b = 1 for each row (a, b) of M (2 x 2,
    nonsingular), the identity first"""
    (a1, b1), (a2, b2) = M
    D = a1 * b2 - a2 * b1
    n = abs(D)
    seen, out = set(), []
    for i in range(n):
        for j in range(n):
            # (u, v) = M^-1 (i, j)
            u = sp.Rational(b2 * i - b1 * j, D) % 1
            v = sp.Rational(-a2 * i + a1 * j, D) % 1
            if (u, v) in seen:
                continue
            seen.add((u, v))
            out.append((u, v))
    out.sort(key=lambda x: (x != (0, 0), x))
    return [(_root_of_unity(u), _root_of_unity(v)) for u, v in out]


def normalise(eq, time_budget=20.0, field="C"):
    """(eq_normal, map): the NORMAL FORM of the module docstring.

    field="R" (only used when every coefficient after steps 1-3 is a real number): real changes of variables
    only; the coefficients of m* and m1 become +-T and +-1 (|alpha|, |gamma| from real radicals) and the signs of
    alpha, gamma are chosen to make, in this order, c(m*) = +T, c(m1) = +1 and the remaining coefficients (in
    the order of their exponent tuples) positive.  With symbolic parameters field="R" falls back to "C".

    map = {"alpha", "beta", "gamma", "lam" (strings), "forward": {"w": ..., "z": ...},
           "inverse": {"W": ..., "Z": ...}, "conditions": [...], "steps": [...], "mstar", "pstar", "m1",
           "residual_group_order", "convention", "_exact": {sympy objects}}
    """
    t0 = time.monotonic()
    eq = _as_eq(eq)
    E = _E_of(eq)
    K = eq.K
    params = set(_params_of(eq))
    terms = _terms(E, K)
    top = tuple([0] * K + [1])
    conds, steps = [], []
    solved = top in terms and all(m[K] == 0 for m in terms if m != top)
    if solved:
        lead = terms[top]
        steps.append("divide by the coefficient of w%d" % K)
    else:
        lm = max(terms, key=lambda m: (_ord(m), _deg(m), tuple(reversed(m))))
        lead = terms[lm]
        steps.append("not solved for w%d: divide by the coefficient of %s only" % (K, _mono(lm)))
    c = _cond(lead)
    if c:
        conds.append(c)
    T1 = dict((m, sp.cancel(v / lead)) for m, v in terms.items())
    alpha, beta, gamma = sp.Integer(1), sp.Integer(0), sp.Integer(1)
    mstar = pstar = m1 = None
    order = 1
    if solved and K >= 1:
        mstar, pstar = dominant_monomial(T1, K)
    if mstar is not None:
        cstar = T1[mstar]
        c = _cond(cstar)
        if c:
            conds.append(c)
        # 3. shift
        if mstar[0] >= 1:
            target = list(mstar)
            target[0] -= 1
            target = tuple(target)
            if target != top:
                beta = sp.cancel(-T1.get(target, sp.Integer(0)) / (mstar[0] * cstar))
                if beta != 0:
                    Es = sp.expand(_from_terms(T1).subs(_w(0), _w(0) + beta))
                    T1 = _terms(Es, K)
                    steps.append("shift w -> w + (%s) removes the term in %s" % (sp.sstr(beta), _mono(target)))
        # 4. scalings
        W = pstar + K
        Tm = _target(mstar, pstar, K)
        cands = []
        for m, v in T1.items():
            if m in (top, mstar):
                continue
            gap = W - (_deg(m) * pstar + _ord(m))
            if gap > 0:
                cands.append((gap, -_deg(m), tuple(-e for e in reversed(m)), m))
        cands.sort()
        ds, os_ = _deg(mstar) - 1, K - _ord(mstar)
        real_mode = field == "R" and all(sp.sympify(v).is_number and sp.sympify(v).is_real for v in T1.values())
        if field == "R" and not real_mode:
            steps.append("field R requested but the coefficients are not real numbers: complex convention used")
        absf = (lambda q: abs(q)) if real_mode else (lambda q: q)
        if cands:
            m1 = cands[0][3]
            c1 = T1[m1]
            c = _cond(c1)
            if c:
                conds.append(c)
            d1, o1 = _deg(m1) - 1, K - _ord(m1)
            D = ds * o1 - d1 * os_
            Lstar = Tm / T1[mstar]
            L1 = 1 / c1
            alpha = sp.Pow(absf(Lstar), sp.Rational(o1, D)) * sp.Pow(absf(L1), sp.Rational(-os_, D))
            gamma = sp.Pow(absf(L1), sp.Rational(ds, D)) * sp.Pow(absf(Lstar), sp.Rational(-d1, D))
            M = ((ds, os_), (d1, o1))
            steps.append("scale so that the coefficient of %s is %s and that of %s is 1"
                         % (_mono(mstar), Tm, _mono(m1)))
        else:
            Lstar = Tm / T1[mstar]
            alpha = sp.Pow(absf(Lstar), sp.Rational(1, ds))
            gamma = sp.Integer(1)
            # residual: alpha^ds gamma^os = 1 modulo the identity component; use (ds, os) and a complement
            g = sp.igcd(ds, os_)
            M = ((ds, os_), (-os_ // g, ds // g)) if os_ else ((ds, 0), (0, 1))
            steps.append("scale so that the coefficient of %s is %s" % (_mono(mstar), Tm))
        alpha, gamma = sp.powsimp(alpha), sp.powsimp(gamma)
        newT = {}
        for m, v in T1.items():
            if m == top:
                newT[m] = sp.Integer(1)
                continue
            newT[m] = _simp(v * alpha ** (_deg(m) - 1) * gamma ** (K - _ord(m)), t0 + time_budget)
        # 5. residual group: canonical representative
        if real_mode:
            one = sp.Integer(1)
            group = [(one, one), (one, -one), (-one, one), (-one, -one)]
            order = 4
        else:
            group = _residual_group(M) if abs(M[0][0] * M[1][1] - M[0][1] * M[1][0]) > 1 else [(1, 1)]
            order = len(group)
        if real_mode:
            rest = sorted(m for m in newT if m not in (top, mstar, m1))

            def _pos(v):
                v = sp.sympify(v)
                if v == 0:
                    return 0
                ip = v.is_positive
                if ip is None:
                    ip = float(v) > 0
                return 0 if ip else 1
            best, bkey = None, None
            for (ag, gg) in group:
                f = lambda m: newT[m] * ag ** (_deg(m) - 1) * gg ** (K - _ord(m))     # noqa: E731
                key = (0 if sp.simplify(f(mstar) - Tm) == 0 else 1,
                       0 if (m1 is None or sp.simplify(f(m1) - 1) == 0) else 1,
                       tuple(_pos(f(m)) for m in rest))
                if bkey is None or key < bkey:
                    best, bkey = (ag, gg), key
            ag, gg = best
            if (ag, gg) != (1, 1):
                alpha, gamma = alpha * ag, gamma * gg
                for m in list(newT):
                    if m != top:
                        newT[m] = _simp(newT[m] * ag ** (_deg(m) - 1) * gg ** (K - _ord(m)), t0 + time_budget)
            steps.append("real normal form: signs of alpha, gamma fixed by the coefficient signs")
        elif order > 1 and time.monotonic() - t0 < time_budget:
            pt = _eval_point(params | set().union(*[v.free_symbols for v in newT.values()]))
            keys = sorted(m for m in newT if m != top)
            best, bkey = (sp.Integer(1), sp.Integer(1)), None
            try:
                for (ag, gg) in group:
                    key = []
                    for m in keys:
                        val = sp.N((newT[m] * ag ** (_deg(m) - 1) * gg ** (K - _ord(m))).subs(pt), 30)
                        re_, im_ = sp.re(val), sp.im(val)
                        key.append((round(float(re_), 9), round(float(im_), 9)))
                    key = tuple(key)
                    if bkey is None or key < bkey:
                        best, bkey = (ag, gg), key
            except (TypeError, ValueError, ZeroDivisionError):
                best = (sp.Integer(1), sp.Integer(1))
                steps.append("residual group: the evaluation point is singular, principal branch kept")
            ag, gg = best
            if (ag, gg) != (1, 1):
                alpha, gamma = alpha * ag, gamma * gg
                for m in list(newT):
                    if m != top:
                        newT[m] = _simp(newT[m] * ag ** (_deg(m) - 1) * gg ** (K - _ord(m)), t0 + time_budget)
                steps.append("residual group of order %d: representative chosen" % order)
        En = _from_terms(newT)
    else:
        En = _from_terms(T1)
        if solved:
            steps.append("no balance of w%d with a nonlinear monomial: only the scale of E is fixed" % K)
    lam = gamma ** K / (alpha * lead) if solved else 1 / lead
    lam = _simp(lam)
    # radicals of parameters in the normal form become new parameters rho1, rho2, ... (mero.equation does not
    # accept roots of symbolic expressions); their definitions are recorded in the map
    En, radicals = _radicals_to_params(sp.expand(En), set(str(q) for q in _params_of(eq)))
    if radicals:
        steps.append("radicals of the parameters are written as new parameters: " +
                     ", ".join("%s = %s" % (k, sp.sstr(v)) for k, v in radicals.items()))
    try:
        eqn = _new_eq(En, eq, unknown=getattr(eq, "unknown", "w"))
    except ValueError:
        from .pde import _LocalEquation
        eqn = _LocalEquation(En, _params_of(eq), getattr(eq, "unknown", "w"), getattr(eq, "var", "z"))
    W_, Z_ = sp.symbols("W Z")
    mp = {"alpha": sp.sstr(alpha), "beta": sp.sstr(beta), "gamma": sp.sstr(gamma), "lam": sp.sstr(lam),
          "w": sp.sstr(alpha * W_ + beta), "z": sp.sstr(gamma * Z_),
          "forward": {"w": sp.sstr(alpha * W_ + beta), "z": sp.sstr(gamma * Z_)},
          "inverse": {"W": sp.sstr((sp.Symbol("w") - beta) / alpha), "Z": sp.sstr(sp.Symbol("z") / gamma)},
          "relation": "E_normal(W) = lam * E(alpha*W + beta, alpha*gamma**-1*W', ..., alpha*gamma**-K*W^(K))",
          "conditions": conds, "steps": steps,
          "mstar": None if mstar is None else str(_mono(mstar)), "pstar": None if pstar is None else str(pstar),
          "m1": None if m1 is None else str(_mono(m1)), "residual_group_order": order,
          "convention": "monic in wK; shift kills the coefficient of m*/w0; coefficient of m* = T (a0 = 1 in the "
                        "two-term balance); coefficient of the next monomial m1 = 1; see mero.transform",
          "radicals": dict((str(k), sp.sstr(v)) for k, v in radicals.items()),
          "_exact": {"alpha": alpha, "beta": beta, "gamma": gamma, "lam": lam, "radicals": radicals}}
    return eqn, mp


def _radicals_to_params(E, taken, numeric_limit=4):
    """replace every power b**(p/q) with a symbolic base b by rho**(p*Q/q), rho = b**(1/Q) (Q = lcm of the
    denominators for that base); returns (E', {rho: b**(1/Q)}) with deterministic names rho1, rho2, ...
    Numeric radicals are replaced as well when the field they generate may have degree > numeric_limit
    (product of the root orders; mero.equation computes that field and is slow for large degrees)."""
    bases, nbases = {}, {}
    for a in E.atoms(sp.Pow):
        if a.exp.is_integer or not a.exp.is_Rational:
            continue
        if a.base.free_symbols:
            bases.setdefault(a.base, set()).add(sp.Rational(a.exp))
        elif a.base.is_number:
            nbases.setdefault(a.base, set()).add(sp.Rational(a.exp))
    size = 2 if E.has(sp.I) else 1
    for b, es in nbases.items():
        Q = 1
        for e in es:
            Q = sp.ilcm(Q, e.q)
        size *= Q
    if size > numeric_limit:
        bases.update(nbases)
    if not bases:
        return E, {}
    rep, defs, k = {}, {}, 0
    for b in sorted(bases, key=lambda q: (not bool(q.free_symbols), sp.default_sort_key(q))):
        Q = 1
        for e in bases[b]:
            Q = sp.ilcm(Q, e.q)
        k += 1
        name = "rho%d" % k
        while name in taken:
            k += 1
            name = "rho%d" % k
        rho = sp.Symbol(name)
        defs[rho] = sp.Pow(b, sp.Rational(1, Q))
        for e in bases[b]:
            rep[sp.Pow(b, e)] = rho ** int(e * Q)
    return sp.expand(E.xreplace(rep)), defs


def normal_form_expr(eqn, mp):
    """E of the normal form with the radical parameters rho_i replaced by their definitions"""
    rad = (mp.get("_exact") or {}).get("radicals")
    if rad is None:
        rad = dict((sp.Symbol(k), sp.sympify(v)) for k, v in (mp.get("radicals") or {}).items())
    return eqn.E.subs(rad) if rad else eqn.E


def normal_form_block(eq):
    """the "normal_form" block of a report (SCHEMA section 3): {"sympy", "latex", "map", "conditions", "steps",
    "residual_group_order", "family": None}"""
    eqn, mp = normalise(eq)
    try:
        lt = eqn.latex()
    except Exception:          # pragma: no cover
        lt = sp.latex(eqn.E) + " = 0"
    blk = {"sympy": str(eqn.E), "latex": lt,
           "map": {"w": mp["w"], "z": mp["z"], "W": mp["inverse"]["W"], "Z": mp["inverse"]["Z"],
                   "lam": mp["lam"]},
           "conditions": mp["conditions"], "steps": mp["steps"], "residual_group_order": mp["residual_group_order"],
           "convention": mp["convention"], "family": None}
    if not _params_of(_as_eq(eq)):
        try:
            eqr, mpr = normalise(eq, field="R")
            if not any("not real" in st for st in mpr["steps"]):
                try:
                    ltr = eqr.latex()
                except Exception:          # pragma: no cover
                    ltr = sp.latex(eqr.E) + " = 0"
                blk["real"] = {"sympy": str(eqr.E), "latex": ltr,
                               "map": {"w": mpr["w"], "z": mpr["z"], "W": mpr["inverse"]["W"],
                                       "Z": mpr["inverse"]["Z"], "lam": mpr["lam"]}}
        except Exception:                  # pragma: no cover
            pass
    return blk


def _exact(mp, key):
    ex = mp.get("_exact") or {}
    if key in ex:
        return ex[key]
    return sp.sympify(mp[key])


def transport_solution(expr, mp, var="z"):
    """w(z) = alpha * W(z / gamma) + beta for a solution W of the normal form (W given as an expression in `var`)."""
    v = sp.Symbol(var) if isinstance(var, str) else var
    a, b, g = _exact(mp, "alpha"), _exact(mp, "beta"), _exact(mp, "gamma")
    return a * sp.sympify(expr).subs(v, v / g) + b


def transport_to_normal(expr, mp, var="z"):
    """W(z) = (w(gamma z) - beta) / alpha for a solution w of the original equation."""
    v = sp.Symbol(var) if isinstance(var, str) else var
    a, b, g = _exact(mp, "alpha"), _exact(mp, "beta"), _exact(mp, "gamma")
    return (sp.sympify(expr).subs(v, g * v) - b) / a


# ---------------------------------------------------------------------------------------------- power changes

def power_change(eq, s):
    """w = u**s (s rational, s != 0, 1).  Returns (Equation for u in jets w0.., info) or (None, reason).

    Each w_j = u^(s-j) P_j(u, u', ...) with P_0 = 1, P_{j+1} = (s-j) u1 P_j + u0 D P_j.  A monomial m becomes
    u^(d s - o) prod P_j^e_j; this is polynomial after multiplying by a power of u iff d(m) s is the same modulo 1
    for all monomials.  The result is multiplied by u^N (N minimal), the common power of u0 is divided out and
    the integer content is removed."""
    eq = _as_eq(eq)
    s = sp.Rational(s)
    E = _E_of(eq)
    K = eq.K
    terms = _terms(E, K)
    fr = set((_deg(m) * s) % 1 for m in terms)
    if len(fr) > 1:
        return None, "the degrees of the monomials are not congruent modulo the denominator of %s" % s
    P = [sp.Integer(1)]
    for j in range(K):
        P.append(sp.expand((s - j) * _w(1) * P[j] + _w(0) * total_derivative(P[j])))
    N = max(_ord(m) - _deg(m) * s for m in terms)
    out = sp.Integer(0)
    for m, c in terms.items():
        ex = _deg(m) * s - _ord(m) + N
        assert ex.is_integer and ex >= 0
        t = c * _w(0) ** int(ex)
        for j, e in enumerate(m):
            if e:
                t *= P[j] ** e
        out += t
    out = sp.expand(out)
    # divide out the common power of u0
    Pl = sp.Poly(out, *_jets(K))
    k0 = min(mm[0] for mm in Pl.monoms())
    if k0 > 0:
        out = sp.expand(out / _w(0) ** k0)
    num, den = sp.fraction(sp.together(out))
    out = sp.expand(num)
    cont = sp.Poly(out, *_jets(K)).primitive()[0]
    if cont.is_number and cont != 0:
        out = sp.expand(out / cont)
    info = {"s": s, "N": N - k0, "factor": "E_u = u^(%s) * E_w * (const)" % sp.sstr(N - k0),
            "divided_u0": k0}
    return _new_eq(out, eq, unknown="u"), info


def _check_power(eq, equ, s):
    """exact check with a random explicit function: E_u[f] is a constant times f^e E_w[f^s]"""
    f = 2 + z + z ** 2 / 3 + sp.exp(z) / 5
    left = sp.simplify(equ.residual(f, z))
    right = eq.residual(f ** s, z)
    ratio = sp.simplify(sp.powsimp(left / right, force=True))
    return ratio


def newton_balances(terms):
    """all p > 0 (rational) at which the maximal weight sum_j e_j (p + j) is attained by at least two monomials,
    with those monomials: [(p, [m, ...])], increasing p.  (The corners of the upper envelope of the lines
    d(m) p + o(m).)"""
    ms = list(terms)
    cand = set()
    for m1, m2 in itertools.combinations(ms, 2):
        d1, d2 = _deg(m1), _deg(m2)
        if d1 == d2:
            continue
        p = sp.Rational(_ord(m2) - _ord(m1), d1 - d2)
        if p > 0:
            cand.add(p)
    out = []
    for p in sorted(cand):
        wts = dict((m, _deg(m) * p + _ord(m)) for m in ms)
        top = max(wts.values())
        dom = [m for m in ms if wts[m] == top]
        if len(set(_deg(m) for m in dom)) >= 2:
            out.append((p, dom))
    return out


def power_substitution(eq):
    """u = w**m when the dominant pole order p* = r/m is not an integer (m > 1); also u = w**(-m) (reciprocal).
    Each item: {"name", "map", "equation", "conditions", "note"}."""
    eq = _as_eq(eq)
    E = _E_of(eq)
    K = eq.K
    terms = _terms(E, K)
    top = tuple([0] * K + [1])
    out = []
    solved = top in terms and all(m[K] == 0 for m in terms if m != top)
    mstar, pstar = dominant_monomial(terms, K) if solved else (None, None)
    ps = []
    if pstar is not None:
        ps.append(pstar)
    for p, dom in newton_balances(terms):
        if p not in ps:
            ps.append(p)
    done = set()
    for pp in ps:
        if pp.q == 1 or pp.q in done:
            continue
        m = int(pp.q)
        done.add(m)
        for sgn, nm in ((1, "power"), (-1, "power-reciprocal")):
            s = sp.Rational(sgn, m)
            equ, info = power_change(eq, s)
            if equ is None:
                continue
            mp = {"w": "u**(%s)" % s, "u": "w**(%d)" % (sgn * m), "s": str(s), "p": str(pp)}
            note = ("a balance with pole order %s%s; u = w^%d has %s of integer order %d there"
                    % (pp, " (the balance with w%d)" % K if pp == pstar else "", sgn * m,
                       "poles" if sgn > 0 else "zeros", int(pp.p)))
            if sgn < 0:
                note += "; poles of u come from zeros of w"
            if info["divided_u0"]:
                note += "; a factor u^%d was divided out" % info["divided_u0"]
            out.append({"name": nm, "map": mp, "equation": equ, "conditions": [], "note": note})
    return out


# ---------------------------------------------------------------------------------------------- first integrals

def first_integral_reduction(eq, const=None):
    """[{"name": "integration" | "first-integral", ...}]:
    E = D F (direct antiderivative, verified)  ->  F + C = 0 ;
    E solved, K = 2, w'' = F(w)  ->  w'^2 = 2 int_0^w F + C  (multiplier w')."""
    eq = _as_eq(eq)
    E = _E_of(eq)
    K = eq.K
    taken = set(str(p) for p in _params_of(eq))
    C = sp.Symbol(const) if const else sp.Symbol(_fresh("C1", taken))
    out = []
    F = antiderivative(E)
    if F is not None and F != 0:
        out.append({"name": "integration", "map": {"relation": "E = D(F)", "F": sp.sstr(F)},
                    "equation": _new_eq(F + C, eq), "conditions": [],
                    "note": "E is the total derivative of F; F + %s = 0 with a constant of integration %s" % (C, C)})
    if K == 2:
        terms = _terms(E, K)
        top = (0, 0, 1)
        if top in terms and all(m[2] == 0 and m[1] == 0 for m in terms if m != top):
            lead = terms[top]
            Fw = sp.expand(-(E - lead * _w(2)) / lead)
            G = sp.Poly(Fw, _w(0)).integrate().as_expr() if Fw.has(_w(0)) else Fw * _w(0)
            E1 = sp.expand(_w(1) ** 2 - 2 * G - C)
            conds = [] if _cond(lead) is None else [_cond(lead)]
            out.append({"name": "first-integral", "map": {"multiplier": "w1", "relation": "D(E1) = 2*w1*E/lead"},
                        "equation": _new_eq(E1, eq), "conditions": conds,
                        "note": "w'' = F(w) times w' integrates to w'^2 = 2*int F dw + %s" % C})
    return out


# ---------------------------------------------------------------------------------------------- exponential twist

def exponential_twist(eq):
    """w = c + (kappa s)^p Y(s), s = exp(kappa z), for E = wK + sum_{j<K} a_j w_j + N(w0) with a nonlinear part
    N depending on w0 only.  After the shift w = c + v the nonlinear part must be one power b v^n (n >= 2) and
    the linear part must have the characteristic roots kappa p, kappa (p+1), ..., kappa (p+K-1), p = K/(n-1),
    and E(c) = 0.  Then  E = (kappa s)^(p+K) * (Y^(K) + b Y^n)  (exactly), i.e. the target is autonomous in s.
    Returns [] or [{"name": "exponential-twist", "map", "equation", "conditions", "note"}] where "conditions"
    are polynomial expressions in the parameters that must vanish (as 'expr = 0') or nonvanishing conditions."""
    eq = _as_eq(eq)
    E = _E_of(eq)
    K = eq.K
    if K < 1:
        return []
    terms = _terms(E, K)
    top = tuple([0] * K + [1])
    if top not in terms or any(m[K] for m in terms if m != top):
        return []
    lead = terms[top]
    T = dict((m, sp.cancel(v / lead)) for m, v in terms.items())
    lin = {}
    nonlin = {}
    const = sp.Integer(0)
    for m, v in T.items():
        if m == top:
            continue
        d = _deg(m)
        if d == 0:
            const = v
        elif d == 1:
            lin[m.index(1)] = v
        else:
            if any(m[1:]):
                return []           # derivative nonlinearity: not treated
            nonlin[m[0]] = v
    if not nonlin:
        return []
    if K < 2:
        return []
    n = max(nonlin)
    bn = nonlin[n]
    w0 = _w(0)
    N = sum((v * w0 ** k for k, v in nonlin.items()), sp.Integer(0))
    lin0 = lin.get(0, sp.Integer(0))
    p = sp.Rational(K, n - 1)
    a = [lin.get(j, sp.Integer(0)) for j in range(K)]
    s1 = K * p + sp.Rational(K * (K - 1), 2)
    kappa = sp.cancel(-a[K - 1] / s1)          # sum of the characteristic roots kappa*(p + i)
    if kappa == 0:
        return []
    lam = sp.Symbol("lam_")
    target_char = sp.expand(sp.prod([lam - kappa * (p + i) for i in range(K)]))
    if n == 2:
        # the shift c matches the coefficient of w0:  lin0 + 2 b c = target_char(0)
        cc = sp.cancel((target_char.coeff(lam, 0) - lin0) / (2 * bn))
    else:
        # the shift c removes v^(n-1) from the nonlinear part
        cc = sp.cancel(-nonlin.get(n - 1, sp.Integer(0)) / (n * bn))
    vv = sp.Symbol("v_")
    Nshift = sp.expand(N.subs(w0, cc + vv))
    conds = []
    for k in range(2, n):
        co = sp.factor(sp.together(Nshift.coeff(vv, k)))
        if co != 0:
            if co.is_number:
                return []
            conds.append("%s = 0" % sp.sstr(sp.numer(co)))
    a = [sp.expand(lin0 + Nshift.coeff(vv, 1))] + a[1:]
    have_char = sp.expand(lam ** K + sum(a[j] * lam ** j for j in range(K)))
    diff = sp.Poly(sp.expand(have_char - target_char), lam)
    for co in diff.all_coeffs():
        co = sp.factor(sp.together(co))
        if co != 0:
            if co.is_number:
                return []
            conds.append("%s = 0" % sp.sstr(sp.numer(co)))
    Ec = sp.factor(sp.together(const + N.subs(w0, cc) + lin0 * cc))
    if Ec != 0:
        if Ec.is_number:
            return []
        conds.append("%s = 0" % sp.sstr(sp.numer(Ec)))
    nz = [] if _cond(kappa) is None else [_cond(kappa)]
    if _cond(lead):
        nz.append(_cond(lead))
    target = sp.expand(_w(K) + bn * _w(0) ** n)
    teq = make_equation(target, [q for q in _params_of(eq) if target.has(q)], unknown="Y", var="s")
    S_, Yf = sp.Symbol("s"), sp.Function("Y")
    mp = {"w": sp.sstr(cc + (sp.Symbol("kappa") * S_) ** p * Yf(S_)), "s": "exp(kappa*z)", "kappa": sp.sstr(kappa),
          "c": sp.sstr(cc), "p": str(p),
          "relation": "E[w] = (kappa*s)**(p+K) * (Y^(K) + b*Y^n), b = %s, n = %d" % (sp.sstr(bn), n),
          "_exact": {"kappa": kappa, "c": cc, "p": p, "b": bn, "n": n}}
    note = ("w = c + (kappa s)^p Y(s), s = exp(kappa z) turns the equation into the autonomous pure-power equation "
            "Y^(%d) + (%s) Y^%d = 0 in s, provided the conditions hold" % (K, sp.sstr(bn), n))
    return [{"name": "exponential-twist", "map": mp, "equation": teq, "conditions": conds + nz, "note": note}]


# ---------------------------------------------------------------------------------------------- collection

def _finish(item):
    """JSON-friendly item: map without SymPy objects, plus "sympy" and "latex" of the equation"""
    item = dict(item)
    item["map"] = dict((k, v) for k, v in (item.get("map") or {}).items() if k != "_exact")
    e = item.get("equation")
    if e is not None:
        item["sympy"] = str(e.E)
        try:
            item["latex"] = e.latex()
        except Exception:          # pragma: no cover
            item["latex"] = sp.latex(e.E) + " = 0"
    return item


def substitutions(eq, include_normal_form=True):
    """everything applicable: [{"name", "map", "equation", "conditions", "note", "sympy", "latex"}]
    (names: "integration", "first-integral", "power", "power-reciprocal", "exponential-twist",
    "affine-normal-form"); "equation" is an Equation, everything else is JSON-ready."""
    eq = _as_eq(eq)
    out = []
    for fn in (first_integral_reduction, power_substitution, exponential_twist):
        try:
            out.extend(fn(eq))
        except Exception as err:     # a failing transformation must not break the report
            out.append({"name": fn.__name__, "map": {}, "equation": None, "conditions": [],
                        "note": "not computed: %s" % err})
    if include_normal_form:
        try:  # noqa: SIM105
            eqn, mp = normalise(eq)
            mp2 = dict((k, v) for k, v in mp.items() if k != "_exact")
            out.append({"name": "affine-normal-form", "map": mp2, "equation": eqn,
                        "conditions": mp["conditions"], "note": "; ".join(mp["steps"])})
            if not _params_of(eq):
                eqr, mpr = normalise(eq, field="R")
                if not any("not real" in st for st in mpr["steps"]):
                    out.append({"name": "affine-normal-form-real", "map": mpr, "equation": eqr,
                                "conditions": mpr["conditions"], "note": "; ".join(mpr["steps"])})
        except Exception as err:
            out.append({"name": "affine-normal-form", "map": {}, "equation": None, "conditions": [],
                        "note": "not computed: %s" % err})
    return [_finish(it) for it in out]


def _has_radicals(e):
    return any(not a.exp.is_integer for a in sp.sympify(e).atoms(sp.Pow))


def _algebraic_zero(v):
    """exact zero test for an algebraic number given by radicals"""
    v = sp.nsimplify(v) if v.has(sp.Float) else v
    if v == 0:
        return True
    try:
        X = sp.Dummy("X")
        return sp.minimal_polynomial(v, X) == X
    except Exception:
        return sp.simplify(v) == 0


def check_transformation(eq, eqn, mp, f=None, npoints=2, budget=30.0):
    """Exact check of a normal-form map.  Returns 0 when verified, else a nonzero witness.

    (1) The jet identity  E_normal(W) - lam * E(alpha W + beta, alpha gamma^-1 W1, ...)  is expanded in the jets
        and each coefficient is simplified.  If radicals of parameters remain (branch-sensitive expressions that
        SymPy cannot always simplify), each remaining coefficient is evaluated at `npoints` rational parameter
        points and shown to be 0 there exactly (minimal polynomial of the algebraic number).
    (2) If the map is rational, also an explicit function f(z) is substituted into both equations."""
    t0 = time.monotonic()
    a, b, g, lam = (_exact(mp, k) for k in ("alpha", "beta", "gamma", "lam"))
    En = normal_form_expr(eqn, mp)
    D = sp.expand(En - lam * affine_transform(eq, a, b, g))
    if D != 0:
        K = max(eq.K, eqn.K)
        rest = []
        for co in sp.Poly(D, *_jets(K)).coeffs():
            if sp.simplify(co) != 0:
                rest.append(co)
        if rest:
            syms = sorted(set().union(*[co.free_symbols for co in rest]), key=str)
            done = 0
            for k in range(npoints + 6):
                if done >= npoints:
                    break
                pt = dict((sy, sp.Rational(3 + 2 * i + k, 5 + i + 3 * k)) for i, sy in enumerate(syms))
                try:
                    vals = [co.subs(pt) for co in rest]
                    if any(v.has(sp.zoo, sp.nan, sp.oo) for v in vals):
                        continue
                except Exception:
                    continue
                for v in vals:
                    if time.monotonic() - t0 > budget:
                        return sp.Symbol("unverified")
                    if not _algebraic_zero(v):
                        return v
                done += 1
            if done < npoints:
                return sp.Symbol("unverified")
    if not any(_has_radicals(e) for e in (a, b, g, lam)):
        f = f if f is not None else 1 + z / 3 + z ** 4 / 5 + sp.exp(z / 3)
        left = eqn.residual(f, z)
        rad = (mp.get("_exact") or {}).get("radicals")
        if rad:
            left = left.subs(rad)
        right = lam * eq.residual(transport_solution(f, mp), z).subs(z, g * z)
        num = sp.expand(sp.numer(sp.together(sp.expand(left - right))))
        return num if num == 0 else sp.simplify(left - right)
    return sp.Integer(0)
