"""mero.pde -- polynomial evolution equations and their travelling-wave / stationary reductions.

    parse_pde(text, unknown=None)         -> PDE      one scalar polynomial equation in u(x, t), u(x, y, t), ...
    detect_kind(text)                     -> 'ode' | 'pde' | 'unknown'
    travelling_wave(pde, speed='c', wavevector=None, integrate=True, stationary=True)
                                          -> list of reductions (dicts), the most integrated travelling wave first
    antiderivative(E)                     -> F with D F = E (F a differential polynomial without constant term) or None
    euler_operator(E)                     -> the variational derivative of E (zero iff E is a total derivative,
                                             for E without a jet-free term)

Notation of the input (no eval is used; the text is read by a small recursive-descent parser):
    derivatives    u_t, u_xx, u_xxt, u_tt, u_xy, u_{xx}, (expr)_xx, diff(u, x, 2), diff(u, x, x, t), diff(u^2, x),
                   Dx(expr), Dx(expr, 2), Dt(expr)  (D followed by x, y, z or t, directly before a parenthesis)
    powers         ^ or **  (also the superscripts 2..6)
    products       *, or implicit (6 u u_x, 2u, u(1 - u), (u^2)_x u)
    equation       lhs = rhs  (or an expression, meaning expression = 0)
    parameters     every other name (Greek letters may be typed as such); I = sqrt(-1), pi = 3.14...
The independent variables are the letters used in the derivative subscripts / diff(...) calls (single letters);
t is time, the others are space variables (order x, y, z, then alphabetical).

A *reduction* is a dict
    {"ansatz": "u = w(z), z = x - c*t", "kind": "travelling-wave" | "stationary" | "plane-wave",
     "integrated": k, "lowered": j, "constants": ["Ck"], "conditions": ["C1 = 0", ...], "equation": Equation,
     "sympy": str(E), "note": "..."}
Complex equations (an unknown q with i/I, |q|, abs(q), conj(q), q^*, qb / qbar = conjugate, e.g. NLS, Hirota,
Kaup-Newell, Sasa-Satsuma, Klein-Gordon with a complex field) give PDE.complex = True; travelling_wave then returns
envelope_wave(...): q = w(z) exp(i theta), theta = -kappa x + omega t + theta0 (optionally with the chirp
Theta'(z) = s w^2), reductions of kind "envelope" carrying "constraints" (c = ..., relations among the parameters)
and the real ODE for w; see the comment before envelope_wave.
"lowered" = j > 0 when only derivatives of w occur and the form is written for v = w^(j) (order lowered by j; the
unlowered form follows it in the list).  Rejected with ValueError('unsupported: ...'): non-polynomial terms (exp, sin,
sqrt, u^n with symbolic n, u in a denominator), a modulus |q| (NLS-type), systems ('eq1; eq2', or a second unknown
such as v_x), explicit x or t; complex equations whose imaginary part cannot be removed (complex coefficients, e.g.
complex Ginzburg-Landau).
The k-times integrated form carries the constant Ck of the last integration; integrating once more is possible only
when the previous constant vanishes (otherwise a term C*z appears), so the k-times integrated form is valid under
C1 = ... = C(k-1) = 0, recorded in "conditions".  Integration is exact: E = D F is decided by the direct
antiderivative algorithm (top-order linearity, integrate the coefficient, subtract, repeat) and the result is
verified by differentiating; no multiplier (such as w') is ever used here.
"""
import re
import time
import sympy as sp

__all__ = ["PDE", "parse_pde", "detect_kind", "travelling_wave", "stationary_reduction", "envelope_wave",
           "antiderivative", "euler_operator", "total_derivative", "make_equation", "jets"]

# ---------------------------------------------------------------------------------------------- jets


def jets(K):
    return tuple(sp.Symbol("w%d" % j) for j in range(K + 1))


_JET = re.compile(r"^w(\d+)$")


def _jet_index(sym):
    m = _JET.match(getattr(sym, "name", ""))
    return int(m.group(1)) if m else None


def _order(expr):
    """highest jet index present in expr (-1 if none)"""
    js = [_jet_index(s) for s in sp.sympify(expr).free_symbols]
    js = [j for j in js if j is not None]
    return max(js) if js else -1


def total_derivative(expr, n=1):
    """D^n of a polynomial in the jets w0, w1, ... (D w_j = w_{j+1}; parameters are constants)"""
    expr = sp.sympify(expr)
    for _ in range(int(n)):
        new = sp.Integer(0)
        for s in expr.free_symbols:
            j = _jet_index(s)
            if j is not None:
                new += sp.diff(expr, s) * sp.Symbol("w%d" % (j + 1))
        expr = sp.expand(new)
    return expr


def euler_operator(E):
    """variational derivative  sum_j (-D)^j dE/dw_j  (expanded)"""
    E = sp.expand(E)
    N = _order(E)
    out = sp.Integer(0)
    for j in range(N + 1):
        t = sp.diff(E, sp.Symbol("w%d" % j))
        out += (-1) ** j * total_derivative(t, j)
    return sp.expand(out)


def antiderivative(E):
    """F (a polynomial in the jets with no jet-free term) with D F = E, or None if E is not a total derivative.

    Direct algorithm: if E = D F with F of order m then E has order m+1 and is linear in w_{m+1} with
    coefficient dF/dw_m; integrate that coefficient in w_m, subtract D of the result and repeat.  The answer is
    verified by differentiation before it is returned.
    """
    E = sp.expand(sp.sympify(E))
    if E == 0:
        return sp.Integer(0)
    F = sp.Integer(0)
    R = E
    for _ in range(_order(E) + 2):
        if R == 0:
            break
        N = _order(R)
        if N <= 0:                       # nonzero function of w0 alone (or a constant): not a derivative
            return None
        wN, wM = sp.Symbol("w%d" % N), sp.Symbol("w%d" % (N - 1))
        P = sp.Poly(R, wN)
        if P.degree() > 1:
            return None
        A = P.coeff_monomial(wN)
        F1 = sp.Poly(A, wM).integrate().as_expr()
        F = F + F1
        R = sp.expand(R - total_derivative(F1))
    if R != 0:
        return None
    F = sp.expand(F)
    if sp.expand(total_derivative(F) - E) != 0:      # verification (cannot fail if the algebra is right)
        return None
    return F


# ---------------------------------------------------------------------------------------------- Equation


def make_equation(E, params=None, unknown="w", var="z", name="", source=None):
    """An Equation (mero.equation.Equation of CORE when importable, else a minimal local class)."""
    E = sp.expand(sp.sympify(E))
    params = [q for q in (params or []) if E.has(sp.Symbol(str(q)))]
    try:
        from .equation import Equation as _CoreEquation
    except ImportError:
        return _LocalEquation(E, params, unknown, var, name)
    try:
        return _CoreEquation(E=E, parameters=list(params or []), name=name, unknown=unknown, var=var,
                             source=source)
    except TypeError:                      # a changed constructor signature: the minimal form
        return _CoreEquation(E=E)


class _LocalEquation(object):
    """Fallback with the attributes of SCHEMA section 1 (used only if mero.equation is missing)."""

    def __init__(self, E, params=None, unknown="w", var="z", name=""):
        E = sp.expand(sp.sympify(E))
        self.K = max(_order(E), 0)
        self.w = jets(self.K)
        P = sp.Poly(E, *self.w)
        self.terms = dict((tuple(int(e) for e in m), sp.factor(c)) for m, c in P.terms() if c != 0)
        self.E = P.as_expr()
        declared = [sp.Symbol(str(q)) for q in (params or [])]
        present = set()
        for c in self.terms.values():
            present |= c.free_symbols
        self.params = [s for s in declared if s in present] + sorted(present - set(declared), key=str)
        self.degree = max((sum(m) for m in self.terms), default=0)
        top = tuple([0] * self.K + [1])
        self.solved = top in self.terms and all(m[self.K] == 0 for m in self.terms if m != top)
        self.lead = self.terms[top] if self.solved else None
        self.rhs = sp.expand(-(self.E - self.lead * self.w[self.K]) / self.lead) if self.solved else None
        self.unknown, self.var, self.name = unknown, var, name

    def residual(self, expr, var=sp.Symbol("z")):
        var = sp.Symbol(var) if isinstance(var, str) else var
        return self.E.subs(dict((self.w[j], sp.diff(expr, var, j)) for j in range(self.K + 1)),
                           simultaneous=True)

    def to_dict(self):
        return {"order": self.K, "sympy": str(self.E), "E": str(self.E), "params": [str(s) for s in self.params],
                "unknown": self.unknown, "var": self.var, "solved": self.solved, "degree": self.degree}

    def latex(self):
        return sp.latex(self.E) + " = 0"

    def __repr__(self):
        return "Equation(%s = 0)" % self.E


def _E_of(eq):
    E = getattr(eq, "E", None)
    if E is None:
        E = eq.w[eq.K] - eq.rhs
    return sp.expand(E)


# ---------------------------------------------------------------------------------------------- tokenizer

_GREEK = {"α": "alpha", "β": "beta", "γ": "gamma", "δ": "delta", "ε": "epsilon", "ϵ": "epsilon", "ζ": "zeta",
          "η": "eta", "θ": "theta", "ϑ": "theta", "ι": "iota", "κ": "kappa", "λ": "lamda", "μ": "mu", "ν": "nu",
          "ξ": "xi", "ρ": "rho", "σ": "sigma", "τ": "tau", "υ": "upsilon", "φ": "phi", "ϕ": "phi", "χ": "chi",
          "ψ": "psi", "ω": "omega", "Γ": "Gamma", "Δ": "Delta", "Θ": "Theta", "Λ": "Lamda", "Ξ": "Xi",
          "Σ": "Sigma", "Φ": "Phi", "Ψ": "Psi", "Ω": "Omega"}
_SUPER = {"²": "^2", "³": "^3", "⁴": "^4", "⁵": "^5", "⁶": "^6", "¹": "^1"}
_REPL = {"−": "-", "–": "-", "—": "-", "·": "*", "×": "*", "⋅": "*", "′": "'", "″": "''", "‴": "'''",
         " ": " ", " ": " "}
_FUNCS = {"sqrt": sp.sqrt, "exp": sp.exp, "log": sp.log, "ln": sp.log, "sin": sp.sin, "cos": sp.cos,
          "tan": sp.tan, "sinh": sp.sinh, "cosh": sp.cosh, "tanh": sp.tanh, "abs": sp.Abs, "Abs": sp.Abs,
          "cot": sp.cot, "coth": sp.coth, "sec": sp.sec, "sech": sp.sech, "csc": sp.csc, "csch": sp.csch,
          "asin": sp.asin, "acos": sp.acos, "atan": sp.atan, "arctan": sp.atan, "arcsin": sp.asin,
          "arccos": sp.acos}
_DIFF = ("diff", "Derivative", "derivative")
_RESERVED = {"I": sp.I, "i": sp.I, "pi": sp.pi}
_CONJ_FUNCS = ("conj", "conjugate", "Conjugate")
_FAMILY_CHARGE = {"u": 1, "ubar": -1, "abs": 0}


def _dname(U, family, vars_, alpha):
    """name of a derivative symbol: u_xxt (family u), ub_xxt (conjugate), absu_xxt (modulus |u|)"""
    base = {"u": U, "ubar": U + "b", "abs": "abs" + U}[family]
    sub = "".join(v * k for v, k in zip(vars_, alpha))
    return base + ("_" + sub if sub else "")
_PYKW = {"lambda": "lamda"}

_TOKEN = re.compile(r"""
    (?P<num>\d+\.\d*|\.\d+|\d+)
  | (?P<name>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<op>\*\*|[-+*/^(),=\[\]'|])
  | (?P<ws>\s+)
""", re.X)


_LATEX_GREEK = {"alpha": "alpha", "beta": "beta", "gamma": "gamma", "delta": "delta", "epsilon": "epsilon",
                "varepsilon": "epsilon", "zeta": "zeta", "eta": "eta", "theta": "theta", "vartheta": "theta",
                "iota": "iota", "kappa": "kappa", "lambda": "lamda", "mu": "mu", "nu": "nu", "xi": "xi", "rho": "rho",
                "sigma": "sigma", "tau": "tau", "upsilon": "upsilon", "phi": "phi", "varphi": "phi", "chi": "chi",
                "psi": "psi", "omega": "omega", "Gamma": "Gamma", "Delta": "Delta", "Theta": "Theta",
                "Lambda": "Lamda", "Xi": "Xi", "Sigma": "Sigma", "Phi": "Phi", "Psi": "Psi", "Omega": "Omega"}
_LATEX_FUNCS = ("sqrt", "exp", "log", "ln", "sin", "cos", "tan", "sinh", "cosh", "tanh", "cot", "coth", "sec",
                "sech", "csc", "csch", "arcsin", "arccos", "arctan")


def _latex_group(s, i):
    """(content, next index) of one LaTeX argument at s[i]: {...}, a control word, or one character"""
    while i < len(s) and s[i] == " ":
        i += 1
    if i >= len(s):
        raise ValueError("unsupported: a LaTeX argument is missing")
    if s[i] == "{":
        depth, j = 0, i
        while j < len(s):
            if s[j] == "{":
                depth += 1
            elif s[j] == "}":
                depth -= 1
                if depth == 0:
                    return s[i + 1:j], j + 1
            j += 1
        raise ValueError("unsupported: unbalanced braces in the LaTeX input")
    if s[i] == "\\":
        m = re.match(r"\\[A-Za-z]+", s[i:])
        if m:
            return m.group(0), i + m.end()
    return s[i], i + 1


def _latex_partial_frac(num, den):
    """\\frac{\\partial^2 u}{\\partial x^2} -> u_xx ; \\frac{\\partial}{\\partial x} -> \\partial_{x} (an operator) ;
    \\frac{\\partial (u^2)}{\\partial x} -> \\partial_{x}(u^2) ; None if not of these forms"""
    letters = ""
    for md in re.finditer(r"\\partial\s*\{?\s*([a-z])\s*\}?\s*(?:\^\s*\{?\s*(\d+)\s*\}?)?", den):
        letters += md.group(1) * int(md.group(2) or 1)
    mo = re.match(r"^\s*\\partial\s*(?:\^\s*\{?\s*(\d+)\s*\}?)?\s*(\(.*\))?\s*$", num)
    if mo and letters and (not mo.group(1) or int(mo.group(1)) == len(letters)):
        return "\\partial_{%s}%s" % (letters, (" " + mo.group(2)) if mo.group(2) else " ")
    mn = re.match(r"^\s*\\partial\s*(?:\^\s*\{?\s*(\d+)\s*\}?)?\s*\{?\s*([A-Za-z]\w*)\s*\}?\s*$", num)
    if not mn:
        return None
    letters = ""
    for md in re.finditer(r"\\partial\s*\{?\s*([a-z])\s*\}?\s*(?:\^\s*\{?\s*(\d+)\s*\}?)?", den):
        letters += md.group(1) * int(md.group(2) or 1)
    if not letters or (mn.group(1) and int(mn.group(1)) != len(letters)):
        return None
    U = mn.group(2)
    return U + ("" if "_" in U else "_") + letters


def _latex_to_plain(s, warns=None):
    """the common LaTeX subset of PDE input -> plain notation (Greek control words, \\frac, \\partial forms,
    \\left/\\right, \\cdot, spacing, \\lvert/\\rvert, \\mathrm{i}, \\bar{q}, ^{...})"""
    if "\\" not in s:
        return s
    warns = warns if warns is not None else []
    if re.search(r"\\(Delta|nabla)(?![A-Za-z])", s):
        raise ValueError("unsupported: \\Delta / \\nabla (a Laplacian or gradient) is not read: write the space "
                         "derivatives out, e.g. u_xx + u_yy")
    s = re.sub(r"\\(left|right|big|Big|bigg|Bigg)\b", "", s)
    # Greek letters first (they can be the unknown, e.g. \partial_t \psi)
    s = re.sub(r"\\(%s)(?![A-Za-z])" % "|".join(sorted(_LATEX_GREEK, key=len, reverse=True)),
               lambda m: " " + _LATEX_GREEK[m.group(1)] + " ", s)
    s = s.replace("[", "(").replace("]", ")")
    s = re.sub(r"\b([A-Za-z]+)_\{\s*(\d+)\s*\}", r"\1\2", s)
    s = re.sub(r"\\[,;:!]|\\quad|\\qquad|~", " ", s)
    s = s.replace("\\cdot", "*").replace("\\times", "*")
    s = re.sub(r"\\[lr]?[vV]ert\b", "|", s)
    s = re.sub(r"\\mathrm\{\s*i\s*\}", "I", s)
    s = re.sub(r"\\(mathrm|operatorname|text|mathit)\{([^{}]*)\}", r"\2", s)
    s = re.sub(r"\\(bar|overline)\{\s*([A-Za-z]\w*)\s*\}", r"\2b", s)
    s = re.sub(r"\\(bar|overline)\s+([A-Za-z])(_\{?[a-z]+\}?)?", lambda m: m.group(2) + "b" + (m.group(3) or ""), s)
    s = re.sub(r"\^\{\s*\*\s*\}", "^*", s)
    # \frac with arguments (partial-derivative fractions first)
    out, i = "", 0
    while i < len(s):
        if s.startswith("\\frac", i) or s.startswith("\\tfrac", i) or s.startswith("\\dfrac", i):
            j = i + (5 if s.startswith("\\frac", i) else 6)
            num, j = _latex_group(s, j)
            den, j = _latex_group(s, j)
            pf = _latex_partial_frac(num, den)
            out += pf if pf else "((%s)/(%s))" % (_latex_to_plain(num, warns), _latex_to_plain(den, warns))
            i = j
            continue
        out += s[i]
        i += 1
    s = out
    # \partial_x^2 u, \partial_{xx} u, \partial_t (expr)
    def _dop(m):
        return m.group(0)
    out, i = "", 0
    pat = re.compile(r"\\partial_\{?\s*([a-z]+)\s*\}?(?:\^\{?\s*(\d+)\s*\}?)?\s*")
    while i < len(s):
        m = pat.match(s, i)
        if m:
            letters = m.group(1) * int(m.group(2) or 1)
            j = m.end()
            m2 = pat.match(s, j)
            while m2:                          # \partial_x \partial_t u: a mixed derivative
                letters += m2.group(1) * int(m2.group(2) or 1)
                j = m2.end()
                m2 = pat.match(s, j)
            mn = re.match(r"([A-Za-z]\w*)", s[j:])
            if j < len(s) and s[j] == "(":
                depth, k = 0, j
                while k < len(s):
                    depth += s[k] == "("
                    depth -= s[k] == ")"
                    if depth == 0:
                        break
                    k += 1
                raw = s[j + 1:k]
                after = s[k + 1:].lstrip()
                if "\\partial" in raw:
                    # an operator polynomial ([r - (1 + d^2)^2] u) or an operator followed by more factors:
                    # commuting operator symbols, applied to the rest of the term after expansion
                    out += "(" + "*".join("Dop" + ch for ch in letters) + ")*(" + _latex_to_plain(raw, warns) + ")"
                else:
                    inner = "(" + _latex_to_plain(raw, warns) + ")"
                    for ch in letters:
                        inner = "D%s(%s)" % (ch, inner)
                    out += inner
                i = k + 1
                continue
            if mn:
                name = mn.group(1)
                k2 = j + mn.end()
                mp_ = re.match(r"\s*\^\s*(\{[^{}]*\}|\d+|[A-Za-z])", s[k2:])
                if mp_ and "_" not in name:
                    # \partial_x u^2: the derivative of the power (the usual reading), with a warning
                    ex = mp_.group(1).strip("{}")
                    inner = "(%s^(%s))" % (name, ex)
                    for ch in letters:
                        inner = "D%s(%s)" % (ch, inner)
                    warns.append("\\partial_%s %s^%s was read as the derivative of %s^%s"
                                 % (m.group(1), name, ex, name, ex))
                    out += inner
                    i = k2 + mp_.end()
                    continue
                out += name + ("" if "_" in name else "_") + letters
                i = k2
                continue
            # an operator not followed by its operand: allowed only in a constant-coefficient operator polynomial,
            # e.g. (1 + \partial_x^2)^2 u; refused when the bracket holds the operand (material derivative
            # (\partial_t + u \partial_x) u, (u \partial_x) u)
            depth, a = 0, i - 1
            while a >= 0:
                if s[a] == ")":
                    depth += 1
                elif s[a] == "(":
                    if depth == 0:
                        break
                    depth -= 1
                a -= 1
            depth, b = 0, i
            while b < len(s):
                if s[b] == "(":
                    depth += 1
                elif s[b] == ")":
                    if depth == 0:
                        break
                    depth -= 1
                b += 1
            if a < 0 or b >= len(s):
                raise ValueError("unsupported: \\partial_%s is not followed by what it differentiates; write "
                                 "\\partial_%s u or u_%s" % (m.group(1), m.group(1), m.group(1)))
            content = re.sub(r"\\partial_\{?[a-z]+\}?(\^\{?\d+\}?)?", " ", s[a + 1:b])
            names_in = set(re.findall(r"[A-Za-z]\w*", content))
            rest = s[b + 1:]
            mo_ = re.match(r"\s*(?:\^\s*\{?\s*\d+\s*\}?)?\s*(?:\*\s*)?\(?\s*([A-Za-z]\w*)", rest)
            if mo_ and mo_.group(1) in names_in:
                raise ValueError("unsupported: the operator notation (... %s \\partial_%s ...) %s, a material "
                                 "derivative, is not read: write the products out, e.g. u_t + u*u_x"
                                 % (mo_.group(1), m.group(1), mo_.group(1)))
            out += "(" + "*".join("Dop" + ch for ch in letters) + ")"
            i = j
            continue
        out += s[i]
        i += 1
    s = out
    # control words
    def _cw(m):
        w = m.group(1)
        if w in ("dot", "ddot", "dddot"):
            raise ValueError("unsupported: the dot notation \\%s is a time derivative of a function of one "
                             "variable; in an equation with several variables write u_t" % w)
        if w in _LATEX_GREEK:
            return " " + _LATEX_GREEK[w] + " "
        if w in _LATEX_FUNCS:
            return w
        if w == "partial":
            raise ValueError("unsupported: this form of \\partial is not read; write u_t, u_xx or "
                             "\\frac{\\partial u}{\\partial t}")
        raise ValueError("unsupported: the LaTeX command \\%s is not read" % w)
    s = re.sub(r"\\([A-Za-z]+)", _cw, s)
    return s


_EQUATION_TAGS = {"kdv", "mkdv", "nls", "nlse", "burgers", "fisher", "kpp", "bbm", "kp", "zk", "ks", "kse",
                  "boussinesq", "kawahara", "gardner", "pde"}


def _lead_tags():
    """leading words that are dropped: the verbs of mero.parse (_LEAD_WORDS) and equation names"""
    try:
        from .parse import _LEAD_WORDS as _lw
        words = set(w_.lower() for w_ in _lw)
    except Exception:          # pragma: no cover
        words = {"solve", "find", "equation", "ode", "eq", "eqn", "the", "consider", "analyse", "analyze", "study",
                 "integrate", "please"}
    return words | _EQUATION_TAGS


def _mixed_notation(t):
    """two derivative notations in one input (primes, dots, subscripts / partial derivatives): refused"""
    primed = set(re.findall(r"([A-Za-z]\w*)\s*(?:'+|\u2032|\u2033|\u2034)", t))
    dotted = set(re.findall(r"\\d*dot\s*\{?\s*([A-Za-z]\w*)", t))
    has_prime = bool(primed) or bool(re.search(r"\}\s*('+|\u2032|\u2033|\u2034)", t))
    has_dot = bool(re.search(r"\\d+dot\b|\\dot\b", t))
    carriers = primed | dotted
    has_sub = bool(re.search(r"\\partial|\bdiff\s*\(|\bD[xyzt]\s*\(", t)) or any(
        re.search(r"\b%s_\{?[xyzt]+\}?(?![A-Za-z0-9])" % re.escape(n_), t) for n_ in carriers)
    if not carriers and not has_dot:
        has_sub = has_sub and has_prime
    names = [n for n, f in (("primes (u')", has_prime), ("dots (\\dot u)", has_dot),
                            ("subscripts or partial derivatives (u_t, \\partial_x u)", has_sub)) if f]
    if len(names) >= 2:
        raise ValueError("unsupported: two derivative notations in one input: %s and %s; write every derivative in "
                         "one notation (for an evolution equation: u_t, u_x, u_xx)" % (names[0], names[1]))


def _preclean(text):
    """(text, warnings): equation labels ('KdV: ...'), equation numbers '(2)' at either end and a final '.', ','
    or ';' are dropped with a warning; LaTeX is converted to plain notation"""
    t = str(text).strip()
    warns = []
    _mixed_notation(t)
    # LaTeX display markup, tags, a trailing domain or condition
    if re.search(r"\\tag\*?\{[^{}]*\}", t):
        warns.append("the tag %s was dropped" % re.search(r"\\tag\*?\{[^{}]*\}", t).group(0))
        t = re.sub(r"\\tag\*?\{[^{}]*\}", " ", t)
    if re.search(r"\\(begin|end)\{[A-Za-z*]+\}|\$|\\\[|\\\]", t):
        t = re.sub(r"\\(begin|end)\{[A-Za-z*]+\}|\$|\\\[|\\\]", " ", t)
        warns.append("LaTeX display markers were dropped")
    md = re.search(r",\s*(?:\\quad\s*)?\(?\s*[a-z](?:\s*,\s*[a-z])*\s*\)?\s*(?:\\in|\u2208|>|<|\\geq?|\\leq?|\u2265|\u2264)"
                   r"[^=]*$", t)
    if md:
        warns.append("the condition '%s' was dropped" % md.group(0).strip(" ,"))
        t = t[:md.start()]
    t = t.strip()
    # remarks and labels: the decision of the ODE reader (mero.parse.strip_remarks), then a leading single word
    try:
        from .parse import strip_remarks as _sr
    except Exception:          # pragma: no cover
        _sr = None
    if _sr is not None:
        try:
            t2, notes2 = _sr(t)
            if t2 and t2.strip():
                t, warns = t2.strip(), warns + list(notes2)
        except ValueError as err:
            if str(err).startswith("unsupported"):
                raise
        except Exception:          # pragma: no cover
            pass
    mw = re.match(r"^\s*([A-Za-z]{2,})\s+(?=[A-Za-z]\w*_\{?[a-z]|\\partial|\\frac|diff\s*\(|D[xyzt]\s*\()", t)
    if mw and mw.group(1) not in _GREEK_NAMES and mw.group(1) not in _FUNCS and mw.group(1) not in _LATEX_GREEK:
        if mw.group(1).lower() in _lead_tags():
            warns.append("the word '%s' in front of the equation was not read as part of it" % mw.group(1))
            t = t[mw.end():]
        else:
            warns.append("the word '%s' in front of the first term is read as a coefficient (a parameter)"
                         % mw.group(1))
    m = re.match(r"^\s*([A-Za-z][\w \-\u2013\u2019'()]{0,40}?)\s*:\s+(?=\S)", t)
    if m and "=" not in m.group(1):
        warns.append("the label '%s:' was dropped" % m.group(1).strip())
        t = t[m.end():]
    m = re.match(r"^\s*\(\s*\d+(\.\d+)?[a-z]?\s*\)\s+", t)
    if m:
        warns.append("the equation number %s was dropped" % m.group(0).strip())
        t = t[m.end():]
    m = re.search(r"\s+\(\s*\d+(\.\d+)?[a-z]?\s*\)\s*$", t)
    if m:
        warns.append("the equation number %s was dropped" % m.group(0).strip())
        t = t[:m.start()]
    m = re.search(r"\s*[.,;]\s*$", t)
    if m and not re.search(r"\d\.\s*$", t):
        warns.append("the final '%s' was dropped" % m.group(0).strip())
        t = t[:m.start()]
    t = _latex_to_plain(t, warns)
    return t, warns


def _clean(text):
    s = str(text)
    for a, b in _REPL.items():
        s = s.replace(a, b)
    for a, b in _SUPER.items():
        s = s.replace(a, b)
    for a, b in _GREEK.items():
        s = s.replace(a, b)
    s = s.replace("\\cdot", "*").replace("\\left", "").replace("\\right", "")
    s = re.sub(r"\b([A-Za-z]+)_\{\s*(\d+)\s*\}", r"\1\2", s)        # b_{1} -> b1 (a parameter with an index)
    s = re.sub(r"_\{([A-Za-z ]+)\}", lambda m: "_" + m.group(1).replace(" ", ""), s)
    s = s.replace("{", "(").replace("}", ")")
    s = s.replace("[", "(").replace("]", ")")
    return s.strip()


def _tokenize(s):
    if ";" in s:
        raise ValueError("unsupported: a system of several equations (separated by ';'): only one scalar equation "
                         "for one unknown is read")
    toks, pos = [], 0
    while pos < len(s):
        m = _TOKEN.match(s, pos)
        if not m:
            raise ValueError("unsupported: cannot read the character %r at position %d" % (s[pos], pos))
        pos = m.end()
        kind = m.lastgroup
        if kind == "ws":
            # whitespace matters only for '_' postfix detection: mark it
            if toks:
                toks[-1] = (toks[-1][0], toks[-1][1], True)
            continue
        val = m.group(kind)
        if kind == "op" and val == "**":
            val = "^"
        if kind == "name" and val in _PYKW:
            val = _PYKW[val]
        toks.append((kind, val, False))       # (kind, value, followed_by_space)
    return toks


_SUBSCRIPT = re.compile(r"^([A-Za-z][A-Za-z0-9]*?)_([a-z]+)$")
_DOP = re.compile(r"^D([xyzt])$")          # Dx(expr), Dx(expr, n): total derivative operators


def _scan(text):
    """(unknown candidates with counts, variables) from a cleaned text"""
    toks = _tokenize(text)
    counts = {}
    letters = {}
    for i, (k, v, _) in enumerate(toks):
        if k != "name":
            continue
        m = _SUBSCRIPT.match(v)
        if m:
            counts[m.group(1)] = counts.get(m.group(1), 0) + 1
            letters.setdefault(m.group(1), set()).update(m.group(2))
        if v in _DIFF[:3] and i + 2 < len(toks) and toks[i + 1][1] == "(" and toks[i + 2][0] == "name":
            X = toks[i + 2][1]
            counts[X] = counts.get(X, 0) + 1
            # variables: the single-letter names among the following arguments at depth 1
            depth, j = 0, i + 1
            argno = 0
            while j < len(toks):
                if toks[j][1] == "(":
                    depth += 1
                elif toks[j][1] == ")":
                    depth -= 1
                    if depth == 0:
                        break
                elif toks[j][1] == "," and depth == 1:
                    argno += 1
                elif argno >= 1 and depth == 1 and toks[j][0] == "name" and len(toks[j][1]) == 1:
                    letters.setdefault(X, set()).add(toks[j][1])
                j += 1
    post = set()
    for k_, v_, _ in toks:
        if k_ == "name" and re.match(r"^Dop[a-z]$", v_):
            post.add(v_[3])
    for i in range(len(toks) - 1):
        k, v, sp_after = toks[i]
        if k == "name" and _DOP.match(v) and toks[i + 1][1] == "(":
            post.add(v[1])
            if i + 2 < len(toks) and toks[i + 2][0] == "name" and toks[i + 2][1] not in _FUNCS \
                    and not _DOP.match(toks[i + 2][1]):
                X = toks[i + 2][1]
                counts[X] = counts.get(X, 0) + 1
    for i in range(1, len(toks)):
        k, v, _ = toks[i]
        if k == "name" and v.startswith("_") and toks[i - 1][1] in (")", "|") and not toks[i - 1][2] \
                and re.match(r"^_[a-z]+$", v):
            post.update(v[1:])
    return toks, counts, letters, post


_PREFERRED = ["u", "v", "w", "phi", "psi", "h", "q", "eta", "n", "y", "f", "U", "V"]
_GREEK_NAMES = set(_LATEX_GREEK.values()) | {"lambda", "pi"}


def _bare_words(toks, U, vars_):
    """runs of two or more consecutive words (multi-letter names that are not the unknown, a derivative, a function,
    a Greek letter or a variable) separated only by spaces"""
    def is_word(v):
        if len(v) < 2 or v in _GREEK_NAMES or v in _FUNCS or v in _DIFF or v in _CONJ_FUNCS or v in _RESERVED:
            return False
        if U and (v == U or v.startswith(U + "_") or v in (U + "b", U + "bar")) or v in vars_:
            return False
        if re.search(r"[\d_]", v) or _DOP.match(v) or re.match(r"^Dop[a-z]$", v):
            return False
        return v.isalpha()
    runs, cur = [], []
    for i, (k, v, sp_after) in enumerate(toks):
        nxt = toks[i + 1] if i + 1 < len(toks) else (None, None, False)
        if k == "name" and is_word(v) and nxt[1] != "(":
            cur.append(v)
            if not sp_after or nxt[0] != "name":
                if len(cur) >= 2:
                    runs.append(cur)
                cur = []
        elif k == "name" and sp_after and nxt[0] == "name":
            continue                  # a symbol inside a run of words keeps the run going ('where u is ...')
        else:
            if len(cur) >= 2:
                runs.append(cur)
            cur = []
    if len(cur) >= 2:
        runs.append(cur)
    return runs


def _merge_conj(counts):
    """qb / qbar (conjugate notation) count for q"""
    out = dict(counts)
    for X in list(out):
        for suf in ("bar", "b"):
            if X.endswith(suf) and X[:-len(suf)] in out and X[:-len(suf)]:
                out[X[:-len(suf)]] += out.pop(X)
                break
    return out


def _choose_unknown(counts):
    counts = _merge_conj(counts)
    if not counts:
        return None
    best = max(counts.values())
    cands = [x for x, c in counts.items() if c == best]
    for p in _PREFERRED:
        if p in cands:
            return p
    return sorted(cands)[0]


def _var_order(vs):
    vs = set(vs)
    out = [v for v in "xyz" if v in vs]
    out += sorted(v for v in vs if v not in "xyzt")
    if "t" in vs:
        out.append("t")
    return out


def detect_kind(text, detail=False):
    """'ode' (primes, jets w0 w1 ..., or derivatives in one variable), 'pde' (derivatives in two or more
    variables) or 'unknown' (no derivative found).  With detail=True return (kind, info dict)."""
    try:
        _mixed_notation(str(text))
    except ValueError:
        return ("pde", {"why": "two derivative notations"}) if detail else "pde"
    try:
        s = _clean(_preclean(text)[0])
    except Exception:
        if re.search(r"\\partial|\\frac|_\{?[a-z]", str(text)):
            return ("pde", {"why": "LaTeX that parse_pde refuses with the reason"}) if detail else "pde"
        return ("unknown", {}) if detail else "unknown"
    info = {}
    # for classification only: a modulus |q| and a system "eq1; eq2" are scanned like ordinary text, so that
    # parse_pde gets the input and gives its precise 'unsupported' reason
    s = s.replace("|", " ").replace(";", " + ")
    if "'" in s:
        kind = "ode"
        info["why"] = "primes"
    else:
        names = set(re.findall(r"[A-Za-z_][A-Za-z0-9_]*", s))
        jet_like = {}
        for nm in names:
            m = re.match(r"^([a-z])(\d+)$", nm)
            if m:
                jet_like.setdefault(m.group(1), set()).add(int(m.group(2)))
        jetp = [p for p, js in jet_like.items() if 0 in js and len(js) >= 2 and p in "wxvuy"]
        try:
            toks, counts, letters, post = _scan(s)
        except ValueError:
            return ("unknown", {"why": "unreadable"}) if detail else "unknown"
        X = _choose_unknown(counts)
        vs = set(letters.get(X, set())) | post if X else set(post)
        info.update({"unknown": X, "vars": _var_order(vs)})
        if len(vs) >= 2:
            kind = "pde"
        elif len(vs) == 1:
            kind = "ode"
        elif jetp:
            kind = "ode"
            info["why"] = "jets"
        elif re.search(r"\bdiff\s*\(", s):
            kind = "ode"
        else:
            kind = "unknown"
    return (kind, info) if detail else kind


# ---------------------------------------------------------------------------------------------- PDE


class PDE(object):
    """E(u and its partial derivatives; parameters) = 0, a polynomial in the derivatives.

    unknown  name of the unknown ('u')        vars    independent variables (space first, then 't')
    time     't' or None                     space   the space variables
    E        SymPy expression in the derivative symbols (u, u_x, u_xxt, ...)
    derivs   {Symbol: multi-index tuple aligned with vars}      params  parameter symbols (by name)
    order    highest total order              degree  total degree in the derivatives
    """

    def __init__(self, E, unknown, vars, derivs, text=None, fam=None):
        self.E = sp.expand(E)
        self.unknown = unknown
        self.vars = list(vars)
        self.time = "t" if "t" in self.vars else None
        self.space = [v for v in self.vars if v != "t"]
        self.derivs = dict((s, a) for s, a in derivs.items() if self.E.has(s))
        self.fam = dict((s, (fam or {}).get(s, "u")) for s in self.derivs)
        self.complex = self.E.has(sp.I) or any(f != "u" for f in self.fam.values())
        self.notes = []
        dsyms = set(self.derivs)
        self.params = sorted((s for s in self.E.free_symbols if s not in dsyms), key=lambda s: s.name)
        self.text = text
        P = sp.Poly(self.E, *self.derivs.keys()) if self.derivs else None
        self.degree = P.total_degree() if P is not None else 0
        self.order = max((sum(a) for a in self.derivs.values()), default=0)

    def __repr__(self):
        return "PDE(%s = 0)" % self.E

    def latex(self):
        rep = {}
        for s, a in self.derivs.items():
            f = self.fam.get(s, "u")
            base = {"u": self.unknown, "ubar": "\\bar{%s}" % self.unknown, "abs": "|%s|" % self.unknown}[f]
            if sum(a) == 0 and f == "u":
                continue
            sub = "".join(v * k for v, k in zip(self.vars, a))
            rep[s] = sp.Symbol("%s_{%s}" % (base, sub) if sub else base)
        return sp.latex(self.E.subs(rep, simultaneous=True)) + " = 0"

    def to_dict(self):
        return {"kind": "pde", "unknown": self.unknown, "vars": self.vars, "sympy": str(self.E),
                "params": [s.name for s in self.params], "order": self.order, "degree": self.degree,
                "latex": self.latex(), "text": self.text}

    def t_derivatives(self):
        """the multi-indices of the derivatives that involve t"""
        if self.time is None:
            return []
        it = self.vars.index("t")
        return [a for a in self.derivs.values() if a[it] > 0]

    def as_ode(self):
        """the equation as an ODE in jets when it has exactly one independent variable"""
        if len(self.vars) != 1:
            raise ValueError("as_ode: the equation has %d independent variables" % len(self.vars))
        rep = dict((s, sp.Symbol("w%d" % a[0])) for s, a in self.derivs.items())
        return make_equation(self.E.subs(rep, simultaneous=True), self.params, unknown=self.unknown,
                             var=self.vars[0])


class _Parser(object):
    def __init__(self, toks, unknown, vars):
        self.toks = toks
        self.i = 0
        self.unknown = unknown
        self.vars = list(vars)
        self.vsyms = dict((v, sp.Symbol(v)) for v in self.vars)
        self.derivs = {}       # Symbol -> multi-index
        self.fam = {}          # Symbol -> family: 'u', 'ubar' (complex conjugate), 'abs' (|u|)
        self.names = {}        # parameter name -> Symbol
        self.abs_depth = 0
        self.exp_depth = 0
        self.warnings = []

    # -- derivative symbols and the total derivative in the PDE algebra
    def dsym(self, alpha, family="u"):
        alpha = tuple(alpha)
        s = sp.Symbol(_dname(self.unknown, family, self.vars, alpha))
        self.derivs[s] = alpha
        self.fam[s] = family
        return s

    def conj(self, expr):
        """complex conjugate: u <-> ub (same derivative), |u| unchanged, I -> -I, parameters real"""
        expr = sp.sympify(expr)
        rep = {sp.I: -sp.I}
        for s in list(expr.free_symbols):
            if s in self.derivs:
                f = self.fam[s]
                if f in ("u", "ubar"):
                    rep[s] = self.dsym(self.derivs[s], "ubar" if f == "u" else "u")
        return expr.xreplace(rep)

    def modulus(self, inner):
        """|inner|: the symbol |u| (family 'abs') for the unknown itself, else Abs(inner) (even powers of it are
        rewritten as (inner * conj(inner))^(n/2) after parsing)"""
        inner = sp.sympify(inner)
        if inner in self.derivs and self.fam[inner] == "u" and sum(self.derivs[inner]) == 0:
            return self.dsym(self.derivs[inner], "abs")
        if inner in self.derivs and self.fam[inner] == "abs":
            return inner
        return sp.Abs(inner)

    def D(self, expr, v):
        """total derivative of expr with respect to the variable v"""
        iv = self.vars.index(v)
        expr = sp.sympify(expr)
        out = sp.Integer(0)
        for s in list(expr.free_symbols):
            if s in self.derivs:
                a = list(self.derivs[s])
                a[iv] += 1
                out += sp.diff(expr, s) * self.dsym(a, self.fam[s])
            elif s.name == v:
                out += sp.diff(expr, s)
        return out

    def peek(self, k=0):
        j = self.i + k
        return self.toks[j] if j < len(self.toks) else (None, None, False)

    def take(self, val=None):
        t = self.peek()
        if val is not None and t[1] != val:
            raise ValueError("unsupported: expected %r, found %r" % (val, t[1]))
        self.i += 1
        return t

    # -- grammar
    def equation(self):
        lhs = self.expr()
        if self.peek()[1] == "=":
            self.take("=")
            rhs = self.expr()
            if self.peek()[1] == "=":
                raise ValueError("unsupported: more than one '='")
            res = lhs - rhs
        else:
            res = lhs
        if self.peek()[0] is not None:
            raise ValueError("unsupported: cannot read the input after %r" % (self.toks[self.i - 1][1],))
        return res

    def expr(self):
        val = self.term()
        while self.peek()[1] in ("+", "-"):
            op = self.take()[1]
            rhs = self.term()
            val = val + rhs if op == "+" else val - rhs
        return val

    def _starts_factor(self):
        k, v, _ = self.peek()
        return k in ("num", "name") or v == "(" or (v == "|" and self.abs_depth == 0)

    def term(self):
        val = self.unary()
        while True:
            v = self.peek()[1]
            if v == "*":
                self.take()
                val = val * self.unary()
            elif v == "/":
                self.take()
                val = val / self.unary()
            elif self._starts_factor():
                val = val * self.unary()        # implicit multiplication
            else:
                return val

    def unary(self):
        v = self.peek()[1]
        if v == "-":
            self.take()
            return -self.unary()
        if v == "+":
            self.take()
            return self.unary()
        return self.power()

    def power(self):
        base = self.postfix()
        if self.peek()[1] == "^" and self.peek(1)[1] == "*":
            self.take()
            self.take()
            base = self.conj(base)
        if self.peek()[1] == "^":
            self.take()
            self.exp_depth += 1
            ex = self.unary_exponent()
            self.exp_depth -= 1
            return base ** ex
        return base

    def unary_exponent(self):
        v = self.peek()[1]
        if v == "-":
            self.take()
            return -self.unary_exponent()
        if v == "+":
            self.take()
            return self.unary_exponent()
        return self.power()

    def postfix(self):
        val = self.atom()
        while True:
            k, v, _ = self.peek()
            prev = self.toks[self.i - 1]
            if k == "name" and v.startswith("_") and prev[1] in (")", "|") and not prev[2] \
                    and re.match(r"^_[a-z]+$", v):
                if self.exp_depth > 0:
                    raise ValueError("unsupported: a subscript after an exponent (u^{2}_{x}) is ambiguous: write "
                                     "(u^2)_x or (u_x)^2")
                self.take()
                for ch in v[1:]:
                    if ch not in self.vars:
                        raise ValueError("unsupported: derivative in an unknown variable %r" % ch)
                    val = self.D(val, ch)
            elif v == "'":
                raise ValueError("unsupported: primes in an equation with several variables")
            else:
                return val

    def atom(self):
        k, v, sp_after = self.take()
        if k is None:
            raise ValueError("unsupported: the input ends too early")
        if k == "num":
            return sp.Rational(v)
        if v == "(":
            val = self.expr()
            self.take(")")
            return val
        if v == "|":
            self.abs_depth += 1
            val = self.expr()
            self.take("|")
            self.abs_depth -= 1
            return self.modulus(val)
        if k != "name":
            raise ValueError("unsupported: unexpected %r" % v)
        # function calls: a known function name must be followed by a bracket (a space before it is allowed)
        known_fn = v in _DIFF or v in ("abs", "Abs") or v in _CONJ_FUNCS or v in _FUNCS
        if known_fn and self.peek()[1] != "(":
            raise ValueError("unsupported: the function name %r must be followed by a bracket, e.g. %s(u)" % (v, v))
        if _DOP.match(v) and self.peek()[1] == "(":
            # D[xyzt] before a bracket (with or without a space) is the derivative operator, never a parameter
            if v[1] not in self.vars:
                raise ValueError("unsupported: %s(...) reads as a derivative with respect to %s, which is not a "
                                 "variable of the equation" % (v, v[1]))
            return self.dop_call(v[1])
        msub = _SUBSCRIPT.match(v)
        is_deriv_name = bool(msub) and msub.group(1) in (self.unknown, self.unknown + "b", self.unknown + "bar",
                                                         "abs" + self.unknown)
        if self.peek()[1] == "(" and (not sp_after or (v != self.unknown and not is_deriv_name)) and not known_fn \
                and v not in _RESERVED and v not in (self.unknown + "b", self.unknown + "bar") \
                and not v.startswith("_") and not is_deriv_name:
            if v == self.unknown and self._skip_arglist():
                return self.dsym([0] * len(self.vars))
            return self._bracket_after_name(v)
        if self.peek()[1] == "(" and (not sp_after or known_fn):
            if v in _DIFF:
                return self.diff_call()
            if _DOP.match(v) and v[1] in self.vars:
                return self.dop_call(v[1])
            if v in ("abs", "Abs"):
                self.take("(")
                arg = self.expr()
                self.take(")")
                return self.modulus(arg)
            if v in _CONJ_FUNCS:
                self.take("(")
                arg = self.expr()
                self.take(")")
                return self.conj(arg)
            if v in _FUNCS:
                self.take("(")
                arg = self.expr()
                self.take(")")
                return _FUNCS[v](arg)
            if v == self.unknown and self._skip_arglist():
                return self.dsym([0] * len(self.vars))
        return self.name(v)

    def _bracket_after_name(self, v):
        """a name directly before a bracket: an unspecified function of the unknown is refused (the bracket holds
        the unknown alone, one derivative, or a power of |u|); otherwise the product, with a warning (the rule
        of mero.parse)"""
        self.take("(")
        arg = sp.sympify(self.expr())
        self.take(")")
        k2, v2, _ = self.peek()
        if k2 == "name" and v2.startswith("_") and re.match(r"^_[a-z]+$", v2) and not self.toks[self.i - 1][2]:
            self.take()                        # (...)_x right after the bracket: the derivative of the bracket
            for ch in v2[1:]:
                if ch not in self.vars:
                    raise ValueError("unsupported: derivative in an unknown variable %r" % ch)
                arg = self.D(arg, ch)
        U = self.unknown
        shown = re.sub(r"\babs%s\b" % re.escape(U), "|%s|" % U, sp.sstr(arg)).replace("**", "^")
        single = arg in self.derivs or (arg.is_Pow and arg.base in self.derivs and
                                        self.fam.get(arg.base) == "abs")
        if v == U:
            if arg.free_symbols & set(self.vsyms.values()) or not (arg.free_symbols & set(self.derivs)) \
                    and arg.is_number:
                raise ValueError("unsupported: %s(%s) reads as a value of the unknown at a point; values at a point "
                                 "are not part of the equation (for the product write %s*(%s))" % (U, shown, U, shown))
        elif single:
            raise ValueError("unsupported: %s(%s) is read as an unspecified function %s of the unknown, and the site "
                             "treats polynomial equations only; if the product is meant, write %s*(%s)"
                             % (v, shown, v, v, shown))
        if self.peek()[1] == "^" and self.peek(1)[1] != "*":
            self.take()
            self.exp_depth += 1
            ex = self.unary_exponent()
            self.exp_depth -= 1
            arg = arg ** ex
            shown = "(%s)^%s" % (shown, sp.sstr(ex))
        self.warnings.append("%s(%s) was read as the product %s*(%s)" % (v, shown, v, shown))
        head = self.dsym([0] * len(self.vars)) if v == U else self.name(v)
        return head * arg

    def _skip_arglist(self):
        """u(x, t): skip the argument list if it is a list of the independent variables"""
        j = self.i + 1
        seen = []
        while j < len(self.toks):
            k, v, _ = self.toks[j]
            if v == ")":
                break
            if v == ",":
                j += 1
                continue
            if k == "name" and v in self.vars:
                seen.append(v)
                j += 1
                continue
            return False
        if not seen or j >= len(self.toks):
            return False
        self.i = j + 1
        return True

    def dop_call(self, var):
        """Dx(expr) or Dx(expr, n)"""
        self.take("(")
        target = self.expr()
        n = 1
        if self.peek()[1] == ",":
            self.take(",")
            k, v, _ = self.take()
            if k != "num":
                raise ValueError("unsupported: D%s(expr, n) needs an integer n, found %r" % (var, v))
            n = int(v)
        self.take(")")
        for _ in range(n):
            target = self.D(target, var)
        return target

    def diff_call(self):
        self.take("(")
        target = self.expr()
        while self.peek()[1] == ",":
            self.take(",")
            k, v, _ = self.take()
            if k != "name" or v not in self.vars:
                raise ValueError("unsupported: diff(...) needs independent variables, found %r" % v)
            n = 1
            if self.peek()[1] == "," and self.peek(1)[0] == "num":
                self.take(",")
                n = int(self.take()[1])
            for _ in range(n):
                target = self.D(target, v)
        self.take(")")
        return target

    def name(self, v):
        if v in _RESERVED:
            return _RESERVED[v]
        if v == self.unknown:
            return self.dsym([0] * len(self.vars))
        if v in (self.unknown + "b", self.unknown + "bar"):
            return self.dsym([0] * len(self.vars), "ubar")
        m = _SUBSCRIPT.match(v)
        if m and m.group(1) in (self.unknown + "b", self.unknown + "bar"):
            a = [0] * len(self.vars)
            for ch in m.group(2):
                if ch not in self.vars:
                    raise ValueError("unsupported: derivative in an unknown variable %r" % ch)
                a[self.vars.index(ch)] += 1
            return self.dsym(a, "ubar")
        if m and m.group(1) == self.unknown:
            a = [0] * len(self.vars)
            for ch in m.group(2):
                if ch not in self.vars:
                    raise ValueError("unsupported: derivative in an unknown variable %r" % ch)
                a[self.vars.index(ch)] += 1
            return self.dsym(a)
        # concatenations such as 'uu_x' or 'uu' (the unknown repeated without a space)
        U = self.unknown
        if v.startswith(U) and len(v) > len(U):
            rest = v[len(U):]
            if rest == U or _SUBSCRIPT.match(rest) and _SUBSCRIPT.match(rest).group(1) == U \
                    or (rest.startswith(U) and len(rest) > len(U)):
                return self.dsym([0] * len(self.vars)) * self.name(rest)
        if v in self.vars:
            return self.vsyms[v]
        if v.startswith("_"):
            raise ValueError("unsupported: cannot read %r" % v)
        if v not in self.names:
            self.names[v] = sp.Symbol(self._param_name(v))
        return self.names[v]

    def _param_name(self, v):
        """the symbol name of a parameter: names that clash with the engine's own symbols are renamed (w0, w1, ...
        are the derivatives of the profile; z is the travelling variable), with a warning; names that look like
        derivatives or products of the unknown are kept, with a warning"""
        U = self.unknown
        new = v
        taken = set(getattr(self, "all_names", set())) | set(q.name for q in self.names.values()) | {U}
        if re.match(r"^w\d+$", v):
            new = _fresh("w_" + v[1:], taken)
            self.warnings.append("the parameter %s was renamed %s (w0, w1, ... denote the profile and its "
                                 "derivatives)" % (v, new))
        elif v in ("z", "X_phase_", "w"):
            new = _fresh(v + "_par", taken)
            why = "w denotes the profile" if v == "w" else "%s is the travelling variable" % v
            self.warnings.append("the parameter %s was renamed %s (%s)" % (v, new, why))
        letters = "".join(self.vars)
        greek = _GREEK_NAMES
        parts = [q for q in re.split(r"(?=%s_)" % re.escape(U), v) if q]
        if v == "D":
            self.warnings.append("D is read as a parameter (a coefficient), not as a derivative; a derivative is "
                                 "written Dx(...), u_x or \\partial_x u")
        elif re.match(r"^%s_?\d+$" % re.escape(U), v):
            self.warnings.append("%s is read as a parameter" % v)
        elif len(parts) >= 2 and all(re.match(r"^%s_[%s]+$" % (re.escape(U), letters), q) for q in parts):
            self.warnings.append("%s is read as a parameter (for a product write %s)" % (v, "*".join(parts)))
        elif re.match(r"^%s[%s]+$" % (re.escape(U), letters), v):
            self.warnings.append("%s is read as a parameter (for a derivative write %s_%s)" % (v, U, v[len(U):]))
        elif (U + "_") in v:
            self.warnings.append("%s is read as a parameter" % v)
        elif len(U) == 1 and len(v) == 2 and v[1] == U and v[0].isalpha() and v not in greek:
            self.warnings.append("%s is read as a parameter (for a product write %s*%s)" % (v, v[0], U))
        elif len(v) >= 3 and v.isalpha() and v not in greek and v not in _RESERVED and not re.match(r"^Dop[a-z]$", v):
            self.warnings.append("the word %s is read as one parameter" % v)
        return new


def parse_pde(text, unknown=None):
    """Read one scalar polynomial evolution equation (see the module docstring).  Raises ValueError('unsupported:
    ...') for anything else (non-polynomial in the unknown, explicit dependence on the variables, no
    derivative)."""
    s0, pre_warnings = _preclean(text)
    s = _clean(s0)
    md_ = re.search(r"\bD_\{?([xyzt]+)\}?\s+(?=(?!D\b)[A-Za-z(\\])", s)
    if md_:
        raise ValueError("unsupported: D_%s followed by a term reads as a derivative operator written with a "
                         "subscript; write u_%s or D%s(u) (D%s(...) is the derivative operator; a subscript on D "
                         "makes D an unknown function)" % (md_.group(1), md_.group(1), md_.group(1)[0],
                                                           md_.group(1)[0]))
    toks, counts, letters, post = _scan(s)
    U = unknown or _choose_unknown(counts)
    if U is None:
        if post:
            raise ValueError("unsupported: the unknown could not be identified (only derivatives of expressions such "
                             "as (q**m)_t occur; symbolic powers of the unknown are not polynomial)")
        # u(x, t) form without derivatives, or nothing at all
        raise ValueError("unsupported: no derivative of an unknown function was found")
    conjnames = (U + "b", U + "bar", "abs" + U)
    vs = set(letters.get(U, set())) | post
    for X in conjnames:
        vs |= set(letters.get(X, set()))
    m = re.search(r"\b%s\s*\(\s*([a-z](?:\s*,\s*[a-z])*)\s*\)" % re.escape(U), s)
    if m:
        vs |= set(x.strip() for x in m.group(1).split(","))
    if not vs:
        raise ValueError("unsupported: no independent variable was found")
    vars_ = _var_order(vs)
    others = sorted(X for X, L in letters.items() if X != U and L <= set(vars_) | set("xyzt")
                    and not X.startswith(U) and not U.startswith(X) and X not in conjnames)
    if others:
        raise ValueError("unsupported: several unknown functions (%s): only one scalar equation for one unknown "
                         "is read" % ", ".join([U] + others))
    runs = _bare_words(toks, U, vars_)
    if runs:
        raise ValueError("unsupported: the input contains the words '%s': type the equation only"
                         % "', '".join(" ".join(r) for r in runs))
    P = _Parser(toks, U, vars_)
    P.all_names = set(v for k_, v, _ in toks if k_ == "name")
    E = sp.sympify(P.equation())
    notes = list(pre_warnings)
    dops = [q for q in E.free_symbols if re.match(r"^Dop[a-z]$", q.name)]
    if dops:
        # operator polynomial (LaTeX \partial inside brackets): each operator acts on the rest of its term
        Ex = sp.expand(E)
        newE = sp.Integer(0)
        for term in sp.Add.make_args(Ex):
            rest, ops = term, []
            for q in dops:
                k_ = sp.degree(term, q)
                if k_:
                    rest = rest / q ** k_
                    ops += [q.name[3]] * int(k_)
            for v in ops:
                if v not in P.vars:
                    raise ValueError("unsupported: derivative in an unknown variable %r" % v)
                rest = P.D(rest, v)
            newE += rest
        E = sp.expand(newE)
    # |expr|^(2m) = (expr * conj(expr))^m ; other moduli of expressions are not polynomial
    if E.has(sp.Abs):
        def _even_abs(e):
            return e.is_Pow and isinstance(e.base, sp.Abs) and e.exp.is_Integer and e.exp % 2 == 0
        E = E.replace(_even_abs, lambda e: (e.base.args[0] * P.conj(e.base.args[0])) ** (e.exp // 2))
        if E.has(sp.Abs):
            raise ValueError("unsupported: %s (an odd power of the modulus of an expression other than %s)"
                             % (sorted(E.atoms(sp.Abs), key=str)[0], U))
    dsyms = set(P.derivs)
    is_complex = E.has(sp.I) or any(P.fam[s_] != "u" for s_ in dsyms if E.has(s_))
    for f in sp.sympify(E).atoms(sp.Function):
        if f.free_symbols & dsyms:
            raise ValueError("unsupported: %s is not polynomial in %s and its derivatives" % (f, U))
    for f in sp.sympify(E).atoms(sp.Pow):
        if f.base.free_symbols & dsyms and not (f.exp.is_Integer and f.exp > 0):
            if f.exp.is_Integer:
                if is_complex and all(P.fam[q_] == "abs" for q_ in f.base.free_symbols & dsyms):
                    continue        # a denominator in |u| only: cleared below (it is real and phase-free)
                raise ValueError("unsupported: the unknown occurs in a denominator (the equation is not "
                                 "polynomial)")
            raise ValueError("unsupported: %s is not polynomial in %s and its derivatives" % (f, U))
        if f.exp.free_symbols & dsyms:
            raise ValueError("unsupported: %s is not polynomial in %s and its derivatives" % (f, U))
    E = sp.together(sp.sympify(E))
    num, den = sp.fraction(E)
    if den.free_symbols & dsyms:
        if is_complex and all(P.fam[q_] == "abs" for q_ in den.free_symbols & dsyms):
            dj = sp.factor(den / sp.Poly(den, *sorted(den.free_symbols & dsyms, key=str)).LC()) \
                if den.free_symbols & dsyms else den
            notes.append("the equation was multiplied by %s (a power or polynomial of |%s|, assumed nonzero)"
                         % (sp.sstr(dj), U))
            den = den / dj
        else:
            raise ValueError("unsupported: the unknown occurs in a denominator (the equation is not polynomial)")
    E = sp.expand(num / den)
    bad = [x for x in vars_ if E.has(sp.Symbol(x))]
    if bad:
        raise ValueError("unsupported: the equation depends explicitly on %s (not autonomous)" % ", ".join(bad))
    used = [s_ for s_ in dsyms if E.has(s_)]
    if not used:
        raise ValueError("unsupported: the unknown does not occur in the equation")
    try:
        Pl = sp.Poly(E, *used)
    except sp.PolynomialError as err:
        raise ValueError("unsupported: the equation is not a polynomial in %s and its derivatives (%s)" % (U, err))
    for c in Pl.coeffs():
        if c.free_symbols & dsyms:
            raise ValueError("unsupported: the equation is not a polynomial in %s and its derivatives" % U)
    for f in E.atoms(sp.Function):
        if f.free_symbols & dsyms:
            raise ValueError("unsupported: %s is not polynomial" % f)
    if not any(sum(P.derivs[s_]) > 0 for s_ in used):
        raise ValueError("unsupported: no derivative of %s occurs (an algebraic equation)" % U)
    # keep only the variables that really occur
    occurring = set()
    for s_ in used:
        for v, k in zip(vars_, P.derivs[s_]):
            if k:
                occurring.add(v)
    pde = PDE(E, U, vars_, P.derivs, text=text, fam=P.fam)
    if set(vars_) != occurring:
        # e.g. u(x, t) declared but no t-derivative: drop the unused variable
        keep = [v for v in vars_ if v in occurring]
        idx = [vars_.index(v) for v in keep]
        rep, newd, newf = {}, {}, {}
        for s_, a in pde.derivs.items():
            b = tuple(a[i] for i in idx)
            ns = sp.Symbol(_dname(U, P.fam[s_], keep, b))
            rep[s_] = ns
            newd[ns] = b
            newf[ns] = P.fam[s_]
        pde = PDE(E.subs(rep, simultaneous=True), U, keep, newd, text=text, fam=newf)
    pde.notes = notes + P.warnings
    return pde


# ---------------------------------------------------------------------------------------------- reductions


def _fresh(name, taken):
    taken = set(str(t) for t in taken)
    if name not in taken:
        return name
    for suffix in ["0", "_", "1", "2", "3"]:
        if name + suffix not in taken:
            return name + suffix
    k = 4
    while "%s%d" % (name, k) in taken:
        k += 1
    return "%s%d" % (name, k)


def _sign_normal(E):
    """multiply by -1 if the coefficient of the leading monomial (highest jet, highest power) looks negative"""
    E = sp.expand(E)
    N = _order(E)
    if N < 0:
        return E
    wN = sp.Symbol("w%d" % N)
    P = sp.Poly(E, wN)
    lc = sp.expand(P.LC())
    # leading coefficient of lc itself w.r.t. the lower jets, then its sign
    lower = [sp.Symbol("w%d" % j) for j in range(N - 1, -1, -1)]
    c = lc
    if lower and c.free_symbols & set(lower):
        c = sp.Poly(c, *lower).LC()
    if c.is_number:
        neg = bool(c < 0) if c.is_real else c.could_extract_minus_sign()
    else:
        neg = c.could_extract_minus_sign()
    return sp.expand(-E) if neg else E


def _integration_chain(E0, integrate, max_steps=8):
    """[(k, F_k)] with F_0 = E0 and D F_k = F_{k-1} (no constants), as long as exact."""
    out = [(0, sp.expand(E0))]
    cur = sp.expand(E0)
    k = 0
    while integrate and k < max_steps:
        F = antiderivative(cur)
        if F is None or F == 0:
            break
        k += 1
        out.append((k, F))
        cur = F
    return out


def _lowered_ansatz(unknown, zname, zexpr, j0):
    """the relation between the PDE's unknown and the function w of a lowered form"""
    tail = "" if zexpr == zname else ", %s = %s" % (zname, zexpr)
    if j0 == 1:
        return "%s = \u222b w(%s) d%s%s" % (unknown, zname, zname, tail)
    if j0 == 2:
        return "%s = \u222b\u222b w(%s) d%s d%s%s" % (unknown, zname, zname, zname, tail)
    return "d^%d %s/d%s^%d = w(%s)%s" % (j0, unknown, zname, j0, zname, tail)


def _forms(E0, ansatz, kind, extra_params, taken, integrate, var_display, unknown_display="w", lowered=None,
           warnings=()):
    """lowered = (unknown, zexpr) to write the ansatz of order-lowered forms as a true relation"""
    chain = _integration_chain(E0, integrate)
    res = []
    for k, F in reversed(chain):
        consts, conds, assumed = [], [], []
        expr = _sign_normal(F)
        if k > 0:
            names = [_fresh("C%d" % i, taken) for i in range(1, k + 1)]
            C = sp.Symbol(names[-1])
            expr = expr + C
            consts = [names[-1]]
            conds = ["%s = 0" % n for n in names[:-1]]
            for n in names[:-1]:
                assumed.append({"constant": n, "value": "0", "covered_by": "another reduction in this list",
                                "kind": "integration-constant",
                                "why": "the next integration of the form with %s != 0 gives the non-autonomous term "
                                       "%s*%s; the travelling waves with %s != 0 satisfy the once-integrated "
                                       "equation (another reduction in this list)" % (n, n, var_display, n)})
        if k == 0:
            note = "not integrated"
            if len(chain) == 1:
                note = "the reduced equation is not a total derivative: not integrated"
        elif k == 1:
            note = "integrated once; %s is the constant of integration" % consts[0]
        else:
            note = ("integrated %d times under the condition %s: the first integration constant%s set to 0; the "
                    "form with %s != 0 has the non-autonomous term %s*%s and is not treated in this form (the "
                    "travelling waves with %s != 0 satisfy the once-integrated equation, another reduction in this "
                    "list); %s is the constant of the last integration"
                    % (k, ", ".join("%s = 0" % n for n in names[:-1]), " is" if k == 2 else "s are",
                       names[0], names[0], var_display, names[0], consts[0]))
        if warnings:
            note += "; " + "; ".join(warnings)
        params = list(extra_params) + [sp.Symbol(c) for c in consts]
        js = [_jet_index(q) for q in sp.sympify(expr).free_symbols]
        js = [j for j in js if j is not None]
        j0 = min(js) if js else 0
        if j0 >= 1:
            # only derivatives of the profile occur: w = (profile)^(j0) lowers the order by j0
            low = sp.expand(sp.sympify(expr).subs(dict((sp.Symbol("w%d" % j), sp.Symbol("w%d" % (j - j0)))
                                                       for j in sorted(js)), simultaneous=True))
            low = _sign_normal(low - (sp.Symbol(consts[0]) if consts else 0)) + \
                (sp.Symbol(consts[0]) if consts else 0)
            if lowered:
                lans = _lowered_ansatz(lowered[0], var_display, lowered[1], j0)
            else:
                lans = ansatz + "; the equation is for the derivative of order %d of the profile" % j0
            eql = make_equation(low, params, unknown=unknown_display, var=var_display)
            res.append({"ansatz": lans, "kind": kind, "integrated": k, "lowered": j0,
                        "constants": consts, "conditions": conds, "assumed": list(assumed), "equation": eql,
                        "sympy": str(low), "warnings": list(warnings),
                        "note": note + "; only derivatives of the profile occur, so the equation is written for "
                                       "w = its derivative of order %d (order lowered by %d; the profile is "
                                       "recovered by integration)" % (j0, j0)})
        if _order(expr) < 1:
            continue                      # an algebraic form is not offered (see travelling_wave)
        eq = make_equation(expr, params, unknown=unknown_display, var=var_display)
        res.append({"ansatz": ansatz, "kind": kind, "integrated": k, "lowered": 0, "constants": consts,
                    "conditions": conds, "assumed": assumed, "equation": eq, "sympy": str(sp.expand(expr)),
                    "warnings": list(warnings), "note": note})
    return [r for r in res if _order(r["equation"].E) >= 1]


def _zstring(ks, space, cs):
    """'x - c*t', 'k1*x + k2*y - c*t' (written by hand to keep the usual order)"""
    parts = []
    for k, v in zip(ks, space):
        k = sp.sympify(k)
        if k == 0:
            continue
        txt = v if k == 1 else ("-%s" % v if k == -1 else "%s*%s" % (sp.sstr(k) if k.is_Atom else
                                                                     "(%s)" % sp.sstr(k), v))
        parts.append(txt)
    s = " + ".join(parts).replace("+ -", "- ") if parts else "0"
    cs = sp.sympify(cs)
    if cs != 0:
        s += " - %s*t" % (sp.sstr(cs) if cs.is_Atom else "(%s)" % sp.sstr(cs))
    return s


def _substitute(pde, kvec):
    """u_alpha -> prod k_v^alpha_v * w_|alpha|"""
    rep = {}
    for s, a in pde.derivs.items():
        f = sp.Integer(1)
        for kv, e in zip(kvec, a):
            if e:
                f *= sp.sympify(kv) ** e
        rep[s] = f * sp.Symbol("w%d" % sum(a))
    return sp.expand(pde.E.subs(rep, simultaneous=True))


def travelling_wave(pde, speed="c", wavevector=None, integrate=True, stationary=True):
    """Travelling-wave reductions u = w(z), z = x - c t  (several space variables: z = k1 x + k2 y + ... - c t
    with symbolic k_i, or the given wavevector), each integrated as long as it is a total derivative.

    Returns a list of reductions (see the module docstring): first the travelling-wave forms, the most integrated
    one first, then (if `stationary` and the only t-derivative is u_t) the stationary forms u_t = 0.
    """
    if isinstance(pde, str):
        pde = parse_pde(pde)
    if getattr(pde, "complex", False):
        return envelope_wave(pde, speed=speed, wavevector=wavevector)
    taken = set(s.name for s in pde.params) | set(pde.vars) | {pde.unknown}
    zname = _zname(pde)
    taken.add(zname)
    # wave vector
    if wavevector is None:
        if len(pde.space) == 1:
            ks = [sp.Integer(1)]
        else:
            ks = []
            for i in range(len(pde.space)):
                nm = _fresh("k%d" % (i + 1), taken)
                taken.add(nm)
                ks.append(sp.Symbol(nm))
    else:
        wv = wavevector if isinstance(wavevector, (list, tuple)) else [wavevector]
        if len(wv) != len(pde.space):
            raise ValueError("wavevector needs %d components" % len(pde.space))
        ks = [sp.sympify(x) for x in wv]
    extra = [s for k in ks for s in sp.sympify(k).free_symbols]
    # speed
    if pde.time is not None and speed is not None and speed != 0:
        if isinstance(speed, str):
            cname = _fresh(speed, taken)
            taken.add(cname)
            cs = sp.Symbol(cname)
        else:
            cs = sp.sympify(speed)
        extra = extra + sorted(cs.free_symbols, key=str)
    else:
        cs = sp.Integer(0)
    kvec = []
    for v in pde.vars:
        if v == "t":
            kvec.append(-cs)
        else:
            kvec.append(ks[pde.space.index(v)])
    zexpr = _zstring(ks, pde.space, cs if pde.time else 0)
    ansatz = "%s = w(%s), %s = %s" % (pde.unknown, zname, zname, zexpr)
    E0 = _substitute(pde, kvec)
    if E0 == 0:
        raise ValueError("unsupported: the travelling-wave substitution gives 0 identically: every profile is a "
                         "solution for every speed")
    if _order(E0) < 1:
        _refuse_algebraic(E0, cs, zname)
    degenerate = _degenerate_locus(E0, cs)
    kind = "travelling-wave" if cs != 0 else ("plane-wave" if pde.time is None else "stationary")
    warns = list(getattr(pde, "notes", []) or [])
    if degenerate:
        warns.append("the reduced equation vanishes identically when %s: then every profile w(%s) gives a "
                     "travelling wave" % (degenerate, zname))
    out = _forms(E0, ansatz, kind, [s for s in pde.params] + extra, taken, integrate, zname,
                 lowered=(pde.unknown, zexpr), warnings=warns)
    if degenerate:
        for r in out:
            r["degenerate"] = {"when": degenerate, "statement": "every profile is a solution"}
    if stationary and pde.time is not None and cs != 0:
        st = stationary_reduction(pde, wavevector=wavevector, integrate=integrate, _taken=taken, _ks=ks)
        out.extend(st)
    return out


def _zname(pde):
    """the name of the travelling variable: z, xi or zeta, whichever is not a variable, the unknown or a parameter"""
    used = set(pde.vars) | {pde.unknown} | set(s.name for s in pde.params)
    for nm in ("z", "xi", "zeta"):
        if nm not in used:
            return nm
    return _fresh("z", used)


def _degenerate_locus(E0, cs):
    """the speeds (or parameter values) at which the reduced equation vanishes identically, as text, or None"""
    eqs = _jet_coeff_eqs(E0)
    if not eqs:
        return None
    syms = [cs] if isinstance(cs, sp.Symbol) and any(e.has(cs) for e in eqs) else []
    if syms:
        try:
            sols = sp.solve(eqs, syms, dict=True)
        except Exception:          # pragma: no cover
            sols = []
        sols = [d for d in sols if cs in d and all(sp.simplify(e.subs(d)) == 0 for e in eqs)]
        if sols:
            return " or ".join("%s = %s" % (cs, sp.sstr(d[cs])) for d in sols)
        if all(e.has(cs) for e in eqs):
            return None
    if all(e.free_symbols for e in eqs) and len(eqs) == 1 and not (isinstance(cs, sp.Symbol) and eqs[0].has(cs)):
        return "%s = 0" % sp.sstr(eqs[0])
    return None


def _refuse_algebraic(E0, cs, zname):
    """A-6: when the reduced equation integrates to an algebraic equation P(w) + C = 0, it is not a differential
    equation; refuse with the description of its solutions"""
    F = E0
    while True:
        G = antiderivative(F)
        if G is None or G == 0:
            break
        F = G
    if _order(F) >= 1:
        return
    P = sp.Poly(sp.expand(F), sp.Symbol("w0"))
    coeffs = [P.coeff_monomial(sp.Symbol("w0") ** j) for j in range(1, P.degree() + 1)]
    coeffs = [c_ for c_ in coeffs if c_ != 0]
    every = ""
    if isinstance(cs, sp.Symbol) and coeffs and all(c_.has(cs) or c_ == 0 for c_ in coeffs):
        sols = sp.solve(coeffs, cs, dict=True)
        if sols:
            every = "; every profile w(%s) is a solution when %s" % (
                zname, " or ".join("%s = %s" % (cs, sp.sstr(d[cs])) for d in sols if cs in d))
    elif coeffs and all(not c_.free_symbols for c_ in coeffs):
        every = ""
    raise ValueError("unsupported: the travelling-wave reduction is not a differential equation: it integrates to "
                     "the algebraic equation %s + C = 0 for the profile w, so the profile is constant%s"
                     % (sp.sstr(sp.expand(F)).replace("w0", "w"), every))


def stationary_reduction(pde, wavevector=None, integrate=True, _taken=None, _ks=None):
    """u_t = 0 (offered only when u_t is the only derivative involving t): u = w(x) for one space variable,
    u = w(z), z = k1 x + k2 y + ... for several.  [] if not applicable."""
    if isinstance(pde, str):
        pde = parse_pde(pde)
    if pde.time is None:
        return []
    it = pde.vars.index("t")
    for a in pde.t_derivatives():
        if not (a[it] == 1 and sum(a) == 1):
            return []
    taken = set(_taken or (set(s.name for s in pde.params) | set(pde.vars) | {pde.unknown}))
    ut = [s for s, a in pde.derivs.items() if a[it] == 1]
    E = sp.expand(pde.E.subs(dict((s, 0) for s in ut)))
    if E == 0:
        return []
    red = PDE(E, pde.unknown, pde.vars, pde.derivs, text=None)
    if len(pde.space) == 1:
        ks = [sp.Integer(1)]
        zname = pde.space[0]
        ansatz = "%s = w(%s) (stationary: %s_t = 0)" % (pde.unknown, zname, pde.unknown)
    else:
        ks = _ks or [sp.Symbol(_fresh("k%d" % (i + 1), taken)) for i in range(len(pde.space))]
        zname = _zname(pde)
        ansatz = "%s = w(%s), %s = %s (stationary: %s_t = 0)" % (pde.unknown, zname, zname,
                                                               _zstring(ks, pde.space, 0), pde.unknown)
    kvec = [sp.Integer(0) if v == "t" else ks[pde.space.index(v)] for v in pde.vars]
    E0 = _substitute(red, kvec)
    if E0 == 0:
        return []
    extra = [s for k in ks for s in sp.sympify(k).free_symbols]
    if _order(E0) < 1:
        return []                         # an algebraic stationary form is not offered
    zexpr = pde.space[0] if len(pde.space) == 1 else _zstring(ks, pde.space, 0)
    return _forms(E0, ansatz, "stationary", list(pde.params) + extra, taken, integrate, zname,
                  lowered=(pde.unknown, zexpr), warnings=list(getattr(pde, "notes", []) or []))


# ---------------------------------------------------------------------------------------------- envelope waves
#
# Complex equations for q(x, t) that are invariant under q -> exp(i phi) q (every term has the same charge:
# q and its derivatives +1, the conjugate qb -1, |q| 0).  Ansatz (sign convention of the corpus, worker the catalogue):
#     q = w(z) exp(i theta),  z = x - c t   (k1 x + k2 y + ... - c t),  theta = -kappa x + omega t + theta0
#     (-kappa1 x - kappa2 y - ... + omega t + theta0), w real;  chirped: theta + Theta(z) with Theta'(z) = s w^2.
# After dividing by exp(i charge theta) the equation is A + i B with A, B real differential polynomials in w.
#   mode "vanish":      B = 0 identically (coefficients of the jet monomials of B vanish) -> c (and kappa, omega,
#                       s) solved, the remaining coefficient equations are constraints among the parameters;
#   mode "compatible":  B = D G (exact) and the two ODEs A = 0, G = 0 must be proportional (g*A - a*G = 0 with a, g
#                       the coefficients of the highest derivative) -> constraints; used, as in the catalogue, when B
#                       has order >= 3 or order >= max(2, order of A).
# The ODE is A = 0 with the constraints substituted.

_PH = sp.Symbol("X_phase_")


def _split_conditions(conds):
    """'expr != 0' conditions -> one condition per irreducible factor (numeric factors and powers removed),
    without repetitions"""
    out = []
    for c_ in conds:
        txt = c_.split("!=")[0] if isinstance(c_, str) else c_
        try:
            e = sp.sympify(txt)
        except Exception:          # pragma: no cover
            if c_ not in out:
                out.append(c_)
            continue
        if e.is_number:
            continue
        for f, _ in sp.factor_list(e)[1]:
            if f.is_number:
                continue
            if f.could_extract_minus_sign():
                f = -f
            item = "%s != 0" % sp.sstr(f)
            if item not in out:
                out.append(item)
    return out


def _jet_coeff_eqs(E):
    """numerators of the coefficients of the jet monomials of E (the nonzero ones)"""
    E = sp.expand(E)
    if E == 0:
        return []
    js = sorted((q for q in E.free_symbols if _jet_index(q) is not None), key=_jet_index)
    if not js:
        return [_tidy(sp.numer(sp.together(E)))]
    out = []
    for _, co in sp.Poly(E, *js).terms():
        co = _tidy(sp.numer(sp.together(co)))
        if co != 0:
            out.append(co)
    return out


def _phase_split(pde, zfac, thfac):
    """(charge, A, B): the equation after u = w(z) exp(i theta) (phase factors as in the comment above) is
    exp(i charge theta) (A + i B)"""
    rep = {}
    for sym, alpha in pde.derivs.items():
        n = _FAMILY_CHARGE[pde.fam[sym]]
        F = sp.Symbol("w0")
        for v, k in zip(pde.vars, alpha):
            for _ in range(k):
                F = sp.expand(zfac[v] * total_derivative(F) + sp.I * n * thfac[v] * F)
        rep[sym] = _PH ** n * F
    E = sp.expand(pde.E.subs(rep, simultaneous=True))
    parts = sp.collect(E, _PH, evaluate=False)
    charges = {}
    for key, val in parts.items():
        if key == 1:
            n = 0
        elif key == _PH:
            n = 1
        else:
            n = int(key.exp)
        charges[n] = charges.get(n, 0) + val
    charges = dict((n, sp.expand(v)) for n, v in charges.items() if sp.expand(v) != 0)
    if len(charges) != 1:
        raise ValueError("unsupported: the equation is not invariant under the phase rotation %s -> exp(i*phi)*%s "
                         "(terms of charges %s): the envelope ansatz does not separate"
                         % (pde.unknown, pde.unknown, sorted(charges)))
    (n, F), = charges.items()
    A = sp.expand(F.subs(sp.I, 0))
    B = sp.expand((F - A) / sp.I)
    return n, A, B


class _Budget(Exception):
    pass


def _tidy(e, limit=150):
    """factor small expressions, only bring large ones to a common denominator (factor can take very long)"""
    e = sp.together(sp.sympify(e))
    return sp.factor(e) if sp.count_ops(e) < limit else e


def _solve_seq(eqs, unknowns, max_branches=6, deadline=None):
    """solve the equations (expressions = 0) for the unknowns one after the other (an equation of lowest degree in
    the unknown); returns [(solution dict, remaining relations)]; raises _Budget after the deadline"""
    def tick():
        if deadline is not None and time.monotonic() > deadline:
            raise _Budget()
    branches = [({}, list(eqs))]
    for u in unknowns:
        new = []
        for sol, rel in branches:
            tick()
            rel2 = []
            for r in rel:
                tick()
                rel2.append(_tidy(sp.numer(sp.together(sp.sympify(r).subs(sol)))) if sol else r)
            rel = rel2
            rel = [r for r in rel if r != 0]
            cand = [r for r in rel if r.has(u)]
            if not cand:
                new.append((sol, rel))
                continue
            r = min(cand, key=lambda q: (sp.degree(q, u), sp.count_ops(q)))
            if sp.degree(r, u) != 1:           # only linear solves: no radicals of the parameters
                new.append((sol, rel))
                continue
            try:
                vals = sp.solve(r, u)
            except Exception:          # pragma: no cover
                vals = []
            if not vals:
                new.append((sol, rel))
                continue
            for val in vals:
                sol2 = {}
                for k_, x_ in sol.items():
                    tick()
                    sol2[k_] = _tidy(sp.sympify(x_).subs(u, val))
                sol2[u] = _tidy(val)
                new.append((sol2, [q for q in rel if q is not r]))
        branches = new[:max_branches]
    out = []
    for sol, rel in branches:
        rr = []
        for r in rel:
            tick()
            r2 = _tidy(sp.numer(sp.together(sp.sympify(r).subs(sol))))
            if r2 != 0:
                rr.append(r2)
        out.append((sol, rr))
    return out


def _no_real_solution(rel):
    """True when the relation (= 0) has no real solution: a univariate polynomial without real roots, or a sum of
    even powers plus a positive number"""
    r = sp.expand(sp.sympify(rel))
    fs = sorted(r.free_symbols, key=str)
    try:
        if len(fs) == 1:
            P = sp.Poly(r, fs[0])
            return P.degree() > 0 and P.count_roots() == 0
        if fs:
            P = sp.Poly(r, *fs)
            terms = P.terms()
            c0 = P.coeff_monomial(1)
            if all(all(e % 2 == 0 for e in m) and (co > 0 if co.is_number else False) for m, co in terms) \
                    and c0 != 0:
                return True
            if all(all(e % 2 == 0 for e in m) and (co < 0 if co.is_number else False) for m, co in terms) \
                    and c0 != 0:
                return True
    except Exception:          # pragma: no cover
        return False
    return False


def _is_degenerating(rel):
    """a relation that sets a parameter (or a product of parameters) to zero"""
    r = sp.factor(rel)
    c, rest = r.as_coeff_Mul()
    return all(f.is_Symbol or (f.is_Pow and f.base.is_Symbol) for f in sp.Mul.make_args(rest))


def envelope_wave(pde, speed="c", wavevector=None, chirp="auto", taken=None, time_budget=20.0):
    """Envelope reductions of a complex equation (see the comment above): a list of reduction dicts
    {"ansatz", "kind": "envelope", "integrated": 0, "lowered": 0, "constants": [], "constraints": [...],
     "conditions": [...], "equation", "sympy", "note", "mode", "chirp", "real_part", "imaginary_part",
     "coefficients", "sign_convention"}, the one with fewest parameter constraints first.  chirp: 'auto' (try the
    chirp only when the plain ansatz needs constraints among the model parameters), True, False."""
    if isinstance(pde, str):
        pde = parse_pde(pde)
    taken = set(taken or (set(s.name for s in pde.params) | set(pde.vars) | {pde.unknown}))

    def fresh(nm):
        x = _fresh(nm, taken)
        taken.add(x)
        return sp.Symbol(x)
    cs = fresh(speed) if isinstance(speed, str) else sp.sympify(speed)
    om = fresh("omega")
    if len(pde.space) == 1:
        ks = [sp.Integer(1)] if wavevector is None else [sp.sympify(wavevector[0] if isinstance(wavevector, (list, tuple))
                                                                   else wavevector)]
        kaps = [fresh("kappa")]
    else:
        ks = [fresh("k%d" % (i + 1)) for i in range(len(pde.space))] if wavevector is None \
            else [sp.sympify(q) for q in wavevector]
        kaps = [fresh("kappa%d" % (i + 1)) for i in range(len(pde.space))]
    s_ = fresh("s")
    th0 = fresh("theta0")
    w0 = sp.Symbol("w0")
    zname = _zname(pde)
    has_t = pde.time is not None
    zstr = _zstring(ks, pde.space, cs if has_t else 0)
    th = " ".join("- %s*%s" % (k_, v) for k_, v in zip(kaps, pde.space)).lstrip()
    thstr = (th + (" + %s*t" % om if has_t else "") + " + %s" % th0).replace("- ", "-", 1)
    sign = ("%s = w(%s)*exp(I*theta), %s = %s, theta = %s; w real" % (pde.unknown, zname, zname, zstr, thstr))
    uses_abs = any(f == "abs" for f in pde.fam.values())
    t_start = time.monotonic()
    split_cache = {}
    impossible = []

    def attempt(chirped, mode):
        Th = s_ * w0 ** 2 if chirped else 0
        zfac, thfac = {}, {}
        for i, v in enumerate(pde.space):
            zfac[v] = ks[i]
            thfac[v] = -kaps[i] + ks[i] * Th
        if has_t:
            zfac["t"] = -cs
            thfac["t"] = om - cs * Th
        if chirped not in split_cache:
            split_cache[chirped] = _phase_split(pde, zfac, thfac)
        n, A, B = split_cache[chirped]
        if A == 0:
            return [], "the real part vanishes identically"
        KA = _order(A)
        if mode == "compatible" and B == 0:
            return [], None
        if mode == "vanish":
            eqs = _jet_coeff_eqs(B)
            G = None
        else:
            G = antiderivative(B)
            if G is None:
                return [], "the imaginary part is not a total derivative (it cannot be integrated to an ODE " \
                           "compatible with the real part)"
            if _order(G) != KA:
                return [], "the integrated imaginary part has order %d, the real part %d" % (_order(G), KA)
            wK = sp.Symbol("w%d" % KA)
            a_ = sp.Poly(A, wK).coeff_monomial(wK)
            g_ = sp.Poly(G, wK).coeff_monomial(wK)
            eqs = _jet_coeff_eqs(sp.expand(g_ * A - a_ * G))
        unknowns = [cs] if has_t else []
        if chirped:
            unknowns.append(s_)
        unknowns += kaps + [om]
        out = []
        try:
            branches = _solve_seq(eqs, [u for u in unknowns if isinstance(u, sp.Symbol)],
                                  deadline=t_start + time_budget)
        except _Budget:
            return [], "time limit of %.0f s reached while solving the %s conditions" % (time_budget, mode)
        for sol, rel in branches:
            if time.monotonic() > t_start + time_budget:
                break
            if sum(sp.count_ops(v_) for v_ in sol.values()) > 400:
                continue           # too large to expand within the time budget
            if chirped and (s_ not in sol or sol[s_] == 0):
                continue
            bad = [r for r in rel if sp.sympify(r).is_number and sp.sympify(r) != 0]
            bad += [r for r in rel if not sp.sympify(r).is_number and _no_real_solution(r)]
            if bad:
                impossible.append(bad[0])    # "number = 0" or no real solution: no envelope in this branch
                continue
            if chirped and rel:
                continue
            if any(_is_degenerating(r) for r in rel):
                continue
            ode = sp.expand(sp.numer(sp.together(A.subs(sol))))
            if ode == 0 or _order(ode) < 0:
                continue
            k0 = min(m[0] for m in sp.Poly(ode, *jets(_order(ode))).monoms())
            if k0 > 0:                         # a common factor w^k0 (w != 0 on the wave)
                ode = sp.expand(ode / w0 ** k0)
            if _order(ode) < 1:
                continue                       # algebraic: not a differential equation for w
            out.append((sol, rel, ode, A, B, G, mode, n))
        return out, None

    results, reasons = [], []

    def best():
        return min((len(r[1]) for r, _ in results), default=None)
    res0, why0 = attempt(False, "vanish")
    results += [(r, False) for r in res0]
    if why0:
        reasons.append(why0)
    if best() is None or best() > 0:
        res0, why0 = attempt(False, "compatible")
        results += [(r, False) for r in res0]
        if why0:
            reasons.append(why0)
    if chirp is True or (chirp == "auto" and (best() is None or best() > 0) and has_t
                         and time.monotonic() - t_start < time_budget):
        res1, why1 = attempt(True, "vanish")
        results += [(r, True) for r in res1]
        if why1:
            reasons.append(why1)
    if not results and impossible:
        raise ValueError("unsupported: no travelling envelope with a non-constant real profile w of the form %s "
                         "exists: the imaginary part of the reduced equation requires %s = 0 (for example a damping or "
                         "gain term); plane waves q = A*exp(I*theta) may exist and are not treated"
                         % (sign, sp.sstr(impossible[0])))
    if not results:
        why = "; ".join(reasons) or "the imaginary part cannot be made to vanish by conditions on the constants"
        raise ValueError("unsupported: envelope reduction of a complex equation failed: %s (also with the chirp "
                         "Theta' = s*w^2). For example, complex coefficients (complex Ginzburg-Landau equation) give "
                         "a system for amplitude and phase, not one real ODE." % why)
    results.sort(key=lambda rc: (len(rc[0][1]), rc[1], rc[0][6] != "vanish"))
    reds = []
    for (sol, rel, ode, A, B, G, mode, n), chirped in results:
        ode = _sign_normal(ode)
        conds = []
        for k_, v_ in sol.items():
            d_ = sp.denom(sp.together(v_))
            if not d_.is_number:
                conds.append("%s != 0" % sp.sstr(_tidy(d_)))
        own = set(cs.free_symbols if hasattr(cs, "free_symbols") else []) | {om, s_} | set(kaps) | \
            set(q for k_ in ks for q in sp.sympify(k_).free_symbols)
        par_rel = [r for r in rel if not (sp.sympify(r).free_symbols & own)]
        constraints = ["%s = %s" % (k_, sp.sstr(v_)) for k_, v_ in sol.items() if k_ != s_] + \
                      ["%s = 0" % sp.sstr(r) for r in rel if r not in par_rel]
        conds = _split_conditions(conds)
        ans = sign + ("; chirp: theta + Theta(%s), Theta'(%s) = %s*w**2, %s = %s"
                      % (zname, zname, s_, s_, sp.sstr(sol[s_])) if chirped else "")
        note = ("phase-invariant equation (charge %d); real and imaginary parts after dividing by exp(%s*I*theta)"
                % (n, n if n != 1 else "")).replace("exp(*I", "exp(I")
        if mode == "vanish":
            note += "; the imaginary part vanishes identically under the constraints"
        else:
            note += ("; the imaginary part is the derivative of an ODE proportional to the real part under the "
                     "constraints (integration constant 0)")
        if uses_abs:
            note += "; |%s| = w (w >= 0 where odd powers of |%s| occur)" % (pde.unknown, pde.unknown)
        if pde.notes:
            note += "; " + "; ".join(pde.notes)
        assumed = []
        if mode == "compatible":
            assumed.append({"constant": "C (integration constant of the imaginary part)", "value": "0",
                            "covered_by": None, "kind": "envelope-imaginary-part",
                            "why": "the imaginary part is the derivative of a differential polynomial G; this form "
                                   "takes the integration constant as 0 (G = 0) and requires the two equations for w "
                                   "to be proportional; envelopes with a nonzero constant are not covered by any "
                                   "reduction in this list"})
        params = [p for p in list(pde.params) + [cs, om] + list(kaps) + list(ks) if isinstance(p, sp.Symbol)]
        try:
            eq = make_equation(ode, params, unknown="w", var=zname)
        except ValueError:
            continue
        K = _order(ode)
        coeffs = {}
        if K >= 0:
            wK = sp.Symbol("w%d" % K)
            lead = sp.Poly(ode, wK).coeff_monomial(wK)
            if not (lead.free_symbols & set(jets(K))):
                monic = sp.expand(ode / lead)
                js_ = jets(K)
                for m, co in sp.Poly(monic, *js_).terms():
                    mono = sp.Mul(*[q ** e for q, e in zip(js_, m)])
                    if mono != wK:
                        coeffs[sp.sstr(mono)] = sp.sstr(_tidy(co))
                if not lead.is_number:
                    conds.append("%s != 0" % sp.sstr(_tidy(lead)))
        conds = _split_conditions(conds) + ["%s = 0" % sp.sstr(r) for r in par_rel]
        warns = list(pde.notes) + ["this reduction exists only for parameter values with %s = 0" % sp.sstr(r)
                                   for r in par_rel]
        reds.append({"ansatz": ans, "kind": "envelope", "integrated": 0, "lowered": 0, "constants": [],
                     "assumed": assumed, "warnings": warns,
                     "constraints": constraints, "conditions": conds, "equation": eq, "sympy": str(ode),
                     "note": note, "mode": mode, "chirp": sp.sstr(sol[s_]) if chirped else None,
                     "real_part": str(A.subs(sol)), "imaginary_part": str(B),
                     "integrated_imaginary_part": None if G is None else str(G),
                     "coefficients": coeffs, "sign_convention": sign,
                     "_exact": {"sol": sol, "A": A, "B": B, "G": G, "c": cs, "omega": om, "kappa": kaps, "k": ks,
                                "s": s_ if chirped else None, "charge": n, "relations": rel}})
    return reds


# ---------------------------------------------------------------------------------------------- catalogue entries

def catalogue_ansatz(entry):
    """The true first line for a corpus entry: the relation between the PDE's unknown and the function w whose
    equation (field "ode") and solutions are listed.  Uses reduction.ansatz, the order lowering (reduction.shift, or
    the sentences 'written for v = w^(k)' / 'W = w' (potential)' in reduction.steps or notes) and the substitution
    (entry.substitution or reduction.substitution, e.g. 'v = exp(I*w)').  Returns the string unchanged when there
    is neither."""
    red = entry.get("reduction") or {}
    base = red.get("ansatz") or ""
    if base.strip().lower().startswith("none"):
        return ""                          # an ODE model: no ansatz line
    sub = entry.get("substitution") or red.get("substitution")
    me = re.match(r"^\s*([A-Za-z]\w*)\s*=\s*w\((\w+)\)\s*\*\s*exp\(I\*theta\)\s*,\s*(.*)$", base)
    if me and sub:
        # envelope with an amplitude substitution: 'amplitude = w**(1/(2*n))', 'amplitude = w**(1/2) (w = |q|**2)'
        ma = re.match(r"^\s*amplitude\s*=\s*w\s*\*\*\s*(\([^()]*(?:\([^()]*\))?[^()]*\)|\S+)", sub)
        if ma:
            pw = ma.group(1)
            q, z = me.group(1), me.group(2)
            try:
                inv = sp.sstr(1 / sp.sympify(pw))
            except Exception:          # pragma: no cover
                inv = "1/(%s)" % pw
            return ("%s = w(%s)**%s*exp(I*theta), %s (the listed functions are w = |%s|**%s)"
                    % (q, z, pw, me.group(3), q, "(%s)" % inv if not re.match(r"^\w+$", inv) else inv))
    m = re.match(r"^\s*([A-Za-z]\w*)\s*=\s*w\((\w+)\)\s*,\s*(.*)$", base)
    if not m:
        return base
    U, z, rest = m.group(1), m.group(2), m.group(3)
    shift = red.get("shift") or 0
    text = " ".join(str(x) for x in (red.get("steps"), entry.get("notes")) if x)
    if not shift:
        mm = re.search(r"written for v = w\^\((\d+)\)", text)
        if mm:
            shift = int(mm.group(1))
        elif "W = w' (potential)" in text or "written for v = w' " in text or "v = w' (renamed w)" in text:
            shift = 1
    if sub:
        # power substitutions: 'u = w**(1/n) (after C1 = 0)', 'u = w**2', 'w = v**2' (profile w = v^2)
        mp_ = re.match(r"^\s*(%s|w)\s*=\s*(w|v)\s*\*\*\s*(\([^()]*\)|\S+)" % re.escape(U), sub)
        if mp_:
            pw = mp_.group(3)
            after = re.search(r"\(after ([^)]*)\)", sub)
            try:
                inv = sp.sstr(1 / sp.sympify(pw))
            except Exception:          # pragma: no cover
                inv = "1/(%s)" % pw
            inv_s = inv if re.match(r"^\w+$", inv) else "(%s)" % inv
            return ("%s = w(%s)**%s, %s (the listed functions are w = %s**%s%s)"
                    % (U, z, pw, rest, U, inv_s, "; %s" % after.group(1) if after else ""))
        # 'v = exp(I*w)' or 'u = -I*log(w), i.e. w = exp(I*u)': the listed function is exp(I*u) etc.
        ms = re.search(r"w\s*=\s*([^,;]+)$", sub.split("i.e.")[-1].strip())
        if "i.e." in sub and ms:
            g = ms.group(1).strip()
        else:
            ms = re.match(r"^\s*v\s*=\s*(.+)$", sub)
            g = ms.group(1).strip().replace("w", U) if ms else None
        if g:
            return "%s = w(%s), %s (the listed functions are w; %s itself is not listed)" % (g, z, rest, U)
    if shift:
        return _lowered_ansatz(U, z, rest.split("=", 1)[1].strip() if "=" in rest else rest, int(shift))
    return base
