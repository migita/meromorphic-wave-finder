"""mero.parse -- read an autonomous polynomial ODE typed by a visitor.

    parse_ode(text, unknown=None, var=None) -> Equation

No `eval`, no `sympify` of raw text: the text is tokenised and read by a small recursive-descent parser that
only knows numbers, names, + - * / ^ **, brackets, primes, subscripts, `diff(...)` and a list of function
names (which are recognised only in order to say "unsupported").

Accepted (examples)
    w''' + a*w'' = 12 w w' + 1        primes (also the unicode primes), implicit multiplication, one '=' sign
    u_zzz + u u_z = 0                 subscript derivatives (the independent variable is read from them)
    diff(w, z, 3), diff(w(z), z, z)   also Derivative(...); a derivative of a polynomial expression is expanded
    dw/dz, d^2w/dz^2, d2w/dz2         Leibniz notation, also \\frac{d^2 w}{dz^2} (one-letter unknown and variable)
    w^(4), w^{(4)}, w^(iv)            derivative of order four (w^4, w**4, w^{4} are powers)
    w3 = 12*w0*w1                     jets w0, w1, ... (or x0, x1, ... of the older atlas) when no other
                                      derivative notation occurs
    alpha, \\alpha, the letter itself  Greek names; every name that is not the unknown is a parameter
    0.5                               decimals become exact rationals (a warning is recorded)

Rejected with ValueError('unsupported: ...'): functions of the unknown (sin, exp, sqrt, ...), fractional or
symbolic powers of the unknown, irrational constants, an explicit independent variable (not autonomous), two
unknowns.  An equation that is rational in the unknown is multiplied by its denominator and a warning is recorded
(with allow_rational=False it is rejected).  ValueError('ambiguous: ...'): the unknown cannot be identified.

Rules that keep the reader from analysing another equation than the one typed (audit of 6 October 2026):
    sin w, \\sqrt w                a function name without a bracket after it is refused, never a parameter
                                    (sin (w), \\sqrt{w} are calls and are refused as non-polynomial)
    F(w), g(w'), a(w')^2            a name followed by a bracket that contains the unknown is an unspecified
                                    function of the unknown: refused (write a*(w')^2 for the product);
                                    w(1 - w), u(1 - u) with the unknown itself in front remain products
    a(b + 1) w                      a name followed by a bracket without the unknown: product, with a warning
    w(0), w'(0), w(a)               a value at a point: refused;  w(z), w(xi): the unknown
    w^(iv), w^{(v)}                 roman numerals are derivative orders of the unknown only, and only if the
                                    letters are not names used elsewhere; a^(v) is a symbolic power (refused)
    solve w'' = ...                 a leading word (solve, find, equation, ode, ...) is dropped with a warning;
                                    every other multi-letter name that is not Greek gets the warning
                                    "read as a parameter: <name>"
    w^2/2w, 1/2w                    read as (w^2/2)*w, (1/2)*w -- with a warning
    w'/w = w                        the cleared factor is recorded in eq.cleared_denominators (["w0"])
    w^(100)                         derivative orders above MAX_ORDER = 12 are refused
    (2) w'' = ..., ... (2.3), (P1), (*)   an equation number is a label (dropped, with a warning) only when it
                                    stands alone at the very beginning or end, after/before a space: (2)(w')^2 and
                                    w^2 + (1) are numbers; before or after another bracket, and for a single
                                    letter '(a) w'' = ...', label and factor cannot be told apart: refused
    w (cap - w), a (a constant)     a bracket with the unknown, an operator sign or a symbol of the equation is
                                    never dropped as a remark; '(Weierstrass)', '(see above)' at the end are
    kw, aw, bu                      one letter glued to the unknown is the product (warning "kw was read as k*w");
                                    a three-letter word with the unknown inside (abw, max) is refused; a longer
                                    word (power) is one parameter, with a warning
    u_t = u'' + ..., dot and u_xx   two derivative notations in one input (dots, primes, subscripts, d/dz) are
                                    refused unless both name their variable (subscripts with d/dz)
    lambda, if, wp                  parameter names that are Python keywords or names of the engine's functions
                                    are renamed (lamda, ifpar, wppar) with a warning; I and i are the imaginary
                                    unit, with a warning

    parse_jet_expression(text) -> SymPy expression     strict form used by Equation(E="...") and by JSON files:
                                                       identifiers w0, w1, ... are jets, all others parameters.
"""
import re
import sympy as sp

from .equation import Equation, total_derivative, exact_zero

# ----------------------------------------------------------------------------------------- tables
_GREEK = {
    "α": "alpha", "β": "beta", "γ": "gamma", "δ": "delta", "ε": "epsilon", "ϵ": "epsilon", "ζ": "zeta",
    "η": "eta", "θ": "theta", "ϑ": "theta", "ι": "iota", "κ": "kappa", "λ": "lambda", "μ": "mu", "µ": "mu",
    "ν": "nu", "ξ": "xi", "ο": "omicron", "π": "pi", "ρ": "rho", "ϱ": "rho", "σ": "sigma", "ς": "sigma",
    "τ": "tau", "υ": "upsilon", "φ": "phi", "ϕ": "phi", "χ": "chi", "ψ": "psi", "ω": "omega",
    "Γ": "Gamma", "Δ": "Delta", "Θ": "Theta", "Λ": "Lambda", "Ξ": "Xi", "Π": "Pi", "Σ": "Sigma",
    "Υ": "Upsilon", "Φ": "Phi", "Ψ": "Psi", "Ω": "Omega",
}
_GREEK_NAMES = set(_GREEK.values()) | {"varepsilon", "vartheta", "varphi", "varrho", "varsigma"}
_ALIASES = {"varepsilon": "epsilon", "vartheta": "theta", "varphi": "phi", "varrho": "rho",
            "varsigma": "sigma"}
_EXTRA_NAMES = {"eps", "lam", "lmbda"}
# Function names.  A name of _STRICT_FUNCS is never a parameter: without a bracket after it the input is refused
# (`sin w` is not `sin*w`).  The other names of _FUNCS are functions when a bracket follows.  `gamma` is not
# here: it is a parameter name.
_STRICT_FUNCS = {"sin", "cos", "tan", "cot", "sec", "csc", "sinh", "cosh", "tanh", "coth", "sech", "csch",
                 "exp", "log", "ln", "sqrt", "abs", "asin", "acos", "atan", "asinh", "acosh", "atanh",
                 "arcsin", "arccos", "arctan", "erf", "cbrt", "sign", "floor"}
_FUNCS = _STRICT_FUNCS | {"sn", "cn", "dn", "wp"}
# words in front of an equation that are not part of it
_LEAD_WORDS = {"solve", "find", "equation", "ode", "eq", "eqn", "the", "consider", "analyse", "analyze",
               "study", "integrate", "please"}
# parameter names that later modules (and the independent checker) cannot read: Python keywords and the names
# of the engine's functions.  They are renamed on input.
_PY_KEYWORDS = {"False", "None", "True", "and", "as", "assert", "async", "await", "break", "class", "continue",
                "def", "del", "elif", "else", "except", "finally", "for", "from", "global", "if", "import",
                "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise", "return", "try", "while",
                "with", "yield"}
_RESERVED = dict((kw, kw + "par") for kw in _PY_KEYWORDS)
_RESERVED.update({"lambda": "lamda", "wp": "wppar", "wpp": "wpppar", "zeta_w": "zeta_wpar",
                  "sigma_w": "sigma_wpar"})
#: largest derivative order that is read (the site treats orders up to 6; higher ones get "unsupported" later)
MAX_ORDER = 12
_ORDER_MSG = ("unsupported: a derivative of order %s occurs; derivative orders above " + str(MAX_ORDER)
              + " are not read (the site treats equations of order at most 6)")
# roman numerals that are read as derivative orders (of the unknown only)
_ROMAN_OK = {"ii", "iii", "iv", "v", "vi", "vii", "viii", "ix"}
_DIFF = {"diff", "Derivative"}
_KNOWN_WORDS = _GREEK_NAMES | _EXTRA_NAMES | _FUNCS | _DIFF
_VAR_LETTERS = ("z", "x", "t", "xi", "s", "y", "tau", "eta", "zeta", "theta", "r", "Z", "X", "T")
_SUPERSCRIPT = {"⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4", "⁵": "5", "⁶": "6", "⁷": "7",
                "⁸": "8", "⁹": "9"}
_CHAR_MAP = {
    "−": "-", "–": "-", "—": "-", "‐": "-", "‑": "-", "‒": "-", "﹣": "-", "－": "-",
    "′": "'", "’": "'", "‘": "'", "ʹ": "'", "´": "'", "`": "'", "″": "''", "‴": "'''", "⁗": "''''", '"': "''",
    "·": "*", "×": "*", "⋅": "*", "∙": "*", "∗": "*", "÷": "/", "∕": "/", "⁄": "/",
    "[": "(", "]": ")", "（": "(", "）": ")", "＝": "=", "＋": "+", " ": " ", " ": " ", " ": " ",
    "$": " ",
}
_ROMAN = {"i": 1, "ii": 2, "iii": 3, "iv": 4, "v": 5, "vi": 6, "vii": 7, "viii": 8, "ix": 9, "x": 10}
_JETNAME = re.compile(r"^([A-Za-z])(\d+)$")
# names that need no remark when they are read as parameters: a letter or a Greek name, with optional digits
# and an optional subscript (a, C1, k_1, alpha, mu2, c_s)
_PLAIN_NAME = re.compile(r"^(?:[A-Za-z]|%s)\d*(?:_[A-Za-z0-9]+)?$"
                         % "|".join(sorted(_GREEK_NAMES | _EXTRA_NAMES | {"lamda"}, key=len, reverse=True)))
_LEAD_RE = re.compile(r"^\s*([A-Za-z]+)\.?\s*(?::|\s)\s*")
# what an equation number looks like: 2, 2.3, 2a, P1, Eq2, A.1, *, **
_LABEL = r"(?:\d+(?:\.\d+)*[A-Za-z]?|[A-Z][A-Za-z]?\.?\d+(?:\.\d+)*[a-z]?|\*{1,3})"
_LABEL_START = re.compile(r"^\s*[(\[]\s*(%s)\s*[)\]]" % _LABEL)
_LABEL_END = re.compile(r"\s+[(\[]\s*(%s)\s*[)\]]\s*$" % _LABEL)
_NUMBER = re.compile(r"(\d+\.\d*|\.\d+|\d+)([eE][+-]?\d+)?")


class _Tok(object):
    __slots__ = ("kind", "val", "sub", "pos")

    def __init__(self, kind, val, sub=None, pos=0):
        self.kind, self.val, self.sub, self.pos = kind, val, sub, pos

    def __repr__(self):
        return "%s:%s%s" % (self.kind, self.val, "" if self.sub is None else "_%s" % (self.sub,))


_U = r"([A-Za-ce-z])"                  # the unknown: one letter other than d
_V = r"([a-z])"                        # the independent variable: one small letter
_ORD = r"(?:\^|\*\*)?\s*\{?\s*(\d+)\s*\}?"
_LEIB_N = re.compile(r"(?<![A-Za-z0-9_\\])d\s*" + _ORD + r"\s*" + _U + r"\s*/\s*d\s*" + _V
                     + r"\s*(?:\^|\*\*)?\s*\{?\s*\1\s*\}?(?![A-Za-z0-9_])")
_LEIB_1 = re.compile(r"(?<![A-Za-z0-9_\\])d" + _U + r"\s*/\s*d" + _V + r"(?![A-Za-z0-9_'^])")
_LEIB_FRAC_N = re.compile(r"\\frac\s*\{\s*d\s*" + _ORD + r"\s*" + _U + r"\s*\}\s*\{\s*d\s*" + _V
                          + r"\s*(?:\^|\*\*)?\s*\{?\s*\1\s*\}?\s*\}")
_LEIB_FRAC_1 = re.compile(r"\\frac\s*\{\s*d\s*" + _U + r"\s*\}\s*\{\s*d\s*" + _V + r"\s*\}")


def _group_end(s, i):
    """index just after the brace group that starts at s[i] == '{' (balanced), or -1"""
    depth = 0
    for j in range(i, len(s)):
        if s[j] == "{":
            depth += 1
        elif s[j] == "}":
            depth -= 1
            if depth == 0:
                return j + 1
    return -1


def _one_token_args(s, cmd, nargs):
    r"""LaTeX: an argument without braces is ONE token (a digit, a letter or a control word):
    \frac12 -> \frac{1}{2}, \frac ab -> \frac{a}{b}, \frac1{2a} -> \frac{1}{2a}, \sqrt2 -> \sqrt{2}"""
    out, i, L = [], 0, len(cmd)
    while True:
        j = s.find(cmd, i)
        if j < 0:
            out.append(s[i:])
            break
        k = j + L
        out.append(s[i:k])
        i = k
        if k < len(s) and s[k].isalpha():          # a longer control word
            continue
        for _ in range(nargs):
            while i < len(s) and s[i].isspace():
                i += 1
            if i >= len(s):
                break
            if s[i] == "{":
                e = _group_end(s, i)
                if e < 0:
                    break
                out.append("{" + _one_token_args(s[i + 1:e - 1], cmd, nargs) + "}")
                i = e
            elif s[i] == "\\":
                m = re.match(r"\\[A-Za-z]+", s[i:])
                if not m:
                    break
                out.append("{" + m.group(0) + "}")
                i += m.end()
            elif s[i].isalnum():
                out.append("{" + s[i] + "}")
                i += 1
            else:
                break
    return "".join(out)


_LATEX_SPACING = re.compile(r"\\(left|right|bigl|bigr|Bigl|Bigr|biggl|biggr|big|Big|bigg|displaystyle|textstyle|,|;|!|:|"
                            r"quad|qquad| )")


def _latex_common(s):
    r"""the LaTeX rewrites shared by parse_ode and latex_to_plain: spacing commands, \cdot, \dfrac, \prime,
    one-token arguments of \frac and \sqrt, \dot{x}, x^{\prime\prime}"""
    s = _LATEX_SPACING.sub(" ", s)
    s = re.sub(r"\\(cdot|times|ast)(?![A-Za-z])", "*", s)
    s = re.sub(r"\\(dfrac|tfrac)(?![A-Za-z])", r"\\frac", s)
    s = re.sub(r"\{([^{}]*?)\\over(?![A-Za-z])([^{}]*)\}", r"\\frac{\1}{\2}", s)      # {1 \over 2}
    s = re.sub(r"\\prime(?![A-Za-z])", "'", s)
    s = re.sub(r"\^\s*((?:'\s*)+)", lambda m: m.group(1).replace(" ", ""), s)         # w^\prime is w'
    s = re.sub(r"\\(mathrm|text|operatorname|mathit|rm)\s*\{([^{}]*)\}", r" \2 ", s)
    if "\\frac" in s:
        s = _one_token_args(s, "\\frac", 2)
    if "\\sqrt" in s and not re.search(r"\\sqrt\s*[\[(]", s):
        s = _one_token_args(s, "\\sqrt", 1)
    # \dot{x}, \ddot{x}, \dddot{x}: derivatives with respect to the independent variable
    # (a space is put on both sides: \gamma\dot{x} is gamma x', not the control word \gammax)
    s = re.sub(r"\\(d{1,4})ot\s*\{\s*([A-Za-z]|\\[A-Za-z]+)\s*\}",
               lambda m: " " + m.group(2) + "'" * len(m.group(1)) + " ", s)
    s = re.sub(r"\\(d{1,4})ot\s+([A-Za-z])(?![A-Za-z])", lambda m: " " + m.group(2) + "'" * len(m.group(1)) + " ", s)
    s = re.sub(r"\\(d{1,4})ot\s*\{([^{}]*)\}", lambda m: " (" + m.group(2) + ")" + "'" * len(m.group(1)) + " ", s)
    # x^{\prime\prime} (now x^{''}) is x''
    s = re.sub(r"\^\s*\{\s*((?:'\s*)+)\}", lambda m: m.group(1).replace(" ", ""), s)
    return s


def _latex_markup(s):
    r"""environment markup that is not part of the equation: \begin{equation}, \end{...}, \label{...},
    \nonumber are removed; \tag{...} is removed and returned as a label.  Returns (text, labels)."""
    labels = []
    s = re.sub(r"\\(begin|end)\s*\{[A-Za-z*]+\}", " ", s)
    s = re.sub(r"\\label\s*\{[^{}]*\}", " ", s)
    s = re.sub(r"\\(nonumber|notag)(?![A-Za-z])", " ", s)

    def _tag(m):
        labels.append(m.group(1).strip())
        return " "
    s = re.sub(r"\\tag\s*\*?\s*\{([^{}]*)\}", _tag, s)
    return s, labels


def _resolve_operators(s):
    r"""the marker \x01vars\x02 of a derivative operator (\partial_x, \frac{\partial}{\partial x}) and its
    operand:  ( ... ) -> Dx( ... ;  u -> u_x ;  u^2 -> Dx(u^2) ;  anything else: the operator is put back as
    \partial_{x}, which the readers refuse (it is never left as a name that could be taken for a parameter)"""
    out, i = [], 0
    while True:
        j = s.find("\x01", i)
        if j < 0:
            out.append(s[i:])
            return "".join(out)
        k = s.find("\x02", j)
        var = s[j + 1:k]
        out.append(s[i:j])
        rest = s[k + 1:]
        m = re.match(r"\s*\(", rest)
        if m:
            out.append(" D%s(" % var)
            i = k + 1 + m.end()
            continue
        m = re.match(r"\s*([A-Za-z]|\\[A-Za-z]+)(?![A-Za-z])\s*(\^\s*(?:\{[^{}]*\}|\d|[A-Za-z]))?", rest)
        if m and m.group(2):
            out.append(" D%s(%s%s) " % (var, m.group(1), m.group(2)))      # \partial_x u^2 is (u^2)_x
            i = k + 1 + m.end()
        elif m and not re.match(r"\s*[_(]", rest[m.end():]):
            out.append(" %s_%s " % (_plain_name(m.group(1)), var))
            i = k + 1 + m.end()
        else:
            out.append(" \\partial_{%s} " % var)
            i = k + 1


_GREEK_WORDS = sorted(set(_GREEK.values()) | set(_ALIASES), key=len, reverse=True)
_PARTIAL_EXPR_FRAC = re.compile(r"\\frac\s*\{\s*\\partial\s*(?:\^\s*\{?\s*(\d)\s*\}?)?\s*\(([^{}]*)\)\s*\}\s*"
                                r"\{((?:\s*\\partial\s*(?:[A-Za-z]|\\[A-Za-z]+)\s*(?:\^\s*\{?\s*\d\s*\}?)?)+)\s*\}")
_PARTIAL_FRAC = re.compile(r"\\frac\s*\{\s*\\partial\s*(?:\^\s*\{?\s*(\d)\s*\}?)?\s*([A-Za-z]|\\[A-Za-z]+)\s*\}\s*"
                           r"\{((?:\s*\\partial\s*(?:[A-Za-z]|\\[A-Za-z]+)\s*(?:\^\s*\{?\s*\d\s*\}?)?)+)\s*\}")
_PARTIAL_OP_FRAC = re.compile(r"\\frac\s*\{\s*\\partial\s*(?:\^\s*\{?\s*(\d)\s*\}?)?\s*\}\s*"
                              r"\{((?:\s*\\partial\s*(?:[A-Za-z]|\\[A-Za-z]+)\s*(?:\^\s*\{?\s*\d\s*\}?)?)+)\s*\}")
_PARTIAL_VARS = re.compile(r"\\partial\s*([A-Za-z]|\\[A-Za-z]+)\s*(?:\^\s*\{?\s*(\d)\s*\}?)?")
_ORD_FRAC = re.compile(r"\\frac\s*\{\s*d\s*(?:\^\s*\{?\s*(\d)\s*\}?)?\s*([A-Za-z]|\\[A-Za-z]+)\s*\}\s*"
                       r"\{\s*d\s*([A-Za-z]|\\[A-Za-z]+)\s*(?:\^\s*\{?\s*\d\s*\}?)?\s*\}")


def _plain_name(tok):
    tok = tok.strip()
    if tok.startswith("\\"):
        tok = tok[1:]
    return _ALIASES.get(tok, tok)


def _partial_subscript(denominator):
    r"""'\partial x^2 \partial t' -> 'xxt'"""
    out = ""
    for m in _PARTIAL_VARS.finditer(denominator):
        out += _plain_name(m.group(1)) * int(m.group(2) or 1)
    return out


def latex_to_plain(text):
    r"""Normalise LaTeX markup to the plain notation that parse_ode and the PDE reader accept.

        \frac{a}{b}, \frac12, \tfrac{1}{2}      ->  ((a)/(b)), ((1)/(2))
        \frac{\partial u}{\partial t}, \frac{\partial^2 u}{\partial x^2}, \partial_t u, \partial_x^2 u,
        \partial_{xx} u, u_{xx}                  ->  u_t, u_xx
        \frac{\partial}{\partial x}( ... ), \partial_x ( ... )   ->  Dx( ... )
        \frac{d^2 w}{dz^2}, \frac{dw}{dz}        ->  d^2w/dz^2, dw/dz
        \dot{x}, \ddot{x}, x^{\prime\prime}      ->  x', x'', x''
        \alpha, \varepsilon, \sin, \sqrt{a}      ->  alpha, epsilon, sin, sqrt(a)
        x^{2}, x^{n+1}, a_{1}, \left( \right), \cdot, \,  ->  x^2, x^(n+1), a_1, ( ), *, space
    Control words that are not known are left in place (the readers refuse them).  The function only rewrites
    notation; it does not decide whether the text is an ordinary or a partial differential equation."""
    if not isinstance(text, str):
        raise ValueError("unsupported: the equation must be given as text")
    s = text.replace("$", " ").replace("\\[", " ").replace("\\]", " ").replace("\\(", " ").replace("\\)", " ")
    s = s.replace("~", " ").replace("&", " ")
    s = _latex_markup(s)[0]
    s = re.sub(r"\\(lvert|rvert|vert|mid)(?![A-Za-z])", "|", s)
    s = _latex_common(s)
    # partial derivatives written as fractions
    s = _PARTIAL_FRAC.sub(lambda m: " %s_%s " % (_plain_name(m.group(2)), _partial_subscript(m.group(3))), s)
    s = _PARTIAL_EXPR_FRAC.sub(lambda m: " D%s(%s) " % (_partial_subscript(m.group(3)), m.group(2)), s)
    s = _PARTIAL_OP_FRAC.sub(lambda m: "\x01%s\x02" % _partial_subscript(m.group(2)), s)
    s = _ORD_FRAC.sub(lambda m: " d%s%s/d%s%s " % ("^" + m.group(1) if m.group(1) else "", _plain_name(m.group(2)),
                                                    _plain_name(m.group(3)), "^" + m.group(1) if m.group(1) else ""), s)
    # \partial_t u, \partial_x^2 u, \partial_{xx} u ; \partial_x ( ... ) ; \partial_x u^2
    s = re.sub(r"\\partial\s*_\s*(?:\{\s*([A-Za-z\\ ]+?)\s*\}|([A-Za-z]))\s*(?:\^\s*\{?\s*(\d)\s*\}?)?",
               lambda m: "\x01%s\x02" % (_plain_name(m.group(1) or m.group(2)).replace(" ", "")
                                          * int(m.group(3) or 1)), s)
    s = _resolve_operators(s)
    # generic fractions (the arguments may contain braces: \\frac{u_{x}^{2}}{2})
    for _ in range(400):
        j = s.find("\\frac")
        if j < 0:
            break
        k, args = j + 5, []
        for _arg in range(2):
            while k < len(s) and s[k].isspace():
                k += 1
            e = _group_end(s, k) if k < len(s) and s[k] == "{" else -1
            if e < 0:
                break
            args.append(s[k + 1:e - 1])
            k = e
        if len(args) == 2:
            s = s[:j] + "((" + args[0] + ")/(" + args[1] + "))" + s[k:]
        else:
            s = s[:j] + "\x00frac" + s[j + 5:]          # not of the form \\frac{..}{..}: left for the reader
    s = s.replace("\x00frac", "\\frac")
    for _ in range(100):
        j = s.find("\\sqrt")
        e = -1
        if j >= 0:
            k = j + 5
            while k < len(s) and s[k].isspace():
                k += 1
            e = _group_end(s, k) if k < len(s) and s[k] == "{" else -1
        if e < 0:
            break
        s = s[:j] + "sqrt(" + s[k + 1:e - 1] + ")" + s[e:]
    # Greek and function names
    def _word(m):
        name = m.group(1)
        if name in _GREEK_NAMES or name in _FUNCS:
            before = " " if m.start() > 0 and (s[m.start() - 1].isalnum() or s[m.start() - 1] in ")}") else ""
            after = " " if m.end() < len(s) and s[m.end()].isalnum() else ""
            return before + _ALIASES.get(name, name) + after
        return m.group(0)
    s = re.sub(r"\\([A-Za-z]+)", _word, s)
    # subscripts and superscripts in braces
    s = re.sub(r"_\s*\{\s*([A-Za-z0-9 ,]+?)\s*\}", lambda m: "_" + m.group(1).replace(" ", "").replace(",", ""), s)
    def _sup(m):
        c = m.group(1).strip()
        if re.match(r"^(\d+|[A-Za-z])$", c):
            return "^" + c                      # x^{2} -> x^2  (x^(2) would be read as a derivative)
        if c.startswith("(") and c.endswith(")"):
            return "^" + c                      # w^{(4)} -> w^(4)
        return "^(" + c + ")"
    s = re.sub(r"\^\s*\{([^{}]*)\}", _sup, s)
    s = re.sub(r"(sin|cos|tan|cot|sec|csc|sinh|cosh|tanh|coth|sech|csch|exp|log|ln)\s*\{([^{}]*)\}", r"\1(\2)", s)
    s = s.replace("{", "(").replace("}", ")")
    return re.sub(r"\s+", " ", s).strip()


def _normalise(text, limit=20000, leibniz=False):
    if not isinstance(text, str):
        raise ValueError("unsupported: the equation must be given as text")
    if len(text) > limit:
        raise ValueError("unsupported: the text is too long (%d characters, the limit is %d)" % (len(text), limit))
    if re.search(r"\\sqrt\s*\[", text):
        raise ValueError("unsupported: \\sqrt[n]{...}: write a root as a power, (...)^(1/n); a root of the "
                         "unknown is not polynomial")
    out = []
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch in _SUPERSCRIPT:
            j = i
            digs = ""
            while j < n and text[j] in _SUPERSCRIPT:
                digs += _SUPERSCRIPT[text[j]]
                j += 1
            out.append("**" + digs + " ")
            i = j
            continue
        out.append(_CHAR_MAP.get(ch, ch))
        i += 1
    s = "".join(out)
    # LaTeX: spacing and sizing commands, one-token arguments of \\frac and \\sqrt, \\dot{x}, x^{\\prime}
    if "\\" in s or "^" in s:
        s = _latex_common(s)
    s = s.replace("==", "=")
    if leibniz:
        # Leibniz notation:  dw/dz, d^2w/dz^2, d2w/dz2, \frac{d^2 w}{dz^2}  ->  diff(w, z, 2)
        s = _LEIB_FRAC_N.sub(r" diff(\2,\3,\1) ", s)
        s = _LEIB_FRAC_1.sub(r" diff(\1,\2) ", s)
        s = _LEIB_N.sub(r" diff(\2,\3,\1) ", s)
        s = _LEIB_1.sub(r" diff(\1,\2) ", s)
        # operator notation: \frac{d^2}{dz^2} w, (d/dz)^2 w, (d/dz) w
        s = re.sub(r"\\frac\s*\{\s*d\s*(?:\^\s*\{?\s*(\d)\s*\}?)?\s*\}\s*\{\s*d\s*([a-z])\s*(?:\^\s*\{?\s*\d\s*\}?)?\s*\}"
                   r"\s*([A-Za-ce-z])(?![A-Za-z0-9_'(])",
                   lambda m: " diff(%s,%s,%s) " % (m.group(3), m.group(2), m.group(1) or "1"), s)
        s = re.sub(r"\(\s*d\s*/\s*d\s*([a-z])\s*\)\s*(?:(?:\^|\*\*)\s*\{?\s*(\d)\s*\}?)?\s*([A-Za-ce-z])(?![A-Za-z0-9_'(])",
                   lambda m: " diff(%s,%s,%s) " % (m.group(3), m.group(1), m.group(2) or "1"), s)
    return s


def _segment(word, known, unknown=None, carrier=False):
    """split a run of letters and digits into names: known multi-letter names are kept, a letter followed
    by digits is one name, everything else is a product of single letters"""
    if unknown and word == unknown:
        return [word]
    tail = []
    if unknown and carrier and len(word) > len(unknown) and word.endswith(unknown):
        tail = [unknown]
        word = word[:-len(unknown)]
        if word in known or re.match(r"^[A-Za-z]\d*$", word):
            return [word] + tail
    elif word in known or re.match(r"^[A-Za-z]\d*$", word):
        return [word]
    out = []
    i = 0
    while i < len(word):
        best = None
        if unknown and len(unknown) > 1 and word.startswith(unknown, i):
            best = unknown
        else:
            for L in range(min(len(word) - i, 10), 1, -1):
                if word[i:i + L] in known:
                    best = word[i:i + L]
                    break
        if best is None:
            best = word[i]
        i += len(best)
        j = i
        while j < len(word) and word[j].isdigit():
            j += 1
        out.append(best + word[i:j])
        i = j
    return out + tail


def _sub_units(sub):
    """a subscript as a list of units: 'zzz' -> ['z','z','z'], 'xixi' -> ['xi','xi'], '12' -> ['12']"""
    sub = sub.strip()
    sub = re.sub(r"\\([A-Za-z]+)", r"\1", sub).replace(" ", "")
    for g, name in _GREEK.items():
        sub = sub.replace(g, "<%s>" % name)
    if not sub:
        return []
    if "<" in sub:
        units = re.findall(r"<([a-zA-Z]+)>|(.)", sub)
        return [a or b for a, b in units]
    for name in ("xi", "eta", "tau", "zeta", "theta"):
        if len(sub) % len(name) == 0 and sub == name * (len(sub) // len(name)):
            return [name] * (len(sub) // len(name))
    if sub.isalpha():
        return list(sub)
    return [sub]


def _tokenise(text, strict=False, unknown=None, split="all", notes=None):
    """split: 'all'  every word that is not a known name is a product of single letters (first pass, used
                     to find the unknown);
              'unknown'  only words that contain the unknown as a factor are split (w w', a w'', b w w');
              'none' words are kept whole (jet notation, SymPy syntax)."""
    s = _normalise(text, 2000000 if strict else 20000, leibniz=not strict)
    toks = []
    i, n = 0, len(s)
    known = set(_KNOWN_WORDS)
    while i < n:
        ch = s[i]
        if ch.isspace():
            i += 1
            continue
        m = _NUMBER.match(s, i)
        if m and (ch.isdigit() or ch == "."):
            toks.append(_Tok("NUM", m.group(0), pos=i))
            i = m.end()
            continue
        if strict and (ch.isalpha() or ch == "_") and ch not in _GREEK:
            m = re.match(r"[A-Za-z_][A-Za-z_0-9]*", s[i:])
            if not m:
                raise ValueError("unsupported: character %r" % ch)
            toks.append(_Tok("NAME", m.group(0), pos=i))
            i += m.end()
            continue
        word, latex_cmd = None, False
        if ch == "\\":
            m = re.match(r"\\([A-Za-z]+)", s[i:])
            if not m:
                raise ValueError("unsupported: character %r" % ch)
            cmd = m.group(1)
            i += m.end()
            if cmd == "frac":
                toks.append(_Tok("FRAC", "frac", pos=i))
                continue
            if cmd not in _KNOWN_WORDS:
                raise ValueError("unsupported: LaTeX command \\%s" % cmd)
            word, latex_cmd = cmd, True
        elif ch in _GREEK:
            word, latex_cmd = _GREEK[ch], True
            i += 1
            m = re.match(r"\d+", s[i:])
            if m:
                word += m.group(0)
                i += m.end()
        elif ch.isalpha():
            m = re.match(r"[A-Za-z][A-Za-z0-9]*", s[i:])
            if not m:
                raise ValueError("unsupported: character %r" % ch)
            word = m.group(0)
            i += m.end()
        if word is not None:
            sub = None
            loose_sub = False
            if i < n and s[i] == "_" and not strict:
                if i + 1 < n and s[i + 1] == "{":
                    j = s.find("}", i + 2)
                    if j < 0:
                        raise ValueError("unsupported: unbalanced brace in a subscript")
                    sub = s[i + 2:j]
                    i = j + 1
                else:
                    # an unbraced subscript is ONE run of digits, or of letters, or of Greek letters -- never
                    # digits followed by letters: a_1w is a_1*w, g_2w^3 is g_2*w^3 (said in a warning)
                    m = re.match(r"_(\d+|[A-Za-z]+|[%s]+)" % "".join(_GREEK.keys()), s[i:])
                    if not m:
                        raise ValueError("unsupported: empty subscript")
                    sub = m.group(1)
                    i += m.end()
                    m2 = re.match(r"[A-Za-z0-9]+", s[i:])
                    if m2 and notes is not None:
                        notes.append("%s_%s%s was read as %s_%s*%s"
                                     % (word, sub, m2.group(0), word, sub, m2.group(0)))
                    loose_sub = True
            if strict:
                toks.append(_Tok("NAME", _ALIASES.get(word, word), pos=i))
                continue
            carrier = (sub is not None) or (i < n and s[i] == "'")
            if latex_cmd or split == "none":
                parts = [word]
            else:
                parts = _segment(word, known, unknown, carrier)
                if split == "unknown" and len(parts) > 1:
                    letters = sum(1 for ch_ in word if ch_.isalpha())
                    singles = [q.rstrip("0123456789") for q in parts if len(q.rstrip("0123456789")) == 1]
                    others = [q for q in singles if q != unknown]
                    if unknown is None or unknown not in parts:
                        parts = [word]
                    elif all(q == unknown for q in parts):
                        pass                       # ww', uu_x: the unknown repeated
                    elif not others or (carrier and letters <= 3 and parts[-1] == unknown) \
                            or (len(others) == len([q for q in parts if q != unknown])
                                and all(q in ("z", "x", "t") for q in others)):
                        # ... and the unknown next to a letter of the independent variable (ty, xw): a product,
                        # which makes the equation non-autonomous (refused later unless the letter is a parameter)
                        # Greek names glued to the unknown (alphaw, muu'), and a short word that carries a
                        # derivative (aw'', bww', auu_x: a parameter has no derivative, so it is a product)
                        if notes is not None:
                            notes.append("%s was read as the product %s" % (word, "*".join(parts)))
                    elif len(parts) == 2 and len(others) == 1:
                        # one letter glued to the unknown: kw, aw, wk are products (a parameter is not given
                        # a name with the unknown's letter inside)
                        if notes is not None:
                            notes.append("%s was read as %s" % (word, "*".join(parts)))
                    elif letters <= 3:
                        # abw, max: the product a*b*w or one name -- not decidable
                        raise ValueError("unsupported: the word '%s' contains the unknown %s: it can be the "
                                         "product %s or one name. Write the product with spaces or *, or give "
                                         "the parameter another name" % (word, unknown, "*".join(parts)))
                    else:
                        # a longer word is ONE name: power, amplitude are not p*o*w*e*r
                        parts = [word]
            if loose_sub and split == "unknown" and unknown and sub.isalpha() and parts[-1] != unknown \
                    and unknown in sub:
                # k_w, k_xw: letters after '_' on a parameter, with the unknown's letter among them
                if sub == unknown:
                    if notes is not None:
                        notes.append("%s_%s was read as one parameter (%s with the subscript %s), not as a "
                                     "product with the unknown" % (word, sub, word, sub))
                else:
                    cut = sub.rfind(unknown)
                    raise ValueError("unsupported: '%s_%s' has two readings: the parameter %s_%s times %s, or one "
                                     "name with the subscript %s. Write %s_{%s} %s or %s_{%s}"
                                     % (word, sub, word, sub[:cut] or "?", sub[cut:], sub,
                                        word, sub[:cut] or "?", sub[cut:], word, sub))
            for q, part in enumerate(parts):
                part = _ALIASES.get(part, part)
                toks.append(_Tok("NAME", part, _sub_units(sub) if (sub is not None and q == len(parts) - 1)
                                 else None, pos=i))
            continue
        if ch == "'":
            j = i
            while j < n and (s[j] == "'" or (s[j] == " " and j + 1 < n and s[j + 1] == "'")):
                j += 1
            cnt = s[i:j].count("'")
            if strict:
                raise ValueError("unsupported: primes are not allowed in a jet expression")
            toks.append(_Tok("PRIME", cnt, pos=i))
            i = j
            continue
        if s.startswith("**", i):
            toks.append(_Tok("POW", "**", pos=i))
            i += 2
            continue
        if ch == "^":
            toks.append(_Tok("POW", "^", pos=i))
            i += 1
            continue
        if ch in "+-*/(),={}":
            toks.append(_Tok("OP", ch, pos=i))
            i += 1
            continue
        raise ValueError("unsupported: character %r in the equation" % ch)
    toks.append(_Tok("END", None, pos=n))
    return toks


# ----------------------------------------------------------------------------------------- AST
# nodes: ('num', text) ('name', base, sub_units|None, primes) ('call', name_node, [args], primes_after)
#        ('group', inner, bracket, primes) ('neg', a) ('add'|'sub'|'mul'|'div', a, b) ('pow', base, exp, style)
class _Parser(object):
    def __init__(self, toks):
        self.toks = toks
        self.i = 0
        self.notes = []            # remarks on how an ambiguous spelling was read

    def text(self, i, j):
        """the tokens i..j-1 spelled out (for messages)"""
        out, prev = [], None
        for t in self.toks[i:j]:
            if t.kind == "END":
                continue
            if t.kind == "NAME":
                word = t.val + ("_" + "".join(t.sub) if t.sub else "")
            elif t.kind == "PRIME":
                word = "'" * t.val
            elif t.kind == "FRAC":
                word = "\\frac"
            else:
                word = str(t.val)
            if out and prev in ("NAME", "NUM", "PRIME") and t.kind in ("NAME", "NUM"):
                out.append(" ")
            out.append(word)
            prev = t.kind
        return "".join(out)

    def peek(self):
        return self.toks[self.i]

    def next(self):
        t = self.toks[self.i]
        self.i += 1
        return t

    def is_op(self, *vals):
        t = self.peek()
        return t.kind == "OP" and t.val in vals

    def expect(self, val):
        t = self.next()
        if t.kind != "OP" or t.val != val:
            raise ValueError("unsupported: syntax error near position %d (expected '%s')" % (t.pos, val))

    def equation(self):
        sides = [self.expr()]
        while self.is_op("="):
            self.next()
            sides.append(self.expr())
        t = self.peek()
        if t.kind != "END":
            raise ValueError("unsupported: syntax error near position %d" % t.pos)
        return sides

    def expr(self):
        node = self.term()
        while self.is_op("+", "-"):
            op = self.next().val
            rhs = self.term()
            node = ("add" if op == "+" else "sub", node, rhs)
        return node

    def starts_atom(self):
        t = self.peek()
        return t.kind in ("NUM", "NAME", "FRAC") or (t.kind == "OP" and t.val in "({")

    def term(self):
        start = self.i
        node = self.unary()
        div_end = None             # position just after a divisor
        while True:
            if self.is_op("*", "/"):
                op = self.next().val
                rhs = self.unary()
                node = ("mul" if op == "*" else "div", node, rhs)
                div_end = self.i if op == "/" else None
            elif self.starts_atom():
                j = self.i
                rhs = self.power()
                last = self.toks[j - 1]
                if div_end == j and not (last.kind == "OP" and last.val in ")}"):
                    # a/2w: the grammar gives (a/2)*w; say so, because a/(2w) may have been meant.  A divisor
                    # that ends with a bracket, a/(b + 1) w or 5/sqrt(6) w', is delimited by the visitor.
                    self.notes.append("%s was read as (%s)*%s; write brackets if the product is the divisor"
                                      % (self.text(start, self.i), self.text(start, j), self.text(j, self.i)))
                node = ("mul", node, rhs)
                div_end = None
            else:
                return node

    def unary(self):
        if self.is_op("+"):
            self.next()
            return self.unary()
        if self.is_op("-"):
            self.next()
            return ("neg", self.unary())
        return self.power()

    def power(self):
        base = self.postfix()
        if self.peek().kind == "POW":
            style = self.next().val
            exp = self.exponent()
            if base[0] == "call" and base[1][1] not in _FUNCS and base[1][1] not in _DIFF \
                    and len(base[2]) == 1 and base[3] == 0:
                # a (w')^2 is a*((w')^2); w(z)^2 is (w(z))^2 -- decided when the unknown is known
                return ("callpow", base, exp, style)
            return ("pow", base, exp, style)
        return base

    def exponent(self):
        if self.is_op("-"):
            self.next()
            return ("neg", self.exponent())
        if self.is_op("+"):
            self.next()
            return self.exponent()
        base = self.postfix(in_exponent=True)
        if self.peek().kind == "POW":
            style = self.next().val
            return ("pow", base, self.exponent(), style)
        return base

    def primes(self):
        cnt = 0
        while self.peek().kind == "PRIME":
            cnt += self.next().val
        return cnt

    def postfix(self, in_exponent=False):
        t = self.peek()
        if t.kind == "NUM":
            self.next()
            return ("num", t.val)
        if t.kind == "FRAC":
            self.next()
            a = self.brace_group()
            b = self.brace_group()
            return ("group", ("div", a, b), "(", self.primes())
        if t.kind == "NAME":
            self.next()
            node = ("name", t.val, t.sub, self.primes())
            if self.is_op("(") and not in_exponent:
                self.next()
                args = [self.expr()]
                while self.is_op(","):
                    self.next()
                    args.append(self.expr())
                self.expect(")")
                return ("call", node, args, self.primes())
            if t.val in _FUNCS and t.sub is None and node[3] == 0 and self.is_op("{") and not in_exponent:
                # LaTeX: \sqrt{w}, \exp{w}
                self.next()
                args = [self.expr()]
                self.expect("}")
                return ("call", node, args, self.primes())
            return node
        if t.kind == "OP" and t.val in "({":
            self.next()
            close = ")" if t.val == "(" else "}"
            inner = self.expr()
            items = [inner]
            while self.is_op(","):
                self.next()
                items.append(self.expr())
            self.expect(close)
            if len(items) > 1:
                return ("tuple", items)
            return ("group", inner, t.val, self.primes())
        raise ValueError("unsupported: syntax error near position %d" % t.pos)

    def brace_group(self):
        if self.is_op("{"):
            self.next()
            inner = self.expr()
            self.expect("}")
            return inner
        t = self.peek()
        if t.kind == "NUM":
            self.next()
            return ("num", t.val)
        if t.kind == "NAME":
            self.next()
            return ("name", t.val, t.sub, 0)
        raise ValueError("unsupported: \\frac needs two groups in braces")


def _walk(node):
    yield node
    kind = node[0]
    if kind in ("add", "sub", "mul", "div"):
        for c in node[1:3]:
            for x in _walk(c):
                yield x
    elif kind == "neg":
        for x in _walk(node[1]):
            yield x
    elif kind in ("pow", "callpow"):
        for c in node[1:3]:
            for x in _walk(c):
                yield x
    elif kind == "group":
        for x in _walk(node[1]):
            yield x
    elif kind == "tuple":
        for c in node[1]:
            for x in _walk(c):
                yield x
    elif kind == "call":
        for x in _walk(node[1]):
            yield x
        for c in node[2]:
            for x in _walk(c):
                yield x


def _roman_names(node):
    """(word, names) if the node spells a word with names: one name (iv) or, after the splitting of words, a
    product of one-letter names (i*v); None otherwise"""
    if node[0] == "name" and node[2] is None and node[3] == 0:
        return node[1], [node[1]]
    if node[0] == "mul":
        a, b = _roman_names(node[1]), _roman_names(node[2])
        if a and b:
            return a[0] + b[0], a[1] + b[1]
    return None


def _paren_int(node):
    """(n, braced, names).  n: the integer if node is '(n)' or '{(n)}' with digits or with a roman numeral
    ii ... ix (a derivative order), else None; braced: True for the braced form; names: the names that spell
    the roman numeral (None for digits)"""
    braced = False
    if node[0] == "group" and node[2] == "{" and node[3] == 0:
        node = node[1]
        braced = True
        rn = _roman_names(node)                    # y^{IV}, y^{iv}
        if rn and (rn[0].islower() or rn[0].isupper()) and rn[0].lower() in _ROMAN_OK:
            return _ROMAN[rn[0].lower()], braced, rn[1]
    if node[0] == "group" and node[2] == "(" and node[3] == 0:
        inner = node[1]
        if inner[0] == "num" and re.match(r"^\d{1,9}$", inner[1]):
            return int(inner[1]), braced, None
        rn = _roman_names(inner)
        if rn and (rn[0].islower() or rn[0].isupper()) and rn[0].lower() in _ROMAN_OK:
            return _ROMAN[rn[0].lower()], braced, rn[1]
    return None, braced, None


def _show(node):
    """the syntax tree spelled out (for messages)"""
    k = node[0]
    if k == "num":
        return node[1]
    if k == "name":
        return _full_name(node[1], node[2]) + "'" * node[3]
    if k == "neg":
        return "-" + _show(node[1])
    if k in ("add", "sub", "mul", "div"):
        return _show(node[1]) + {"add": " + ", "sub": " - ", "mul": "*", "div": "/"}[k] + _show(node[2])
    if k == "group":
        return "(" + _show(node[1]) + ")" + "'" * node[3]
    if k == "tuple":
        return "(" + ", ".join(_show(x) for x in node[1]) + ")"
    if k in ("pow", "callpow"):
        return _show(node[1]) + "^" + _show(node[2])
    if k == "call":
        return _show(node[1]) + "(" + ", ".join(_show(a) for a in node[2]) + ")" + "'" * node[3]
    return "?"


def _remark(node):
    """the words of a bracket that contains nothing but names written side by side, at least one of which is
    a word (three or more letters, not Greek, not a letter with digits): '(Weierstrass)', '(a constant)'.
    Such a bracket is a remark in words, not a factor of the equation.  None otherwise."""
    rn = _roman_names(node)
    if rn is None:
        return None
    names = rn[1]
    if any(len(nm) >= 3 and nm.isalpha() and not _PLAIN_NAME.match(nm) and _func_name(nm) is None
           for nm in names):
        return names
    return None


def _full_name(base, sub):
    return base if not sub else base + "_" + "".join(sub)


def _func_name(word):
    """the function name that `word` denotes (sin for sin, Sin, SIN), or None"""
    if word in _FUNCS:
        return word
    low = word.lower()
    if low in _STRICT_FUNCS and (word[1:] == low[1:] or word.isupper()):
        return low
    return None


def _is_var_sub(sub):
    return bool(sub) and len(set(sub)) == 1 and sub[0] in _VAR_LETTERS


class _Reader(object):
    """interprets the syntax tree: finds the unknown, the independent variable, the mode (jets or
    derivatives) and builds the SymPy expression"""

    def __init__(self, sides, unknown=None, var=None, strict=False, e_is_parameter=True):
        self.e_is_parameter = e_is_parameter
        self.sides = sides
        self.unknown_arg = unknown
        self.var_arg = var
        self.strict = strict
        self.warnings = []
        self.jet_letter = None
        self.unknown = None
        self.var = var
        self.var_explicit = var is not None
        self.max_jet = -1
        self.renamed = {}
        self.count = {}            # occurrences of every name
        self.roman_uses = {}       # (base, name) -> occurrences of the name inside base^(roman numeral)
        self.cleared = []          # factors with the unknown by which the equation was multiplied
        self.divisors = []         # every divisor typed that contains the unknown

    def warn(self, msg):
        if msg not in self.warnings:
            self.warnings.append(msg)

    # ---------------------------------------------------------------- detection
    def detect(self):
        strong, subs, calls, calls_any, jets, bare = {}, {}, {}, {}, {}, set()
        var_seen = set()
        count, roman_uses = {}, {}
        for side in self.sides:
            for node in _walk(side):
                kind = node[0]
                if kind == "name":
                    base, sub, primes = node[1], node[2], node[3]
                    full = _full_name(base, sub)
                    bare.add(full)
                    count[full] = count.get(full, 0) + 1
                    if primes:
                        strong[base if _is_var_sub(sub) else full] = True
                    if _is_var_sub(sub):
                        subs.setdefault(base, set()).add(sub[0])
                    m = _JETNAME.match(base) if not sub else None
                    if m:
                        jets.setdefault(m.group(1), set()).add(int(m.group(2)))
                elif kind == "call":
                    head = node[1]
                    if head[1] in _DIFF and head[2] is None and head[3] == 0:
                        tgt = node[2][0]
                        if tgt[0] == "call":
                            tgt = tgt[1]
                        if tgt[0] == "name":
                            strong[_full_name(tgt[1], tgt[2])] = True
                        elif tgt[0] != "name":
                            strong.setdefault(None, True)
                        for a in node[2][1:]:
                            items = a[1] if a[0] == "tuple" else [a]
                            for it in items:
                                if it[0] == "name" and it[3] == 0:
                                    var_seen.add(_full_name(it[1], it[2]))
                    elif head[1] not in _FUNCS and len(node[2]) == 1:
                        a = node[2][0]
                        hname = _full_name(head[1], head[2] if not _is_var_sub(head[2]) else None)
                        if a[0] == "name" and a[2] is None and a[3] == 0:
                            d_ = calls_any.setdefault(hname, {})
                            d_[a[1]] = d_.get(a[1], 0) + 1
                            if a[1] in _VAR_LETTERS:
                                calls.setdefault(hname, set()).add(a[1])
                        if node[3]:
                            strong[_full_name(head[1], head[2])] = True
                elif kind == "pow":
                    b = node[1]
                    n, braced, rnames = _paren_int(node[2])
                    if n is not None and b[0] == "name" and b[3] == 0 and (braced or node[3] == "^"):
                        strong.setdefault(_full_name(b[1], b[2]), "weak" if not braced else True)
                        for nm in rnames or []:
                            key = (_full_name(b[1], b[2]), nm)
                            roman_uses[key] = roman_uses.get(key, 0) + 1
                elif kind == "group" and node[3]:
                    strong.setdefault(None, True)
        self.count, self.roman_uses = count, roman_uses
        self.other_deriv = any(v is True for v in strong.values())    # primes, subscripts, diff, w^{(n)}
        self.uses_primes = any(n_[0] == "name" and n_[3] or n_[0] == "group" and n_[3] or n_[0] == "call" and n_[3]
                               for side in self.sides for n_ in _walk(side))
        self.uses_diff = any(n_[0] == "call" and n_[1][1] in _DIFF for side in self.sides for n_ in _walk(side))
        strong_names = [k for k in strong if k is not None]
        U = self.unknown_arg
        if U is not None:
            U = _ALIASES.get(_GREEK.get(U, U), _GREEK.get(U, U))
        if U is None:
            real = [k for k in strong_names if strong[k] is True]
            cands = real or strong_names
            if len(set(cands)) == 1:
                U = cands[0]
            elif len(set(cands)) > 1:
                single = [c for c in set(cands) if len(c) == 1]
                if len(single) == 1 and all(c.endswith(single[0]) for c in set(cands)):
                    raise _Retry(single[0])
                raise ValueError("ambiguous: derivatives of several names occur (%s); the equation must "
                                 "contain one unknown function, every other name is a constant"
                                 % ", ".join(sorted(set(cands))))
            elif subs:
                cs = sorted(subs)
                if len(cs) == 1:
                    U = cs[0]
                else:
                    pref = [c for c in cs if subs[c] & {"z", "x", "xi", "t"}]
                    if len(pref) == 1:
                        U = pref[0]
                    else:
                        raise ValueError("ambiguous: several names carry subscripts (%s), so the unknown "
                                         "function cannot be identified; write its derivatives with primes"
                                         % ", ".join(cs))
            elif calls and len(calls) == 1:
                U = list(calls)[0]
        has_deriv_notation = bool(strong) or (U is not None and U in subs)
        # jets
        if not has_deriv_notation:
            letter = None
            if U is not None and U in jets and U not in bare:
                letter = U
            elif U is None or U not in bare:
                if "w" in jets and "w" not in bare:
                    letter = "w"
                elif "x" in jets and "x" not in bare:
                    letter = "x"
                else:
                    others = [c for c in ("u", "v", "y", "f", "g") if c in jets and c not in bare]
                    if len(others) == 1 and U is None:
                        letter = others[0]
            if letter is not None and (U is None or U == letter or U not in bare):
                self.jet_letter = letter
                if U is None:
                    U = "w" if letter == "x" else letter
        if U is None:
            names = sorted(bare)
            if "w" in bare:
                U = "w"
            elif len(names) == 1:
                U = names[0]
            else:
                raise ValueError("ambiguous: no derivative was found, so the unknown function cannot be "
                                 "identified (names that occur: %s); write its derivatives with primes, for "
                                 "example w'' = 6 w^2" % ", ".join(names))
        self.unknown = U
        # independent variable
        vs = set(var_seen)
        if U in subs:
            vs |= subs[U]
        if U in calls:
            vs |= calls[U]
        if not vs and self.var_arg is None:
            extra = [nm for nm in calls_any.get(U, {}) if nm not in _VAR_LETTERS]
            if len(extra) == 1 and count.get(extra[0], 0) == calls_any[U][extra[0]] == count.get(U, 0):
                # every occurrence of the unknown carries this argument, and the name occurs nowhere else:
                # f''(q) = f(q)^2.  (w'' = 6 w^2 + w(a) is not of this kind: w(a) is a value at a point.)
                vs = {extra[0]}
                self.warn("%s was read as the independent variable" % extra[0])
        if self.var_arg is not None:
            v = _ALIASES.get(_GREEK.get(self.var_arg, self.var_arg), _GREEK.get(self.var_arg, self.var_arg))
            if vs - {v}:
                raise ValueError("unsupported: derivatives with respect to %s occur, but the independent "
                                 "variable is %s" % (", ".join(sorted(vs - {v})), v))
            self.var = v
        elif len(vs) == 1:
            self.var = list(vs)[0]
            self.var_explicit = True
        elif len(vs) > 1:
            raise ValueError("unsupported: derivatives with respect to several variables (%s): this is a "
                             "partial differential equation; it is read by the reader of partial differential "
                             "equations, not by the reader of ordinary ones" % ", ".join(sorted(vs)))
        else:
            self.var = "z"
        self.subs_bases = subs

    # ---------------------------------------------------------------- evaluation
    def jetsym(self, j):
        if j > MAX_ORDER:
            raise ValueError(_ORDER_MSG % j)
        self.max_jet = max(self.max_jet, j)
        return sp.Symbol("w%d" % j)

    def param(self, name):
        if name == self.var or (not self.var_explicit and name in ("z", "x", "t")):
            raise ValueError("unsupported: the equation is not autonomous (the independent variable %s "
                             "occurs explicitly); if %s is a parameter, rename it" % (name, name))
        if _func_name(name) in _STRICT_FUNCS:
            raise ValueError("unsupported: the function name %s is not followed by a bracket (read: %s with "
                             "no argument); it is not taken for a parameter. An equation with %s of the "
                             "unknown is not polynomial, and the site treats polynomial equations"
                             % (name, name, name))
        if name in ("I", "i"):
            self.warn("%s was read as the imaginary unit" % name)
            return sp.I
        if name == "pi":
            raise ValueError("unsupported: the transcendental constant pi; use a parameter for it")
        if name == "e":
            if not self.e_is_parameter:
                raise ValueError("unsupported: the transcendental constant e; use another letter if a "
                                 "parameter is meant")
            self.warn("e was read as a parameter (not as the base of the natural logarithm)")
        new = name
        why = "the name is used by the engine"
        if name in _RESERVED:
            new = _RESERVED[name]
            why = "the name is a keyword of the programming language or a function name of the engine"
        elif re.match(r"^w\d+$", name):
            new = "w_" + name[1:]
        elif name == "z":
            new = "zpar"
        U = self.unknown or ""
        if new != name:
            while new in self.count and new not in self.renamed.values():
                new += "_"               # the equation already has a parameter with the new name
            self.renamed[name] = new
            self.warn("the parameter %s was renamed %s (%s)" % (name, new, why))
        elif not _PLAIN_NAME.match(name):
            self.warn("read as a parameter: %s" % name)
        if U and name != U and name.lower() == U.lower():
            self.warn("read as a parameter: %s (it differs from the unknown %s by the case of the letter)" % (name, U))
        elif U and self.jet_letter is None and re.match(r"^%s\d+$" % re.escape(U), name):
            digits = name[len(U):]
            self.warn("read as a parameter: %s (a constant, not a power or a derivative of %s%s)"
                      % (name, U, "; a power is written %s^%s" % (U, digits) if int(digits) >= 2 else ""))
        return sp.Symbol(new)

    def name_value(self, node):
        base, sub, primes = node[1], node[2], node[3]
        U = self.unknown
        if self.jet_letter is not None and not sub:
            m = _JETNAME.match(base)
            if m and m.group(1) == self.jet_letter:
                return self.jetsym(int(m.group(2)) + primes)
        if base == U and (not sub or _is_var_sub(sub)):
            order = primes + (len(sub) if sub else 0)
            return self.jetsym(order)
        full = _full_name(base, sub)
        if full == U:
            return self.jetsym(primes)
        if primes:
            raise ValueError("unsupported: a derivative of %s occurs, but the unknown is %s (one unknown "
                             "only; parameters are constants)" % (full, U))
        if _is_var_sub(sub):
            # v_y, c_s next to the unknown u: a parameter, but it looks like a derivative of a second function
            self.warn("read as a parameter: %s (a subscript is a derivative only on the unknown %s)" % (full, U))
        elif sub and base == U:
            self.warn("read as a parameter: %s (a constant, not a derivative of %s)" % (full, U))
        return self.param(full)

    def number(self, text):
        short = text if len(text) <= 24 else text[:21] + "..."
        if re.match(r"^\d+$", text):
            if len(text) > 60:
                raise ValueError("unsupported: the number %s has more than 60 digits" % short)
            return sp.Integer(text)
        m = _NUMBER.match(text)
        mant, expo = m.group(1), m.group(2)
        if len(mant) > 62 or (expo and (len(expo) > 5 or abs(int(expo[1:])) > 60)):
            raise ValueError("unsupported: the number %s is too long or too large for exact arithmetic" % short)
        val = sp.Rational(text)
        self.warn("the decimal %s was read as the exact rational number %s" % (text, val))
        return val

    def has_unknown(self, expr):
        return any(re.match(r"^w\d+$", s.name) for s in expr.free_symbols)

    def ev(self, node):
        kind = node[0]
        if kind == "num":
            return self.number(node[1])
        if kind == "name":
            return self.name_value(node)
        if kind == "neg":
            return -self.ev(node[1])
        if kind == "add":
            return self.ev(node[1]) + self.ev(node[2])
        if kind == "sub":
            return self.ev(node[1]) - self.ev(node[2])
        if kind == "mul":
            return self.ev(node[1]) * self.ev(node[2])
        if kind == "div":
            den = self.ev(node[2])
            if den == 0:
                raise ValueError("unsupported: division by zero")
            if self.has_unknown(den):
                self.divisors.append(den)
            return self.ev(node[1]) / den
        if kind == "group":
            self.no_remark(node[1])
            val = self.ev(node[1])
            if node[3]:
                val = self.derivative(val, node[3])
            return val
        if kind == "tuple":
            raise ValueError("unsupported: a list of expressions where one expression is expected")
        if kind == "pow":
            return self.power(node)
        if kind == "call":
            return self.call(node)
        if kind == "callpow":
            call, e, style = node[1], node[2], node[3]
            if self.is_function_value(call) or (_func_name(call[1][1]) is not None and call[1][2] is None
                                                and call[1][3] == 0):
                return self.power(("pow", call, e, style))
            return self.bracket_product(call, (e, style))
        raise ValueError("unsupported: syntax")

    def no_remark(self, inner):
        words = _remark(inner)
        if words and (self.unknown in words or (self.jet_letter is not None
                                                and any(_JETNAME.match(w_) for w_ in words))):
            return                 # (cap w): the unknown is inside, so it is a factor, not a remark
        if words:
            raise ValueError("unsupported: the bracket (%s) looks like a remark in words, not a part of the "
                             "equation; type the equation alone (a product is written with *)" % " ".join(words))

    def is_function_value(self, node):
        """True if the call node is the unknown written as a function of the independent variable"""
        head, args = node[1], node[2]
        full = _full_name(head[1], head[2])
        is_unknown = (full == self.unknown) or (head[1] == self.unknown and _is_var_sub(head[2]))
        if is_unknown and len(args) == 1:
            a = args[0]
            return a[0] == "name" and a[2] is None and a[3] == 0 and a[1] == self.var
        return False

    def derivative(self, val, n):
        if n > MAX_ORDER:
            raise ValueError(_ORDER_MSG % n)
        num, den = sp.fraction(sp.together(val))
        if self.has_unknown(den):
            raise ValueError("unsupported: derivative of an expression that is rational in the unknown")
        res = total_derivative(sp.expand(val), n)
        for s_ in res.free_symbols:
            m = re.match(r"^w(\d+)$", s_.name)
            if m and int(m.group(1)) > MAX_ORDER:
                raise ValueError(_ORDER_MSG % m.group(1))
        return res

    def power(self, node):
        b, e, style = node[1], node[2], node[3]
        n, braced, rnames = _paren_int(e)
        if n is not None and b[0] == "name" and b[3] == 0 and (braced or style == "^"):
            full = _full_name(b[1], b[2])
            if full == self.unknown or (b[1] == self.unknown and _is_var_sub(b[2])):
                if rnames:
                    # a roman numeral is a derivative order only if its letters are not names of the equation
                    word = "".join(rnames)
                    for nm in sorted(set(rnames)):
                        if nm != self.unknown and self.count.get(nm, 0) > self.roman_uses.get((full, nm), 0):
                            raise ValueError("unsupported: the exponent (%s) of %s is not a number: the name "
                                             "%s occurs elsewhere in the equation, so it was not read as a "
                                             "roman numeral. For the derivative of order %d write %s^(%d)"
                                             % (word, full, nm, n, full, n))
                    self.warn("%s^(%s) was read as the derivative of order %d" % (full, word, n))
                elif not braced:
                    if n <= 3 and (getattr(self, "other_deriv", False) or self.unknown in self.subs_bases):
                        # the equation writes derivatives with primes (or subscripts): w^(2) is the square
                        self.warn("%s^(%d) was read as the power %s^%d, because this equation writes its "
                                  "derivatives in another way; for the derivative of order %d use primes"
                                  % (full, n, full, n, n))
                        return self.ev(b) ** n
                    self.warn("%s^(%d) was read as the derivative of order %d; write %s^%d for the power"
                              % (full, n, n, full, n))
                return self.jetsym(n + (len(b[2]) if b[2] and full != self.unknown else 0))
        base = self.ev(b)
        ex = self.ev(e)
        if not ex.is_number:
            raise ValueError("unsupported: the exponent %s is not a number; substitute a value" % ex)
        if not ex.is_Rational:
            raise ValueError("unsupported: the exponent %s is not a rational number" % ex)
        if ex.is_Integer:
            if ex < 0 and base == 0:
                raise ValueError("unsupported: division by zero")
            if abs(ex) > 60:
                raise ValueError("unsupported: the exponent %s is too large" % ex)
            if ex < 0 and self.has_unknown(base):
                self.divisors.append(base)
            return base ** ex
        if self.has_unknown(base):
            raise ValueError("unsupported: fractional power of the unknown (exponent %s): the equation is "
                             "not polynomial" % ex)
        if base.free_symbols:
            raise ValueError("unsupported: fractional power (%s)**(%s) of an expression that contains a "
                             "parameter; introduce a parameter for it" % (base, ex))
        if base == 0 and ex < 0:
            raise ValueError("unsupported: division by zero")
        return base ** ex              # an algebraic number, kept exactly

    def call(self, node):
        head, args, primes_after = node[1], node[2], node[3]
        fname = head[1]
        plain = head[2] is None and head[3] == 0
        if fname in _DIFF and plain:
            target = self.ev(args[0])
            order = 0
            last = None
            flat = []
            for a in args[1:]:
                flat.extend(a[1] if a[0] == "tuple" else [a])
            for a in flat:
                if a[0] == "num" and re.match(r"^\d+$", a[1]):
                    if last is None:
                        raise ValueError("unsupported: diff(expr, variable, n) expected")
                    if len(a[1]) > 4:
                        raise ValueError(_ORDER_MSG % a[1][:12])
                    order += int(a[1]) - 1
                elif a[0] == "name" and a[3] == 0:
                    nm = _full_name(a[1], a[2])
                    if nm != self.var:
                        raise ValueError("unsupported: derivative with respect to %s (the independent "
                                         "variable is %s)" % (nm, self.var))
                    last = nm
                    order += 1
                else:
                    raise ValueError("unsupported: arguments of diff")
            if not flat:
                order = 1
            val = self.derivative(target, order)
            return self.derivative(val, primes_after) if primes_after else val
        if _func_name(fname) is not None and plain:
            fname = _func_name(fname)
            vals = [self.ev(a) for a in args]
            if any(self.has_unknown(v) for v in vals):
                raise ValueError("unsupported: %s of the unknown; the equation must be a polynomial in the "
                                 "unknown and its derivatives" % fname)
            if fname in ("sqrt", "cbrt") and len(vals) == 1 and not vals[0].free_symbols:
                val = sp.sqrt(vals[0]) if fname == "sqrt" else sp.cbrt(vals[0])
                return self.derivative(val, primes_after) if primes_after else val
            if all(not v.free_symbols for v in vals):
                raise ValueError("unsupported: the constant %s(%s) is not an algebraic number written with "
                                 "roots; use a parameter for it" % (fname, ", ".join(str(v) for v in vals)))
            raise ValueError("unsupported: %s of a parameter; introduce a new parameter for it" % fname)
        # the unknown as a function of the independent variable:  w(z), w'(z), w_zz(z), w(z)'
        if self.is_function_value(node):
            full = _full_name(head[1], head[2])
            order = head[3] + primes_after + (len(head[2]) if head[2] and full != self.unknown else 0)
            return self.jetsym(order)
        return self.bracket_product(node, None)

    def bracket_product(self, node, power):
        """NAME(...) that is neither a known function nor the unknown at the independent variable.

        * the unknown in front:  w(1 - w) is the product (no remark);  w(a + 1): product, with a warning;
          w(0), w'(0), w(a): a value at a point -- refused (initial values are not part of the equation);
        * another name in front:  F(w), g(w'), a(w')^2 (the bracket contains the unknown) is an unspecified
          function of the unknown -- refused;  a(b + 1): product, with a warning.
        power: None, or (exponent node, style) for NAME(...)^e, where the power belongs to the bracket."""
        head, args, primes_after = node[1], node[2], node[3]
        hname = _show(head)
        shown = _show(node) + ("^" + _show(power[0]) if power else "")
        hval = self.ev(head)
        unknown_head = self.has_unknown(hval)
        if len(args) != 1:
            raise ValueError("unsupported: %s is read as a function %s of several arguments; the site treats "
                             "polynomial equations in one unknown function" % (_show(node), hname))
        arg = args[0]
        self.no_remark(arg)
        aval = self.ev(arg)
        with_unknown = self.has_unknown(aval)
        product = "%s*(%s)%s" % (hname, _show(arg), ("^" + _show(power[0])) if power else "")
        if primes_after:
            raise ValueError("unsupported: a prime after %s(...)" % hname)
        if unknown_head:
            if not aval.free_symbols:
                raise ValueError("unsupported: %s is a value of the unknown at a point; initial and boundary "
                                 "values are not part of the equation -- type the equation alone (for the "
                                 "product write %s)" % (_show(node), product))
            if arg[0] == "name" and arg[3] == 0 and not with_unknown:
                raise ValueError("unsupported: %s reads as the unknown at the point %s; values at a point "
                                 "are not part of the equation -- type the equation alone (for the product "
                                 "write %s*%s)" % (_show(node), _show(arg), hname, _show(arg)))
            if not with_unknown:
                self.warn("%s was read as the product %s" % (shown, product))
        else:
            if with_unknown and aval.is_Symbol:
                # F(w), g(w'), f(u)^2: the bracket holds exactly the unknown or one derivative
                raise ValueError("unsupported: %s is read as an unspecified function %s of the unknown, and "
                                 "the site treats polynomial equations only; if the product is meant, write %s"
                                 % (_show(node), hname, product))
            self.warn("%s was read as the product %s" % (shown, product))
        if power is not None:
            aval = self.power(("pow", ("group", arg, "(", 0), power[0], power[1]))
        return hval * aval

    def build(self):
        self.detect()
        vals = [self.ev(s) for s in self.sides]
        if len(vals) > 2:
            raise ValueError("unsupported: more than one '=' sign: several equations (a system) or a chain of "
                             "equalities; the site reads one equation at a time")
        expr = vals[0] - vals[1] if len(vals) == 2 else vals[0]
        return expr


class _Retry(Exception):
    def __init__(self, unknown):
        Exception.__init__(self, unknown)
        self.unknown = unknown


def _clean_fraction(expr, reader, allow_rational):
    """E as a polynomial in the jets: multiply out a denominator that contains the unknown.

    reader.cleared receives the irreducible factors, containing the unknown, of every divisor that was typed
    (reader.divisors) -- those that are multiplied out and those that cancel against a numerator: where one of
    them vanishes the typed equation is not defined, so a function on which it vanishes identically is not a
    solution of the typed equation even if it solves E = 0."""
    jets = set(s for s in expr.free_symbols if re.match(r"^w\d+$", s.name))
    for d_ in reader.divisors:
        jets |= set(s for s in d_.free_symbols if re.match(r"^w\d+$", s.name))

    def jet_factors(d_):
        out = []
        for part in sp.fraction(sp.together(d_)):
            try:
                out += [f for f, _ in sp.factor_list(part)[1] if f.free_symbols & jets]
            except Exception:
                if part.free_symbols & jets:
                    out.append(part)
        return out
    typed = []
    for d_ in reader.divisors:
        for f in jet_factors(d_):
            if f.could_extract_minus_sign():
                f = -f
            if str(f) not in typed:
                typed.append(str(f))
    expr = sp.together(expr)
    num, den = sp.fraction(expr)
    if typed or (den.free_symbols & jets):
        if not allow_rational:
            raise ValueError("unsupported: the unknown occurs in a denominator")
        num, den = sp.fraction(sp.cancel(expr))
        kept = []
        if den.free_symbols & jets:
            # keep the part of the denominator that is free of the unknown as a coefficient
            const, rest = sp.factor(den).as_independent(*jets, as_Add=False)
            reader.warnings.append("the equation is rational in the unknown: it was multiplied by %s; "
                                   "a function on which this factor vanishes identically is not a solution "
                                   "of the original equation" % rest)
            for f in jet_factors(rest):
                if f.could_extract_minus_sign():
                    f = -f
                kept.append(str(f))
            result = num / const
        else:
            result = num / den
        gone = [f for f in typed if f not in kept]
        if gone:
            reader.warnings.append("the divisor%s %s cancelled against a numerator; a function on which %s "
                                   "vanishes identically is not a solution of the original equation"
                                   % ("s" if len(gone) > 1 else "", ", ".join(gone),
                                      "one of them" if len(gone) > 1 else "it"))
        reader.cleared = kept + gone
        return result
    return expr


def _jet_notation(toks, unknown):
    """True if the text uses jets (w0, w1, ...) and no other derivative notation: then words are identifiers"""
    words = set()
    for q, t in enumerate(toks):
        if t.kind == "PRIME":
            return False
        if t.kind == "NAME":
            if t.val in _DIFF:
                return False
            if t.sub is not None and _is_var_sub(t.sub):
                return False
            words.add(t.val)
            nxt = toks[q + 1:q + 5]
            if len(nxt) >= 4 and nxt[0].kind == "POW" and nxt[0].val == "^" and nxt[1].kind == "OP" \
                    and nxt[1].val == "(" and nxt[2].kind == "NUM" and nxt[3].kind == "OP" and nxt[3].val == ")":
                return False
    fam = {}
    for wd in words:
        m = _JETNAME.match(wd)
        if m:
            fam.setdefault(m.group(1), set()).add(int(m.group(2)))
    cands = [unknown] if unknown else []
    cands += ["w", "x"]
    for c in cands:
        if c in fam and c not in words:
            return True
    others = [c for c in ("u", "v", "y", "f", "g") if c in fam and c not in words]
    return len(others) == 1 and unknown is None


def _strip_leading_words(text):
    """drop words such as 'solve', 'find', 'the equation', 'ODE:' in front of the equation; returns the rest
    and the words dropped"""
    words = []
    for _ in range(4):
        m = _LEAD_RE.match(text)
        if not m or m.group(1).lower() not in _LEAD_WORDS:
            break
        rest = text[m.end():]
        if not rest.strip() or rest.lstrip()[0] in "=*/^,)":
            break                      # the word is an operand of the equation, not a remark
        words.append(m.group(1))
        text = rest
    return text, words


def _split_top(t, seps):
    """split at the separators that are outside every bracket"""
    depth, parts, last = 0, [], 0
    for i, ch in enumerate(t):
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth = max(0, depth - 1)
        elif ch in seps and depth == 0:
            parts.append(t[last:i])
            last = i + 1
    parts.append(t[last:])
    return parts


_EQUATION_TAGS = {"KdV", "mKdV", "NLS", "KPP", "KS", "KP", "BBM", "ODE", "PDE", "sG", "SG", "FKPP", "KdVB"}
_LETTER_LABEL_START = re.compile(r"^\s*[(\[]\s*([A-Za-z]|i{2,3}|iv|vi{0,3}|ix)\s*[)\]](?=\s+[A-Za-z0-9\\+-])")
_LETTER_LABEL_END = re.compile(r"(?<![-+*/^=,(\[{\s])\s+[(\[]\s*([A-Za-z]|i{2,3}|iv|vi{0,3}|ix)\s*[)\]]\s*$")


def _is_symbol_of(content, rest):
    """True if the label text is a name that occurs in the rest of the input (then it is a factor)"""
    return bool(content[:1].isalpha()
                and re.search(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(content), rest))


def _label_start(t, notes):
    r"""An equation number at the very beginning: (2), (2.3), (2a), (P1), (*), [3] -- a label only if it
    stands alone: a space after it, and then a term of the equation (possibly with a sign).  Directly
    followed by anything, '(2)(w')^2' or '(2)w', it is a number; before '*', '/', '^', '=' it is an operand;
    before another bracket it cannot be told from a factor: refused."""
    m0 = re.match(r"^\s*(\d+(?:\.\d+)*[a-z]?)\)\s+(?=[A-Za-z0-9\\(+-])", t)
    if m0 and t.count("(") < t.count(")"):
        # "1) w'' = w^2": a number with a closing bracket in front
        notes.append("the label %s) was not read as part of the equation" % m0.group(1))
        return t[m0.end():]
    m = _LABEL_START.match(t)
    if not m:
        m = _LETTER_LABEL_START.match(t)
        if m and not re.search(r"(?<![A-Za-z])%s(?![A-Za-z])" % re.escape(m.group(1)), t[m.end():]):
            # (a) w'' = ..., (ii) w'' = ...: a letter that occurs nowhere else -- a label or a factor?
            raise ValueError("unsupported: the bracket (%s) at the beginning can be a label or the factor %s; "
                             "remove the label, or write %s*... for the factor" % (m.group(1), m.group(1), m.group(1)))
        return t
    content, rest = m.group(1), t[m.end():]
    if not rest or not rest[0].isspace():
        return t
    nxt = rest.lstrip()[:1]
    if nxt == "" or nxt in "*/^=," or _is_symbol_of(content, rest):
        return t
    if nxt in "([{":
        raise ValueError("unsupported: the bracket (%s) at the beginning can be an equation number or a factor "
                         "of the bracket that follows; remove the label, or write %s*(...) for the factor"
                         % (content, content))
    notes.append("the label (%s) was not read as part of the equation" % content)
    return rest.lstrip()


def _label_end(t, notes):
    """An equation number at the very end, after a space.  After an operator sign, 'w^2 + (1)', it is a
    number; after a round or square bracket it cannot be told from a factor: refused."""
    m = _LABEL_END.search(t)
    if not m:
        m = _LETTER_LABEL_END.search(t)
        if m and not re.search(r"(?<![A-Za-z])%s(?![A-Za-z])" % re.escape(m.group(1)), t[:m.start()]) \
                and t[:m.start()].rstrip()[-1:] not in ")]":
            raise ValueError("unsupported: the bracket (%s) at the end can be a label or the factor %s; "
                             "remove the label, or write ...*%s for the factor" % (m.group(1), m.group(1), m.group(1)))
        return t
    content, before = m.group(1), t[:m.start()].rstrip()
    prev = before[-1:]
    if prev == "" or prev in "+-*/^=,([{" or _is_symbol_of(content, before):
        return t
    if prev in ")]":
        raise ValueError("unsupported: the bracket (%s) at the end can be an equation number or a factor of "
                         "the bracket before it; remove the label, or write (...)*%s for the factor"
                         % (content, content))
    notes.append("the label (%s) was not read as part of the equation" % content)
    return before


def _is_declaration(part):
    """True for 'w = w(z)', 'u = u(x, t)': the statement that the unknown is a function, not an equation"""
    return bool(re.match(r"^\s*([A-Za-z]+)\s*=\s*\1\s*\(\s*[A-Za-z](\s*,\s*[A-Za-z])*\s*\)\s*$", part))


def _prepare(text):
    """What is not part of the equation is taken off the text, each time with a remark:
       a full stop, comma or semicolon at the end;  '..., where a > 0';  leading words ('Solve the equation');
       a label with a colon in front ('KdV: ...', 'Eq. (3): ...');  an equation number in brackets at the very
       beginning or the very end ('(2) w'' = 6w^2', 'w'' = 6w^2 (2.3)', '[3]').
    Refused: several equations (a system typed with commas or semicolons), a decimal comma, a condition with
    '=' after 'where'.  Returns (text, leading words dropped, remarks)."""
    notes = []
    t, tags = _latex_markup(text)                  # \begin{equation}, \label{..}; \tag{..} is a label
    for tag in tags:
        notes.append("the label (%s) was not read as part of the equation" % tag)
    t = _LATEX_SPACING.sub(" ", t)                 # \, \; \quad are spaces, not separators
    m = re.search(r"\s*(#|%|//)(.*)$", t)
    if m and "=" in t[:m.start()]:
        notes.append("the text '%s' after the equation was not read" % t[m.start():].strip())
        t = t[:m.start()]
    t = re.sub(r"[\s.,;]+$", "", t.strip())
    # a remark in words at the very end: (Weierstrass).  A bracket with an operator sign, or with a word that
    # occurs elsewhere in the text (the unknown, a parameter), is never a remark: w (cap - w), a (a constant)
    m = re.search(r"\s+\(\s*([A-Za-z][A-Za-z ]*)\)$", t)
    if m and "=" in t[:m.start()]:
        words = m.group(1).split()
        others = re.findall(r"[A-Za-z]+", t[:m.start()])
        elsewhere = any(w_ == tok or (len(w_) == 1 and len(tok) <= 3 and w_ in tok)
                        for w_ in words for tok in others)
        real = [w_ for w_ in words if len(w_) >= 3 and not _PLAIN_NAME.match(w_) and _func_name(w_) is None]
        # one word alone is a remark only if it looks like a name of a person or of an equation (Weierstrass,
        # Duffing, KdV); '(cap)' or '(Kmax)' after the equation may be a factor: left to the reader, which
        # refuses a bracket of words
        if len(words) == 1 and not (re.match(r"^[A-Z][a-z]{4,}$", words[0]) or words[0] in _EQUATION_TAGS):
            real = []
        if not elsewhere and real:
            notes.append("the remark (%s) at the end was not read as part of the equation" % m.group(1).strip())
            t = re.sub(r"[\s.,;]+$", "", t[:m.start()])
    # a hyphenated name at the very end: (sine-Gordon), (Allen-Cahn), (phi-four).  Each word alphabetic with
    # three letters or more and none of them a name of the text; (a-b), (k-1) stay factors
    m = re.search(r"\s+\(\s*([A-Za-z]{2,}(?:\s*-\s*[A-Za-z]{2,}){1,2})\s*\)$", t)
    if m and "=" in t[:m.start()]:
        words = re.split(r"\s*-\s*", m.group(1))
        others = set(re.findall(r"[A-Za-z]+", t[:m.start()]))
        long_ = [w_ for w_ in words if len(w_) >= 3]
        particles = [w_ for w_ in words if len(w_) < 3]            # Korteweg-de-Vries
        if len(long_) >= 2 and all(w_ in ("de", "du", "la", "le", "di") for w_ in particles) \
                and not any(w_ in others for w_ in words):
            notes.append("the remark (%s) at the end was not read as part of the equation" % m.group(1).strip())
            t = re.sub(r"[\s.,;]+$", "", t[:m.start()])
    m = re.search(r"\d,\d", t)
    if m and not re.search(r"(diff|Derivative)\s*\(", t):
        raise ValueError("unsupported: a comma between digits (%s): write a decimal point, or a fraction"
                         % t[max(0, m.start() - 2):m.end() + 2].strip())
    m = re.search(r"(?:^|[\s,;])where\b(.*)$", t, re.I | re.S)
    if m and "=" in t[:m.start()]:
        if "=" in m.group(1) and not _is_declaration(m.group(1)):
            raise ValueError("unsupported: the text after 'where' contains an equality (%s); put the value into "
                             "the equation and type the equation alone" % m.group(1).strip()[:40])
        notes.append("the text '%s' after the equation was not read" % t[m.start():].strip(" ,;"))
        t = re.sub(r"[\s.,;]+$", "", t[:m.start()])
    # "... with a real", "... for all z": a clause in words after the equation (no operator in it)
    m = re.search(r"\s(with|for|when|if)\s+([^=^*/+']*)$", t)
    if m and "=" in t[:m.start()]:
        notes.append("the text '%s' after the equation was not read" % t[m.start():].strip())
        t = re.sub(r"[\s.,;]+$", "", t[:m.start()])
    t, dropped = _strip_leading_words(t)
    parts = _split_top(t, ",;")
    if len(parts) > 1:
        with_eq = [q for q in parts if "=" in q and not _is_declaration(q)]
        if not with_eq:
            with_eq = [q for q in parts if "=" in q][:1]
        if len(with_eq) > 1:
            raise ValueError("unsupported: %d equations were typed (a system); the site reads one equation at a "
                             "time, for one unknown function" % len(with_eq))
        if len(with_eq) == 1:
            rest = [q.strip() for q in parts if q is not with_eq[0] and q.strip()]
            if rest:
                notes.append("the text %s next to the equation was not read" % ", ".join("'%s'" % q for q in rest))
            t = with_eq[0].strip()
    if t.count(":") == 1:
        a_, b_ = t.split(":")
        if "=" not in a_ and "'" not in a_ and b_.strip():
            if a_.strip():
                notes.append("the label '%s' in front of the equation was not read as part of it" % a_.strip())
            t = b_.strip()
        elif "=" not in b_:
            if b_.strip():
                notes.append("the text '%s' after the equation was not read" % b_.strip())
            t = a_.strip()
    t = _label_start(t, notes)
    t = _label_end(t, notes)
    # LaTeX: an exponent or subscript without braces is one character; the usual reading is kept, with a remark
    if re.search(r"\\[A-Za-z]", t):
        for m in re.finditer(r"([A-Za-z0-9')}]+)\s*\^\s*(\d{2,})", t):
            notes.append("%s^%s was read as %s^(%s) (in LaTeX an exponent without braces is one digit)"
                         % (m.group(1), m.group(2), m.group(1), m.group(2)))
        for m in re.finditer(r"([A-Za-z]+)_(\d{2,})", t):
            notes.append("%s_%s was read as %s_{%s}" % (m.group(1), m.group(2), m.group(1), m.group(2)))
    return t, dropped, notes


def strip_remarks(text):
    """Public form of the clean-up that parse_ode applies before reading (for the PDE reader as well):
    returns (equation text, remarks).  Dropped, each with a remark: leading words ('Solve the equation'),
    a label with a colon ('KdV: ...'), an equation number in brackets at the very beginning or end, a remark
    in words in brackets at the end, '..., where a > 0', '... with a real', '# comment', the declaration
    'u = u(x, t)', a final full stop.  Raises ValueError('unsupported: ...') for a system of equations, a
    decimal comma, or a condition with '=' after 'where'."""
    t, dropped, notes = _prepare(text)
    if dropped:
        notes = ["the word%s %s in front of the equation %s not read as part of it"
                 % ("s" if len(dropped) > 1 else "", ", ".join("'%s'" % w_ for w_ in dropped),
                    "were" if len(dropped) > 1 else "was")] + notes
    return t, notes


def _word_runs(toks, unknown):
    """runs of two or more words written side by side (names of two or more letters that are not the
    unknown, not Greek, not a letter with digits, not a function name): 'all solutions of'"""
    runs, cur = [], []
    for q, t in enumerate(toks):
        nxt = toks[q + 1] if q + 1 < len(toks) else None
        is_word = (t.kind == "NAME" and t.sub is None and t.val != unknown and len(t.val) >= 2
                   and t.val.isalpha() and not _PLAIN_NAME.match(t.val) and _func_name(t.val) is None
                   and t.val not in _DIFF and not (nxt is not None and nxt.kind == "PRIME"))
        if is_word:
            cur.append(t.val)
        else:
            if len(cur) >= 2:
                runs.append(cur)
            cur = []
    if len(cur) >= 2:
        runs.append(cur)
    return runs


def looks_like_pde(text):
    r"""True if the text is written as a partial differential equation: one function carries derivatives with
    respect to two or more independent variables (u_t and u_xx, u_{xt}, \partial_t u, Dx(...),
    \frac{\partial u}{\partial t}), or a modulus |q| occurs (envelope equations).  LaTeX markup is normalised
    first (latex_to_plain).  For the dispatcher: such a text belongs to the PDE reader."""
    if not isinstance(text, str):
        return False
    try:
        plain = latex_to_plain(text)
    except Exception:
        plain = text
    if "|" in plain or "\\partial" in plain or "\\nabla" in plain:
        return True
    per_base = {}
    for m in re.finditer(r"([A-Za-z]+|\))\s*_\s*\{?([A-Za-z]+)\}?", plain):
        units = _sub_units(m.group(2))
        if units and all(u_ in _VAR_LETTERS for u_ in units):
            per_base.setdefault(m.group(1), set()).update(units)
    ops = set()
    for m in re.finditer(r"\bD([xtyzs]+)\s*\(", plain):
        ops.update(m.group(1))
    ops |= per_base.pop(")", set())            # ( ... )_x: a derivative of an expression
    for a_ in list(per_base):                  # Du_xx next to u_t: a coefficient glued to the unknown
        for b_ in list(per_base):
            if a_ != b_ and a_.endswith(b_):
                per_base[b_] = per_base[b_] | per_base[a_]
    return any(len(v | ops) >= 2 for v in per_base.values()) or len(ops) >= 2


def parse_ode(text, unknown=None, var=None, allow_rational=True, name="", e_is_parameter=True):
    """Read an autonomous polynomial ODE.  Returns an Equation (jets w0..wK, E = left side - right side);
    eq.unknown, eq.var are the visitor's letters, eq.warnings the remarks of the parser (how an ambiguous
    spelling was read, what was not read, renamed parameters, decimals), eq.source the text,
    eq.cleared_denominators the factors with the unknown by which the equation was multiplied.

    unknown, var   for programmatic callers: the letters when they cannot be read off
    allow_rational an equation that is rational in the unknown is multiplied by its denominator (a warning is
                   recorded); with False it is rejected
    ValueError('unsupported: ...') or ValueError('ambiguous: ...') if the text is not read; a text that is
    written as a partial differential equation is refused with the sentence that says so.
    See the module text for the rules."""
    try:
        return _parse_ode(text, unknown, var, allow_rational, name, e_is_parameter)
    except ValueError as err:
        if "partial differential equation" not in str(err) and looks_like_pde(text):
            raise ValueError("unsupported: this is a partial differential equation (derivatives with respect "
                             "to several variables, or a modulus |q|); it is read by the reader of partial "
                             "differential equations, not by the reader of ordinary ones")
        raise


def _parse_ode(text, unknown=None, var=None, allow_rational=True, name="", e_is_parameter=True):
    """Read an autonomous polynomial ODE.  Returns an Equation (jets w0..wK, E = left side - right side);
    eq.unknown, eq.var are the visitor's letters, eq.warnings the remarks of the parser (how an ambiguous
    spelling was read, renamed parameters, decimals), eq.source the text, eq.cleared_denominators the factors
    with the unknown by which the equation was multiplied (list of polynomial strings in the jets).

    unknown, var   for programmatic callers: the letters when they cannot be read off
    allow_rational an equation that is rational in the unknown is multiplied by its denominator (a warning is
                   recorded); with False it is rejected
    Algebraic constants (sqrt(6), 2^(1/3), I and combinations) are kept exactly; decimals become rationals
    (warning); pi and functions of numbers other than roots are rejected.  The bare letter e is read as a
    parameter and a warning is recorded (e_is_parameter=False rejects it as the transcendental constant).
    See the module text for the rules on function names, brackets after names and values at a point."""
    if not isinstance(text, str):
        raise ValueError("unsupported: the equation must be given as text")
    source = text
    text, dropped, pre_notes = _prepare(text)
    if unknown is not None:
        unknown = _ALIASES.get(_GREEK.get(unknown, unknown), _GREEK.get(unknown, unknown))
    notes = []
    toks = _tokenise(text, unknown=unknown, split="none", notes=notes)
    if len(toks) == 1:
        raise ValueError("unsupported: empty input")
    U = unknown
    if not _jet_notation(toks, unknown):
        # first pass: every word is split, only to find the unknown
        for _attempt in range(2):
            toks1 = _tokenise(text, unknown=U, split="all")
            reader1 = _Reader(_Parser(toks1).equation(), unknown=U, var=var)
            try:
                reader1.detect()
                U = reader1.unknown
                break
            except _Retry as r:
                if _attempt == 1:
                    raise ValueError("ambiguous: the unknown function cannot be identified; write its "
                                     "derivatives with primes, for example w'' = 6 w^2")
                U = r.unknown
        # two derivative notations in one input are not merged into one variable (\dot{u} = u_{xx} + u^2,
        # u_t = u'' + u - u^3): a dot or a prime does not name its variable, a subscript or d/dz does
        kinds = []
        dots = bool(re.search(r"\\d{1,4}ot(?![A-Za-z])", source))
        if dots:
            kinds.append("dots (\\dot)")
        if (reader1.uses_primes and not dots) or (dots and re.search(r"['\u2032\u2033\u2034\u2019\"]|\\prime", source)):
            kinds.append("primes")
        named = []
        if U in reader1.subs_bases:
            named.append("subscripts (%s_%s)" % (U, sorted(reader1.subs_bases[U])[0]))
        if reader1.uses_diff:
            named.append("d/d%s" % reader1.var)
        if kinds and (len(kinds) > 1 or named):
            both = kinds + named
            raise ValueError("unsupported: two derivative notations in one input (%s and %s): the reader "
                             "cannot tell whether they mean the same variable. Use one notation; in a partial "
                             "differential equation write both variables as subscripts (u_t, u_xx)"
                             % (both[0], both[1]))
        toks = _tokenise(text, unknown=U, split="unknown", notes=notes)
    runs = _word_runs(toks, U)
    if runs:
        raise ValueError("unsupported: the input contains the words '%s': type the equation only"
                         % "', '".join(" ".join(r_) for r_ in runs))
    parser = _Parser(toks)
    sides = parser.equation()
    reader = _Reader(sides, unknown=U, var=var, e_is_parameter=e_is_parameter)
    for msg in pre_notes:
        reader.warn(msg)
    if dropped:
        reader.warn("the word%s %s in front of the equation %s not read as part of it"
                    % ("s" if len(dropped) > 1 else "", ", ".join("'%s'" % w_ for w_ in dropped),
                       "were" if len(dropped) > 1 else "was"))
    try:
        expr = reader.build()
    except _Retry:
        raise ValueError("ambiguous: the unknown function cannot be identified; write its derivatives with "
                         "primes, for example w'' = 6 w^2")
    for msg in notes + parser.notes:
        reader.warn(msg)
    expr = _clean_fraction(expr, reader, allow_rational)
    jets = [s for s in expr.free_symbols if re.match(r"^w\d+$", s.name)]
    if expr == 0 or exact_zero(expr):
        raise ValueError("unsupported: the equation is trivial (0 = 0)")
    if not jets:
        raise ValueError("unsupported: the unknown %s does not occur in the equation" % reader.unknown)
    if max(int(s.name[1:]) for s in jets) == 0:
        raise ValueError("unsupported: no derivative of %s occurs (this is an algebraic equation, not a "
                         "differential equation)" % reader.unknown)
    eq = Equation(E=expr, unknown=reader.unknown, var=reader.var, warnings=reader.warnings,
                  source=source, name=name, cleared_denominators=reader.cleared)
    return eq


def parse_jet_expression(text):
    """Strict reader for expressions in SymPy syntax: w0, w1, ... are jets, every other identifier is a
    parameter; + - * / ** ^ and brackets; integers and fractions (decimals become exact rationals)."""
    toks = _tokenise(text, strict=True)
    if len(toks) == 1:
        raise ValueError("unsupported: empty input")
    sides = _Parser(toks).equation()
    if len(sides) > 2:
        raise ValueError("unsupported: more than one '=' sign")
    vals = [_strict_ev(s) for s in sides]
    return vals[0] - vals[1] if len(vals) == 2 else vals[0]


def _strict_ev(node):
    kind = node[0]
    if kind == "num":
        return sp.Integer(node[1]) if re.match(r"^\d+$", node[1]) else sp.Rational(node[1])
    if kind == "name":
        if node[1] == "I":
            return sp.I
        if node[1] == "pi":
            raise ValueError("unsupported: the transcendental constant pi; use a parameter for it")
        return sp.Symbol(node[1])
    if kind == "neg":
        return -_strict_ev(node[1])
    if kind == "add":
        return _strict_ev(node[1]) + _strict_ev(node[2])
    if kind == "sub":
        return _strict_ev(node[1]) - _strict_ev(node[2])
    if kind == "mul":
        return _strict_ev(node[1]) * _strict_ev(node[2])
    if kind == "div":
        den = _strict_ev(node[2])
        if den == 0:
            raise ValueError("unsupported: division by zero")
        return _strict_ev(node[1]) / den
    if kind == "group":
        return _strict_ev(node[1])
    if kind in ("pow", "callpow"):
        if kind == "callpow":
            raise ValueError("unsupported: %s(...) in a jet expression (a product is written with *)"
                             % node[1][1][1])
        ex = _strict_ev(node[2])
        if not ex.is_Rational:
            raise ValueError("unsupported: the exponent %s is not a rational number" % ex)
        base = _strict_ev(node[1])
        if not ex.is_Integer and base.free_symbols:
            raise ValueError("unsupported: fractional power (%s)**(%s) of an expression that contains a "
                             "symbol" % (base, ex))
        if base == 0 and ex < 0:
            raise ValueError("unsupported: division by zero")
        return base ** ex
    if kind == "call":
        head, args = node[1], node[2]
        if head[1] in ("sqrt", "cbrt") and len(args) == 1:
            val = _strict_ev(args[0])
            if val.free_symbols:
                raise ValueError("unsupported: %s of an expression that contains a symbol" % head[1])
            return sp.sqrt(val) if head[1] == "sqrt" else sp.cbrt(val)
        raise ValueError("unsupported: %s(...) in a jet expression (a product is written with *; functions "
                         "other than sqrt of a number are not read)" % head[1])
    raise ValueError("unsupported: syntax")
