"""mero.parse -- read an autonomous polynomial ODE typed by a visitor.

    parse_ode(text, unknown=None, var=None) -> Equation

No `eval`, no `sympify` of raw text: the text is tokenised and read by a small recursive-descent parser that
only knows numbers, names, + - * / ^ **, brackets, primes, subscripts, `diff(...)` and a list of function
names (which are recognised only in order to say "unsupported").

Accepted (examples)
    w''' + a*w'' = 12 w w' + 1        primes (also the unicode primes), implicit multiplication, one '=' sign
    u_zzz + u u_z = 0                 subscript derivatives (the independent variable is read from them)
    diff(w, z, 3), diff(w(z), z, z)   also Derivative(...); a derivative of a polynomial expression is expanded
    dw/dz, d^2w/dz^2, d2w/dz2         Leibniz notation, also \\frac{d^2 w}{dz^2} (one-letter unknown and variable)
    w^(4), w^{(4)}, w^(iv)            derivative of order four (w^4, w**4, w^{4} are powers)
    w3 = 12*w0*w1                     jets w0, w1, ... (or x0, x1, ... of the older atlas) when no other
                                      derivative notation occurs
    alpha, \\alpha, the letter itself  Greek names; every name that is not the unknown is a parameter
    0.5                               decimals become exact rationals (a warning is recorded)

Rejected with ValueError('unsupported: ...'): functions of the unknown (sin, exp, sqrt, ...), fractional or
symbolic powers of the unknown, irrational constants, an explicit independent variable (not autonomous), two
unknowns.  An equation that is rational in the unknown is multiplied by its denominator and a warning is recorded
(with allow_rational=False it is rejected).  ValueError('ambiguous: ...') asks for `unknown=`.

    parse_jet_expression(text) -> SymPy expression     strict form used by Equation(E="...") and by JSON files:
                                                       identifiers w0, w1, ... are jets, all others parameters.
"""
import re
import sympy as sp

from .equation import Equation, total_derivative, exact_zero

# ----------------------------------------------------------------------------------------- tables
_GREEK = {
    "α": "alpha", "β": "beta", "γ": "gamma", "δ": "delta", "ε": "epsilon", "ϵ": "epsilon", "ζ": "zeta",
    "η": "eta", "θ": "theta", "ϑ": "theta", "ι": "iota", "κ": "kappa", "λ": "lambda", "μ": "mu", "µ": "mu",
    "ν": "nu", "ξ": "xi", "ο": "omicron", "π": "pi", "ρ": "rho", "ϱ": "rho", "σ": "sigma", "ς": "sigma",
    "τ": "tau", "υ": "upsilon", "φ": "phi", "ϕ": "phi", "χ": "chi", "ψ": "psi", "ω": "omega",
    "Γ": "Gamma", "Δ": "Delta", "Θ": "Theta", "Λ": "Lambda", "Ξ": "Xi", "Π": "Pi", "Σ": "Sigma",
    "Υ": "Upsilon", "Φ": "Phi", "Ψ": "Psi", "Ω": "Omega",
}
_GREEK_NAMES = set(_GREEK.values()) | {"varepsilon", "vartheta", "varphi", "varrho", "varsigma"}
_ALIASES = {"varepsilon": "epsilon", "vartheta": "theta", "varphi": "phi", "varrho": "rho",
            "varsigma": "sigma"}
_EXTRA_NAMES = {"eps", "lam", "lmbda"}
_FUNCS = {"sin", "cos", "tan", "cot", "sec", "csc", "sinh", "cosh", "tanh", "coth", "sech", "csch",
          "exp", "log", "ln", "sqrt", "abs", "asin", "acos", "atan", "asinh", "acosh", "atanh",
          "arcsin", "arccos", "arctan", "sn", "cn", "dn", "wp", "erf", "cbrt", "sign", "floor"}
_DIFF = {"diff", "Derivative"}
_KNOWN_WORDS = _GREEK_NAMES | _EXTRA_NAMES | _FUNCS | _DIFF
_VAR_LETTERS = ("z", "x", "t", "xi", "s", "y", "tau", "eta", "zeta", "theta", "r")
_SUPERSCRIPT = {"⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4", "⁵": "5", "⁶": "6", "⁷": "7",
                "⁸": "8", "⁹": "9"}
_CHAR_MAP = {
    "−": "-", "–": "-", "—": "-", "‐": "-", "‑": "-", "‒": "-", "﹣": "-", "－": "-",
    "′": "'", "’": "'", "‘": "'", "ʹ": "'", "´": "'", "`": "'", "″": "''", "‴": "'''", "⁗": "''''", '"': "''",
    "·": "*", "×": "*", "⋅": "*", "∙": "*", "∗": "*", "÷": "/", "∕": "/", "⁄": "/",
    "[": "(", "]": ")", "（": "(", "）": ")", "＝": "=", "＋": "+", " ": " ", " ": " ", " ": " ",
    "$": " ",
}
_ROMAN = {"i": 1, "ii": 2, "iii": 3, "iv": 4, "v": 5, "vi": 6, "vii": 7, "viii": 8, "ix": 9, "x": 10}
_JETNAME = re.compile(r"^([A-Za-z])(\d+)$")
_NUMBER = re.compile(r"(\d+\.\d*|\.\d+|\d+)([eE][+-]?\d+)?")


class _Tok(object):
    __slots__ = ("kind", "val", "sub", "pos")

    def __init__(self, kind, val, sub=None, pos=0):
        self.kind, self.val, self.sub, self.pos = kind, val, sub, pos

    def __repr__(self):
        return "%s:%s%s" % (self.kind, self.val, "" if self.sub is None else "_%s" % (self.sub,))


_U = r"([A-Za-ce-z])"                  # the unknown: one letter other than d
_V = r"([a-z])"                        # the independent variable: one small letter
_ORD = r"(?:\^|\*\*)?\s*\{?\s*(\d+)\s*\}?"
_LEIB_N = re.compile(r"(?<![A-Za-z0-9_\\])d\s*" + _ORD + r"\s*" + _U + r"\s*/\s*d\s*" + _V
                     + r"\s*(?:\^|\*\*)?\s*\{?\s*\1\s*\}?(?![A-Za-z0-9_])")
_LEIB_1 = re.compile(r"(?<![A-Za-z0-9_\\])d" + _U + r"\s*/\s*d" + _V + r"(?![A-Za-z0-9_'^])")
_LEIB_FRAC_N = re.compile(r"\\frac\s*\{\s*d\s*" + _ORD + r"\s*" + _U + r"\s*\}\s*\{\s*d\s*" + _V
                          + r"\s*(?:\^|\*\*)?\s*\{?\s*\1\s*\}?\s*\}")
_LEIB_FRAC_1 = re.compile(r"\\frac\s*\{\s*d\s*" + _U + r"\s*\}\s*\{\s*d\s*" + _V + r"\s*\}")


def _normalise(text, limit=20000, leibniz=False):
    if not isinstance(text, str):
        raise ValueError("unsupported: the equation must be given as text")
    if len(text) > limit:
        raise ValueError("unsupported: the text is too long (%d characters, the limit is %d)" % (len(text), limit))
    out = []
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch in _SUPERSCRIPT:
            j = i
            digs = ""
            while j < n and text[j] in _SUPERSCRIPT:
                digs += _SUPERSCRIPT[text[j]]
                j += 1
            out.append("**" + digs + " ")
            i = j
            continue
        out.append(_CHAR_MAP.get(ch, ch))
        i += 1
    s = "".join(out)
    # LaTeX commands that are only spacing or sizing
    s = re.sub(r"\\(left|right|bigl|bigr|Bigl|Bigr|big|Big|displaystyle|,|;|!|:|quad|qquad| )", " ", s)
    s = re.sub(r"\\(cdot|times|ast)(?![A-Za-z])", "*", s)
    s = re.sub(r"\\(dfrac|tfrac)(?![A-Za-z])", r"\\frac", s)
    s = re.sub(r"\\prime(?![A-Za-z])", "'", s)
    s = s.replace("==", "=")
    if leibniz:
        # Leibniz notation:  dw/dz, d^2w/dz^2, d2w/dz2, \frac{d^2 w}{dz^2}  ->  diff(w, z, 2)
        s = _LEIB_FRAC_N.sub(r" diff(\2,\3,\1) ", s)
        s = _LEIB_FRAC_1.sub(r" diff(\1,\2) ", s)
        s = _LEIB_N.sub(r" diff(\2,\3,\1) ", s)
        s = _LEIB_1.sub(r" diff(\1,\2) ", s)
    # derivative orders written as roman numerals:  w^(iv), w^{(IV)}
    def _roman(m):
        return "%s(%d)%s" % (m.group(1), _ROMAN[m.group(2).lower()], m.group(3))
    s = re.sub(r"(\^\s*\{?\s*)\(\s*(iv|v|vi|vii|viii|ix|iii|ii|IV|V|VI|VII|VIII|IX|III|II)\s*\)(\s*\}?)",
               _roman, s)
    return s


def _segment(word, known, unknown=None, carrier=False):
    """split a run of letters and digits into names: known multi-letter names are kept, a letter followed
    by digits is one name, everything else is a product of single letters"""
    if unknown and word == unknown:
        return [word]
    tail = []
    if unknown and carrier and len(word) > len(unknown) and word.endswith(unknown):
        tail = [unknown]
        word = word[:-len(unknown)]
        if word in known or re.match(r"^[A-Za-z]\d*$", word):
            return [word] + tail
    elif word in known or re.match(r"^[A-Za-z]\d*$", word):
        return [word]
    out = []
    i = 0
    while i < len(word):
        best = None
        if unknown and len(unknown) > 1 and word.startswith(unknown, i):
            best = unknown
        else:
            for L in range(min(len(word) - i, 10), 1, -1):
                if word[i:i + L] in known:
                    best = word[i:i + L]
                    break
        if best is None:
            best = word[i]
        i += len(best)
        j = i
        while j < len(word) and word[j].isdigit():
            j += 1
        out.append(best + word[i:j])
        i = j
    return out + tail


def _sub_units(sub):
    """a subscript as a list of units: 'zzz' -> ['z','z','z'], 'xixi' -> ['xi','xi'], '12' -> ['12']"""
    sub = sub.strip()
    sub = re.sub(r"\\([A-Za-z]+)", r"\1", sub).replace(" ", "")
    for g, name in _GREEK.items():
        sub = sub.replace(g, "<%s>" % name)
    if not sub:
        return []
    if "<" in sub:
        units = re.findall(r"<([a-zA-Z]+)>|(.)", sub)
        return [a or b for a, b in units]
    for name in ("xi", "eta", "tau", "zeta", "theta"):
        if len(sub) % len(name) == 0 and sub == name * (len(sub) // len(name)):
            return [name] * (len(sub) // len(name))
    if sub.isalpha():
        return list(sub)
    return [sub]


def _tokenise(text, strict=False, unknown=None, split="all", notes=None):
    """split: 'all'  every word that is not a known name is a product of single letters (first pass, used
                     to find the unknown);
              'unknown'  only words that contain the unknown as a factor are split (w w', a w'', b w w');
              'none' words are kept whole (jet notation, SymPy syntax)."""
    s = _normalise(text, 2000000 if strict else 20000, leibniz=not strict)
    toks = []
    i, n = 0, len(s)
    known = set(_KNOWN_WORDS)
    while i < n:
        ch = s[i]
        if ch.isspace():
            i += 1
            continue
        m = _NUMBER.match(s, i)
        if m and (ch.isdigit() or ch == "."):
            toks.append(_Tok("NUM", m.group(0), pos=i))
            i = m.end()
            continue
        if strict and (ch.isalpha() or ch == "_") and ch not in _GREEK:
            m = re.match(r"[A-Za-z_][A-Za-z_0-9]*", s[i:])
            if not m:
                raise ValueError("unsupported: character %r" % ch)
            toks.append(_Tok("NAME", m.group(0), pos=i))
            i += m.end()
            continue
        word, latex_cmd = None, False
        if ch == "\\":
            m = re.match(r"\\([A-Za-z]+)", s[i:])
            if not m:
                raise ValueError("unsupported: character %r" % ch)
            cmd = m.group(1)
            i += m.end()
            if cmd == "frac":
                toks.append(_Tok("FRAC", "frac", pos=i))
                continue
            if cmd not in _KNOWN_WORDS:
                raise ValueError("unsupported: LaTeX command \\%s" % cmd)
            word, latex_cmd = cmd, True
        elif ch in _GREEK:
            word, latex_cmd = _GREEK[ch], True
            i += 1
            m = re.match(r"\d+", s[i:])
            if m:
                word += m.group(0)
                i += m.end()
        elif ch.isalpha():
            m = re.match(r"[A-Za-z][A-Za-z0-9]*", s[i:])
            if not m:
                raise ValueError("unsupported: character %r" % ch)
            word = m.group(0)
            i += m.end()
        if word is not None:
            sub = None
            if i < n and s[i] == "_" and not strict:
                if i + 1 < n and s[i + 1] == "{":
                    j = s.find("}", i + 2)
                    if j < 0:
                        raise ValueError("unsupported: unbalanced brace in a subscript")
                    sub = s[i + 2:j]
                    i = j + 1
                else:
                    m = re.match(r"_((?:[A-Za-z0-9]|[%s])+)" % "".join(_GREEK.keys()), s[i:])
                    if not m:
                        raise ValueError("unsupported: empty subscript")
                    sub = m.group(1)
                    i += m.end()
            if strict:
                toks.append(_Tok("NAME", _ALIASES.get(word, word), pos=i))
                continue
            carrier = (sub is not None) or (i < n and s[i] == "'")
            if latex_cmd or split == "none":
                parts = [word]
            else:
                parts = _segment(word, known, unknown, carrier)
                if split == "unknown" and len(parts) > 1:
                    if unknown is None or unknown not in parts:
                        parts = [word]
                    elif notes is not None and sum(1 for q in parts if q != unknown) >= 2:
                        notes.append("%s was read as the product %s" % (word, "*".join(parts)))
            for q, part in enumerate(parts):
                part = _ALIASES.get(part, part)
                toks.append(_Tok("NAME", part, _sub_units(sub) if (sub is not None and q == len(parts) - 1)
                                 else None, pos=i))
            continue
        if ch == "'":
            j = i
            while j < n and (s[j] == "'" or (s[j] == " " and j + 1 < n and s[j + 1] == "'")):
                j += 1
            cnt = s[i:j].count("'")
            if strict:
                raise ValueError("unsupported: primes are not allowed in a jet expression")
            toks.append(_Tok("PRIME", cnt, pos=i))
            i = j
            continue
        if s.startswith("**", i):
            toks.append(_Tok("POW", "**", pos=i))
            i += 2
            continue
        if ch == "^":
            toks.append(_Tok("POW", "^", pos=i))
            i += 1
            continue
        if ch in "+-*/(),={}":
            toks.append(_Tok("OP", ch, pos=i))
            i += 1
            continue
        raise ValueError("unsupported: character %r in the equation" % ch)
    toks.append(_Tok("END", None, pos=n))
    return toks


# ----------------------------------------------------------------------------------------- AST
# nodes: ('num', text) ('name', base, sub_units|None, primes) ('call', name_node, [args], primes_after)
#        ('group', inner, bracket, primes) ('neg', a) ('add'|'sub'|'mul'|'div', a, b) ('pow', base, exp, style)
class _Parser(object):
    def __init__(self, toks):
        self.toks = toks
        self.i = 0

    def peek(self):
        return self.toks[self.i]

    def next(self):
        t = self.toks[self.i]
        self.i += 1
        return t

    def is_op(self, *vals):
        t = self.peek()
        return t.kind == "OP" and t.val in vals

    def expect(self, val):
        t = self.next()
        if t.kind != "OP" or t.val != val:
            raise ValueError("unsupported: syntax error near position %d (expected '%s')" % (t.pos, val))

    def equation(self):
        sides = [self.expr()]
        while self.is_op("="):
            self.next()
            sides.append(self.expr())
        t = self.peek()
        if t.kind != "END":
            raise ValueError("unsupported: syntax error near position %d" % t.pos)
        return sides

    def expr(self):
        node = self.term()
        while self.is_op("+", "-"):
            op = self.next().val
            rhs = self.term()
            node = ("add" if op == "+" else "sub", node, rhs)
        return node

    def starts_atom(self):
        t = self.peek()
        return t.kind in ("NUM", "NAME", "FRAC") or (t.kind == "OP" and t.val in "({")

    def term(self):
        node = self.unary()
        while True:
            if self.is_op("*", "/"):
                op = self.next().val
                rhs = self.unary()
                node = ("mul" if op == "*" else "div", node, rhs)
            elif self.starts_atom():
                rhs = self.power()
                node = ("mul", node, rhs)
            else:
                return node

    def unary(self):
        if self.is_op("+"):
            self.next()
            return self.unary()
        if self.is_op("-"):
            self.next()
            return ("neg", self.unary())
        return self.power()

    def power(self):
        base = self.postfix()
        if self.peek().kind == "POW":
            style = self.next().val
            exp = self.exponent()
            if base[0] == "call" and base[1][1] not in _FUNCS and base[1][1] not in _DIFF \
                    and len(base[2]) == 1 and base[3] == 0:
                # a (w')^2 is a*((w')^2); w(z)^2 is (w(z))^2 -- decided when the unknown is known
                return ("callpow", base, exp, style)
            return ("pow", base, exp, style)
        return base

    def exponent(self):
        if self.is_op("-"):
            self.next()
            return ("neg", self.exponent())
        if self.is_op("+"):
            self.next()
            return self.exponent()
        base = self.postfix(in_exponent=True)
        if self.peek().kind == "POW":
            style = self.next().val
            return ("pow", base, self.exponent(), style)
        return base

    def primes(self):
        cnt = 0
        while self.peek().kind == "PRIME":
            cnt += self.next().val
        return cnt

    def postfix(self, in_exponent=False):
        t = self.peek()
        if t.kind == "NUM":
            self.next()
            return ("num", t.val)
        if t.kind == "FRAC":
            self.next()
            a = self.brace_group()
            b = self.brace_group()
            return ("group", ("div", a, b), "(", self.primes())
        if t.kind == "NAME":
            self.next()
            node = ("name", t.val, t.sub, self.primes())
            if self.is_op("(") and not in_exponent:
                self.next()
                args = [self.expr()]
                while self.is_op(","):
                    self.next()
                    args.append(self.expr())
                self.expect(")")
                return ("call", node, args, self.primes())
            return node
        if t.kind == "OP" and t.val in "({":
            self.next()
            close = ")" if t.val == "(" else "}"
            inner = self.expr()
            items = [inner]
            while self.is_op(","):
                self.next()
                items.append(self.expr())
            self.expect(close)
            if len(items) > 1:
                return ("tuple", items)
            return ("group", inner, t.val, self.primes())
        raise ValueError("unsupported: syntax error near position %d" % t.pos)

    def brace_group(self):
        if self.is_op("{"):
            self.next()
            inner = self.expr()
            self.expect("}")
            return inner
        t = self.peek()
        if t.kind == "NUM":
            self.next()
            return ("num", t.val)
        if t.kind == "NAME":
            self.next()
            return ("name", t.val, t.sub, 0)
        raise ValueError("unsupported: \\frac needs two groups in braces")


def _walk(node):
    yield node
    kind = node[0]
    if kind in ("add", "sub", "mul", "div"):
        for c in node[1:3]:
            for x in _walk(c):
                yield x
    elif kind == "neg":
        for x in _walk(node[1]):
            yield x
    elif kind in ("pow", "callpow"):
        for c in node[1:3]:
            for x in _walk(c):
                yield x
    elif kind == "group":
        for x in _walk(node[1]):
            yield x
    elif kind == "tuple":
        for c in node[1]:
            for x in _walk(c):
                yield x
    elif kind == "call":
        for x in _walk(node[1]):
            yield x
        for c in node[2]:
            for x in _walk(c):
                yield x


def _paren_int(node):
    """n if node is '(n)' or '{(n)}' with an integer or a roman numeral n (derivative order), else None;
    second value: True if the form was the braced one"""
    braced = False
    if node[0] == "group" and node[2] == "{" and node[3] == 0:
        node = node[1]
        braced = True
    if node[0] == "group" and node[2] == "(" and node[3] == 0:
        inner = node[1]
        if inner[0] == "num" and re.match(r"^\d+$", inner[1]):
            return int(inner[1]), braced
        if inner[0] == "name" and inner[2] is None and inner[3] == 0 and inner[1].lower() in _ROMAN:
            return _ROMAN[inner[1].lower()], braced
    return None, braced


def _full_name(base, sub):
    return base if not sub else base + "_" + "".join(sub)


def _is_var_sub(sub):
    return bool(sub) and len(set(sub)) == 1 and sub[0] in _VAR_LETTERS


class _Reader(object):
    """interprets the syntax tree: finds the unknown, the independent variable, the mode (jets or
    derivatives) and builds the SymPy expression"""

    def __init__(self, sides, unknown=None, var=None, strict=False, e_is_parameter=True):
        self.e_is_parameter = e_is_parameter
        self.sides = sides
        self.unknown_arg = unknown
        self.var_arg = var
        self.strict = strict
        self.warnings = []
        self.jet_letter = None
        self.unknown = None
        self.var = var
        self.var_explicit = var is not None
        self.max_jet = -1
        self.renamed = {}

    # ---------------------------------------------------------------- detection
    def detect(self):
        strong, subs, calls, jets, bare = {}, {}, {}, {}, set()
        var_seen = set()
        for side in self.sides:
            for node in _walk(side):
                kind = node[0]
                if kind == "name":
                    base, sub, primes = node[1], node[2], node[3]
                    full = _full_name(base, sub)
                    bare.add(full)
                    if primes:
                        strong[base if _is_var_sub(sub) else full] = True
                    if _is_var_sub(sub):
                        subs.setdefault(base, set()).add(sub[0])
                    m = _JETNAME.match(base) if not sub else None
                    if m:
                        jets.setdefault(m.group(1), set()).add(int(m.group(2)))
                elif kind == "call":
                    head = node[1]
                    if head[1] in _DIFF and head[2] is None and head[3] == 0:
                        tgt = node[2][0]
                        if tgt[0] == "call":
                            tgt = tgt[1]
                        if tgt[0] == "name":
                            strong[_full_name(tgt[1], tgt[2])] = True
                        elif tgt[0] != "name":
                            strong.setdefault(None, True)
                        for a in node[2][1:]:
                            items = a[1] if a[0] == "tuple" else [a]
                            for it in items:
                                if it[0] == "name" and it[3] == 0:
                                    var_seen.add(_full_name(it[1], it[2]))
                    elif head[1] not in _FUNCS and len(node[2]) == 1:
                        a = node[2][0]
                        if a[0] == "name" and a[2] is None and a[3] == 0 and a[1] in _VAR_LETTERS:
                            calls.setdefault(_full_name(head[1], head[2] if not _is_var_sub(head[2])
                                                        else None), set()).add(a[1])
                        if node[3]:
                            strong[_full_name(head[1], head[2])] = True
                elif kind == "pow":
                    b = node[1]
                    n, braced = _paren_int(node[2])
                    if n is not None and b[0] == "name" and b[3] == 0 and (braced or node[3] == "^"):
                        strong.setdefault(_full_name(b[1], b[2]), "weak" if not braced else True)
                elif kind == "group" and node[3]:
                    strong.setdefault(None, True)
        strong_names = [k for k in strong if k is not None]
        U = self.unknown_arg
        if U is not None:
            U = _ALIASES.get(_GREEK.get(U, U), _GREEK.get(U, U))
        if U is None:
            real = [k for k in strong_names if strong[k] is True]
            cands = real or strong_names
            if len(set(cands)) == 1:
                U = cands[0]
            elif len(set(cands)) > 1:
                single = [c for c in set(cands) if len(c) == 1]
                if len(single) == 1 and all(c.endswith(single[0]) for c in set(cands)):
                    raise _Retry(single[0])
                raise ValueError("ambiguous: derivatives of several names occur (%s); pass unknown=..."
                                 % ", ".join(sorted(set(cands))))
            elif subs:
                cs = sorted(subs)
                if len(cs) == 1:
                    U = cs[0]
                else:
                    pref = [c for c in cs if subs[c] & {"z", "x", "xi", "t"}]
                    if len(pref) == 1:
                        U = pref[0]
                    else:
                        raise ValueError("ambiguous: several names carry subscripts (%s); pass unknown=..."
                                         % ", ".join(cs))
            elif calls and len(calls) == 1:
                U = list(calls)[0]
        has_deriv_notation = bool(strong) or (U is not None and U in subs)
        # jets
        if not has_deriv_notation:
            letter = None
            if U is not None and U in jets and U not in bare:
                letter = U
            elif U is None or U not in bare:
                if "w" in jets and "w" not in bare:
                    letter = "w"
                elif "x" in jets and "x" not in bare:
                    letter = "x"
                else:
                    others = [c for c in ("u", "v", "y", "f", "g") if c in jets and c not in bare]
                    if len(others) == 1 and U is None:
                        letter = others[0]
            if letter is not None and (U is None or U == letter or U not in bare):
                self.jet_letter = letter
                if U is None:
                    U = "w" if letter == "x" else letter
        if U is None:
            names = sorted(bare)
            if "w" in bare:
                U = "w"
            elif len(names) == 1:
                U = names[0]
            else:
                raise ValueError("ambiguous: no derivative found; pass unknown=... (names: %s)"
                                 % ", ".join(names))
        self.unknown = U
        # independent variable
        vs = set(var_seen)
        if U in subs:
            vs |= subs[U]
        if U in calls:
            vs |= calls[U]
        if self.var_arg is not None:
            v = _ALIASES.get(_GREEK.get(self.var_arg, self.var_arg), _GREEK.get(self.var_arg, self.var_arg))
            if vs - {v}:
                raise ValueError("unsupported: derivatives with respect to %s, but var=%s was given"
                                 % (", ".join(sorted(vs - {v})), v))
            self.var = v
        elif len(vs) == 1:
            self.var = list(vs)[0]
            self.var_explicit = True
        elif len(vs) > 1:
            raise ValueError("unsupported: derivatives with respect to several variables (%s): this is a "
                             "partial differential equation" % ", ".join(sorted(vs)))
        else:
            self.var = "z"
        self.subs_bases = subs

    # ---------------------------------------------------------------- evaluation
    def jetsym(self, j):
        self.max_jet = max(self.max_jet, j)
        return sp.Symbol("w%d" % j)

    def param(self, name):
        if name == self.var or (not self.var_explicit and name in ("z", "x", "t")):
            raise ValueError("unsupported: the equation is not autonomous (the independent variable %s "
                             "occurs explicitly); if %s is a parameter, rename it" % (name, name))
        if name in ("I", "i"):
            if name == "i" and "i" not in self.renamed:
                self.renamed["i"] = "I"
                self.warnings.append("i was read as the imaginary unit")
            return sp.I
        if name == "pi":
            raise ValueError("unsupported: the transcendental constant pi; use a parameter for it")
        if name == "e":
            if not self.e_is_parameter:
                raise ValueError("unsupported: the transcendental constant e; use another letter if a "
                                 "parameter is meant")
            if "e" not in self.renamed:
                self.renamed["e"] = "e"
                self.warnings.append("e was read as a parameter (not as the base of the natural logarithm)")
        new = name
        if re.match(r"^w\d+$", name):
            new = "w_" + name[1:]
        elif name == "z":
            new = "zpar"
        if new != name and name not in self.renamed:
            self.renamed[name] = new
            self.warnings.append("the parameter %s was renamed %s (the name is used by the engine)"
                                 % (name, new))
        return sp.Symbol(new)

    def name_value(self, node):
        base, sub, primes = node[1], node[2], node[3]
        U = self.unknown
        if self.jet_letter is not None and not sub:
            m = _JETNAME.match(base)
            if m and m.group(1) == self.jet_letter:
                return self.jetsym(int(m.group(2)) + primes)
        if base == U and (not sub or _is_var_sub(sub)):
            order = primes + (len(sub) if sub else 0)
            return self.jetsym(order)
        full = _full_name(base, sub)
        if full == U:
            return self.jetsym(primes)
        if primes:
            raise ValueError("unsupported: a derivative of %s occurs, but the unknown is %s (one unknown "
                             "only; parameters are constants)" % (full, U))
        return self.param(full)

    def number(self, text):
        if re.match(r"^\d+$", text):
            return sp.Integer(text)
        val = sp.Rational(text)
        self.warnings.append("the decimal %s was read as the exact rational number %s" % (text, val))
        return val

    def has_unknown(self, expr):
        return any(re.match(r"^w\d+$", s.name) for s in expr.free_symbols)

    def ev(self, node):
        kind = node[0]
        if kind == "num":
            return self.number(node[1])
        if kind == "name":
            return self.name_value(node)
        if kind == "neg":
            return -self.ev(node[1])
        if kind == "add":
            return self.ev(node[1]) + self.ev(node[2])
        if kind == "sub":
            return self.ev(node[1]) - self.ev(node[2])
        if kind == "mul":
            return self.ev(node[1]) * self.ev(node[2])
        if kind == "div":
            den = self.ev(node[2])
            if den == 0:
                raise ValueError("unsupported: division by zero")
            return self.ev(node[1]) / den
        if kind == "group":
            val = self.ev(node[1])
            if node[3]:
                val = self.derivative(val, node[3])
            return val
        if kind == "tuple":
            raise ValueError("unsupported: a list of expressions where one expression is expected")
        if kind == "pow":
            return self.power(node)
        if kind == "call":
            return self.call(node)
        if kind == "callpow":
            call, e, style = node[1], node[2], node[3]
            if self.is_function_value(call):
                return self.power(("pow", call, e, style))
            head, arg = call[1], call[2][0]
            return self.ev(head) * self.power(("pow", ("group", arg, "(", 0), e, style))
        raise ValueError("unsupported: syntax")

    def is_function_value(self, node):
        """True if the call node is the unknown written as a function of the independent variable"""
        head, args = node[1], node[2]
        full = _full_name(head[1], head[2])
        is_unknown = (full == self.unknown) or (head[1] == self.unknown and _is_var_sub(head[2]))
        if is_unknown and len(args) == 1:
            a = args[0]
            return a[0] == "name" and a[2] is None and a[3] == 0 and a[1] == self.var
        return False

    def derivative(self, val, n):
        num, den = sp.fraction(sp.together(val))
        if self.has_unknown(den):
            raise ValueError("unsupported: derivative of an expression that is rational in the unknown")
        return total_derivative(sp.expand(val), n)

    def power(self, node):
        b, e, style = node[1], node[2], node[3]
        n, braced = _paren_int(e)
        if n is not None and b[0] == "name" and b[3] == 0 and (braced or style == "^"):
            full = _full_name(b[1], b[2])
            if full == self.unknown or (b[1] == self.unknown and _is_var_sub(b[2])):
                if not braced:
                    self.warnings.append("%s^(%d) was read as the derivative of order %d; write %s^%d "
                                         "for the power" % (full, n, n, full, n))
                return self.jetsym(n + (len(b[2]) if b[2] and full != self.unknown else 0))
        base = self.ev(b)
        ex = self.ev(e)
        if not ex.is_number:
            raise ValueError("unsupported: the exponent %s is not a number; substitute a value" % ex)
        if not ex.is_Rational:
            raise ValueError("unsupported: the exponent %s is not a rational number" % ex)
        if ex.is_Integer:
            if ex < 0 and base == 0:
                raise ValueError("unsupported: division by zero")
            if abs(ex) > 60:
                raise ValueError("unsupported: the exponent %s is too large" % ex)
            return base ** ex
        if self.has_unknown(base):
            raise ValueError("unsupported: fractional power of the unknown (exponent %s): the equation is "
                             "not polynomial" % ex)
        if base.free_symbols:
            raise ValueError("unsupported: fractional power (%s)**(%s) of an expression that contains a "
                             "parameter; introduce a parameter for it" % (base, ex))
        if base == 0 and ex < 0:
            raise ValueError("unsupported: division by zero")
        return base ** ex              # an algebraic number, kept exactly

    def call(self, node):
        head, args, primes_after = node[1], node[2], node[3]
        fname = head[1]
        plain = head[2] is None and head[3] == 0
        if fname in _DIFF and plain:
            target = self.ev(args[0])
            order = 0
            last = None
            flat = []
            for a in args[1:]:
                flat.extend(a[1] if a[0] == "tuple" else [a])
            for a in flat:
                if a[0] == "num" and re.match(r"^\d+$", a[1]):
                    if last is None:
                        raise ValueError("unsupported: diff(expr, variable, n) expected")
                    order += int(a[1]) - 1
                elif a[0] == "name" and a[3] == 0:
                    nm = _full_name(a[1], a[2])
                    if nm != self.var:
                        raise ValueError("unsupported: derivative with respect to %s (the independent "
                                         "variable is %s)" % (nm, self.var))
                    last = nm
                    order += 1
                else:
                    raise ValueError("unsupported: arguments of diff")
            if not flat:
                order = 1
            val = self.derivative(target, order)
            return self.derivative(val, primes_after) if primes_after else val
        if fname in _FUNCS and plain:
            vals = [self.ev(a) for a in args]
            if any(self.has_unknown(v) for v in vals):
                raise ValueError("unsupported: %s of the unknown; the equation must be a polynomial in the "
                                 "unknown and its derivatives" % fname)
            if fname in ("sqrt", "cbrt") and len(vals) == 1 and not vals[0].free_symbols:
                val = sp.sqrt(vals[0]) if fname == "sqrt" else sp.cbrt(vals[0])
                return self.derivative(val, primes_after) if primes_after else val
            if all(not v.free_symbols for v in vals):
                raise ValueError("unsupported: the constant %s(%s) is not an algebraic number written with "
                                 "roots; use a parameter for it" % (fname, ", ".join(str(v) for v in vals)))
            raise ValueError("unsupported: %s of a parameter; introduce a new parameter for it" % fname)
        # the unknown as a function of the independent variable:  w(z), w'(z), w_zz(z), w(z)'
        full = _full_name(head[1], head[2])
        is_unknown = (full == self.unknown) or (head[1] == self.unknown and _is_var_sub(head[2]))
        if is_unknown and len(args) == 1:
            a = args[0]
            if a[0] == "name" and a[2] is None and a[3] == 0 and a[1] == self.var:
                order = head[3] + primes_after + (len(head[2]) if head[2] and full != self.unknown else 0)
                return self.jetsym(order)
        if len(args) != 1:
            raise ValueError("unsupported: %s(...) with several arguments" % fname)
        val = self.ev(head) * self.ev(args[0])
        if primes_after:
            raise ValueError("unsupported: a prime after %s(...)" % fname)
        return val

    def build(self):
        self.detect()
        vals = [self.ev(s) for s in self.sides]
        if len(vals) > 2:
            raise ValueError("unsupported: more than one '=' sign")
        expr = vals[0] - vals[1] if len(vals) == 2 else vals[0]
        return expr


class _Retry(Exception):
    def __init__(self, unknown):
        Exception.__init__(self, unknown)
        self.unknown = unknown


def _clean_fraction(expr, reader, allow_rational):
    """E as a polynomial in the jets: multiply out a denominator that contains the unknown"""
    expr = sp.together(expr)
    num, den = sp.fraction(expr)
    jets = set(s for s in expr.free_symbols if re.match(r"^w\d+$", s.name))
    if den.free_symbols & jets:
        if not allow_rational:
            raise ValueError("unsupported: the unknown occurs in a denominator")
        num, den = sp.fraction(sp.cancel(expr))
        if den.free_symbols & jets:
            # keep the part of the denominator that is free of the unknown as a coefficient
            const, rest = sp.factor(den).as_independent(*jets, as_Add=False)
            reader.warnings.append("the equation is rational in the unknown: it was multiplied by %s; "
                                   "a function on which this factor vanishes identically is not a solution "
                                   "of the original equation" % rest)
            return num / const
        return num / den
    return expr


def _jet_notation(toks, unknown):
    """True if the text uses jets (w0, w1, ...) and no other derivative notation: then words are identifiers"""
    words = set()
    for q, t in enumerate(toks):
        if t.kind == "PRIME":
            return False
        if t.kind == "NAME":
            if t.val in _DIFF:
                return False
            if t.sub is not None and _is_var_sub(t.sub):
                return False
            words.add(t.val)
            nxt = toks[q + 1:q + 5]
            if len(nxt) >= 4 and nxt[0].kind == "POW" and nxt[0].val == "^" and nxt[1].kind == "OP" \
                    and nxt[1].val == "(" and nxt[2].kind == "NUM" and nxt[3].kind == "OP" and nxt[3].val == ")":
                return False
    fam = {}
    for wd in words:
        m = _JETNAME.match(wd)
        if m:
            fam.setdefault(m.group(1), set()).add(int(m.group(2)))
    cands = [unknown] if unknown else []
    cands += ["w", "x"]
    for c in cands:
        if c in fam and c not in words:
            return True
    others = [c for c in ("u", "v", "y", "f", "g") if c in fam and c not in words]
    return len(others) == 1 and unknown is None


def parse_ode(text, unknown=None, var=None, allow_rational=True, name="", e_is_parameter=True):
    """Read an autonomous polynomial ODE.  Returns an Equation (jets w0..wK, E = left side - right side);
    eq.unknown, eq.var are the visitor's letters, eq.warnings the remarks of the parser, eq.source the text.

    unknown, var   the visitor's letters when they cannot be read off (ValueError('ambiguous: ...') asks)
    allow_rational an equation that is rational in the unknown is multiplied by its denominator (a warning is
                   recorded); with False it is rejected
    Algebraic constants (sqrt(6), 2^(1/3), I and combinations) are kept exactly; decimals become rationals
    (warning); pi and functions of numbers other than roots are rejected.  The bare letter e is read as a
    parameter and a warning is recorded (e_is_parameter=False rejects it as the transcendental constant)."""
    if unknown is not None:
        unknown = _ALIASES.get(_GREEK.get(unknown, unknown), _GREEK.get(unknown, unknown))
    notes = []
    toks = _tokenise(text, unknown=unknown, split="none")
    if len(toks) == 1:
        raise ValueError("unsupported: empty input")
    U = unknown
    if not _jet_notation(toks, unknown):
        # first pass: every word is split, only to find the unknown
        for _attempt in range(2):
            toks1 = _tokenise(text, unknown=U, split="all")
            reader1 = _Reader(_Parser(toks1).equation(), unknown=U, var=var)
            try:
                reader1.detect()
                U = reader1.unknown
                break
            except _Retry as r:
                if _attempt == 1:
                    raise ValueError("ambiguous: pass unknown=...")
                U = r.unknown
        toks = _tokenise(text, unknown=U, split="unknown", notes=notes)
    sides = _Parser(toks).equation()
    reader = _Reader(sides, unknown=U, var=var, e_is_parameter=e_is_parameter)
    try:
        expr = reader.build()
    except _Retry:
        raise ValueError("ambiguous: pass unknown=...")
    for msg in notes:
        if msg not in reader.warnings:
            reader.warnings.append(msg)
    expr = _clean_fraction(expr, reader, allow_rational)
    jets = [s for s in expr.free_symbols if re.match(r"^w\d+$", s.name)]
    if expr == 0 or exact_zero(expr):
        raise ValueError("unsupported: the equation is trivial (0 = 0)")
    if not jets:
        raise ValueError("unsupported: the unknown %s does not occur in the equation" % reader.unknown)
    if max(int(s.name[1:]) for s in jets) == 0:
        raise ValueError("unsupported: no derivative of %s occurs (this is an algebraic equation, not a "
                         "differential equation)" % reader.unknown)
    eq = Equation(E=expr, unknown=reader.unknown, var=reader.var, warnings=reader.warnings,
                  source=text, name=name)
    return eq


def parse_jet_expression(text):
    """Strict reader for expressions in SymPy syntax: w0, w1, ... are jets, every other identifier is a
    parameter; + - * / ** ^ and brackets; integers and fractions (decimals become exact rationals)."""
    toks = _tokenise(text, strict=True)
    if len(toks) == 1:
        raise ValueError("unsupported: empty input")
    sides = _Parser(toks).equation()
    if len(sides) > 2:
        raise ValueError("unsupported: more than one '=' sign")
    vals = [_strict_ev(s) for s in sides]
    return vals[0] - vals[1] if len(vals) == 2 else vals[0]


def _strict_ev(node):
    kind = node[0]
    if kind == "num":
        return sp.Integer(node[1]) if re.match(r"^\d+$", node[1]) else sp.Rational(node[1])
    if kind == "name":
        if node[1] == "I":
            return sp.I
        if node[1] == "pi":
            raise ValueError("unsupported: the transcendental constant pi; use a parameter for it")
        return sp.Symbol(node[1])
    if kind == "neg":
        return -_strict_ev(node[1])
    if kind == "add":
        return _strict_ev(node[1]) + _strict_ev(node[2])
    if kind == "sub":
        return _strict_ev(node[1]) - _strict_ev(node[2])
    if kind == "mul":
        return _strict_ev(node[1]) * _strict_ev(node[2])
    if kind == "div":
        den = _strict_ev(node[2])
        if den == 0:
            raise ValueError("unsupported: division by zero")
        return _strict_ev(node[1]) / den
    if kind == "group":
        return _strict_ev(node[1])
    if kind in ("pow", "callpow"):
        if kind == "callpow":
            call = node[1]
            return _strict_ev(call[1]) * _strict_ev(("pow", ("group", call[2][0], "(", 0), node[2], node[3]))
        ex = _strict_ev(node[2])
        if not ex.is_Rational:
            raise ValueError("unsupported: the exponent %s is not a rational number" % ex)
        base = _strict_ev(node[1])
        if not ex.is_Integer and base.free_symbols:
            raise ValueError("unsupported: fractional power (%s)**(%s) of an expression that contains a "
                             "symbol" % (base, ex))
        if base == 0 and ex < 0:
            raise ValueError("unsupported: division by zero")
        return base ** ex
    if kind == "call":
        head, args = node[1], node[2]
        if head[1] in ("sqrt", "cbrt") and len(args) == 1:
            val = _strict_ev(args[0])
            if val.free_symbols:
                raise ValueError("unsupported: %s of an expression that contains a symbol" % head[1])
            return sp.sqrt(val) if head[1] == "sqrt" else sp.cbrt(val)
        if len(args) == 1 and head[1] not in _FUNCS and head[1] not in _DIFF:
            return _strict_ev(head) * _strict_ev(args[0])
        raise ValueError("unsupported: function %s in a jet expression" % head[1])
    raise ValueError("unsupported: syntax")
