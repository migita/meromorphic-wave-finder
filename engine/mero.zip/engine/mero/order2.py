"""mero.order2 -- decision procedure for autonomous equations of order two (worker ORDER2, 6 October 2026).

    order2_answer(eq) -> dict  {"applies", "found", "ruled_out", "not_decided", "verdict", "basis", "strata", ...}
                                 in the format of SCHEMA section 3 (Solution objects of section 2).

Sectors (statements and sources: lemmas/order2/project note):

  C   conservative  w'' = F(w), F a polynomial of any degree   (statement C1: first integral; deg F <= 3 all
      solutions meromorphic; deg F >= 4 only constants)
  L   linear        w'' = b w' + c w + d                        (record ORD2 Theorem L)
  Q22               w'' = a w^2 + b w' + c w + d, a != 0        (record ORD2 Theorem Q22 = Conte-Ng-Wu 2015 Lemma 4.4)
  B                 w'' = b w w' + c w^2 + d w' + e w + f, b != 0   (record ORD2 Theorem B)
  P                 w'' = a w^3 + b w w' + c w^2 + d w' + e w + f, a != 0   (record ORD2 Theorem P)
  other second-order equations: local analysis and the optional modules of the engine (partial answers).

Every closed form is checked by exact substitution on a carrier (mero.order1.verify_carrier); the families of
Bessel and Airy type are certified by exact identities (factorisation, linearisation, reduction to the special
function's equation).  With symbolic parameters the decision tree branches on every test whose value depends on
the parameters; the generic stratum comes first.  Pure SymPy.
"""
import time
import sympy as sp

from .order1 import (w0, w1, w2, z, wp, wpp, is_zero, zero_status, nice, sqrt_exact, cond_str, aux, set_reserved, _CTX, S_,
                     factor_list_x, sqf_part_x, gcd_x, is_exact_input, Carrier, carrier_t,
                     carrier_exp, carrier_wp, make_solution, finalize, constant_solutions, riccati_solutions,
                     binomial2_solutions, solve_for_param, jets_and_E, verify_carrier, order1_answer, _latex,
                     _wp_invariants_cubic, weierstrass_quartic)

ORD2_PATH = "project note"
REC = "record:" + ORD2_PATH
CIT_CNW15 = "Conte, Ng, Wu, Complex Var. Elliptic Equ. 60 (2015) 1539-1552, arXiv:1503.07074 (Lemmas 4.4, 4.5, Remark 4.6)"
CIT_NW19 = "Ng, Wu, Israel J. Math. 229 (2019) 1-38, doi:10.1007/s11856-018-1791-0 (Theorems 1.4-1.5)"
CIT_AZ = "Ablowitz, Zeppetella, Bull. Math. Biol. 41 (1979) 835-840"
CIT_WW = "Whittaker and Watson, A Course of Modern Analysis, sec. 20.6"
LEAF_CAP = 40
_DEADLINE = [None]          # wall-clock deadline of the current order2_answer call (time.time() value)
_EXPLORE_CUT = []           # conditions of the strata cut by the last enumeration


def _late():
    return _DEADLINE[0] is not None and time.time() > _DEADLINE[0]


_DEG = {"E": None, "deg": None, "strata": []}   # degenerate strata of the current call (lower degree there)


def _degenerate(subs):
    """True if the substitution lowers the total degree of the equation in the jets (a degenerate stratum)"""
    if _DEG["E"] is None or not subs:
        return False
    try:
        E2 = sp.expand(sp.together(sp.sympify(_DEG["E"]).subs(subs)))
        E2 = sp.numer(sp.together(E2))
        d2 = sp.Poly(E2, w0, w1, w2).total_degree() if E2.has(w0) or E2.has(w1) or E2.has(w2) else 0
        return d2 < _DEG["deg"]
    except Exception:
        return False


def _record_degenerate(conds):
    key = tuple(conds)
    if all(tuple(x["conditions"]) != key for x in _DEG["strata"]):
        _DEG["strata"].append({"conditions": list(conds),
                               "note": "the equation has lower degree on this stratum (a coefficient of its "
                                       "top-degree part vanishes); enter the reduced equation separately"})


class _Degenerate(Exception):
    pass


def _grace():
    """deadline for the substitution checks: the call's deadline plus 20 s"""
    return None if _DEADLINE[0] is None else _DEADLINE[0] + 20.0

BASIS_LABEL = {   # basis id -> label (lemmas/order2/project note)
    "lemma:order2/C1": "published", "lemma:order2/O1": "published", "lemma:order2/O2": "published",
    "lemma:order2/O3": "agent-proof",
    "record:ORD2/Theorem-L": "agent-proof", "record:ORD2/Theorem-Q22": "published",
    "record:ORD2/Theorem-B": "agent-proof", "record:ORD2/Theorem-P": "agent-proof",
    "published:CNW2015/Lemma-4.5": "published",
}


# =============================================================================================== decision context
class Ctx(object):
    """Runs one path of the decision tree.  Tests whose value depends on the parameters are decided by the
    list `forced` (successive entries 'n' = nonzero, ('z', j) = zero with the j-th solution for a parameter),
    and generically ('n') beyond it.  Records the conditions and the parameter substitutions."""

    def __init__(self, forced=(), nonzero=()):
        self.forced = list(forced)
        self.k = 0
        self.conds = []
        self.nonzero = list(nonzero)
        self.subs = {}
        self.log = []            # [(expr, nonzero list at that moment)] for each parameter-dependent test
        self.unresolved = None
        self.notes = []          # disjunctive side conditions (words), e.g. 'not both X = 0 and Y = 0'
        self.marks = []          # number of conditions before each parameter-dependent test

    def V(self, x):
        return nice(sp.sympify(x).subs(self.subs)) if self.subs else nice(x)

    def test(self, expr):
        """True iff expr == 0 on this path."""
        if _late():
            self.unresolved = "time limit of this call"
            raise _Unresolved()
        x = self.V(expr)
        st = zero_status(x)
        if st == 'zero':
            return True
        if st == 'nonzero':
            return False
        dec = self.forced[self.k] if self.k < len(self.forced) else 'n'
        self.log.append((x, list(self.nonzero)))
        self.marks.append(len(self.conds))
        self.k += 1
        if dec == 'n':
            cs = cond_str(x, "!=")
            if cs not in self.conds:
                self.conds.append(cs)
            self.nonzero.append(x)
            return False
        sols = solve_for_param_strata(x, nonzero=self.nonzero)
        if sols is None or dec[1] >= len(sols):
            self.unresolved = "the condition %s = 0 is not solved for a parameter by this module" % sp.factor(x)
            self.conds.append(cond_str(x, "=="))
            raise _Unresolved()
        sub = sols[dec[1]]
        self._apply(sub)
        return True

    def _apply(self, sub):
        new = dict((k, nice(sp.sympify(v).subs(sub))) for k, v in self.subs.items())
        new.update(sub)
        if any(sp.sympify(v).has(sp.zoo, sp.nan, sp.oo) for v in new.values()):
            raise _Infeasible()
        self.subs = new
        self.nonzero = [nice(sp.sympify(x).subs(sub)) for x in self.nonzero]
        if any(zero_status(x) == 'zero' for x in self.nonzero):
            raise _Infeasible()
        self.nonzero += [sp.denom(sp.together(v)) for v in sub.values() if sp.denom(sp.together(v)).free_symbols]
        for k_, v_ in sub.items():
            self.conds.append("%s == %s" % (k_, v_))
        if _degenerate(self.subs):
            raise _Degenerate()


class _Infeasible(Exception):
    pass


def _ctx_test_system(self, exprs):
    """True iff all exprs vanish on this path (one decision for the whole system)."""
    if _late():
        self.unresolved = "time limit of this call"
        raise _Unresolved()
    xs = [self.V(x) for x in exprs]
    sts = [zero_status(x) for x in xs]
    if all(st == 'zero' for st in sts):
        return True
    if any(st == 'nonzero' for st in sts):
        return False
    xs = [x for x, st in zip(xs, sts) if st != 'zero']
    dec = self.forced[self.k] if self.k < len(self.forced) else 'n'
    self.log.append((tuple(xs), list(self.nonzero)))
    self.marks.append(len(self.conds))
    self.k += 1
    if dec == 'n':
        self.notes.append("not all of %s vanish" % ", ".join(str(sp.factor(x)) for x in xs))
        return False
    sols = solve_system_for_params(xs, self.nonzero)
    if sols is None or dec[1] >= len(sols):
        self.unresolved = "the system %s = 0 is not solved by this module" % [str(sp.factor(x)) for x in xs]
        for x in xs:
            self.conds.append(cond_str(x, "=="))
        raise _Unresolved()
    sub = sols[dec[1]]
    self._apply(sub)
    return True


Ctx.test_system = _ctx_test_system


def _solve_small_system(xs, nonzero):
    """sympy.solve for systems in at most two parameters (fast there); None otherwise"""
    nums = [sp.numer(sp.together(sp.sympify(x))) for x in xs]
    syms = sorted(set().union(*[n.free_symbols for n in nums]), key=str)
    if not syms or len(syms) > 2:
        return None
    try:
        sols = sp.solve(nums, syms, dict=True)
    except Exception:
        return None
    out = []
    for d in sols:
        d = dict((k, nice(v)) for k, v in d.items())
        if len(d) < len(syms):
            continue                      # an implicit (positive-dimensional) solution: not used
        if any(zero_status(sp.sympify(n).subs(d)) == 'zero' for n in nonzero):
            continue
        if any(not is_zero(sp.sympify(n).subs(d)) for n in nums):
            continue
        out.append(d)
    return out


def solve_system_for_params(xs, nonzero):
    """solutions of the polynomial system xs = 0, solved one equation at a time for one parameter each
    (solve_for_param: linear preferred, quadratic allowed); solutions that make a known nonzero expression vanish
    or a substitution singular are discarded.  None if some equation cannot be solved this way."""
    if len(xs) == 1:
        return solve_for_param(xs[0], nonzero=nonzero)
    partial = [dict()]
    for x in xs:
        nxt = []
        for sub in partial:
            xx = nice(sp.sympify(x).subs(sub)) if sub else nice(x)
            st = zero_status(xx)
            if st == 'zero':
                nxt.append(sub)
                continue
            if st == 'nonzero':
                continue
            sols = solve_for_param(xx, nonzero=[sp.sympify(n).subs(sub) for n in nonzero])
            if sols is None:
                return _solve_small_system(xs, nonzero)
            for s1 in sols:
                comp = dict((k, nice(sp.sympify(v).subs(s1))) for k, v in sub.items())
                comp.update(s1)
                if any(sp.sympify(v).has(sp.zoo, sp.nan, sp.oo) for v in comp.values()):
                    continue
                nxt.append(comp)
        partial = nxt
        if not partial:
            return []
    out = []
    for d in partial:
        if any(zero_status(sp.sympify(n).subs(d)) == 'zero' for n in nonzero):
            continue
        if any(not is_zero(sp.sympify(x).subs(d)) for x in xs):
            continue
        out.append(d)
    return out


def solve_for_param_strata(x, nonzero=None):
    """the solutions of x = 0 for one parameter (solve_for_param) followed by the strata that such a solution leaves
    out: where its denominator dn vanishes, {dn = 0 and x = 0} (solved in turn).  None if x is not solvable."""
    sols = solve_for_param(x, nonzero=nonzero)
    if not sols:
        return sols
    extra, keys = [], set()
    for sub in sols:
        keys.add(tuple(sorted((str(k), str(v)) for k, v in sub.items())))
    for sub in sols:
        for v in sub.values():
            dn = sp.denom(sp.together(sp.sympify(v)))
            if not dn.free_symbols:
                continue
            for sd in (solve_for_param(dn, nonzero=nonzero) or []):
                x2 = nice(sp.sympify(x).subs(sd))
                cands = [sd] if zero_status(x2) == 'zero' else []
                if not cands:
                    for s2 in (solve_for_param(x2, nonzero=nonzero) or []):
                        comp = dict((k, nice(sp.sympify(u).subs(s2))) for k, u in sd.items())
                        comp.update(s2)
                        cands.append(comp)
                for c_ in cands:
                    if any(sp.sympify(u).has(sp.zoo, sp.nan) for u in c_.values()):
                        continue
                    key = tuple(sorted((str(k), str(u)) for k, u in c_.items()))
                    if key not in keys:
                        keys.add(key)
                        extra.append(c_)
    return list(sols) + extra


class _Unresolved(Exception):
    pass


# =============================================================================================== the decision tree
def _coords(Ai, Aj, c, d, e, f):
    B = (c + d * Ai) / (Ai - 2 * Aj)
    be = d - B
    C = -(e + be * B) / (2 * Aj)
    return nice(B), nice(be), nice(C), nice(f + be * C)


def classify(ctx, a, b, c, d, e, f):
    """The decision tree of Theorems L, Q22, B, P (project note section 6) for
         w'' = a w^3 + b w w' + c w^2 + d w' + e w + f.
    Returns (stratum, [family specs])."""
    a, b, c, d, e, f = [sp.sympify(x) for x in (a, b, c, d, e, f)]
    V, T = ctx.V, ctx.test
    fam = []
    if T(a):
        if T(b):
            if T(c):
                return 'L', [('linear', {'b': V(d), 'c': V(e), 'd': V(f)})]
            aQ, bQ, cQ, dQ = V(c), V(d), V(e), V(f)
            if T(bQ):
                return 'Q22-ell', [('conservative', {'F': V(c * w0 ** 2 + e * w0 + f)})]
            if T(36 * bQ ** 4 - 625 * (cQ ** 2 - 4 * aQ * dQ)):
                return 'Q22-tw', [('q22twist', {'aQ': V(c), 'bQ': V(d), 'cQ': V(e), 'dQ': V(f)})]
            return 'Q22-none', []
        R = b ** 2 * e - 2 * c * (b * d + 2 * c)
        if T(R):
            if not T(c):
                return 'B-Ric (Bessel)', [('bric_exp', {'b': V(b), 'c': V(c), 'd': V(d), 'e': V(e), 'f': V(f)})]
            if not T(f):
                return 'B-Ric (Airy)', [('bric_airy', {'b': V(b), 'd': V(d), 'f': V(f)})]
            return 'B-Ric (constant coefficients)', [('bric_const', {'b': V(b), 'd': V(d)})]
        if not T(c):
            Eexp = b ** 4 * f - b ** 3 * d * e + b ** 2 * c * d ** 2 - b ** 2 * c * e + 2 * b * c ** 2 * d + c ** 3
            if T(Eexp):
                return 'B-exp', [('b_exp', {'b': V(b), 'c': V(c), 'd': V(d), 'e': V(e)})]
            return 'B-none', []
        if T(b * f - d * e):
            return 'B-lin', [('b_lin', {'b': V(b), 'e': V(e)})]
        return 'B-none', []
    # a != 0: Theorem P
    if T(b ** 2 + 8 * a):
        A = V(b / 4)
        Bc, be, Cc, r = _coords(A, A, V(c), V(d), V(e), V(f))
        if T(r):
            fam.append(('front', {'A': A, 'B': V(Bc), 'C': V(Cc), 'type': 'single type'}))
        return 'P row 1 (one pole type)', fam
    if T(b ** 2 + 9 * a):
        Ai, Aj = V(b / 3), V(b / 6)
        if T(c + d * Ai):
            # the linear equation for y has characteristic polynomial chi(lam) = lam^3 - d lam^2 - e lam + A f; it may
            # have a double or a triple root on special strata (confluent solutions: polynomial factors of exp)
            lam_ = sp.Dummy('lam')
            chi_ = sp.expand(lam_ ** 3 - V(d) * lam_ ** 2 - V(e) * lam_ + V(Ai) * V(f))
            disc_ = nice(sp.discriminant(sp.Poly(chi_, lam_)))
            spec_ = {'A': V(Ai), 'd': V(d), 'e': V(e), 'f': V(f)}
            if T(disc_):
                spec_ = {'A': V(Ai), 'd': V(d), 'e': V(e), 'f': V(f)}
                if T(V(d) ** 2 + 3 * V(e)):
                    return 'P row 2 (Cole-Hopf, triple root)', [('colehopf', dict(spec_, mult='triple'))]
                return 'P row 2 (Cole-Hopf, double root)', [('colehopf', dict(spec_, mult='double'))]
            return 'P row 2 (Cole-Hopf)', [('colehopf', dict(spec_, mult='simple'))]
        Bc, be, Cc, r = _coords(Aj, Ai, V(c), V(d), V(e), V(f))
        if T(r):
            fam.append(('front', {'A': Aj, 'B': V(Bc), 'C': V(Cc), 'type': 'index -2'}))
        return 'P row 2 (index 1 incompatible)', fam
    if T(b ** 2 - a):
        Ai, Aj = V(b), V(-b / 2)
        Bi, bei, Ci, ri = _coords(Ai, Aj, V(c), V(d), V(e), V(f))
        Bj, bej, Cj, rj = _coords(Aj, Ai, V(c), V(d), V(e), V(f))
        if T(ri):
            fam.append(('front', {'A': V(Ai), 'B': V(Bi), 'C': V(Ci), 'type': 'index 3'}))
            bF = V(2 * bei + Bi)
            cF = V(-(bei ** 2 + Bi * bei + Ai * Ci))
            if T(bF):
                fam.append(('fisher', {'A': V(Ai), 'beta': V(bei), 'aQ': V(-Ai), 'bQ': 0, 'cQ': V(cF), 'kind': 'ell'}))
            elif T(36 * bF ** 4 - 625 * cF ** 2):
                fam.append(('fisher', {'A': V(Ai), 'beta': V(bei), 'aQ': V(-Ai), 'bQ': V(bF), 'cQ': V(cF), 'kind': 'twist'}))
            if T(rj):
                fam.append(('front', {'A': V(Aj), 'B': V(Bj), 'C': V(Cj), 'type': 'index 6',
                                      'note': 'contained in the family of the Fisher correspondence'}))
            return 'P row 3 (indices 3, 6; index 3 compatible)', fam
        if T(rj):
            fam.append(('front', {'A': V(Aj), 'B': V(Bj), 'C': V(Cj), 'type': 'index 6'}))
        return 'P row 3 (indices 3, 6; index 3 incompatible)', fam
    if T(b):
        if T(d):
            return 'P row 4 (no first-derivative terms: conservative)', [('conservative', {'F': V(a * w0 ** 3 + c * w0 ** 2 + e * w0 + f)})]
        A1 = sqrt_exact(V(a / 2))
        A2 = -A1
        B1, be1, C1, r1 = _coords(A1, A2, V(c), V(d), V(e), V(f))
        B2, be2, C2, r2 = _coords(A2, A1, V(c), V(d), V(e), V(f))
        z1 = T(r1)
        z2 = T(r2)
        if z1:
            fam.append(('front', {'A': V(A1), 'B': V(B1), 'C': V(C1), 'type': 'residue %s' % V(-1 / A1)}))
        if z2:
            fam.append(('front', {'A': V(A2), 'B': V(B2), 'C': V(C2), 'type': 'residue %s' % V(-1 / A2)}))
        if z1 and z2:
            for sp_ in fam:
                if sp_[0] == 'front':
                    sp_[1]['note'] = 'the member k = 0 of the twisted family below'
            fam.append(('duffing_twist', {'a': V(a), 'c': V(c), 'd': V(d)}))
            return 'P row 4 (no w w\' term; exponential change of variable)', fam
        return 'P row 4 (no w w\' term)', fam
    s = sqrt_exact(V(b ** 2 + 8 * a))
    A1, A2 = V((V(b) + s) / 4), V((V(b) - s) / 4)
    B1, be1, C1, r1 = _coords(A1, A2, V(c), V(d), V(e), V(f))
    if T(r1):
        fam.append(('front', {'A': V(A1), 'B': V(B1), 'C': V(C1), 'type': 'residue %s' % V(-1 / A1)}))
    A1, A2 = V(A1), V(A2)
    B2, be2, C2, r2 = _coords(A2, A1, V(c), V(d), V(e), V(f))
    if T(r2):
        fam.append(('front', {'A': V(A2), 'B': V(B2), 'C': V(C2), 'type': 'residue %s' % V(-1 / A2)}))
    aa, bb, cc, dd = V(a), V(b), V(c), V(d)
    kap = (bb * cc - 3 * aa * dd) / (bb ** 2 + 9 * aa)
    if not T(kap):
        aa, bb, cc, dd = V(a), V(b), V(c), V(d)
        kap = V((bb * cc - 3 * aa * dd) / (bb ** 2 + 9 * aa))
        sig = V(-(5 * bb * cc + (bb ** 2 - 6 * aa) * dd) / (bb * (bb ** 2 + 9 * aa)))
        cp = V(kap * (bb ** 2 - 6 * aa) / bb)
        if ctx.test_system([e - (3 * aa * sig ** 2 - 2 * cp * sig - 6 * kap ** 2),
                            f - (-aa * sig ** 3 + cp * sig ** 2 + 6 * kap ** 2 * sig)]):
            if True:
                aa, bb, cc, dd = V(a), V(b), V(c), V(d)
                kap = V((bb * cc - 3 * aa * dd) / (bb ** 2 + 9 * aa))
                sig = V(-(5 * bb * cc + (bb ** 2 - 6 * aa) * dd) / (bb * (bb ** 2 + 9 * aa)))
                s2 = sqrt_exact(V(b ** 2 + 8 * a))
                fam.append(('twopole', {'A1': V((V(b) + s2) / 4), 'A2': V((V(b) - s2) / 4),
                                        'sigma': V(sig), 'kappa': V(kap)}))
    q = V(b ** 2 / a)
    row = 'P rows 5-6 (two pole types)'
    if q.is_Rational and q > 0:
        k = sp.Dummy('k')
        for kk in sp.solve(k ** 2 - (4 + q) * k + 4, k):
            if kk.is_Integer and kk >= 3 and kk != 4:
                row = 'P row 5 (Fuchs indices %s and %s)' % (kk + 2, 2 + sp.Rational(4, kk))
    return row, fam


# =============================================================================================== families
def _sol_meta(sol, origin, citations, conds, subs, basis):
    sol["origin"] = origin
    sol["citations"] = list(citations)
    merged = []
    for c_ in list(conds) + list(sol["conditions"]):
        if c_ not in merged:
            merged.append(c_)
    sol["conditions"] = merged
    if subs:
        own = sol.get("_subs") or {}
        new = dict((k, nice(sp.sympify(v).subs(own))) for k, v in subs.items())
        new.update(own)
        sol["_subs"] = new
        if any(sp.sympify(v).has(sp.zoo, sp.nan, sp.oo) for v in new.values()):
            sol["_drop"] = True        # the family's own condition is singular on this stratum: empty
    sol["basis"] = basis
    return sol


def fam_linear(b, c, d):
    """w'' = b w' + c w + d: all solutions (entire)."""
    C1, C2 = aux('C1'), aux('C2')
    out = []
    if is_zero(c):
        if is_zero(b):
            t = sp.Dummy('t')
            car = Carrier({t: 1}, display={t: z})
            out.append(make_solution("polynomial", 1 if not is_zero(d) else 1, C1 + C2 * t + d * t ** 2 / 2, car,
                                     constants={'C1': 'free', 'C2': 'free'}, free=['C1', 'C2'], pole_orders=[],
                                     note="all solutions"))
            return out
        S = sp.Dummy('S')
        t = sp.Dummy('t')
        car = Carrier({S: b * S, t: 1}, display={S: sp.exp(b * z), t: z})
        out.append(make_solution("entire", 2 if not is_zero(d) else 1, C1 + C2 * S - d * t / b, car,
                                 constants={'C1': 'free', 'C2': 'free'}, free=['C1', 'C2'], pole_orders=[],
                                 note="all solutions; d = 2 when C2*d != 0 (z and exp(b z) independent)"))
        return out
    Delta = nice(b ** 2 + 4 * c)
    if is_zero(Delta):
        lam = nice(b / 2)
        S, t = sp.Dummy('S'), sp.Dummy('t')
        car = Carrier({S: lam * S, t: 1}, display={S: sp.exp(lam * z), t: z})
        out.append(make_solution("entire", 2, -d / c + (C1 + C2 * t) * S, car, constants={'C1': 'free', 'C2': 'free'},
                                 free=['C1', 'C2'], pole_orders=[], note="all solutions; d = 2 when C2 != 0"))
        return out
    sq = sqrt_exact(Delta)
    l1, l2 = nice((b + sq) / 2), nice((b - sq) / 2)
    S1, S2 = sp.Dummy('S1'), sp.Dummy('S2')
    car = Carrier({S1: l1 * S1, S2: l2 * S2}, display={S1: sp.exp(l1 * z), S2: sp.exp(l2 * z)})
    ratio = nice(l1 / l2)
    if ratio.free_symbols:
        dd, note = None, "d = 2 iff lambda1/lambda2 = %s is irrational (C1*C2 != 0)" % ratio
    elif ratio.is_Rational:
        dd, note = 1, "lambda1/lambda2 = %s is rational: rational in one exponential (class W)" % ratio
    else:
        dd, note = 2, "lambda1/lambda2 = %s is irrational: d = 2 when C1*C2 != 0 (not in W)" % ratio
    sol = make_solution("entire", dd if dd is not None else 2, -d / c + C1 * S1 + C2 * S2, car,
                        constants={'C1': 'free', 'C2': 'free'}, free=['C1', 'C2'], pole_orders=[],
                        note="all solutions; " + note + ("; " + COMMENSURABLE if dd is None else ""))
    sol["d_note"] = note
    out.append(sol)
    return out


def _root_items(F):
    """[(r, alg)] for the roots of F: r explicit for linear factors (alg None); a symbol r_k with alg = q(r_k)
    for an irreducible factor q of degree >= 2 (one item for all roots of q)."""
    items = []
    try:
        facs = factor_list_x(F, w0)[1]
    except Exception:
        facs = [(F, 1)]
    k = 0
    for fac, mult in facs:
        fp = sp.Poly(fac, w0)
        if fp.degree() < 1:
            continue
        if fp.degree() == 1:
            items.append((nice(-fp.coeff_monomial(1) / fp.LC()), None, mult))
        elif fp.degree() == 2:
            for rr in sp.roots(fp, multiple=True):
                items.append((nice(rr), None, mult))
        else:
            k += 1
            r = aux('r%d' % k)
            items.append((r, sp.expand(fac.subs(w0, r)), mult))
    return items


def _alg_status(x, alg):
    """zero test of x modulo the algebraic relations alg = {r: m(r)}"""
    x = sp.sympify(x)
    num = sp.numer(sp.together(x))
    for r, m in alg.items():
        if num.has(r):
            num = sp.rem(sp.Poly(sp.expand(num), r), sp.Poly(m, r)).as_expr()
    return zero_status(num)


def fam_conservative(F, conds=(), subs=None, origin='live:order2', basis="lemma:order2/C1"):
    """w'' = F(w), deg F = 2 or 3: all nonconstant solutions (statement C1).  Returns list of Solutions."""
    F = sp.expand(F)
    n = sp.Poly(F, w0).degree()
    G = sp.integrate(F, w0)
    sols = []
    k, g3s = aux('k'), aux('g3')
    cit = [CIT_WW, "classical: first integral w'^2 = 2 G(w) + C"]
    if n == 2:
        p2 = sp.Poly(F, w0).LC()
        p1 = sp.Poly(F, w0).coeff_monomial(w0)
        p0 = sp.Poly(F, w0).coeff_monomial(1)
        alpha = nice(6 / p2)
        beta = nice(-p1 / (2 * p2))
        Cs = sp.Dummy('C')
        _a, _b, g2, g3C = _wp_invariants_cubic(sp.expand(2 * G + Cs))
        (t, P, Q), car = carrier_wp(g2, g3s, 't')
        s = make_solution("elliptic", 1, alpha * P + beta, car, constants={str(g3s): 'free'},
                          free=['z0', 'g3'], ppp=1, pole_orders=[2],
                          note="all nonconstant solutions (first integral w'^2 = 2G(w) + C); degenerate wp for g2^3 = 27 g3^2")
        sols.append(_sol_meta(s, origin, cit, conds, subs, basis))
    elif n == 3:
        f = sp.expand(2 * G + k ** 2)
        wexpr, g2, g3, car = weierstrass_quartic(f, sp.Integer(0), k)
        s = make_solution("elliptic", 1, wexpr, car, constants={'k': 'free; C = k^2 is the energy, w(z0) = 0'},
                          free=['z0', 'k'], ppp=2, pole_orders=[1],
                          note="all nonconstant solutions with a non-degenerate first integral w'^2 = 2G(w) + k^2 "
                               "(Weierstrass's formula); the degenerate energies are listed separately")
        sols.append(_sol_meta(s, origin, cit, conds, subs, basis))
    else:
        return sols
    # degenerate energies C_r = -2 G(r), r a root of F: w = r + 1/u, u'^2 = H(u) of degree <= 2
    for r, alg, mult in _root_items(F):
        Fr = [sp.diff(F, w0, j).subs(w0, r) for j in range(4)]
        Au, Bu, Cu = nice(Fr[1]), nice(Fr[2] / 3), nice(Fr[3] / 12)      # H(u) = Au u^2 + Bu u + Cu
        alg_d = {r: alg} if alg is not None else {}
        st = (lambda x: _alg_status(x, alg_d)) if alg is not None else zero_status
        K = aux('K')
        rnote = ("r = %s" % r) if alg is None else ("%s = any root of %s = 0" % (r, alg))
        consts = {} if alg is None else {str(r): 'any root of %s = 0' % alg}
        if st(Au) != 'zero':
            Du = nice(Bu ** 2 - 4 * Au * Cu)
            if st(Du) != 'zero':
                lam = sqrt_exact(Au)
                S = sp.Dummy('S')
                car = Carrier({S: lam * S}, display={S: sp.exp(lam * z)}, alg=alg_d)
                u = -Bu / (2 * Au) + K * S + Du / (16 * Au ** 2 * K * S)
                kind = "simply-periodic"
                note = ("energy C = -2G(r), %s: w = r + 1/u with u'^2 = %s u^2 + %s u + %s (a soliton or a "
                        "trigonometric wave)" % (rnote, Au, Bu, Cu))
                ppp = 2 if st(Cu) != 'zero' else 1
                s = make_solution(kind, 1, r + 1 / u, car, constants=dict(consts, K='free, nonzero'), free=['K'],
                                  ppp=ppp, pole_orders=[1] if st(Cu) != 'zero' else [2], note=note)
                sols.append(_sol_meta(s, origin, cit, conds, subs, basis))
            if st(Du) == 'zero':
                # u'^2 = Au (u - u1)^2: u = u1 + K exp(+-sqrt(Au) z): a kink
                u1 = nice(-Bu / (2 * Au))
                for sg in (1, -1):
                    lam = nice(sg * sqrt_exact(Au))
                    S = sp.Dummy('S')
                    car = Carrier({S: lam * S}, display={S: sp.exp(lam * z)}, alg=alg_d)
                    s = make_solution("simply-periodic", 1, r + 1 / (u1 + K * S), car,
                                      constants=dict(consts, K='free, nonzero'), free=['K'], ppp=1, pole_orders=[1],
                                      note="energy C = -2G(r), %s: 2G(w) + C is a square; a kink (tanh type)" % rnote)
                    sols.append(_sol_meta(s, origin, cit, conds, subs, basis))
        else:
            t = sp.Dummy('t')
            car = Carrier({t: 1}, display={t: z - aux('z0')}, alg=alg_d)
            if st(Bu) != 'zero':
                u = Bu * t ** 2 / 4 - Cu / Bu
                s = make_solution("rational", 1, r + 1 / u, car, constants=consts, free=['z0'],
                                  pole_orders=[2] if st(Cu) == 'zero' else [1],
                                  note="energy C = -2G(r), %s a double root of F" % rnote)
            else:
                # u'^2 = Cu: u = +- sqrt(Cu) t -- two families (residues +- 1/sqrt(Cu)), both listed
                for sg in (1, -1):
                    u = sg * sqrt_exact(Cu) * t
                    s = make_solution("rational", 1, r + 1 / u, car, constants=consts, free=['z0'], pole_orders=[1],
                                      note="energy C = -2G(r), %s a triple root of F; residue %s"
                                           % (rnote, nice(1 / (sg * sqrt_exact(Cu)))))
                    sols.append(_sol_meta(s, origin, cit, conds, subs, basis))
                continue
            sols.append(_sol_meta(s, origin, cit, conds, subs, basis))
    return sols


def degenerate_root_families(r, alg, Au, Bu, Cu, origin, cit, conds, subs, basis, note):
    """w = r + 1/u with u'^2 = Au u^2 + Bu u + Cu (r a double root of the right side of w'^2 = R(w)); r explicit
    (alg None) or a symbol with alg = q(r), q(r) = 0.  A square root of an expression in r is introduced as a new
    algebraic constant (lam with lam^2 = Au), so that the substitution check stays exact."""
    out = []
    alg_d = {r: alg} if alg is not None else {}
    st = (lambda x: _alg_status(x, alg_d)) if alg is not None else zero_status
    K = aux('K')
    consts = {} if alg is None else {str(r): 'any root of %s = 0' % alg}

    def root_of(val, name):
        """sqrt(val): explicit if val is free of r, else a new algebraic constant"""
        if alg is None or not sp.sympify(val).has(r):
            return sqrt_exact(val), {}, {}
        lam = aux(name)
        return lam, {lam: sp.expand(lam ** 2 - val)}, {str(lam): 'any root of %s = 0' % sp.expand(lam ** 2 - val)}

    if st(Au) != 'zero':
        Du = nice(Bu ** 2 - 4 * Au * Cu)
        if st(Du) != 'zero':
            lam, alg2, c2 = root_of(Au, 'lam')
            S = sp.Dummy('S')
            ad = dict(alg2)                     # reduce by lam first, then by r
            ad.update(alg_d)
            car = Carrier({S: lam * S}, display={S: sp.exp(lam * z)}, alg=ad)
            u = -Bu / (2 * Au) + K * S + Du / (16 * Au ** 2 * K * S)
            cc = dict(consts)
            cc.update(c2)
            cc[str(K)] = 'free; nonzero'
            s_ = make_solution("simply-periodic", 1, r + 1 / u, car, constants=cc,
                               free=[str(K)], ppp=2 if st(Cu) != 'zero' else 1,
                               pole_orders=[1] if st(Cu) != 'zero' else [2], note=note)
            out.append(_sol_meta(s_, origin, cit, conds, subs, basis))
        else:
            u1 = nice(-Bu / (2 * Au))
            lam0, alg2, c2 = root_of(Au, 'lam')
            for sg in (1, -1):
                lam = sg * lam0
                S = sp.Dummy('S')
                ad = dict(alg2)
                ad.update(alg_d)
                car = Carrier({S: lam * S}, display={S: sp.exp(lam * z)}, alg=ad)
                cc = dict(consts)
                cc.update(c2)
                cc[str(K)] = 'free; nonzero'
                s_ = make_solution("simply-periodic", 1, r + 1 / (u1 + K * S), car, constants=cc, free=[str(K)],
                                   ppp=1, pole_orders=[1], note=note + "; a kink")
                out.append(_sol_meta(s_, origin, cit, conds, subs, basis))
    else:
        t = sp.Dummy('t')
        if st(Bu) != 'zero':
            car = Carrier({t: 1}, display={t: z - aux('z0')}, alg=alg_d)
            u = Bu * t ** 2 / 4 - Cu / Bu
            s_ = make_solution("rational", 1, r + 1 / u, car, constants=consts, free=['z0'],
                               pole_orders=[2] if st(Cu) == 'zero' else [1], note=note)
            out.append(_sol_meta(s_, origin, cit, conds, subs, basis))
        elif st(Cu) != 'zero':
            c0, alg2, c2 = root_of(Cu, 'mu')
            ad = dict(alg2)                     # reduce by lam first, then by r
            ad.update(alg_d)
            car = Carrier({t: 1}, display={t: z - aux('z0')}, alg=ad)
            for sg in (1, -1):
                u = sg * c0 * t
                cc = dict(consts)
                cc.update(c2)
                s_ = make_solution("rational", 1, r + 1 / u, car, constants=cc, free=['z0'], pole_orders=[1],
                                   note=note)
                out.append(_sol_meta(s_, origin, cit, conds, subs, basis))
    return out


def double_root_levels(Rk, K, origin, cit, conds, subs, basis):
    """the levels K at which R_K = K r1(w) + r0(w) has a multiple root r: r runs over the roots of
    W(r) = r0(r) r1'(r) - r1(r) r0'(r) (explicit for linear factors, a symbol with its minimal polynomial
    otherwise), K = -r0(r)/r1(r); the families there are built at the double root.  Returns (families, notes)
    or None if W vanishes identically (a multiple root for every K)."""
    PR = sp.Poly(sp.expand(Rk), w0)
    r1 = sp.expand(sp.diff(Rk, K))
    r0 = sp.expand(Rk - K * r1)
    rr = sp.Dummy('rr')
    Wr = sp.expand(r0.subs(w0, rr) * sp.diff(r1, w0).subs(w0, rr) - r1.subs(w0, rr) * sp.diff(r0, w0).subs(w0, rr))
    if Wr == 0:
        return None
    out, notes = [], []
    kk = 0
    for fac, _m in factor_list_x(Wr, rr)[1]:
        fp = sp.Poly(fac, rr)
        if fp.degree() < 1:
            continue
        if fp.degree() == 1:
            items = [(nice(-fp.coeff_monomial(1) / fp.LC()), None)]
        else:
            kk += 1
            sym = aux('r%d' % kk)
            items = [(sym, sp.expand(fac.subs(rr, sym)))]
        for r, alg in items:
            r1r = r1.subs(w0, r)
            st = (lambda x: _alg_status(x, {r: alg})) if alg is not None else zero_status
            if st(r1r) == 'zero':
                continue
            Kr = sp.cancel(-r0.subs(w0, r) / r1r)
            Rr = sp.expand(Kr * r1 + r0)
            Au = nice(sp.diff(Rr, w0, 2).subs(w0, r) / 2)
            Bu = nice(sp.diff(Rr, w0, 3).subs(w0, r) / 6)
            Cu = nice(sp.diff(Rr, w0, 4).subs(w0, r) / 24)
            if alg is not None:
                red = lambda x: sp.rem(sp.Poly(sp.numer(sp.together(x)), r), sp.Poly(alg, r)).as_expr() / \
                    sp.rem(sp.Poly(sp.denom(sp.together(x)), r), sp.Poly(alg, r)).as_expr() \
                    if sp.denom(sp.together(x)).has(r) else sp.rem(sp.Poly(sp.numer(sp.together(x)), r), sp.Poly(alg, r)).as_expr() / sp.denom(sp.together(x))
                try:
                    Au, Bu, Cu = red(Au), red(Bu), red(Cu)
                except Exception:
                    pass
            note = "special level K = %s (a double root %s of R_K)" % (Kr, r if alg is None else "%s, %s = 0" % (r, alg))
            fams_ = degenerate_root_families(r, alg, Au, Bu, Cu, origin, cit, conds, subs, basis, note)
            if alg is not None:
                for f_ in fams_:
                    f_["_heavy_alg"] = True          # nested algebraic constants: not certified (time), see finalize
            out += fams_
    return out, notes


def q22_ell_W(aQ, cQ, dQ, g3s):
    """W'' = aQ W^2 + cQ W + dQ: W = -cQ/(2 aQ) + (6/aQ) wp(z - z0; g2, g3), g2 = (cQ^2 - 4 aQ dQ)/12"""
    g2 = nice((cQ ** 2 - 4 * aQ * dQ) / 12)
    (t, P, Q), car = carrier_wp(g2, g3s, 't')
    return -cQ / (2 * aQ) + 6 * P / aQ, car, g2


def q22_twist_W(aQ, bQ, cQ, g3s, member0=False):
    """W'' = aQ W^2 + bQ W' + cQ W + dQ on 36 bQ^4 = 625 (cQ^2 - 4 aQ dQ):
       W = sigma + (6 kappa^2/aQ) S^2 wp(S - zeta0; 0, g3), S = exp(kappa z), kappa = bQ/5,
       sigma = -(cQ + 6 kappa^2)/(2 aQ).  member0: the member g3 = 0 (wp = 1/(S - zeta0)^2)."""
    kap = nice(bQ / 5)
    sig = nice(-(cQ + 6 * kap ** 2) / (2 * aQ))
    if member0:
        S = sp.Dummy('S')
        zeta0 = aux('zeta0')
        car = Carrier({S: kap * S}, display={S: sp.exp(kap * z)})
        return sig + 6 * kap ** 2 / aQ * S ** 2 / (S - zeta0) ** 2, car, kap, sig
    (S, P, Q), car = carrier_wp(0, g3s, 'exp', lam=kap)
    return sig + 6 * kap ** 2 / aQ * S ** 2 * P, car, kap, sig


_BUILD_ND = []            # not-decided items produced while building families (collected by answer_q21)


def build_family(spec, conds, subs):
    """closed forms for one family spec of the decision tree"""
    kind, p = spec
    out = []
    g3s = aux('g3')
    if kind == 'linear':
        for s in fam_linear(p['b'], p['c'], p['d']):
            out.append(_sol_meta(s, REC + " Theorem L", ["classical (linear equation with constant coefficients)"],
                                 conds, subs, "record:ORD2/Theorem-L"))
    elif kind == 'conservative':
        F = p['F']
        n = sp.Poly(F, w0).degree()
        org = REC + (" Theorem Q22(1)" if n == 2 else " Theorem P(4)")
        if sp.expand(F).free_symbols - {w0}:
            nzc = []
            for c_ in conds:
                if " != " in c_:
                    try:
                        nzc.append(S_(c_.split(" != ")[0]))
                    except Exception:
                        pass
            for (Fl, cl, sl, unres) in conservative_leaves(F, conds, subs, depth=3, nonzero=nzc):
                if unres:
                    _BUILD_ND.append({"what": "the parameter locus %s" % " and ".join(cl), "conditions": list(cl),
                                      "why": unres, "partial": "substitute parameter values on this locus and call again"})
                    continue
                fams, _ = conservative_families(Fl, cl, sl, org)
                out += fams
        else:
            out += fam_conservative(F, conds, subs, origin=org, basis="lemma:order2/C1")
    elif kind == 'q22twist':
        aQ, bQ, cQ = p['aQ'], p['bQ'], p['cQ']
        W, car, kap, sig = q22_twist_W(aQ, bQ, cQ, g3s)
        s = make_solution("other", 2, W, car, constants={'g3': 'free', 'zeta0': 'free'}, free=['zeta0', 'g3'],
                          ppp=None, pole_orders=[2],
                          note="all nonconstant solutions; for g3 != 0 not in W (d = 2: exponentially many poles); "
                               "kappa = %s, sigma = %s" % (kap, sig))
        out.append(_sol_meta(s, REC + " Theorem Q22(2); atlas:ORD2-P222-TWIST", [CIT_AZ, CIT_CNW15], conds, subs,
                             "record:ORD2/Theorem-Q22"))
        W0, car0, _, _ = q22_twist_W(aQ, bQ, cQ, g3s, member0=True)
        s0 = make_solution("simply-periodic", 1, W0, car0, constants={'zeta0': 'free'}, free=['zeta0'], ppp=1,
                           pole_orders=[2], note="the member g3 = 0 of the previous family: rational in exp(%s z) "
                                                 "(class W); the same function as the front of the Fisher equation at "
                                                 "the speed 5/sqrt(6), after an affine change of variables" % kap)
        out.append(_sol_meta(s0, REC + " Theorem Q22(2); atlas:ORD2-P222-TWIST", [CIT_AZ, CIT_CNW15], conds, subs,
                             "record:ORD2/Theorem-Q22"))
    elif kind == 'front':
        ss, _special = riccati_solutions(p['A'], p['B'], p['C'], origin=REC + " Theorem P(1); atlas:ORD2-P231-FRONT")
        for s in ss:
            s["note"] = ("front w' = (%s) w^2 + (%s) w + (%s) (pole type: %s). " % (p['A'], p['B'], p['C'], p['type'])
                         + s.get("note", "") + ((" " + p['note']) if p.get('note') else ""))
            out.append(_sol_meta(s, s["origin"], [CIT_NW19], conds, subs, "record:ORD2/Theorem-P"))
    elif kind == 'colehopf':
        out += fam_colehopf(p['A'], p['d'], p['e'], p['f'], conds, subs, mult=p.get('mult'))
    elif kind == 'fisher':
        A, be = p['A'], p['beta']
        if p['kind'] == 'ell':
            W, car, g2 = q22_ell_W(p['aQ'], p['cQ'], 0, g3s)
            members = [(W, car, "elliptic", 1, {'g3': 'free'}, ['z0', 'g3'], 3,
                        "all solutions with w_i != 0: v = (beta - W'/W)/A, W = %s" % sp.sympify(W).subs(car.display))]
        else:
            W, car, kap, sig = q22_twist_W(p['aQ'], p['bQ'], p['cQ'], g3s)
            W0, car0, _, _ = q22_twist_W(p['aQ'], p['bQ'], p['cQ'], g3s, member0=True)
            members = [(W, car, "other", 2, {'g3': 'free', 'zeta0': 'free'}, ['zeta0', 'g3'], None,
                        "all solutions with w_i != 0 (Fisher correspondence with a twisted (2,2,2) equation); "
                        "d = 2 for g3 != 0"),
                       (W0, car0, "simply-periodic", 1, {'zeta0': 'free'}, ['zeta0'], 2,
                        "member g3 = 0 of the previous family (class W)")]
        for (Wx, cr, kd, dd, consts, free, ppp, note) in members:
            v = (be - cr.deriv(Wx) / Wx) / A
            s = make_solution(kd, dd, sp.together(v), cr, constants=consts, free=free, ppp=ppp, pole_orders=[1],
                              note=note)
            out.append(_sol_meta(s, REC + " Theorem P(3); atlas:ORD2-P231-FISHER-*", [CIT_NW19], conds, subs,
                                 "record:ORD2/Theorem-P"))
    elif kind == 'duffing_twist':
        a, c, d = p['a'], p['c'], p['d']
        kap = nice(d / 3)
        sh = nice(-c / (3 * a))
        pp = nice(a / (2 * kap ** 2))
        kk = aux('k')
        (S, P, Q), car = carrier_wp(nice(pp * kk ** 2), 0, 'exp', lam=kap)
        X = kk * Q / (2 * P ** 2 - pp * kk ** 2 / 2)
        s = make_solution("other", 2, sh + S * X, car, constants={'k': 'free', 'zeta0': 'free'}, free=['zeta0', 'k'],
                          pole_orders=[1],
                          note="all solutions: w = s + zeta X(zeta), zeta = exp(%s z), X_zeta^2 = %s X^4 + k^2; "
                               "d = 2 for k != 0 (k = 0: the fronts)" % (kap, pp))
        out.append(_sol_meta(s, REC + " Theorem P(4); atlas:ORD2-P231-DUFFING-TWIST", [CIT_CNW15], conds, subs,
                             "record:ORD2/Theorem-P"))
    elif kind == 'twopole':
        A1, A2, sig, kap = p['A1'], p['A2'], p['sigma'], p['kappa']
        S, K = sp.Dummy('S'), aux('K')
        car = Carrier({S: kap * S}, display={S: sp.exp(kap * z)})
        v = sig + kap * (1 / (K * S + A1) - 1 / (K * S - A2))
        s = make_solution("simply-periodic", 1, v, car, constants={'K': 'free, nonzero (K = exp(-kappa z0))'},
                          free=['K'], ppp=2, pole_orders=[1, 1],
                          note="two-pole wave: one pole of each residue per period (not a Riccati front)")
        out.append(_sol_meta(s, REC + " Theorem P(5); atlas:ORD2-P231-TWOPOLE", [], conds, subs,
                             "record:ORD2/Theorem-P"))
    elif kind == 'b_exp':
        b, c, d, e = p['b'], p['c'], p['d'], p['e']
        g0 = nice((c ** 2 + b * c * d - b ** 2 * e) / b ** 2)
        S, K0 = sp.Dummy('S'), aux('K0')
        car = Carrier({S: -c / b * S}, display={S: sp.exp(-c * z / b)})
        s = make_solution("entire", 1, g0 / c + K0 * S, car, constants={'K0': 'free'}, free=['K0'], ppp=0,
                          pole_orders=[], note="entire solutions; no solution has a pole (index 2 incompatible)")
        out.append(_sol_meta(s, REC + " Theorem B(2); atlas:ORD2-Q21-BND-EXP", [CIT_NW19], conds, subs,
                             "record:ORD2/Theorem-B"))
    elif kind == 'b_lin':
        b, e = p['b'], p['e']
        t, K0 = sp.Dummy('t'), aux('K0')
        car = Carrier({t: 1}, display={t: z})
        s = make_solution("polynomial", 1, -e / b * t + K0, car, constants={'K0': 'free'}, free=['K0'],
                          pole_orders=[], note="entire solutions; no solution has a pole")
        out.append(_sol_meta(s, REC + " Theorem B(2); atlas:ORD2-Q21-BND-LIN", [], conds, subs,
                             "record:ORD2/Theorem-B"))
    elif kind == 'bric_const':
        b, d = p['b'], p['d']
        K0 = aux('K0')
        ss, _ = riccati_solutions(b / 2, d, K0)
        for s in ss:
            s["note"] = ("all solutions: w' = (b/2) w^2 + d w + K0, K0 free (first integral J = w' - (b/2) w^2 - d w). "
                         + s.get("note", ""))
            s["constants"]["K0"] = "free"
            out.append(_sol_meta(s, REC + " Theorem B(1); atlas:ORD2-Q21-BND-RICCONST", [], conds, subs,
                                 "record:ORD2/Theorem-B"))
    elif kind == 'bric_exp':
        out += fam_bessel(p, conds, subs)
    elif kind == 'bric_airy':
        out += fam_airy(p, conds, subs)
    return out


COMMENSURABLE = ("d = 2 for generic values of the parameters; where the differences of the exponents are "
                 "commensurable the function is simply periodic (d = 1)")


def fam_colehopf(A, d, e, f, conds, subs, mult=None):
    """w = -y'/(A y), where y solves the third-order linear equation with characteristic polynomial
    chi(lam) = lam^3 - d lam^2 - e lam + A f: all solutions.  `mult`: 'simple' (generic, distinct roots of chi),
    'double' (a double root mu and a simple root nu), 'triple' (chi = (lam - d/3)^3); the confluent cases give
    polynomial factors of the exponentials.  Kind and d are computed from the roots."""
    lam = sp.Dummy('lam')
    chi = sp.expand(lam ** 3 - d * lam ** 2 - e * lam + A * f)
    roots = []
    alg = {}
    if mult == 'triple':
        roots = [(nice(d / 3), 3)]
    elif mult == 'double':
        g = gcd_x(sp.Poly(chi, lam), sp.Poly(sp.diff(chi, lam), lam))
        if g.degree() != 1:
            raise ValueError("double root not rational on this stratum")
        mu = nice(-g.coeff_monomial(1) / g.LC())
        roots = [(mu, 2), (nice(d - 2 * mu), 1)]
    else:
        try:
            facs = factor_list_x(chi, lam)[1]
        except Exception:
            facs = [(chi, 1)]
        k = 0
        for fac, m_ in facs:
            fp = sp.Poly(fac, lam)
            if fp.degree() == 1:
                roots.append((nice(-fp.coeff_monomial(1) / fp.LC()), m_))
            elif fp.degree() == 2:
                for r in sp.roots(fp, multiple=True):
                    roots.append((nice(r), m_))
            else:
                for _j in range(fp.degree()):
                    k += 1
                    sym = aux('lambda%d' % k)
                    alg[sym] = sp.expand(fac.subs(lam, sym))
                    roots.append((sym, m_))
    D, disp, y, consts, free = {}, {}, sp.Integer(0), {}, []
    t = sp.Dummy('t')
    D[t] = 1
    disp[t] = z
    idx = 0
    for j, (r, m_) in enumerate(roots):
        S = sp.Dummy('S%d' % (j + 1))
        D[S] = r * S
        disp[S] = sp.exp(r * z)
        poly = sp.Integer(0)
        for m in range(m_):
            idx += 1
            Cc = aux('C%d' % idx)
            poly += Cc * t ** m
            consts[str(Cc)] = 'free'
            free.append(str(Cc))
        y += poly * S
    car = Carrier(D, display=disp, alg=alg)
    v = -car.deriv(y) / (A * y)
    for sym, m in alg.items():
        consts[str(sym)] = 'any root of %s = 0' % m
    # kind and d from the roots (exp(lam0 z) cancels in the logarithmic derivative when there is one exponent)
    distinct = [r for r, _ in roots]
    confluent = any(m_ > 1 for _, m_ in roots)
    if len(distinct) == 1:
        kind, dd, dnote = "rational", 1, "chi has a triple root: w is a rational function of z"
    elif len(distinct) == 2:
        kind, dd = "other", 2
        dnote = ("chi has a double root: w involves z and exp((%s) z); d = 2 when both the coefficient of z in the "
                 "polynomial factor and the coefficient of the other exponential are nonzero; the members without z "
                 "are simply periodic" % nice(distinct[1] - distinct[0]))
    elif alg:
        kind, dd = "other", 2
        dnote = "the exponents are the three roots of chi; d = 2 unless their differences are rationally dependent"
    else:
        r1_, r2_, r3_ = distinct
        q_ = nice((r1_ - r3_) / (r2_ - r3_)) if not is_zero(r2_ - r3_) else None
        if q_ is not None and not q_.free_symbols and q_.is_Rational:
            kind, dd = "simply-periodic", 1
            dnote = "the exponent differences are rationally dependent (ratio %s): rational in one exponential" % q_
        elif q_ is not None and q_.free_symbols:
            kind, dd = "other", 2
            dnote = "d = 2 iff (lambda1 - lambda3)/(lambda2 - lambda3) = %s is irrational" % q_
        else:
            kind, dd = "other", 2
            dnote = "the ratio of the exponent differences is irrational: d = 2"
    s = make_solution(kind, dd, sp.together(v), car, constants=consts, free=free, pole_orders=[1],
                      note="all solutions (Cole-Hopf: y = exp(-A int w) solves the linear equation y''' = %s y'' + %s y' "
                           "- %s y); the exponents lambda1, lambda2, lambda3 (when they are given as roots) are the "
                           "three distinct roots of its characteristic polynomial, one each%s"
                           % (d, e, nice(A * f), "; confluent roots give polynomial factors" if confluent else ""))
    s["d_note"] = dnote
    if dd == 2:
        s["note"] = s.get("note", "") + "; " + COMMENSURABLE
    return [_sol_meta(s, REC + " Theorem P(2); atlas:ORD2-P231-COLEHOPF", [], conds, subs, "record:ORD2/Theorem-P")]


def _identity_cert(checks):
    ok = all(c[1] for c in checks)
    return {"type": "identity", "method": "symbolic", "status": "pass" if ok else "fail",
            "detail": "; ".join("%s: %s" % (c[0], "0 identically" if c[1] else "NONZERO") for c in checks)}


def fam_bessel(p, conds, subs):
    """Theorem B(1), c != 0: (D + sigma)(w' - (b/2) w^2 - mu w - nu) = E."""
    b, c, d, e, f = p['b'], p['c'], p['d'], p['e'], p['f']
    sig = nice(2 * c / b)
    mu = nice(d + sig)
    nu = nice(f / sig)
    out = []
    # (i) K0 = 0: Riccati with constant coefficients (class W)
    ss, _ = riccati_solutions(b / 2, mu, nu)
    for s in ss:
        s["note"] = "member K0 = 0: the front w' = (b/2) w^2 + mu w + nu (class W). " + s.get("note", "")
        out.append(_sol_meta(s, REC + " Theorem B(1); atlas:ORD2-Q21-BND-BESSEL", [CIT_NW19], conds, subs,
                             "record:ORD2/Theorem-B"))
    # (ii) K0 != 0: Bessel functions
    K0, x0, C1, C2 = aux('K0'), aux('x0'), aux('C1'), aux('C2')
    nuB2 = nice((mu ** 2 - 2 * b * nu) / sig ** 2)
    x0val = 2 * b * K0 / sig ** 2
    nuB = sqrt_exact(nuB2)
    X = x0 * sp.exp(-sig * z / 2)
    phi = sp.exp(mu * z / 2) * (C1 * sp.besselj(nuB, X) + C2 * sp.bessely(nuB, X))
    expr = -2 / b * sp.diff(phi, z) / phi
    # certificate: three exact identities
    J = w1 - b / 2 * w0 ** 2 - mu * w0 - nu
    DJ = sp.diff(J, w0) * w1 + sp.diff(J, w1) * w2
    E = w2 - (b * w0 * w1 + c * w0 ** 2 + d * w1 + e * w0 + f)
    chk1 = is_zero(sp.expand(DJ + sig * J - E))
    ph = sp.Function('phi')(z)
    Tz = nu + K0 * sp.exp(-sig * z)
    wl = -2 / b * sp.diff(ph, z) / ph
    lin = sp.diff(ph, z, 2) - mu * sp.diff(ph, z) + b / 2 * Tz * ph
    chk2 = sp.simplify(sp.diff(wl, z) - (b / 2 * wl ** 2 + mu * wl + Tz) - (-2 / b) * lin / ph) == 0
    xs = sp.Dummy('x', positive=True)
    Zf = sp.Function('Z')
    zz = -2 / sig * sp.log(xs / x0)                     # z as a function of x
    phx = sp.exp(mu * zz / 2) * Zf(xs)
    dz = lambda g: sp.diff(g, xs) * (-sig * xs / 2)      # d/dz = (dx/dz) d/dx, dx/dz = -sigma x/2
    linx = dz(dz(phx)) - mu * dz(phx) + b / 2 * (nu + K0 * (xs / x0) ** 2) * phx
    bessel = xs ** 2 * sp.diff(Zf(xs), xs, 2) + xs * sp.diff(Zf(xs), xs) + (xs ** 2 - nuB2) * Zf(xs)
    ratio = sp.simplify(linx / sp.exp(mu * zz / 2))
    resid = sp.simplify((ratio - sig ** 2 / 4 * bessel / xs ** 0).subs(x0, sp.sqrt(x0val)))
    chk3 = resid == 0 or sp.simplify(resid) == 0
    s = make_solution("other", 2, expr, None,
                      constants={str(K0): 'free; nonzero', str(x0): 'any root of %s = 0' % (x0 ** 2 - nice(x0val)),
                                 str(C1): 'free', str(C2): 'free'},
                      free=[str(K0), str(C1), str(C2)], pole_orders=[1],
                      note="all solutions with K0 != 0: w = -(2/b) phi'/phi, phi = exp(mu z/2) Z_nu(x), x = x0 exp(-sigma z/2), "
                           "Bessel order nu with nu^2 = %s; d = 2 unless nu is half an odd integer and Z a Hankel function" % nuB2)
    s["certificate"] = _identity_cert([("(D + sigma) J - E", chk1), ("Riccati -> linear (w = -(2/b) phi'/phi)", chk2),
                                       ("linear -> Bessel (sigma^2/4 x^2-form)", chk3)])
    s.pop("_carrier", None)
    out.append(_sol_meta(s, REC + " Theorem B(1); atlas:ORD2-Q21-BND-BESSEL", [CIT_NW19], conds, subs,
                         "record:ORD2/Theorem-B"))
    return out


def fam_airy(p, conds, subs):
    b, d, f = p['b'], p['d'], p['f']
    K0, C1, C2 = aux('K0'), aux('C1'), aux('C2')
    v_ = nice(-b * f / 2)
    al = -sp.cbrt(-v_) if (v_.is_number and v_.is_real and v_.is_negative) else sp.cbrt(v_)
    be = nice((d ** 2 / 4 - b * K0 / 2) / al ** 2)
    xi = al * z + be
    phi = sp.exp(d * z / 2) * (C1 * sp.airyai(xi) + C2 * sp.airybi(xi))
    expr = -2 / b * sp.diff(phi, z) / phi
    J = w1 - b / 2 * w0 ** 2 - d * w0
    DJ = sp.diff(J, w0) * w1 + sp.diff(J, w1) * w2
    E = w2 - (b * w0 * w1 + d * w1 + f)
    chk1 = is_zero(sp.expand(DJ - f - E))
    ph = sp.Function('phi')(z)
    Tz = f * z + K0
    wl = -2 / b * sp.diff(ph, z) / ph
    lin = sp.diff(ph, z, 2) - d * sp.diff(ph, z) + b / 2 * Tz * ph
    chk2 = sp.simplify(sp.diff(wl, z) - (b / 2 * wl ** 2 + d * wl + Tz) - (-2 / b) * lin / ph) == 0
    # (iii) phi = exp(d z/2) psi(xi), xi = al z + be:  phi'' - d phi' + (b/2) T phi = exp(d z/2) [al^2 psi_xixi - ...]
    Y0, Y1, Y2 = sp.Dummy('Y0'), sp.Dummy('Y1'), sp.Dummy('Y2')               # psi, psi', psi'' at xi
    ph0 = Y0
    ph1 = d / 2 * Y0 + al * Y1                         # exp(-d z/2) phi'
    ph2 = d ** 2 / 4 * Y0 + d * al * Y1 + al ** 2 * Y2  # exp(-d z/2) phi''
    linz = sp.expand(ph2 - d * ph1 + b / 2 * Tz * ph0)
    chk3 = is_zero(sp.expand(linz.subs(Y2, xi * Y0)))
    s = make_solution("other", 2, expr, None, constants={str(K0): 'free', str(C1): 'free', str(C2): 'free'},
                      free=[str(K0), str(C1), str(C2)], pole_orders=[1],
                      note="all solutions: w' = (b/2) w^2 + d w + f z + K0 (J = w' - (b/2) w^2 - d w has J' = f); "
                           "w = -(2/b) phi'/phi with Airy functions of xi = %s; d = 2" % xi)
    s["certificate"] = _identity_cert([("D J - f - E", chk1), ("Riccati -> linear", chk2),
                                       ("linear -> Airy (psi'' = xi psi)", chk3)])
    s.pop("_carrier", None)
    return [_sol_meta(s, REC + " Theorem B(1); atlas:ORD2-Q21-BND-AIRY", [], conds, subs, "record:ORD2/Theorem-B")]


# =============================================================================================== sector Q(2,1)
def _coeffs_q21(Phi):
    """(a, b, c, d, e, f) if Phi lies in span{w^3, w w', w^2, w', w, 1}, else None"""
    try:
        P = sp.Poly(sp.expand(Phi), w0, w1)
    except Exception:
        return None
    allowed = {(3, 0): 'a', (1, 1): 'b', (2, 0): 'c', (0, 1): 'd', (1, 0): 'e', (0, 0): 'f'}
    co = dict.fromkeys('abcdef', sp.Integer(0))
    for mon, val in P.terms():
        if mon not in allowed:
            return None
        co[allowed[mon]] = val
    return [co[x] for x in 'abcdef']


def _denominators(exprs):
    """denominators (depending on the parameters) of the given coefficients: they are nonzero on every stratum"""
    out = []
    for x in exprs:
        dn = sp.denom(sp.together(sp.sympify(x)))
        if dn.free_symbols and dn not in out:
            out.append(dn)
    return out


def _explore(coeffs, t_budget=20.0):
    """enumerate the leaves of the decision tree (numeric coefficients: one leaf).  The cap on the number of leaves
    grows with the budget; when the enumeration stops, the conditions of the leaves that were cut are returned in
    _EXPLORE_CUT (so that they can be named)."""
    nz0 = _denominators(coeffs)
    t0 = time.time()
    cap = max(LEAF_CAP, int(6 * t_budget))
    leaves, queue, seen = [], [([], [])], set()
    truncated = False
    del _EXPLORE_CUT[:]
    while queue:
        if len(leaves) >= cap or time.time() - t0 > t_budget:
            truncated = True
            for f_, desc in queue:
                if desc and desc not in _EXPLORE_CUT:
                    _EXPLORE_CUT.append(desc)
            break
        forced, _desc = queue.pop(0)
        key = tuple(str(x) for x in forced)
        if key in seen:
            continue
        seen.add(key)
        ctx = Ctx(forced, nonzero=nz0)
        try:
            stratum, fams = classify(ctx, *coeffs)
            leaves.append({"forced": forced, "stratum": stratum, "families": fams, "conds": list(ctx.conds),
                           "subs": dict(ctx.subs), "nonzero": list(ctx.nonzero), "unresolved": None,
                           "notes": list(ctx.notes)})
        except _Unresolved:
            leaves.append({"forced": forced, "stratum": "unresolved", "families": [], "conds": list(ctx.conds),
                           "subs": dict(ctx.subs), "nonzero": list(ctx.nonzero), "unresolved": ctx.unresolved})
            continue
        except _Degenerate:
            _record_degenerate(ctx.conds)
            continue
        except (ZeroDivisionError, _Infeasible):
            continue
        # children: force one later parameter-dependent test to zero
        for i in range(len(forced), len(ctx.log)):
            x, nz = ctx.log[i]
            sols = solve_system_for_params(list(x), nz) if isinstance(x, tuple) else solve_for_param_strata(x, nonzero=nz)
            before = list(ctx.conds[:ctx.marks[i]]) if i < len(ctx.marks) else list(ctx.conds)
            if sols is None:
                desc = before + ([cond_str(y, "==") for y in x] if isinstance(x, tuple) else [cond_str(x, "==")])
                queue.append((forced + ['n'] * (i - len(forced)) + [('z', 0)], desc))
                continue
            for j in range(len(sols)):
                desc = before + ["%s == %s" % kv for kv in sols[j].items()]
                queue.append((forced + ['n'] * (i - len(forced)) + [('z', j)], desc))
    return leaves, truncated


SECTOR_CARD = {'L': 'ORD2-Q2LIN-SECTOR', 'Q22': 'ORD2-P222-SECTOR', 'B': 'ORD2-Q21-BND-SECTOR', 'P': 'ORD2-P231-SECTOR'}


def _sector_basis(stratum):
    if stratum.startswith('P row 4'):
        # w'' + c w' + cubic = 0: Conte, Ng, Wu 2015, Lemma 4.5 and Remark 4.6 (all meromorphic solutions)
        return "published:CNW2015/Lemma-4.5", SECTOR_CARD['P']
    if stratum.startswith('L'):
        return "record:ORD2/Theorem-L", SECTOR_CARD['L']
    if stratum.startswith('Q22'):
        return "record:ORD2/Theorem-Q22", SECTOR_CARD['Q22']
    if stratum.startswith('B'):
        return "record:ORD2/Theorem-B", SECTOR_CARD['B']
    return "record:ORD2/Theorem-P", SECTOR_CARD['P']


def stratum_constants(cpoly, strata):
    """the constant solutions of each stratum on which the polynomial of constant solutions changes: it vanishes
    identically there (every constant is a solution) or its leading coefficient vanishes (the generic root formulas,
    which carry 'leading coefficient != 0', do not apply)"""
    out = []
    if not sp.sympify(cpoly).free_symbols - {w0}:
        return out
    lc = sp.Poly(cpoly, w0).LC() if cpoly.has(w0) else cpoly
    seen = set()
    for subs, conds in strata:
        if not subs:
            continue
        cp_l = sp.expand(sp.numer(sp.together(sp.sympify(cpoly).subs(subs))))
        if cp_l != 0 and zero_status(sp.sympify(lc).subs(subs)) != 'zero':
            continue
        key = (str(cp_l), tuple(conds))
        if key in seen:
            continue
        seen.add(key)
        for s_ in constant_solutions(cp_l, origin='live:order2', conditions=list(conds)):
            if subs:
                s_["_subs"] = dict(subs)
            out.append(s_)
    return out


def answer_q21(E, coeffs, params, budget_s=15.0):
    """complete answer for w'' = a w^3 + b w w' + c w^2 + d w' + e w + f (numbers or symbols)"""
    jets = [w0, w1, w2]
    t_start = time.time()
    leaves, truncated = _explore(coeffs, t_budget=budget_s)
    a, b, c, d, e, f = coeffs
    numeric = not any(sp.sympify(x).free_symbols for x in coeffs)
    found, ruled, nd, strata = [], [], [], []
    for li, leaf in enumerate(leaves):
        if leaf["unresolved"]:
            nd.append({"what": "the stratum %s" % " and ".join(leaf["conds"]), "conditions": list(leaf["conds"]),
                       "why": "the condition defining this stratum is not solved for a parameter by this module "
                              "(it needs a radical of the parameters or is of high degree)"
                              if "not solved" in str(leaf["unresolved"]) else str(leaf["unresolved"]),
                       "partial": "substitute parameter values on this stratum and call again"})
            strata.append({"conditions": leaf["conds"], "stratum": "unresolved", "families": []})
            continue
        fams = []
        if time.time() - t_start > 2 * budget_s or _late():
            nd.append({"what": "closed forms on the stratum %s" % " and ".join(leaf["conds"]),
                       "conditions": list(leaf["conds"]),
                       "why": "time limit of this call", "partial": "families exist there (record ORD2)"})
            leaf["unresolved"] = "time limit"
            continue
        failed_kinds = []
        for spec in leaf["families"]:
            if leaf["subs"]:
                spec = (spec[0], dict((k, (nice(sp.sympify(v).subs(leaf["subs"])) if not isinstance(v, str) else v))
                                      for k, v in spec[1].items()))
            try:
                del _BUILD_ND[:]
                built = build_family(spec, leaf["conds"], leaf["subs"])
                for x_ in _BUILD_ND:
                    nd.append(x_)
                del _BUILD_ND[:]
                keep = []
                for f_ in built:
                    if f_.get("_drop"):
                        continue
                    sb = f_.get("_subs") or {}
                    if sb and any(zero_status(sp.sympify(x).subs(sb)) == 'zero' for x in leaf["nonzero"]):
                        continue           # the family's own condition contradicts this stratum
                    keep.append(f_)
                fams += keep
            except Exception:
                failed_kinds.append(spec[0])
                nd.append({"what": "the stratum %s" % (" and ".join(leaf["conds"]) or "of the equation"),
                           "conditions": list(leaf["conds"]),
                           "why": "a family of solutions exists there (record ORD2, family of kind '%s'), but its "
                                  "closed form was not produced by this module" % spec[0],
                           "partial": "the other families of this stratum are listed"})
        ids_before = len(found)
        found += fams
        basis, card = _sector_basis(leaf["stratum"])
        if failed_kinds:
            # a failed construction never produces a "ruled out" statement
            strata.append({"conditions": leaf["conds"], "stratum": leaf["stratum"], "card": card,
                           "families": list(range(ids_before, len(found))),
                           "subs": dict((str(k), str(v)) for k, v in leaf["subs"].items()),
                           "note": "not decided: a family of this stratum was not constructed"})
            leaf["unresolved"] = "construction of a family not produced"
            continue
        strata.append({"conditions": leaf["conds"], "stratum": leaf["stratum"], "card": card,
                       "families": list(range(ids_before, len(found))),
                       "subs": dict((str(k), str(v)) for k, v in leaf["subs"].items()),
                       "note": "; ".join(leaf.get("notes", []))})
        ruled.append({"what": "nonconstant meromorphic solutions other than the families listed for this stratum"
                              if fams else "every nonconstant meromorphic solution",
                      "basis": {"theorem": basis, "label": BASIS_LABEL[basis], "card": "atlas:" + card,
                                "source": ORD2_PATH},
                      "certificate": {"type": "decision-tree", "stratum": leaf["stratum"],
                                      "tests": leaf["conds"] if leaf["conds"] else "all tests decided exactly"},
                      "conditions": leaf["conds"], "note": "; ".join(leaf.get("notes", []))})
    if truncated:
        cut = [list(c_) for c_ in _EXPLORE_CUT]
        nd.append({"what": "further special strata of the parameters (%d named in conditions_cut)" % len(cut),
                   "why": "the enumeration stopped after %d strata (time or size limit of this call)" % len(leaves),
                   "partial": "substitute numbers and call again", "conditions_cut": cut})
        for c_ in cut:                              # each cut stratum is an open locus with its own '==' conditions
            if any(" == " in x_ for x_ in c_):
                nd.append({"what": "the stratum %s (not enumerated)" % " and ".join(c_), "conditions": c_,
                           "why": "the enumeration stopped before this stratum",
                           "partial": "substitute values on this stratum and call again"})
    # constants
    cpoly = sp.expand(a * w0 ** 3 + c * w0 ** 2 + e * w0 + f)
    consts = constant_solutions(cpoly, origin='live:order2')
    consts += stratum_constants(cpoly, [(l["subs"], l["conds"]) for l in leaves if not l["unresolved"]])
    for s in consts:
        s["basis"] = "constant"
    found = consts + found
    found = finalize(found, E, jets, deadline=_grace())
    for i, s in enumerate(found):
        s["stratum_index"] = None
    # map strata family indices to ids
    off = len(consts)
    for st in strata:
        st["families"] = [found[off + i]["id"] for i in st["families"]]
    return found, ruled, nd, strata, leaves


# =============================================================================================== other sectors
def conservative_leaves(F, conds=(), subs=None, depth=2, nonzero=()):
    """parameter strata of w'' = F(w) on which the list of families changes: leading coefficient = 0 (the degree
    drops), discriminant = 0 (multiple roots), and for deg F = 3 the resultant of F(r) and
    F2(r)^2 - 3 F1(r) F3(r), Fj the j-th derivative (an energy level that is a perfect square).
    Returns [(F, conds, subs, unresolved)]."""
    out = []

    def tests_of(F):
        if not F.has(w0):
            return []
        P = sp.Poly(F, w0)
        n = P.degree()
        t = [P.LC()]
        if n in (2, 3):
            dsc = sp.discriminant(P)
            if zero_status(dsc) == 'zero':
                dsc = sp.discriminant(sp.Poly(sqf_part_x(F, w0), w0))
            t.append(dsc)
        if n == 3 and len(sp.expand(F).free_symbols - {w0}) <= 3:
            r = sp.Dummy('r')
            Fr = [sp.diff(F, w0, j).subs(w0, r) for j in range(4)]
            t.append(sp.resultant(sp.expand(F.subs(w0, r)), sp.expand(Fr[2] ** 2 - 3 * Fr[1] * Fr[3]), r))
        return [nice(x) for x in t]

    def rec(F, conds, subs, depth, nonzero):
        unk = [t for t in tests_of(F) if zero_status(t) == 'unknown']
        out.append((F, list(conds) + [cond_str(t, "!=") for t in unk], dict(subs), None))
        if depth <= 0:
            # the sub-loci below this node are not enumerated: name each of them (with its '== 0' condition)
            for i, t in enumerate(unk):
                out.append((F, list(conds) + [cond_str(x, "!=") for x in unk[:i]] + [cond_str(t, "==")], dict(subs),
                            "a special parameter locus of the conservative equation, not enumerated (depth limit)"))
            return
        for i, t in enumerate(unk):
            before = unk[:i]
            sols = solve_for_param(t, nonzero=list(nonzero) + before)
            cnd0 = list(conds) + [cond_str(x, "!=") for x in before]
            cnd = cnd0 + [cond_str(t, "==")]
            if sols is None:
                out.append((F, cnd, dict(subs), "the condition %s = 0 is not solved for a parameter by this module"
                            % sp.factor(t)))
                continue
            extra_subs_ = []
            for sub in sols:
                for v in sub.values():                  # the part of the locus that the solution leaves out
                    dn = sp.denom(sp.together(sp.sympify(v)))
                    if not dn.free_symbols:
                        continue
                    for sd in (solve_for_param(dn, nonzero=list(nonzero) + before) or []):
                        t2 = nice(sp.sympify(t).subs(sd))
                        if zero_status(t2) == 'zero':
                            extra_subs_.append(sd)
                            continue
                        for s2_ in (solve_for_param(t2, nonzero=list(nonzero) + before) or []):
                            comp = dict((k, nice(sp.sympify(x).subs(s2_))) for k, x in sd.items())
                            comp.update(s2_)
                            if not any(sp.sympify(x).has(sp.zoo, sp.nan) for x in comp.values()):
                                extra_subs_.append(comp)
            for sub in list(sols) + extra_subs_:
                if any(zero_status(sp.sympify(x).subs(sub)) == 'zero' for x in list(nonzero) + before):
                    continue
                s2 = dict((k, nice(sp.sympify(v).subs(sub))) for k, v in subs.items())
                s2.update(sub)
                if any(sp.sympify(v).has(sp.zoo, sp.nan, sp.oo) for v in s2.values()):
                    continue          # the new condition makes an earlier substitution singular: empty stratum
                cnd = cnd0 + ["%s == %s" % kv for kv in sub.items()]
                if _degenerate(s2):
                    _record_degenerate(cnd)
                    continue
                F2 = sp.expand(F.subs(sub))
                nz2 = [nice(sp.sympify(x).subs(sub)) for x in list(nonzero) + before]
                nz2 += [sp.denom(sp.together(v)) for v in sub.values() if sp.denom(sp.together(v)).free_symbols]
                rec(F2, cnd, s2, depth - 1, nz2)

    nz0 = [sp.denom(sp.together(v)) for v in (subs or {}).values() if sp.denom(sp.together(v)).free_symbols]
    nz0 += list(nonzero)
    if F.has(w0):
        nz0 += _denominators(sp.Poly(sp.expand(F), w0).all_coeffs())
    rec(sp.expand(F), list(conds), dict(subs or {}), depth, nz0)
    return out


def conservative_families(F, conds, subs, origin):
    """families of the conservative equation on one stratum (any degree)"""
    n = sp.Poly(F, w0).degree() if F.has(w0) else 0
    if n >= 4:
        return [], "C (deg F = %d >= 4: constants only)" % n
    if n in (2, 3):
        return fam_conservative(F, conds, subs, origin=origin), "C (deg F = %d)" % n
    c1 = sp.Poly(F, w0).coeff_monomial(w0) if F.has(w0) else sp.Integer(0)
    c0 = sp.Poly(F, w0).coeff_monomial(1) if F.has(w0) else F
    out = []
    for s_ in fam_linear(sp.Integer(0), c1, c0):
        out.append(_sol_meta(s_, REC + " Theorem L", ["classical (linear equation)"], conds, subs,
                             "record:ORD2/Theorem-L"))
    return out, "L (deg F <= 1)"


def answer_conservative(E, F, params):
    jets = [w0, w1, w2]
    found, ruled, nd, strata = [], [], [], []
    consts = constant_solutions(F, origin='live:order2')
    leaves = conservative_leaves(F) if params else [(sp.expand(F), [], {}, None)]
    consts += stratum_constants(sp.expand(F), [(sl, cl) for (Fl, cl, sl, un) in leaves if not un])
    for (Fl, conds, subs, unres) in leaves:
        if unres or _late():
            nd.append({"what": "the stratum %s" % " and ".join(conds),
                       "why": unres or "time limit of this call",
                       "partial": "substitute parameter values on this stratum and call again"})
            strata.append({"conditions": conds, "stratum": "unresolved", "families": []})
            continue
        i0 = len(found)
        fams, sector = conservative_families(Fl, conds, subs, REC + " (conservative)")
        found += fams
        strata.append({"conditions": conds, "stratum": sector, "families": list(range(i0, len(found))),
                       "subs": dict((str(k), str(v)) for k, v in subs.items())})
        nfl = sp.Poly(Fl, w0).degree() if Fl.has(w0) else 0
        if nfl >= 4:
            ruled.append({"what": "every nonconstant meromorphic solution",
                          "basis": {"theorem": "lemma:order2/C1", "label": BASIS_LABEL["lemma:order2/C1"]},
                          "certificate": {"type": "degree", "detail": "w'^2 = 2G(w) + C has degree %d >= 5 in w for "
                                          "every C: a pole would have order 2/(%d - 2), not an integer, and every "
                                          "nonconstant solution has a pole (statement O2)" % (nfl + 1, nfl + 1)},
                          "conditions": conds})
        else:
            ruled.append({"what": "meromorphic solutions other than those listed for this stratum",
                          "basis": {"theorem": "lemma:order2/C1", "label": BASIS_LABEL["lemma:order2/C1"]},
                          "certificate": {"type": "first-integral", "detail": "every solution satisfies w'^2 = 2G(w) + C; "
                                          "statement O2 lists all solutions of each such equation"},
                          "conditions": conds})
    found = finalize(consts + found, E, jets, deadline=_grace())
    off = len(consts)
    for st in strata:
        st["families"] = [found[off + i]["id"] for i in st["families"]]
    sector = strata[0]["stratum"] if strata else "C"
    return found, ruled, nd, sector, strata


def _optional(modname, fn):
    try:
        mod = __import__('mero.' + modname, fromlist=[fn])
        return getattr(mod, fn)
    except Exception:
        return None


def answer_general(eq_in, K, E, params, solved_rhs, deep=False):
    """second-order equations outside the sectors: local analysis + optional modules (partial answers)"""
    found, ruled, nd, notes = [], [], [], []
    jets = [w0, w1, w2]
    consts = constant_solutions(sp.expand(E.subs({w1: 0, w2: 0})), origin='live:order2')
    local = None
    la = _optional('laurent', 'local_analysis') if deep else None
    eqobj = None
    if isinstance(eq_in, str):
        po = _optional('parse', 'parse_ode')
        if po is not None:
            try:
                eq_in = po(eq_in)
            except Exception:
                pass
    try:
        from .bootstrap import Equation as BEq, balances as bbal
        if solved_rhs is not None:
            eqobj = BEq(2, str(solved_rhs), [str(p) for p in params])
    except Exception:
        bbal = None
    if la is not None:
        try:
            local = la(eq_in)
        except Exception as exc:
            notes.append("local_analysis failed: %s" % exc)
    no_pole = None
    if local is not None:
        no_pole = bool(local.get("no_pole_possible"))
    elif eqobj is not None and bbal is not None:
        try:
            bal = bbal(eqobj)
            no_pole = not any(x["a0"] for x in bal)
            notes.append("integer balances (bootstrap): %s" % [(x["p"], [str(r) for r in x["a0"]]) for x in bal])
        except Exception as exc:
            notes.append("balances failed: %s" % exc)
    if no_pole:
        notes.append("no pole is possible (no integer balance): every meromorphic solution is entire")
        ruled.append({"what": "meromorphic solutions with a pole", "basis": {"theorem": "local analysis", "label": "certificate"},
                      "certificate": {"type": "balances", "detail": "no balance with an integer pole order and a nonzero leading coefficient"},
                      "conditions": []})
    # entire solutions and the W search are run by mero.report itself (applies = False below); here only on request
    ent = _optional('entire', 'entire_solutions') if deep else None
    if ent is not None and not isinstance(eq_in, str):
        try:
            er = ent(eq_in, budget_s=10)
            if isinstance(er, dict):
                notes.append("entire solutions: complete = %s" % er.get("complete"))
                for key in ("polynomials", "exponentials", "found"):
                    for s in er.get(key, []) or []:
                        if isinstance(s, dict):
                            found.append(s)
        except Exception as exc:
            notes.append("entire_solutions failed: %s" % exc)
    ws = _optional('wsolve', 'find_w_solutions') if deep else None
    if ws is not None and local is not None and local.get("balances"):
        try:
            wr = ws(eq_in, local, budget_s=10)
            for s in (wr.get("solutions", []) if isinstance(wr, dict) else (wr or [])):
                if isinstance(s, dict):
                    found.append(s)
        except Exception as exc:
            notes.append("find_w_solutions failed: %s" % exc)
    found = finalize(consts, E, jets) + found
    nd.append({"what": "nonconstant meromorphic solutions" if not no_pole else "nonconstant entire solutions",
               "why": "the equation is outside the order-two sectors decided by this module (conservative, linear, "
                      "(2,2,2), Q(2,1))",
               "partial": "; ".join(notes) if notes else "constant solutions listed"})
    return found, ruled, nd, notes


# =============================================================================================== A w'' + B w'^2 + C = 0
def _abc_form(E):
    """(A, B, C) if E = A(w0) w2 + B(w0) w1^2 + C(w0) with A != 0, else None"""
    try:
        P = sp.Poly(sp.expand(E), w1, w2)
    except Exception:
        return None
    co = {}
    for mon, val in P.terms():
        if mon not in ((0, 1), (2, 0), (0, 0)):
            return None
        co[mon] = val
    A = co.get((0, 1), sp.Integer(0))
    if A == 0:
        return None
    return A, co.get((2, 0), sp.Integer(0)), co.get((0, 0), sp.Integer(0))


def first_integral_data(A, B, C):
    """mu = exp(int 2B/A dw), Phi = int 2 C mu / A dw; both must be rational in w0 (else None).
    Then D(mu w1^2 + Phi) = (2 mu w1 / A) E identically."""
    try:
        q = sp.cancel(2 * B / A)
        if q == 0:
            mu = sp.Integer(1)
        else:
            I1 = sp.integrate(sp.apart(q, w0), w0)
            mu = sp.simplify(sp.exp(I1))
            mu = sp.factor(sp.powsimp(sp.expand_power_base(mu, force=True), force=True))
        if not mu.is_rational_function(w0) or mu.has(sp.exp, sp.log):
            return None
        integrand = sp.cancel(2 * C * mu / A)
        Phi = sp.integrate(sp.apart(integrand, w0) if integrand.has(w0) else integrand, w0)
        if not Phi.is_rational_function(w0) or Phi.has(sp.log, sp.atan, sp.Piecewise):
            return None
        Phi = sp.cancel(Phi)
        E = A * w2 + B * w1 ** 2 + C
        I = mu * w1 ** 2 + Phi
        DI = sp.diff(I, w0) * w1 + sp.diff(I, w1) * w2
        ok = sp.cancel(DI - 2 * mu * w1 / A * E) == 0
        return {"mu": mu, "Phi": Phi, "identity": ok}
    except Exception:
        return None


def poly_leaves(P, depth=2, exclude=()):
    """parameter strata of w'^2 = P(w): leading coefficient = 0 and discriminant of the square-free part = 0
    (tests that depend only on the symbols in `exclude` are not split).  Returns [(P, conds, subs, unresolved)]."""
    out = []
    ex = set(exclude)

    def tests_of(P):
        if not P.has(w0):
            return []
        Pp = sp.Poly(P, w0)
        t = [Pp.LC()]
        if Pp.degree() <= 4 and Pp.degree() >= 2:
            t.append(sp.discriminant(sp.Poly(sqf_part_x(P, w0), w0)))
        return [nice(x) for x in t if (sp.sympify(x).free_symbols - ex)]

    def rec(P, conds, subs, depth, nonzero):
        unk = [t for t in tests_of(P) if zero_status(t) == 'unknown']
        out.append((P, list(conds) + [cond_str(t, "!=") for t in unk], dict(subs), None))
        if depth <= 0:
            return
        for i, t in enumerate(unk):
            before = unk[:i]
            cnd0 = list(conds) + [cond_str(x, "!=") for x in before]
            params = sorted(sp.sympify(t).free_symbols - ex, key=str)
            sols = solve_for_param(t, params=params, nonzero=list(nonzero) + before)
            if sols is None:
                out.append((P, cnd0 + [cond_str(t, "==")], dict(subs),
                            "the condition %s = 0 is not solved for a parameter by this module" % sp.factor(t)))
                continue
            for sub in sols:
                if any(zero_status(sp.sympify(x).subs(sub)) == 'zero' for x in list(nonzero) + before):
                    continue
                s2 = dict((k, nice(sp.sympify(v).subs(sub))) for k, v in subs.items())
                s2.update(sub)
                if any(sp.sympify(v).has(sp.zoo, sp.nan, sp.oo) for v in s2.values()):
                    continue
                cnd = cnd0 + ["%s == %s" % kv for kv in sub.items()]
                if _degenerate(s2):
                    _record_degenerate(cnd)
                    continue
                nz2 = [nice(sp.sympify(x).subs(sub)) for x in list(nonzero) + before]
                nz2 += [sp.denom(sp.together(v)) for v in sub.values() if sp.denom(sp.together(v)).free_symbols]
                rec(sp.expand(P.subs(sub)), cnd, s2, depth - 1, nz2)

    rec(sp.expand(P), [], {}, depth, [])
    return out


def answer_first_integral(E, A, B, C, params, data):
    """all meromorphic solutions of A w'' + B w'^2 + C = 0 with a rational first integral mu w'^2 + Phi = K"""
    jets = [w0, w1, w2]
    K = aux('I0')                                     # the value of the first integral
    mu, Phi = data["mu"], data["Phi"]
    Pn, Pd = sp.fraction(sp.cancel(Phi))
    Mn, Md = sp.fraction(sp.cancel(mu))
    Den = sp.expand(Pd * Mn)
    Num = sp.expand((K * Pd - Pn) * Md)
    found, ruled, nd, levels = [], [], [], []
    rem = sp.rem(sp.Poly(Num, w0), sp.Poly(Den, w0)) if sp.sympify(Den).has(w0) else sp.Poly(0, w0)
    eqs = [sp.expand(cf) for cf in rem.all_coeffs()] if not rem.is_zero else []
    eqs = [x for x in eqs if x != 0]
    level_conds, level_subs = [], {}
    eqs_K = [x for x in eqs if x.has(K)]
    eqs_0 = [x for x in eqs if not x.has(K)]          # must vanish for any level to give a polynomial R_K
    feasible = True
    for x in eqs_0:
        st0 = zero_status(sp.sympify(x).subs(level_subs))
        if st0 == 'zero':
            continue
        if st0 == 'nonzero':
            feasible = False
            break
        sols0 = solve_for_param(sp.sympify(x).subs(level_subs), nonzero=_denominators([mu, Phi]))
        if not sols0:
            feasible = False
            nd.append({"what": "levels of the first integral on the stratum %s" % cond_str(x, "=="),
                       "why": "the condition is not solved for a parameter by this module",
                       "partial": "off this stratum no level K gives a polynomial R_K: only constants"})
            break
        level_subs.update(sols0[0])
        level_conds += ["%s == %s" % kv for kv in sols0[0].items()]
    if not feasible:
        Kvals = []
    elif not eqs_K:
        Kvals = [None]                                   # every level K gives a polynomial R_K
    else:
        eqs_K = [sp.sympify(x).subs(level_subs) for x in eqs_K]
        sol = sp.solve(eqs_K, K, dict=True)
        Kvals = [nice(s_[K]) for s_ in sol if K in s_ and all(is_zero(sp.sympify(x).subs(K, s_[K])) for x in eqs_K)]
    if level_subs:
        Num = sp.expand(sp.sympify(Num).subs(level_subs))
        Den = sp.expand(sp.sympify(Den).subs(level_subs))
    cit = "first integral mu(w) w'^2 + Phi(w) = K, mu = %s, Phi = %s" % (mu, Phi)
    Kvals_extra = []
    Kvals = list(Kvals)
    ilev = 0
    while ilev < len(Kvals) + len(Kvals_extra):
        Kv = (Kvals + Kvals_extra)[ilev]
        ilev += 1
        Rk = sp.expand(sp.quo(sp.Poly(Num if Kv is None else Num.subs(K, Kv), w0),
                              sp.Poly(Den, w0)).as_expr()) if sp.sympify(Den).has(w0) else sp.expand((Num if Kv is None else Num.subs(K, Kv)) / Den)
        degR = sp.Poly(Rk, w0).degree() if Rk.has(w0) else 0
        lvl = "every K" if Kv is None else "K = %s" % Kv
        if degR >= 5 and Kv is None and Rk.has(K):
            # R_K is affine in K: the degree drops to <= 4 exactly where the coefficients of w^k, k >= 5, vanish
            PRk = sp.Poly(Rk, w0)
            high = [sp.expand(PRk.coeff_monomial(w0 ** j)) for j in range(5, degR + 1)]
            high = [x for x in high if x != 0]
            Kstar = None
            if all(x.has(K) or zero_status(x) == 'zero' for x in high):
                lin = [x for x in high if x.has(K)]
                cand = sp.solve(lin[0], K) if lin else []
                cand = [nice(v) for v in cand if all(is_zero(sp.sympify(x).subs(K, v)) for x in high)]
                Kstar = cand[0] if cand else None
            levels.append({"level": "K != %s" % Kstar if Kstar is not None else lvl, "R": str(Rk), "families": [],
                           "note": "deg R = %d >= 5: constants only" % degR})
            if Kstar is None:
                continue
            Kvals_extra.append(Kstar)
            continue
        if degR >= 5:
            levels.append({"level": lvl, "R": str(Rk), "families": [], "note": "deg R = %d >= 5: constants only" % degR})
            continue
        if Kv is None:
            # generic level and the degenerate levels (discriminant / leading coefficient in K)
            sols, notes = binomial2_solutions(Rk, origin='live:order2')
            for s_ in sols:
                s_["constants"][str(K)] = "free; the value of the first integral"
                s_["free"] = list(s_["free"]) + [str(K)]
                s_["note"] = (s_.get("note", "") + "; generic level K").strip("; ")
            fam = sols
            specials = []
            if degR >= 1:
                PR = sp.Poly(Rk, w0)
                tests_ = [PR.LC()]
                dr = None
                if degR >= 2 and not params:
                    dr = double_root_levels(Rk, K, "live:order2 (first integral)", [], [], {}, "lemma:order2/C2")
                    if dr is not None:
                        fam += dr[0]
                if degR >= 2 and (params or dr is None):
                    tests_.append(sp.discriminant(sp.Poly(sqf_part_x(Rk, w0), w0)))
                elif degR >= 2:
                    # levels where a root that is multiple for every K meets another root (not of the double-root
                    # kind above): factors of the discriminant of the square-free part not covered by those levels
                    dsq = sp.numer(sp.together(sp.discriminant(sp.Poly(sqf_part_x(Rk, w0), w0))))
                    r1_ = sp.expand(sp.diff(Rk, K))
                    r0_ = sp.expand(Rk - K * r1_)
                    common = gcd_x(sp.Poly(r1_, w0), sp.Poly(r0_, w0))
                    if dsq.has(K) and common.degree() >= 1:
                        for fK, _m in factor_list_x(dsq, K)[1]:
                            if not fK.has(K):
                                continue
                            covered = False
                            for Kc in sp.roots(sp.Poly(fK, K), multiple=True) if sp.Poly(fK, K).degree() <= 2 else []:
                                Rc = sp.Poly(sp.expand(Rk.subs(K, Kc)), w0)
                                g_ = gcd_x(Rc, Rc.diff(w0))
                                if gcd_x(g_, common).degree() == 0:
                                    covered = True        # a new double root: already a level of the kind above
                            if covered:
                                continue
                            if sp.Poly(fK, K).degree() <= 2:
                                tests_.append(fK)
                            else:
                                nd.append({"what": "special levels of the first integral at the roots of %s" % fK,
                                           "why": "algebraic of degree >= 3 (a multiple root meets another root)",
                                           "partial": "the generic level and the levels with a new double root are listed"})
                for t_ in tests_:
                    t_ = sp.numer(sp.together(t_))
                    if t_.has(K):
                        if params and sp.Poly(t_, K).degree() > 1:
                            nd.append({"what": "the special levels of the first integral (roots in %s of %s)"
                                               % (K, sp.factor(t_)),
                                       "why": "not computed with symbolic parameters (degree > 1 in the level)",
                                       "partial": "substitute numbers and call again"})
                            continue
                        try:
                            specials += [nice(r_) for r_ in sp.solve(t_, K)]
                        except Exception:
                            pass
            def _radical_of_params(v):
                return any(isinstance(a_, sp.Pow) and not a_.exp.is_Integer and a_.base.free_symbols
                           for a_ in sp.sympify(v).atoms(sp.Pow))
            for K0 in sorted(set(specials), key=str):
                if params and _radical_of_params(K0):
                    nd.append({"what": "the special level K = %s" % K0,
                               "why": "a radical of the parameters; not treated with symbolic parameters",
                               "partial": "substitute numbers and call again"})
                    continue
                if _late():
                    nd.append({"what": "the special level K = %s" % K0, "why": "time limit of this call",
                               "partial": "substitute parameter values and call again"})
                    continue
                R0 = sp.expand(Rk.subs(K, K0))
                ss0, _ = binomial2_solutions(R0, origin='live:order2') if (not R0.has(w0) or sp.Poly(R0, w0).degree() <= 4) else ([], [])
                for s_ in ss0:
                    s_["note"] = (s_.get("note", "") + "; level K = %s" % K0).strip("; ")
                fam += ss0
        else:
            fam = []
            for (Rl, cl, sl, unres) in (poly_leaves(Rk) if params else [(Rk, [], {}, None)]):
                if _late():
                    nd.append({"what": "the level K = %s on the stratum %s" % (Kv, " and ".join(cl)),
                               "why": "time limit of this call", "partial": "substitute parameter values and call again"})
                    continue
                if unres:
                    nd.append({"what": "the level K = %s on the stratum %s" % (Kv, " and ".join(cl)), "why": unres,
                               "partial": "substitute parameter values and call again"})
                    continue
                if Rl.has(w0) and sp.Poly(Rl, w0).degree() >= 5:
                    continue
                fl, notes = binomial2_solutions(Rl, origin='live:order2', conditions=cl)
                for s_ in fl:
                    s_["note"] = (s_.get("note", "") + "; level K = %s" % Kv).strip("; ")
                    if sl:
                        s_["_subs"] = dict(sl)
                fam += fl
        for s_ in fam:
            s_["origin"] = "live:order2 (first integral)"
            s_["citations"] = list(s_.get("citations", [])) + [cit]
            s_["basis"] = "lemma:order2/C2"
            if level_subs:
                own = s_.get("_subs") or {}
                new = dict((k, nice(sp.sympify(v).subs(own))) for k, v in level_subs.items())
                new.update(own)
                s_["_subs"] = new
                s_["conditions"] = list(level_conds) + list(s_.get("conditions", []))
        i0 = len(found)
        found += fam
        levels.append({"level": lvl, "R": str(Rk), "families": list(range(i0, len(found)))})
    consts = constant_solutions(sp.expand(C), origin='live:order2')
    found = finalize(consts + found, E, jets, deadline=_grace())
    off = len(consts)
    for lv in levels:
        lv["families"] = [found[off + i]["id"] for i in lv["families"]]
    ruled.append({"what": "meromorphic solutions other than those listed",
                  "basis": {"theorem": "lemma:order2/C2", "label": "published",
                            "source": "first integral (certificate: D(mu w'^2 + Phi) = (2 mu w'/A) E, checked %s) and "
                                      "statements O2, O3 for w'^2 = R_K(w) (R_K must be a polynomial of degree <= 4)"
                                      % ("exactly" if data["identity"] else "NOT")},
                  "certificate": {"type": "first-integral", "mu": str(mu), "Phi": str(Phi),
                                  "levels": [dict((k, v) for k, v in lv.items()) for lv in levels]},
                  "conditions": []})
    return found, ruled, nd, levels


# =============================================================================================== entry point
def _solved_form(E):
    """Phi if E = c*w2 - Phi with c a nonzero constant (independent of the jets), else None"""
    if not E.has(w2):
        return None
    P = sp.Poly(E, w2)
    if P.degree() != 1:
        return None
    c = P.coeff_monomial(w2)
    if c.has(w0) or c.has(w1) or zero_status(c) == 'zero':
        return None
    return sp.expand(sp.cancel(-P.coeff_monomial(1) / c))


def _lead_condition(E):
    """the coefficient of w2 when it depends on the parameters (then 'c != 0' is a standing condition)"""
    try:
        c = sp.Poly(E, w2).coeff_monomial(w2)
    except Exception:
        return None
    if c.has(w0) or c.has(w1):
        return None
    return c if zero_status(c) == 'unknown' else None


REGISTRY_BASIS = {
    # internal id -> (registry id, label, where)
    "lemma:order2/C1": ("T-CONSERVATIVE", "published", "Conte, Ng, Wu 2015, Theorem 3.2(1)"),
    "record:ORD2/Theorem-Q22": ("T-CNW2015-FISHER", "published", "Conte, Ng, Wu 2015, Lemma 4.4"),
    "published:CNW2015/Lemma-4.5": ("T-CNW2015-FISHER", "published", "Conte, Ng, Wu 2015, Lemma 4.5 and Remark 4.6"),
    "record:ORD2/Theorem-L": ("record:ORD2/Theorem-L", "agent-proof", "atlas_20261004/project file note, Theorem L"),
    "record:ORD2/Theorem-B": ("record:ORD2/Theorem-B", "agent-proof", "atlas_20261004/project file note, Theorem B"),
    "record:ORD2/Theorem-P": ("record:ORD2/Theorem-P", "agent-proof", "atlas_20261004/project file note, Theorem P"),
    "lemma:order2/C2": ("lemma:order2/C2", "agent-proof", "lemmas/order2/project note, C2"),
}
_RANK = {"published": 0, "agent-proof": 1, "certificate": 1, "search": 2, "not-decided": 3}


def relabel_report(res):
    """B4: every basis carries the registry id, its label and, if published, the statement number; the verdict
    gets the weakest label of the bases it rests on; a partial verdict names what is not decided."""
    labels = []
    for x in res.get("ruled_out", []):
        b = x.get("basis") or {}
        th = b.get("theorem")
        if th in REGISTRY_BASIS:
            rid, lab, where = REGISTRY_BASIS[th]
            x["basis"] = {"theorem": rid, "label": lab, "where": where}
        elif b.get("label") == "published" and not b.get("where"):
            x["basis"] = dict(b, label="agent-proof")
        if x.get("basis", {}).get("label"):
            labels.append(x["basis"]["label"])
    vb = []
    for th in res.get("verdict", {}).get("basis", []):
        vb.append(REGISTRY_BASIS[th][0] if th in REGISTRY_BASIS else th)
        if th in REGISTRY_BASIS:
            labels.append(REGISTRY_BASIS[th][1])
    v = res.get("verdict", {})
    if v:
        v["basis"] = vb
        v["label"] = max(labels, key=lambda l_: _RANK.get(l_, 2)) if labels else "agent-proof"
        if v.get("level") not in ("complete",):
            items = [x.get("what", "") for x in res.get("not_decided", []) if not x.get("degenerate")]
            deg = [x for x in res.get("not_decided", []) if x.get("degenerate")]
            if items or v.get("level") == "partial":
                v["text"] = ("the solutions listed are certified; not decided: %s%s" %
                             ("; ".join(items[:3]) if items else "see the list below",
                              " (and %d more)" % (len(items) - 3) if len(items) > 3 else ""))
        elif res.get("scope"):
            v["text"] = v.get("text", "") + " (scope: %s)" % res["scope"]
        if res.get("degenerate_strata"):
            v["text"] = v.get("text", "") + "; degenerate strata (lower degree, enter the reduced equation): %s" % \
                "; ".join(" and ".join(x["conditions"]) for x in res["degenerate_strata"])
    return res


def order2_answer(eq, budget_s=10.0, deep=False):
    """complete answer for the order-two sectors (see the module docstring); never raises"""
    try:
        return _order2_answer(eq, budget_s=budget_s, deep=deep)
    except Exception as exc:                       # a safety net: the report must not break
        return {"applies": False, "found": [], "ruled_out": [], "not_decided": [], "basis": [],
                "verdict": {"level": "unsupported", "text": "mero.order2 failed on this input", "basis": []},
                "warnings": ["mero.order2 could not process this input; it is left to the general pipeline"],
                "module": "mero.order2", "_error": type(exc).__name__}


def _order2_answer(eq, budget_s=10.0, deep=False):
    t0 = time.time()
    _DEADLINE[0] = t0 + 2.5 * budget_s
    K, E, params = jets_and_E(eq)
    set_reserved([str(p_) for p_ in params])
    _DEG["E"], _DEG["deg"], _DEG["strata"] = None, None, []
    if params and K == 2:
        try:
            _DEG["E"] = sp.expand(E)
            _DEG["deg"] = sp.Poly(_DEG["E"], w0, w1, w2).total_degree()
        except Exception:
            _DEG["E"] = None
    res = {"applies": False, "found": [], "ruled_out": [], "not_decided": [], "verdict": {}, "basis": [],
           "module": "mero.order2", "strata": [], "sector": None}
    if K == 1:
        r = order1_answer(eq)
        r["module"] = "mero.order1 (via order2)"
        return r
    if K != 2:
        res["verdict"] = {"level": "unsupported", "text": "not an equation of order two", "basis": []}
        return res
    res["applies"] = True
    E = sp.expand(E)
    if not is_exact_input(E):
        res["applies"] = False
        res["verdict"] = {"level": "unsupported", "text": "the coefficients are not exact algebraic numbers; left to the "
                                                          "general pipeline", "basis": []}
        return res
    Phi = _solved_form(E)
    numeric = not params
    if Phi is not None and not Phi.has(w1):
        found, ruled, nd, sector, strata = answer_conservative(E, Phi, params)
        res.update(found=found, ruled_out=ruled, not_decided=nd, sector=sector, strata=strata)
        res["basis"] = ["lemma:order2/C1", "lemma:order2/O2", "certificate:substitution"]
        n = sp.Poly(Phi, w0).degree() if Phi.has(w0) else 0
        if n <= 1 and not params:
            # linear: Theorem L gives every solution (entire)
            cf = [sp.Integer(0), sp.Integer(0), sp.Integer(0), sp.Integer(0), sp.Poly(Phi, w0).coeff_monomial(w0) if n == 1 else sp.Integer(0),
                  sp.Poly(Phi, w0).coeff_monomial(1) if Phi.has(w0) else Phi]
            found, ruled, nd, strata, _ = answer_q21(E, cf, params)
            res.update(found=found, ruled_out=ruled, not_decided=nd, strata=strata, sector="L")
            res["basis"] = ["record:ORD2/Theorem-L", "certificate:substitution"]
        txt = ("every meromorphic solution is listed (conservative equation w'' = F(w), deg F = %d%s)"
               % (n, "; on each parameter stratum shown, generic stratum first" if len(res["strata"]) > 1 else ""))
        unresolved = any(st.get("stratum") == "unresolved" for st in res["strata"]) or bool(res["not_decided"])
        res["verdict"] = {"level": "complete" if not unresolved else "partial", "text": txt, "basis": list(res["basis"])}
    else:
        co = _coeffs_q21(Phi) if Phi is not None else None
        if co is not None:
            found, ruled, nd, strata, leaves = answer_q21(E, co, params, budget_s=budget_s)
            res.update(found=found, ruled_out=ruled, not_decided=nd, strata=strata)
            res["sector"] = "Q(2,1)/Q(2,2) (atlas sector ORD2)"
            bases = sorted(set(r["basis"]["theorem"] for r in ruled))
            res["basis"] = bases + ["certificate:substitution"]
            unresolved = any(l["unresolved"] for l in leaves)
            lvl = "complete" if not unresolved and not [x for x in nd if not x.get("scope_note")] else "partial"
            if numeric:
                st = leaves[0]["stratum"] if leaves else "?"
                nfam = len([s for s in found if s["kind"] != "constant"])
                b_, _c = _sector_basis(st)
                lab = BASIS_LABEL.get(b_, "agent-proof")
                src = ("Conte-Ng-Wu 2015, Lemma 4.5 and Remark 4.6" if b_.startswith("published")
                       else "Theorem %s of the order-two record" % b_.split("-")[-1])
                txt = ("every meromorphic solution is listed (%s; %s): stratum %s, %d famil%s of nonconstant solutions "
                       "besides the constants" % (src, lab, st, nfam, "y" if nfam == 1 else "ies"))
            else:
                labs = sorted(set(BASIS_LABEL.get(_sector_basis(l["stratum"])[0], "agent-proof") for l in leaves
                                  if l["stratum"] != "unresolved"))
                txt = ("every meromorphic solution is listed on each of the %d parameter strata shown, generic stratum "
                       "first (labels: %s)" % (len(leaves), ", ".join(labs)))
                # strata entered by solving for a parameter leave out the points where the denominator vanishes
                dens = []
                for l in leaves:
                    for v in l["subs"].values():
                        dn = sp.denom(sp.together(sp.sympify(v)))
                        if dn.free_symbols and str(dn) not in dens:
                            dens.append(str(dn))
                # denominators whose zero set is reached by some stratum are enumerated (solve_for_param_strata)
                dens = [dn_ for dn_ in dens
                        if not any(zero_status(S_(dn_).subs(l["subs"])) == 'zero' for l in leaves if l["subs"])]
                if dens:
                    res["scope"] = "the parameter strata listed"
                    for dn_ in dens[:6]:
                        nd.append({"what": "parameter points with %s = 0 that lie on none of the strata shown" % dn_,
                                   "conditions": ["%s == 0" % dn_],
                                   "why": "a stratum was entered by solving its condition for a parameter; the points where "
                                          "the denominator of that solution vanishes are not enumerated",
                                   "partial": "substitute the values and call again", "scope_note": True})
            res["verdict"] = {"level": lvl, "text": txt, "basis": list(res["basis"])}
        elif _abc_form(E) is not None and first_integral_data(*_abc_form(E)) is not None:
            A_, B_, C_ = _abc_form(E)
            data = first_integral_data(A_, B_, C_)
            found, ruled, nd, levels = answer_first_integral(E, A_, B_, C_, params, data)
            res.update(found=found, ruled_out=ruled, not_decided=nd, sector="A(w) w'' + B(w) w'^2 + C(w) = 0",
                       strata=[{"conditions": [], "stratum": "levels of the first integral", "levels": levels,
                                "families": [s_["id"] for s_ in found if s_["kind"] != "constant"]}])
            res["basis"] = ["lemma:order2/C2", "lemma:order2/O2", "lemma:order2/O3", "certificate:substitution"]
            if params:
                nd.append({"what": "special parameter values of the first-integral computation",
                           "why": "the levels K and the strata of R_K are computed for generic values of %s; values where "
                                  "mu, Phi or the level equations degenerate are not enumerated" % ", ".join(map(str, params)),
                           "partial": "substitute numbers and call again"})
                res["not_decided"] = nd
            lvl = "complete" if (data["identity"] and not params and not nd) else "partial"
            res["verdict"] = {"level": lvl, "text": "every meromorphic solution is listed (rational first integral "
                              "mu(w) w'^2 + Phi(w) = K; every level decided by the first-order statements)%s"
                              % ("" if not params else "; with symbolic parameters: on the strata shown, the levels K "
                                 "computed for generic parameters; substitute numbers for a complete answer"),
                              "basis": list(res["basis"])}
        else:
            found, ruled, nd, notes = answer_general(eq, K, E, params, Phi, deep=deep)
            res.update(found=found, ruled_out=ruled, not_decided=nd, sector="other")
            res["applies"] = False      # not decided here: the report's general pipeline decides the verdict
            res["basis"] = ["certificate:substitution"] + (["local analysis"] if ruled else [])
            res["verdict"] = {"level": "partial" if any(s.get("kind") != "constant" for s in found) else "formal",
                              "text": "outside the order-two sectors decided by this module; partial information only",
                              "basis": list(res["basis"])}
    # items without a passed exact check are not "found": move them to not_decided with what is known
    keep = []
    for s_ in res["found"]:
        if params and s_.get("certificate", {}).get("status") == "fail" and s_.get("kind") != "constant":
            # with symbolic parameters a failed check comes from the branch of a square root of a parameter
            # expression on a stratum (sqrt(b**2/c**2) is not b/c for all b, c): not certified, not shown as found
            res["not_decided"].append({"what": "a family on the stratum %s" % ", ".join(s_.get("conditions", [])),
                                       "why": "its closed form could not be certified with symbolic parameters "
                                              "(branches of square roots of parameter expressions)",
                                       "partial": "candidate: %s; substitute numbers and call again" % s_.get("expr", "")})
            continue
        if s_.get("certificate", {}).get("status") == "not-run" and s_.get("kind") != "constant":
            where_ = ", ".join(s_.get("conditions", [])) or "of the equation"
            res["not_decided"].append({"what": "a family (%s) %s" % (s_.get("note", "")[:80], where_),
                                       "why": "its substitution check could not be run (%s)"
                                              % s_.get("certificate", {}).get("detail", ""),
                                       "partial": "candidate: %s" % s_.get("expr", "")})
        else:
            keep.append(s_)
    if len(keep) != len(res["found"]):
        res["found"] = keep
        if res["verdict"].get("level") == "complete":
            res["verdict"]["level"] = "partial"
    if _DEG["strata"]:
        res["degenerate_strata"] = list(_DEG["strata"])
        for x_ in _DEG["strata"]:
            res["not_decided"].append({"what": "the degenerate stratum %s" % " and ".join(x_["conditions"]),
                                       "conditions": list(x_["conditions"]), "degenerate": True,
                                       "why": "the equation has lower degree there (a coefficient of its top-degree "
                                              "part vanishes)",
                                       "partial": "enter the reduced equation separately"})
    lc = _lead_condition(E) if res.get("applies") else None
    if lc is not None:
        cs = cond_str(lc, "!=")
        for s_ in res["found"]:
            if cs not in s_.get("conditions", []):
                s_["conditions"] = [cs] + list(s_.get("conditions", []))
        for x in res["ruled_out"]:
            x["conditions"] = [cs] + list(x.get("conditions", []))
        for st in res.get("strata", []):
            st["conditions"] = [cs] + list(st.get("conditions", []))
        res["not_decided"].append({"what": "the stratum %s" % cond_str(lc, "=="),
                                   "conditions": [cond_str(lc, "==")], "degenerate": True,
                                   "why": "the equation is of lower order there",
                                   "partial": "call again with that value substituted"})
    # d summary
    f1 = [s for s in res["found"] if s.get("d") == 1]
    f2 = [s for s in res["found"] if s.get("d") == 2]
    comp = res["verdict"].get("level") == "complete"
    res["d_summary"] = {"1": {"status": "complete" if comp else ("partial" if f1 else "none"), "count": len(f1)},
                        "2": {"status": "found" if f2 else ("ruled out" if comp else "not ruled out"),
                              "basis": res["verdict"].get("text", "")},
                        "3+": {"status": "ruled out" if comp else "not ruled out", "basis": res["verdict"].get("text", "")}}
    if any(s.get("certificate", {}).get("status") == "fail" for s in res["found"]):
        res.setdefault("warnings", []).append("a substitution check FAILED: see the certificates")
    relabel_report(res)
    res["elapsed_s"] = round(time.time() - t0, 3)
    return res
