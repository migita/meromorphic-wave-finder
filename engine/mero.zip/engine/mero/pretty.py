"""mero.pretty -- readable closed forms of the solutions in a report (display only).

    pretty(eq, sol, budget_s=5)                          display fields of one Solution object (SCHEMA section 2)
    pretty_report(report, budget_s=60, per_item_s=5)     the same for every item of `found` (and of the
                                                          sub-reports in strata, substitutions, surfaces)

pretty() returns

    {"display_latex", "display_expr", "display_note",
     "real_form": {"latex", "expr", "note", "bounded": True | False | None} or None,
     "checked": "pass" | "not-run", "method": "..."}

and pretty_report() copies the first four into each item (existing fields are never touched) together with
"display_check": {"status": checked, "method": method}.  display_latex may be a two-line
\\begin{gathered} ... \\\\ k = ... \\end{gathered} block (formula, then the constant k or the invariants).

Checks.  checked = "pass" means: the display form was compared exactly with the item's own formula (constants
substituted, parameter conditions imposed) -- as rational functions of exp(nu (z - z0)/L) for simply periodic
solutions (mero.verify.exact_zero_test applied to the difference, radicals as algebraic numbers), or of wp, wp'
and the exponentials otherwise.  A real form is compared in the same way with the formula after the stated shift
of z0; a free constant traded for a centre z1 (K = c*exp(-nu*z1)) is checked by substituting that relation into
the item's formula.  When no comparison succeeds within the budget, the plain substituted formula is returned
with checked = "not-run" and no real form.  Boundedness is claimed only where it is derived: tanh/sech
polynomials (real k), the poles of a rational function of exp, cosh or cos, and A wp + B with the sign of
g2^3 - 27 g3^2; with symbolic parameters the sign conditions used are listed in the note.

Shapes (kind simply-periodic): with s = exp(nu (z - z0)) the solution is a rational function R(s);
  * one pole in a period:  R is a polynomial in coth k(z - z0), k = nu/2   (cot when k is imaginary);
    the shift z0 -> z0 + i pi/(2k) gives the same polynomial in tanh (bounded on the real axis for real k),
    written with sech^2 when only even powers occur;
  * poles at s = +1 and s = -1:  P(coth X) + csch X Q(coth X), X = nu (z - z0)  (cot, csc for imaginary nu);
    real form P(tanh X) + i sech X Q(tanh X);
  * two poles p, q with R(T) = R(1/T) for T = s/sqrt(pq):  a rational function of cosh X (cos for imaginary nu);
  * otherwise a compact rational function of one exponential; exponential polynomials are only tidied.
Elliptic: A wp(z - z0) + B, or a polynomial / rational function of wp, wp', with g2, g3 below; rational:
partial fractions in z - z0; polynomial, constant, entire, other: collected only.

Time: cooperative checks between the steps, plus a hard SIGALRM limit where the platform allows it (main
thread, no other timer running; not in the browser).  Module-level scratch state: not thread-safe.
Pure Python + SymPy.
"""
import math
import re
import time

import sympy as sp

from .special import wp, wpp, zeta_w
from .verify import _to_exp, exact_zero_test, parse_expression, solution_expression

__all__ = ["pretty", "pretty_report"]

z = sp.Symbol("z")
z0 = sp.Symbol("z0")
z1 = sp.Symbol("z1")
_S = sp.Symbol("S_")
_U = sp.Symbol("U_")
_ZETA = sp.Symbol("zeta_")


class _OutOfTime(BaseException):
    """the time budget of one solution is used up (BaseException: not swallowed by `except Exception`)"""
    pass


def _on_alarm(signum, frame):
    raise _OutOfTime()


def _arm_alarm(seconds):
    """a hard time limit where the platform has one (main thread, SIGALRM, no outer timer running); returns a
    token for _disarm_alarm, or None (then only the cooperative checks between the steps limit the time)"""
    try:
        import signal
        import threading
        if threading.current_thread() is not threading.main_thread() or not hasattr(signal, "setitimer"):
            return None
        if signal.getitimer(signal.ITIMER_REAL)[0] > 0:
            return None
        old = signal.signal(signal.SIGALRM, _on_alarm)
        signal.setitimer(signal.ITIMER_REAL, max(0.05, float(seconds)))
        return (signal, old)
    except Exception:
        return None


def _disarm_alarm(token):
    if token is None:
        return
    try:
        signal, old = token
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, old)
    except Exception:
        pass


class _Budget(object):
    def __init__(self, seconds):
        self.t_stop = time.monotonic() + float(seconds)

    def left(self):
        return max(0.25, self.t_stop - time.monotonic())

    def check(self):
        if time.monotonic() > self.t_stop:
            raise _OutOfTime()


class _Identity(object):
    """the 'equation' E = w: exact_zero_test(_Identity, f) tests f == 0 identically"""

    def __init__(self, params):
        self.terms = {(1,): sp.Integer(1)}
        self.params = list(params)


class _Ctx(object):
    def __init__(self, eq, sol, expr, psub, relations, nonzero, budget):
        self.eq = eq
        self.sol = sol
        self.expr = expr
        self.psub = psub
        self.relations = list(relations)
        self.nonzero = list(nonzero)
        self.params = list(getattr(eq, "params", []))
        self.budget = budget


def _is_zero(f, var, ctx):
    """exact test: f vanishes identically (modulo the relations of the solution)"""
    ctx.budget.check()
    f = sp.sympify(f)
    if f == 0:
        return True
    try:
        if not f.has(sp.exp, wp, wpp, zeta_w, sp.Pow) and sp.expand(f) == 0:
            return True
    except Exception:
        pass
    # no non-vanishing conditions: an identity that holds on {relations = 0} holds on any part of it, and the
    # emptiness test of verify (a Groebner basis with the conditions) is not needed for a comparison
    res = exact_zero_test(_Identity(ctx.params), f, var, ctx.relations, None, (), ctx.budget.left())
    return res.get("status") == "zero"


# ------------------------------------------------------------------------------------------------ numbers
def _ilog(n):
    n = abs(int(n))
    return math.log10(n) if n > 1 else 0.0


def _sqfree(n):
    """n = a**2 * b with b squarefree (n positive integer): returns (a, b)"""
    a, b = 1, 1
    for p, e in sp.factorint(n).items():
        a *= p ** (e // 2)
        if e % 2:
            b *= p
    return a, b


def _num_parts(x):
    """x = q * sqrt(n) with q rational and n a squarefree positive integer (n = 1 allowed), else None"""
    x = sp.nsimplify(x) if isinstance(x, sp.Float) else x
    if x.is_Rational:
        return x, 1
    q, rest = x.as_coeff_Mul()
    if rest.is_Pow and rest.base.is_Integer and rest.base > 0 and rest.exp == sp.Rational(1, 2):
        a, b = _sqfree(int(rest.base))
        return q * a, b
    if rest.is_Pow and rest.base.is_Integer and rest.base > 0 and rest.exp == sp.Rational(-1, 2):
        a, b = _sqfree(int(rest.base))
        return q / (a * b) * a ** 0, b if b != 1 else 1
    return None


def _latex_qsqrt(q, n, split):
    """LaTeX of q*sqrt(n) written as (q*split) * sqrt((n/split)/split) i.e. q*b*sqrt(a/b) with n = a*b"""
    b = split
    a = n // b
    qq = q * b
    sign = "-" if qq < 0 else ""
    qq = abs(qq)
    if a == 1 and b > 1:                      # q*sqrt(n) = q*n/sqrt(n): write  q'/sqrt(b)
        rad = r"\sqrt{%d}" % b
        if qq == 1:
            return sign + r"\frac{1}{%s}" % rad
        if qq.q == 1:
            return sign + r"\frac{%d}{%s}" % (qq.p, rad)
        return sign + r"\frac{%d}{%d %s}" % (qq.p, qq.q, rad)
    rad = r"\sqrt{%d}" % a if b == 1 else r"\sqrt{\tfrac{%d}{%d}}" % (a, b)
    if n == 1:
        rad = ""
    if qq == 1:
        return sign + (rad or "1")
    if qq.q == 1:
        return sign + "%d%s" % (qq.p, (" " + rad) if rad else "")
    if b == 1 and rad:
        return sign + r"\frac{%d %s}{%d}" % (qq.p, rad, qq.q)
    return sign + r"\frac{%d}{%d}%s" % (qq.p, qq.q, (" " + rad) if rad else "")


def _split_score(q, n, b):
    a = n // b
    qq = q * b
    return _ilog(qq.p) + _ilog(qq.q) + _ilog(a) + _ilog(b)


def _best_split(nums):
    """common choice of the split b | n for the numbers q*sqrt(n) of one formula (n fixed)"""
    by_n = {}
    for q, n in nums:
        if n > 1:
            by_n.setdefault(n, []).append(q)
    choice = {}
    for n, qs in by_n.items():
        best = None
        for b in sp.divisors(n):
            sc = sum(_split_score(q, n, b) for q in qs)
            if a_is_one(n, b):
                sc += 0.05
            if best is None or sc < best[0] - 1e-9:
                best = (sc, b)
        choice[n] = best[1]
    return choice


def a_is_one(n, b):
    return n // b == 1 and b > 1


def _latex_number(x, choice=None):
    parts = _num_parts(x)
    if parts is None:
        return None
    q, n = parts
    # self-check: the parts give back x exactly
    if sp.expand(q * sp.sqrt(n) - x) != 0:
        return None
    if n == 1:
        return _latex_qsqrt(q, 1, 1)
    b = (choice or {}).get(n, 1)
    if n % b:
        b = 1
    return _latex_qsqrt(q, n, b)


def _lx(x, choice=None):
    """LaTeX of a coefficient: q*sqrt(n) nicely, anything else by sympy"""
    x = sp.sympify(x)
    t = _latex_number(x, choice)
    if t is not None:
        return t
    return sp.latex(x)


def _tidy(c):
    """a short exact form of a constant expression"""
    c = sp.sympify(c)
    try:
        if sp.count_ops(c) > 400:
            return c
        if not c.free_symbols:
            c2 = sp.radsimp(sp.nsimplify(c) if c.has(sp.Float) else c)
            c3 = sp.simplify(c2) if sp.count_ops(c2) < 80 else c2
            return min([c, c2, c3], key=sp.count_ops)
        c2 = sp.factor(sp.cancel(c))
        cands = [c, c2] if sp.count_ops(c2) <= sp.count_ops(c) + 2 else [c]
        if sp.count_ops(c) < 40 and c.has(sp.Pow):
            c3 = sp.simplify(c)
            if not c3.has(sp.Abs, sp.Piecewise, sp.sign, sp.re, sp.im):
                cands.append(c3)
        return min(cands, key=lambda x: (len(sp.latex(x)), sp.count_ops(x)))
    except Exception:
        return c


# ------------------------------------------------------------------------------------------------ realness
def _realness(exprs, params):
    """(True, [sign conditions]) if every expression is real for real values of all its symbols (radicals of
    symbolic radicands are taken real: 'radicand > 0' is returned as a condition); (False, []) if not or not
    decided"""
    conds = []
    pos = {}
    exprs = [sp.sympify(e) for e in exprs]
    allsyms = set()
    for e in exprs:
        allsyms |= e.free_symbols
        for pw in e.atoms(sp.Pow):
            if pw.exp.is_Rational and not pw.exp.is_Integer and pw.base.free_symbols:
                if pw.exp.q != 2:
                    return False, []
                if pw.base not in pos:
                    pos[pw.base] = sp.Symbol("rho%d_" % len(pos), positive=True)
                    conds.append(pw.base)
    reals = dict((q, sp.Symbol(q.name, real=True)) for q in allsyms)
    try:
        for e in exprs:
            sub = {}
            for pw in e.atoms(sp.Pow):
                if pw.base in pos and pw.exp.is_Rational and not pw.exp.is_Integer:
                    sub[pw] = pos[pw.base] ** pw.exp.p
            e2 = e.xreplace(sub).xreplace(reals)
            if e2.has(sp.exp, wp, wpp, zeta_w):
                return False, []
            im = sp.im(sp.expand(e2))
            if im != 0:
                im = sp.simplify(im)
                if im != 0:
                    return False, []
    except Exception:
        return False, []
    pnames = set(str(q) for q in params) | {"z", "z0", "z1"}
    extra = sorted(str(q) for q in allsyms if str(q) not in pnames)
    return True, ["%s > 0" % sp.sstr(c) for c in conds] + ["%s real" % q for q in extra]


# ------------------------------------------------------------------------------------------------ exponentials
def _to_exp_safe(expr):
    """hyperbolic/trigonometric functions rewritten with exp, radicals of constants left as they are
    (SymPy's rewrite would also turn sqrt(complex) into polar form)"""
    expr = sp.sympify(expr)
    shield = {}
    for pw in expr.atoms(sp.Pow):
        if pw.exp.is_Rational and not pw.exp.is_Integer and z not in pw.free_symbols:
            shield[pw] = sp.Dummy("r")
    if not shield:
        return _to_exp(expr)
    back = dict((v, k) for k, v in shield.items())
    return _to_exp(expr.xreplace(shield)).xreplace(back)


def _exp_atoms(e):
    out = []
    for a in e.atoms(sp.exp):
        if z in a.free_symbols:
            p = sp.Poly(sp.expand(a.args[0]), z)
            if p.degree() != 1:
                raise ValueError("exponent not linear in z")
            A, B = p.all_coeffs()
            out.append((a, A, B))
    return out


def _ratio(A, g):
    """A/g as an exact rational number if it is one (None otherwise)"""
    r = sp.cancel(A / g)
    if r.is_Rational:
        return r
    try:
        r = sp.radsimp(r)
        if r.is_Rational:
            return r
        if sp.count_ops(r) < 80:
            r = sp.simplify(r)
            if r.is_Rational:
                return r
    except Exception:
        pass
    return None


def _to_S(expr, g, center, L=1):
    """expr as a function of S = exp(g*(z - center)/L) (raises ValueError if it is not rational in S)"""
    e = _to_exp_safe(expr)
    sub = {}
    for a, A, B in _exp_atoms(e):
        r = _ratio(A * L, g)
        if r is None or not r.is_Integer:
            raise ValueError("rate not an integer multiple")
        c = sp.expand(B + A * center)
        sub[a] = _S ** int(r) * (sp.exp(c) if c != 0 else 1)
    out = e.xreplace(sub)
    if z in out.free_symbols:
        raise ValueError("not a rational function of exp")
    return out


def _common_L(exprs, g):
    L = 1
    for ex in exprs:
        for _a, A, _B in _exp_atoms(_to_exp_safe(ex)):
            r = _ratio(A, g)
            if r is None:
                raise ValueError("incommensurable rates")
            L = sp.ilcm(L, r.q)
    return int(L)


def _clean(latex):
    return re.sub(r"  +", " ", latex) if isinstance(latex, str) else latex


def _result(latex, expr, note, method, real=None):
    if real is not None and isinstance(real.get("latex"), str):
        real["latex"] = _clean(real["latex"])
    latex = _clean(latex)
    return {"display_latex": latex, "display_expr": sp.sstr(expr) if not isinstance(expr, str) else expr,
            "display_note": note, "real_form": real, "checked": "pass", "method": method}


def _bad_value(expr):
    try:
        return sp.sympify(expr).has(sp.nan, sp.zoo, sp.oo, -sp.oo)
    except Exception:
        return True


def _fallback(sol, expr, why):
    try:
        if _bad_value(expr):
            raise ValueError("the substituted formula is not a finite expression")
        lt = sp.latex(expr)
        ex = sp.sstr(expr)
    except Exception:
        lt, ex = sol.get("latex", ""), sol.get("expr", "")
        why += "; the item's own formula is kept"
    return {"display_latex": lt, "display_expr": ex, "display_note": "", "real_form": None,
            "checked": "not-run", "method": "plain substituted formula (%s)" % why}


# ------------------------------------------------------------------------------------------------ helpers
def _fun_power_latex(name, j, arg_latex):
    if j == 1:
        return r"\%s %s" % (name, arg_latex) if name in ("tanh", "coth", "tan", "cot", "cosh", "cos") \
            else r"\operatorname{%s} %s" % (name, arg_latex)
    if name in ("tanh", "coth", "tan", "cot", "cosh", "cos"):
        return r"\%s^{%d} %s" % (name, j, arg_latex)
    return r"\operatorname{%s}^{%d} %s" % (name, j, arg_latex)


def _poly_display(c0, coeffs, name, arg_latex, choice):
    """LaTeX of c0 + sum_j coeffs[j] f^j (coeffs: dict j -> coefficient), with a common numeric factor"""
    js = sorted([j for j in coeffs if coeffs[j] != 0], reverse=True)
    head = "" if c0 == 0 else _lx(c0, choice)
    if not js:
        return head or "0"
    nums = [coeffs[j] for j in js]
    factor, ints = None, None
    if all(c.is_number for c in nums) and len(js) > 1:
        try:
            top = nums[0]
            ratios = [sp.nsimplify(sp.radsimp(c / top)) for c in nums]
            if all(r.is_Rational for r in ratios):
                Lq = sp.ilcm(*[r.q for r in ratios])
                ms = [int(r * Lq) for r in ratios]
                gq = sp.igcd(*ms)
                ms = [m // gq for m in ms]
                factor = sp.radsimp(top / ms[0])
                ints = ms
                if any(sp.expand(sp.radsimp(factor * m - c)) != 0 for m, c in zip(ms, nums)):
                    factor, ints = None, None          # the factored form must give back every coefficient
        except Exception:
            factor = None
    pieces = []
    if factor is not None and _num_parts(factor) is not None:
        inner = []
        for m, j in zip(ints, js):
            t = _fun_power_latex(name, j, arg_latex)
            if m == 1:
                s = t
            elif m == -1:
                s = "-" + t
            else:
                s = "%d %s" % (m, t)
            inner.append(s)
        inner_s = " + ".join(inner).replace("+ -", "- ")
        fl = _lx(factor, choice)
        if fl == "1":
            body = inner_s
        elif fl == "-1":
            body = r"-\left(%s\right)" % inner_s
        else:
            body = r"%s\left(%s\right)" % (fl, inner_s)
        pieces.append(body)
    else:
        for j in js:
            c = coeffs[j]
            t = _fun_power_latex(name, j, arg_latex)
            cl = _lx(c, choice)
            if cl == "1":
                pieces.append(t)
            elif cl == "-1":
                pieces.append("-" + t)
            elif c.is_number:
                pieces.append("%s %s" % (cl, t))
            else:
                pieces.append(r"\left(%s\right) %s" % (cl, t) if isinstance(c, sp.Add) else "%s %s" % (cl, t))
    out = " + ".join(([head] if head else []) + pieces)
    return out.replace("+ -", "- ")


def _poly_body(c0, coeffs, name, arg, choice):
    """the expanded display, or the factored one when it is shorter"""
    expanded = _poly_display(c0, coeffs, name, arg, choice)
    try:
        vals = [c0] + list(coeffs.values())
        if all(sp.sympify(v).is_number for v in vals) and len([v for v in coeffs.values() if v != 0]) >= 2:
            P = c0 + sp.Add(*[cj * _U ** j for j, cj in coeffs.items()])
            F = sp.factor(P)
            facs = [f for f in sp.Mul.make_args(F) if not f.is_number]
            powered = [f for f in facs if f.is_Pow and isinstance(f.base, sp.Add) and f.exp.is_Integer
                       and f.exp >= 2]
            plain_add = [f for f in facs if isinstance(f, sp.Add)]
            if powered and not plain_add and sp.count_ops(F) < sp.count_ops(P):
                Y = sp.Symbol("Y_")
                fl = (r"\%s %s" % (name, arg)) if name in ("tanh", "coth", "tan", "cot") else \
                    (r"\operatorname{%s} %s" % (name, arg))
                lt = sp.latex(F.xreplace({_U: Y}), symbol_names={Y: fl})
                if len(lt) < len(expanded):
                    return lt
    except Exception:
        pass
    return expanded


def _number_choice(values):
    nums = []
    for v in values:
        p = _num_parts(sp.sympify(v))
        if p is not None:
            nums.append(p)
    return _best_split(nums)


def _poly_expr(c0, coeffs, fexpr):
    return c0 + sp.Add(*[c * fexpr ** j for j, c in coeffs.items()])


# ------------------------------------------------------------------------------------------------ simply periodic
def _find_rate(expr, sol=None):
    """g: the solution is rational in exp(g*z) (the smallest rate that makes every exponent an integer multiple)"""
    atoms = _exp_atoms(_to_exp_safe(expr))
    if not atoms:
        return None
    A0 = sorted([A for _a, A, _B in atoms], key=lambda a: (sp.count_ops(a), str(a)))[0]
    L = 1
    for _a, A, _B in atoms:
        r = _ratio(A, A0)
        if r is None:
            return None
        L = sp.ilcm(L, r.q)
    return A0 / L


def _free_const_form(R0, sol):
    """R0 = R(S; F), S = exp(g z): if R depends on S only through T = F*S or T = S/F for a free constant F,
    returns (R(T), F, mode) with mode 'mul' (T = F*S) or 'div' (T = S/F)"""
    free = [f for f in (sol.get("free") or []) if f != "z0"]
    for name in free + sorted(str(s) for s in R0.free_symbols if str(s) in ("K", "zeta0", "K1", "C", "k0")):
        F = sp.Symbol(name)
        if F not in R0.free_symbols:
            continue
        for mode, sub in (("mul", _S / F), ("div", _S * F)):
            R1 = sp.cancel(sp.together(R0.subs(_S, sub)))
            if F not in R1.free_symbols:
                return R1, F, mode
    return None


def _same_as_R(disp, R, g, center, ctx):
    """disp(z) == R(S) with S = exp(g*(z - center)), exactly (disp rational in exp(g*(z - center)/L))"""
    L = _common_L([disp], g)
    D = _to_S(disp, g, center, L)
    target = R.xreplace({_S: _S ** L}) if L != 1 else R
    return _is_zero(sp.together(D - target), _S, ctx)


def _exp_latex(R, g, center, choice=None, monomial_numerator=False):
    """LaTeX of R(S), S = e^{g (z - center)}, in the shorter of the variables S and 1/S; None if long"""
    best = None
    for sign in (1, -1):
        Rv = sp.factor(sp.cancel(R.xreplace({_S: _S ** sign})))
        if monomial_numerator and len(sp.Add.make_args(sp.expand(sp.fraction(Rv)[0]))) > 1:
            continue
        if best is None or sp.count_ops(Rv) < best[0]:
            best = (sp.count_ops(Rv), Rv, sign)
    if best is None:
        return None
    _n, Rf, sign = best
    if sp.count_ops(Rf) > 30:
        return None
    E = sp.Symbol("E_")
    ch = _number_choice([g])
    arg = _arg_latex(_tidy(sign * g), center, ch)
    return sp.latex(Rf.xreplace({_S: E}), symbol_names={E: r"e^{%s}" % arg})


def _pretty_sp(ctx):
    expr = ctx.expr
    sol = ctx.sol
    g = _find_rate(expr)
    if g is None:
        return None
    ctx.budget.check()
    if z0 in expr.free_symbols:
        L = _common_L([expr], g)
        g = g / L
        R = sp.cancel(sp.together(_to_S(expr, g, z0, 1)))
        if z0 in R.free_symbols:
            return None
        if len(sp.Poly(sp.fraction(R)[1], _S).terms()) <= 1:
            return None                     # no poles: an exponential polynomial, kept as a sum
        center, F, mode = z0, None, None
    else:
        L = _common_L([expr], g)
        g = g / L
        R0 = sp.cancel(sp.together(_to_S(expr, g, 0, 1)))
        if len(sp.Poly(sp.fraction(R0)[1], _S).terms()) <= 1:
            return None                     # no poles: an exponential polynomial (Laurent in exp), kept as a sum
        got = _free_const_form(R0, sol)
        if got is None:
            return None
        R, F, mode = got
        center = z1
    ctx.budget.check()
    shaped = _sp_shapes(ctx, expr, R, g, center, F, mode)
    if shaped is not None:
        return shaped
    return _sp_exp_form(ctx, expr, R, g, center, F, mode)


def _sp_exp_form(ctx, expr, R, g, center, F, mode):
    """fallback: R(S) written compactly in exponentials, S = e^{g (z - center)}"""
    if center == z1:
        Fval = sp.exp(-g * z1) if mode == "mul" else sp.exp(g * z1)
        if not _same_as_R(expr.xreplace({F: Fval}), R, g, z1, ctx):
            return None
        note = "the free constant %s is written as %s = %s" % (F, F, sp.sstr(Fval))
    else:
        note = ""
    best = None
    for sign in (1, -1):
        Rv = sp.factor(sp.cancel(R.xreplace({_S: _S ** sign})))
        if best is None or sp.count_ops(Rv) < best[0]:
            best = (sp.count_ops(Rv), Rv, sign)
    _n, Rf, sign = best
    gg = _tidy(sign * g)
    disp = Rf.xreplace({_S: sp.exp(gg * (z - center))})
    if not _same_as_R(disp, R, g, center, ctx):
        return None
    E = sp.Symbol("E_")
    lt = sp.latex(Rf.xreplace({_S: E}), symbol_names={E: r"e^{%s}" % _arg_latex(gg, center, _number_choice([gg]))})
    real = None
    try:
        real = _exp_real(ctx, R, g, center)
    except _OutOfTime:
        raise
    except Exception:
        real = None
    return _result(lt, disp, note, "rational function of one exponential; compared exactly with the formula", real)


def _exp_real(ctx, R, g, center):
    """real g: the member R(mu*S), mu = 1 or -1 (centre shifted by 0 or i*pi/g), with real coefficients; bounded on
    the real axis iff no pole S > 0 and no pole at S = 0 or infinity (S = e^{g (z - centre)} runs over (0, oo))"""
    if not _eq_is_real(ctx):
        return None
    okg, condg = _realness([g], ctx.params)
    if not okg:
        return None
    found = []
    for mu, shift_txt in ((1, ""), (-1, "%s -> %s + i*pi/(%s)" % (center, center, sp.sstr(g)))):
        Rm = sp.cancel(sp.together(R.xreplace({_S: mu * _S})))
        N, D = sp.fraction(Rm)
        coeffs = sp.Poly(N, _S).coeffs() + sp.Poly(D, _S).coeffs()
        lc = sp.Poly(D, _S).LC()
        ok, conds = _realness([sp.cancel(c / lc) for c in coeffs], ctx.params)
        if not ok:
            continue
        Dp = sp.Poly(D, _S)
        roots = _small_roots(D)
        bounded = None
        if roots is not None and all(not r.free_symbols for r in roots) and not condg:
            pos = [r for r in roots if r == 0 or (r.is_real and r > 0)]
            growth = sp.Poly(N, _S).degree() > Dp.degree()
            bounded = not pos and not growth
        found.append((mu, shift_txt, Rm, ok, conds, bounded))
    if not found:
        return None
    found.sort(key=lambda t: (t[5] is not True,))
    mu, shift_txt, Rm, _ok, conds, bounded = found[0]
    best = None
    for sign in (1, -1):
        Rv = sp.factor(sp.cancel(Rm.xreplace({_S: _S ** sign})))
        if best is None or sp.count_ops(Rv) < best[0]:
            best = (sp.count_ops(Rv), Rv, sign)
    _n, Rf, sign = best
    gg = _tidy(sign * g)
    rexpr = Rf.xreplace({_S: sp.exp(gg * (z - center))})
    Rs = sp.cancel(sp.together(R.xreplace({_S: mu * _S})))
    if not _same_as_R(rexpr, Rs, g, center, ctx):
        return None
    E = sp.Symbol("E_")
    lt = sp.latex(Rf.xreplace({_S: E}), symbol_names={E: r"e^{%s}" % _arg_latex(gg, center, _number_choice([gg]))})
    note = ("%s: " % shift_txt if shift_txt else "") + "real for real %s" % center
    if bounded is True:
        note += "; bounded on the real axis (no pole of the exponential variable on (0, oo))"
    elif bounded is False:
        note += "; not bounded on the real axis (a pole on the real axis, or growth at one end)"
    allc = condg + [c for c in conds if c not in condg]
    if allc:
        note += "; for real parameters with " + ", ".join(allc)
    return {"latex": lt, "expr": sp.sstr(rexpr), "note": note, "bounded": bounded}


def _small_roots(D):
    """{root: multiplicity} of the polynomial D(S) when every irreducible factor has degree <= 2 (no Cardano
    formulas: they are not what a reader wants), else None"""
    _c, facs = sp.factor_list(D, _S)
    roots = {}
    for f, mult in facs:
        fp = sp.Poly(f, _S)
        if fp.degree() == 0:
            continue
        if fp.degree() > 2:
            return None
        rs = sp.roots(fp, _S)
        if sum(rs.values()) != fp.degree():
            return None
        for r, m in rs.items():
            roots[r] = roots.get(r, 0) + m * mult
    return roots


def _sp_shapes(ctx, expr, R, g, center, F, mode):
    N, D = sp.fraction(sp.together(R))
    Dp = sp.Poly(D, _S)
    Np = sp.Poly(N, _S)
    if Np.degree() > Dp.degree():
        return None                                   # growth at one end
    if Dp.degree() > 12 or sp.count_ops(D) > 400:
        return None
    roots = _small_roots(D)
    if roots is None:
        return None
    if 0 in roots:
        return None
    nz = list(roots)
    ctx.budget.check()
    if len(nz) == 1:
        m = nz[0]
        shape = "one"
    elif len(nz) == 2 and sp.simplify(nz[0] + nz[1]) == 0:
        m = nz[0]
        shape = "antipodal"
    elif len(nz) == 2:
        m = sp.sqrt(_tidy(sp.expand(nz[0] * nz[1])))
        shape = "cosh"
    else:
        return None
    Rm = sp.cancel(sp.together(R.xreplace({_S: m * _S})))
    if shape == "cosh":
        sym = sp.cancel(sp.together(Rm - Rm.xreplace({_S: 1 / _S})))
        if sym != 0:
            m = -m
            Rm = sp.cancel(sp.together(R.xreplace({_S: m * _S})))
            if sp.cancel(sp.together(Rm - Rm.xreplace({_S: 1 / _S}))) != 0:
                return None
    # the relation between the free constant and the centre
    if center == z0:
        if m == 1:
            note_pre = ""
        else:
            shift = sp.log(m) / g
            # check: the item's formula at z0 - log(m)/g is the displayed function of exp(g (z - z0))
            if not _same_as_R(expr.xreplace({z0: z0 - shift}), Rm, g, z0, ctx):
                return None
            note_pre = ("z0 is renamed: z0 here = z0 of the item + %s; " % sp.sstr(_tidy(shift)))
    else:
        # mode 'mul': T = F*exp(g z), mode 'div': T = exp(g z)/F, and T = m*exp(g (z - z1))
        Fval = m * sp.exp(-g * z1) if mode == "mul" else sp.exp(g * z1) / m
        # check the relation: the formula with F = Fval is Rm(exp(g (z - z1)))
        if not _same_as_R(expr.xreplace({F: Fval}), Rm, g, z1, ctx):
            return None
        note_pre = "the free constant %s is written as %s = %s; " % (F, F, sp.sstr(Fval))
    if shape == "one":
        return _sp_one_pole(ctx, Rm, g, center, note_pre)
    if shape == "antipodal":
        return _sp_two_pole_antipodal(ctx, Rm, g, center, note_pre)
    return _sp_two_pole_cosh(ctx, Rm, g, center, note_pre)


def _imag_rate(g):
    """g = i*kappa with kappa a real number: returns kappa, else None"""
    g = sp.sympify(g)
    if g.free_symbols:
        return None
    kap = sp.radsimp(sp.expand(g / sp.I))
    try:
        if kap.is_real and not g.is_real:
            return kap
    except Exception:
        pass
    return None


def _arg_latex(k, center, choice):
    """LaTeX of k (z - center)"""
    kl = _lx(k, choice)
    zl = r"\left(z - %s\right)" % sp.latex(center)
    if kl == "1":
        return zl
    if kl == "-1":
        return "-" + zl
    if not sp.sympify(k).is_number and isinstance(sp.sympify(k), sp.Add):
        kl = r"\left(%s\right)" % kl
    return kl + zl


_RESERVED = set()
_ALTS = {"k": ["k", "m", r"\mu", r"\lambda"], r"\kappa": [r"\kappa", r"\mu", "m", r"\lambda"]}


def _free_letter(sym):
    for cand in _ALTS.get(sym, [sym]):
        if cand.lstrip("\\") not in _RESERVED:
            return cand
    return sym


def _with_k(body, kk, sym, choice):
    if kk == 1:
        return body
    sym = _free_letter(sym)
    body = body.replace(" " + _lx(kk, choice) + r"\left(z", " " + sym + r"\left(z")
    return r"\begin{gathered} %s \\ %s = %s \end{gathered}" % (body, sym, _lx(kk, choice))


def _eq_is_real(ctx):
    """the coefficients of the equation, with the parameter values of the conditions substituted, are real for
    real parameters; and no constant of the solution is given only as a root of a polynomial (its realness
    is not known)"""
    try:
        if _ROOT_SYMS & set(str(s_) for s_ in ctx.expr.free_symbols):
            return False
        cos = [sp.sympify(c).xreplace(ctx.psub or {}) for c in ctx.eq.terms.values()]
        return _realness(cos, ctx.params)[0]
    except Exception:
        return False


def _sp_one_pole(ctx, R, g, center, note_pre):
    """R has its only pole at S = 1: a polynomial in coth(k (z - center)), k = g/2"""
    W = sp.cancel(sp.together(R.xreplace({_S: (_U + 1) / (_U - 1)})))
    Wn, Wd = sp.fraction(W)
    if _U in Wd.free_symbols:
        return None
    Wp = sp.Poly(sp.expand(Wn), _U)
    coeffs = {}
    for (j,), cj in Wp.terms():
        coeffs[j] = _tidy(cj / Wd)
    c0 = coeffs.pop(0, sp.Integer(0))
    k = g / 2
    ctx.budget.check()
    kap = _imag_rate(k)
    if kap is not None:
        coeffs_disp = dict((j, _tidy(cj * (-sp.I) ** j)) for j, cj in coeffs.items())
        fexpr, name, kk, sym = sp.cot(kap * (z - center)), "cot", kap, r"\kappa"
    else:
        coeffs_disp = coeffs
        fexpr, name, kk, sym = sp.coth(k * (z - center)), "coth", k, "k"
    if kk.is_number and kk.is_real and kk < 0:          # coth, cot are odd: k > 0
        kk = -kk
        coeffs_disp = dict((j, _tidy(cj * (-1) ** j)) for j, cj in coeffs_disp.items())
        fexpr = (sp.coth if name == "coth" else sp.cot)(kk * (z - center))
    disp = _poly_expr(c0, coeffs_disp, fexpr)
    if not _same_as_R(disp, R, g, center, ctx):
        return None
    choice = _number_choice(list(coeffs_disp.values()) + [c0, kk])
    body = _poly_body(c0, coeffs_disp, name, _arg_latex(kk, center, choice), choice)
    latex = _with_k(body, kk, sym, choice)
    note = note_pre + ("k = nu/2 = %s" % sp.sstr(kk) if name == "coth" else
                       "k = nu/2 is imaginary: coth(k(z - z0)) = -i*cot(kappa*(z - z0)), kappa = %s" % sp.sstr(kk))
    real = None
    try:
        real = _sp_one_pole_real(ctx, R, g, center, c0, coeffs_disp, name, kk, sym, choice)
    except _OutOfTime:
        raise
    except Exception:
        real = None
    return _result(latex, disp, note, "polynomial in %s; compared exactly with the formula as a rational "
                   "function of exp" % name, real)


def _sp_one_pole_real(ctx, R, g, center, c0, coeffs, name, kk, sym, choice):
    if not _eq_is_real(ctx):
        return None
    ok, conds = _realness([c0, kk] + list(coeffs.values()), ctx.params)
    if not ok:
        return None
    cname = sp.sstr(center)
    if name == "coth":
        fexpr = sp.tanh(kk * (z - center))
        rexpr = _poly_expr(c0, coeffs, fexpr)
        shift = sp.I * sp.pi / (2 * kk)
        newname, bounded = "tanh", True
        note = ("%s -> %s + i*pi/(2k) turns coth into tanh: real and bounded on the real axis for real %s"
                % (cname, cname, cname))
    else:
        coeffs = dict((j, _tidy(cj * (-1) ** j)) for j, cj in coeffs.items())
        fexpr = sp.tan(kk * (z - center))
        rexpr = _poly_expr(c0, coeffs, fexpr)
        shift = sp.pi / (2 * kk)
        newname, bounded = "tan", False
        note = ("real, with poles on the real axis (%s -> %s + pi/(2 kappa) turns cot into -tan; for real %s the "
                "cot form is real as well)" % (cname, cname, cname))
    if conds:
        note += "; for real parameters with " + ", ".join(conds)
    # the shift center -> center + shift multiplies S = exp(g (z - center)) by exp(-g*shift)
    Rs = sp.cancel(sp.together(R.xreplace({_S: _S * sp.exp(sp.expand(-g * shift))})))
    if not _same_as_R(rexpr, Rs, g, center, ctx):
        return None
    body = _poly_body(c0, coeffs, newname, _arg_latex(kk, center, choice), choice)
    if newname == "tanh" and coeffs and all(j % 2 == 0 for j in coeffs):
        # only even powers: tanh**2 = 1 - sech**2
        v = sp.Symbol("v_")
        Q = sp.Poly(sp.expand(c0 + sp.Add(*[cj * (1 - v) ** (j // 2) for j, cj in coeffs.items()])), v)
        d = dict((2 * jj, _tidy(cj)) for (jj,), cj in Q.terms())
        d0 = d.pop(0, sp.Integer(0))
        sexpr = _poly_expr(d0, d, sp.sech(kk * (z - center)))
        if len([1 for x in d.values() if x != 0]) <= len(coeffs) and _same_as_R(sexpr, Rs, g, center, ctx):
            body2 = _poly_body(d0, d, "sech", _arg_latex(kk, center, choice), choice)
            body = body2
            rexpr = sexpr
            note += "; tanh**2 = 1 - sech**2"
    latex = _with_k(body, kk, r"\kappa" if newname == "tan" else "k", choice)
    if newname == "tanh":
        try:
            el = _exp_latex(Rs, g, center, monomial_numerator=True)
            if el is not None and len(el) < 120:
                latex = latex.replace(r"\begin{gathered} ", r"\begin{gathered} %s = " % el, 1) \
                    if latex.startswith(r"\begin{gathered}") else "%s = %s" % (el, latex)
        except Exception:
            pass
    return {"latex": latex, "expr": sp.sstr(rexpr), "note": note, "bounded": bounded}


def _sp_two_pole_antipodal(ctx, R, g, center, note_pre):
    """poles at S = 1 and S = -1:  P(coth X) + csch X * Q(coth X), X = g (z - center)"""
    W = sp.cancel(sp.together(R.xreplace({_S: (_U + 1) / (_U - 1)})))
    Wn, Wd = sp.fraction(W)
    Wdp = sp.Poly(Wd, _U)
    if len(Wdp.terms()) != 1:
        return None
    C, Cs = sp.Symbol("C_"), sp.Symbol("Cs_")
    (m,), dcoef = Wdp.terms()[0]
    num = sp.Poly(sp.expand(Wn), _U)
    tot = sp.Integer(0)
    for (j,), cj in num.terms():
        e = j - m
        tot += cj / dcoef * ((C + Cs) ** e if e >= 0 else (C - Cs) ** (-e))
    tot = sp.Poly(sp.expand(tot), Cs)
    P0, Q0 = sp.Integer(0), sp.Integer(0)
    for (j,), cj in tot.terms():
        if j % 2 == 0:
            P0 += cj * (C ** 2 - 1) ** (j // 2)
        else:
            Q0 += cj * (C ** 2 - 1) ** (j // 2)
    P0 = sp.Poly(sp.expand(P0), C)
    Q0 = sp.Poly(sp.expand(Q0), C)
    kap = _imag_rate(g)
    if kap is None:
        X = g * (z - center)
        fc, fs = sp.coth(X), sp.csch(X)
        cP = dict((j, _tidy(cj)) for (j,), cj in P0.terms())
        cQ = dict((j, _tidy(cj)) for (j,), cj in Q0.terms())
        names = ("coth", "csch")
        kk, sym = g, "k"
    else:
        X = kap * (z - center)
        fc, fs = sp.cot(X), sp.csc(X)
        cP = dict((j, _tidy(cj * (-sp.I) ** j)) for (j,), cj in P0.terms())
        cQ = dict((j, _tidy(cj * (-sp.I) ** (j + 1))) for (j,), cj in Q0.terms())
        names = ("cot", "csc")
        kk, sym = kap, r"\kappa"
    if kk.is_number and kk.is_real and kk < 0:          # all four functions are odd: positive rate
        kk = -kk
        cP = dict((j, _tidy(cj * (-1) ** j)) for j, cj in cP.items())
        cQ = dict((j, _tidy(-cj * (-1) ** j)) for j, cj in cQ.items())
        X = kk * (z - center)
        fc, fs = (sp.coth(X), sp.csch(X)) if names[0] == "coth" else (sp.cot(X), sp.csc(X))
    disp = sp.Add(*[cj * fc ** j for j, cj in cP.items()]) + fs * sp.Add(*[cj * fc ** j for j, cj in cQ.items()])
    if not _same_as_R(disp, R, g, center, ctx):
        return None
    choice = _number_choice(list(cP.values()) + list(cQ.values()) + [kk])
    body = _two_latex(cP, cQ, names, _arg_latex(kk, center, choice), choice)
    latex = _with_k(body, kk, sym, choice)
    note = note_pre + ("k = nu = %s" % sp.sstr(kk) if kap is None else "nu = i*kappa, kappa = %s" % sp.sstr(kk))
    real = None
    try:
        real = _antipodal_real(ctx, R, g, center, cP, cQ, names, kk, sym, choice)
    except _OutOfTime:
        raise
    except Exception:
        real = None
    return _result(latex, disp, note, "%s and %s; compared exactly with the formula as a rational function of "
                   "exp" % names, real)


def _two_latex(cP, cQ, names, arg, choice):
    cP, cQ = dict(cP), dict(cQ)
    c0 = cP.pop(0, sp.Integer(0))
    partP = _poly_display(c0, cP, names[0], arg, choice) if (cP or c0 != 0) else ""
    q0 = cQ.pop(0, sp.Integer(0))
    fsl = (r"\operatorname{%s} %s" % (names[1], arg)) if names[1] not in ("tanh", "cosh", "cos", "sin", "sinh")\
        else r"\%s %s" % (names[1], arg)
    if cQ:
        partQ = r"%s\left(%s\right)" % (fsl, _poly_display(q0, cQ, names[0], arg, choice))
    elif q0 != 0:
        ql = _lx(q0, choice)
        partQ = (fsl if ql == "1" else ("-" + fsl if ql == "-1" else
                                        (r"\left(%s\right) %s" % (ql, fsl) if isinstance(q0, sp.Add) else
                                         "%s %s" % (ql, fsl))))
    else:
        partQ = ""
    return " + ".join([t for t in (partP, partQ) if t]).replace("+ -", "- ") or "0"


def _antipodal_real(ctx, R, g, center, cP, cQ, names, kk, sym, choice):
    """real k: center -> center + i*pi/(2k) gives P(tanh X) + i*sech X*Q(tanh X), real iff Q imaginary"""
    if not _eq_is_real(ctx):
        return None
    if names[0] == "cot":
        ok, conds = _realness([kk] + list(cP.values()) + list(cQ.values()), ctx.params)
        if not ok:
            return None
        X = kk * (z - center)
        rexpr = sp.Add(*[cj * sp.cot(X) ** j for j, cj in cP.items()]) + \
            sp.csc(X) * sp.Add(*[cj * sp.cot(X) ** j for j, cj in cQ.items()])
        if not _same_as_R(rexpr, R, g, center, ctx):
            return None
        body = _two_latex(cP, cQ, names, _arg_latex(kk, center, choice), choice)
        note = ("real for real %s, with poles on the real axis (the poles z = %s + n*pi/kappa are real)"
                % (center, center))
        if conds:
            note += "; for real parameters with " + ", ".join(conds)
        return {"latex": _with_k(body, kk, sym, choice), "expr": sp.sstr(rexpr), "note": note, "bounded": False}
    if names[0] != "coth":
        return None
    cQi = dict((j, _tidy(sp.I * cj)) for j, cj in cQ.items())
    ok, conds = _realness([kk] + list(cP.values()) + list(cQi.values()), ctx.params)
    if not ok:
        # the centres giving a real function are Im c = 0 or pi/(2k) (mod pi/k); the second is not real here
        ok0, conds0 = _realness([kk] + list(cP.values()) + list(cQ.values()), ctx.params)
        if not ok0:
            return None
        X = kk * (z - center)
        rexpr = sp.Add(*[cj * sp.coth(X) ** j for j, cj in cP.items()]) + \
            sp.csch(X) * sp.Add(*[cj * sp.coth(X) ** j for j, cj in cQ.items()])
        if not _same_as_R(rexpr, R, g, center, ctx):
            return None
        body = _two_latex(cP, cQ, names, _arg_latex(kk, center, choice), choice)
        note = ("real for real %s, with poles on the real axis; the poles are symmetric under conjugation only "
                "for Im %s = 0 or pi/(2k) (mod pi/k), and the member with Im %s = pi/(2k) is not real"
                % (center, center, center))
        if conds0:
            note += "; for real parameters with " + ", ".join(conds0)
        return {"latex": _with_k(body, kk, sym, choice), "expr": sp.sstr(rexpr), "note": note, "bounded": False}
    X = kk * (z - center)
    rexpr = sp.Add(*[cj * sp.tanh(X) ** j for j, cj in cP.items()]) + \
        sp.sech(X) * sp.Add(*[cj * sp.tanh(X) ** j for j, cj in cQi.items()])
    shift = sp.I * sp.pi / (2 * kk)
    Rs = sp.cancel(sp.together(R.xreplace({_S: _S * sp.exp(sp.expand(-g * shift))})))
    if not _same_as_R(rexpr, Rs, g, center, ctx):
        return None
    body = _two_latex(cP, cQi, ("tanh", "sech"), _arg_latex(kk, center, choice), choice)
    note = ("%s -> %s + i*pi/(2k): coth -> tanh, csch -> i sech; real and bounded on the real axis for real %s"
            % (center, center, center))
    if conds:
        note += "; for real parameters with " + ", ".join(conds)
    return {"latex": _with_k(body, kk, sym, choice), "expr": sp.sstr(rexpr), "note": note, "bounded": True}


def _sp_two_pole_cosh(ctx, Rt, g, center, note_pre):
    """Rt(S) = Rt(1/S): a rational function of cosh(g (z - center)) (cos for imaginary g)"""
    y = sp.Symbol("y_")
    N, D = sp.fraction(sp.together(Rt))
    try:
        fy = _sym_to_y(N, D, _S, y)
    except Exception:
        return None
    if fy is None:
        return None
    fy = sp.cancel(fy)
    kap = _imag_rate(g)
    if kap is None:
        fexpr, kk, nm, sym = sp.cosh(g * (z - center)), g, "cosh", "k"
    else:
        fexpr, kk, nm, sym = sp.cos(kap * (z - center)), kap, "cos", r"\kappa"
    if kk.is_number and kk.is_real and kk < 0:          # cosh, cos are even: positive rate
        kk = -kk
        fexpr = (sp.cosh if nm == "cosh" else sp.cos)(kk * (z - center))
    try:
        fy2 = sp.apart(fy, y) if sp.count_ops(fy) < 200 else fy
    except Exception:
        fy2 = fy
    fy2 = sp.Add(*[_tidy(t) for t in sp.Add.make_args(fy2)])
    disp = fy2.xreplace({y: fexpr})
    if not _same_as_R(disp, Rt, g, center, ctx):
        return None
    choice = _number_choice([kk])
    Y = sp.Symbol("Y_")
    lt = sp.latex(fy2.xreplace({y: Y}), symbol_names={Y: r"\%s %s" % (nm, _arg_latex(kk, center, choice))})
    lt = _with_k(lt, kk, sym, choice)
    real = None
    try:
        real = _cosh_real(ctx, fy, y, Rt, g, center, kk, nm, sym, choice)
    except _OutOfTime:
        raise
    except Exception:
        real = None
    return _result(lt, disp, note_pre.rstrip("; "), "rational function of %s; compared exactly with the formula "
                   "as a rational function of exp" % nm, real)


def _cosh_real(ctx, fy, y, Rt, g, center, kk, nm, sym, choice):
    """real members of f(cosh X) (f(cos X)): the centre as it is, or shifted by i*pi/g (cosh X -> -cosh X);
    bounded iff the denominator of f has no root in the range of cosh (of cos) on the real axis"""
    if not _eq_is_real(ctx):
        return None
    cands = []
    for mu in (1, -1):
        f = sp.cancel(fy.xreplace({y: mu * y}))
        num, den = sp.fraction(sp.together(f))
        ok, conds = _realness([kk] + sp.Poly(num, y).coeffs() + sp.Poly(den, y).coeffs(), ctx.params)
        if not ok:
            continue
        dp = sp.Poly(den, y)
        rts = sp.roots(dp, y) if dp.degree() > 0 else {}
        bounded = None
        if sum(rts.values()) == dp.degree() and all(not r.free_symbols for r in rts):
            if nm == "cosh":
                bad = [r for r in rts if r.is_real and r >= 1]
            else:
                bad = [r for r in rts if r.is_real and -1 <= r <= 1]
            bounded = not bad
        cands.append((mu, f, conds, bounded))
    if not cands:
        return None
    cands.sort(key=lambda t: (t[3] is not True, t[0] != 1))
    mu, f, conds, bounded = cands[0]
    try:
        f2 = sp.apart(f, y) if sp.count_ops(f) < 200 else f
    except Exception:
        f2 = f
    f2 = sp.Add(*[_tidy(t) for t in sp.Add.make_args(f2)])
    fexpr = sp.cosh(kk * (z - center)) if nm == "cosh" else sp.cos(kk * (z - center))
    rexpr = f2.xreplace({y: fexpr})
    Rs = sp.cancel(sp.together(Rt.xreplace({_S: mu * _S})))       # centre + i*pi/g multiplies S by -1
    if not _same_as_R(rexpr, Rs, g, center, ctx):
        return None
    Y = sp.Symbol("Y_")
    lt = sp.latex(f2.xreplace({y: Y}), symbol_names={Y: r"\%s %s" % (nm, _arg_latex(kk, center, choice))})
    lt = _with_k(lt, kk, sym, choice)
    shift = "" if mu == 1 else ("%s -> %s + i*pi/(%s) (%s X -> -%s X): " % (center, center, sp.sstr(g), nm, nm))
    note = shift + "real for real %s; " % center + ("bounded on the real axis" if bounded else
                                                   ("with poles on the real axis" if bounded is False else
                                                    "boundedness not decided"))
    if conds:
        note += "; for real parameters with " + ", ".join(conds)
    return {"latex": lt, "expr": sp.sstr(rexpr), "note": note, "bounded": bounded}


def _sym_to_y(N, D, T, y):
    """N/D symmetric under T -> 1/T: express as a rational function of y = (T + 1/T)/2"""
    Np, Dp = sp.Poly(N, T), sp.Poly(D, T)
    # make both palindromic of even degree by multiplying by powers of T
    def lowdeg(P):
        return min(m[0] for m in P.monoms())
    out = []
    for P in (Np, Dp):
        lo, hi = lowdeg(P), P.degree()
        out.append((P, lo, hi))
    # N/D = (T**-a N)/(T**-a D); choose a = (lo+hi)/2 of D
    (Pd, lo, hi) = out[1]
    if (lo + hi) % 2:
        return None
    a = (lo + hi) // 2
    res = []
    for P in (Np, Dp):
        e = sp.expand(P.as_expr() * T ** (-a))
        res.append(_laurent_sym_to_y(e, T, y))
    if res[0] is None or res[1] is None:
        return None
    return res[0] / res[1]


def _laurent_sym_to_y(e, T, y):
    """a Laurent polynomial in T symmetric under T -> 1/T as a polynomial in y = (T + 1/T)/2"""
    e = sp.expand(e)
    terms = {}
    for t in sp.Add.make_args(e):
        c, k = t.as_independent(T, as_Add=False)
        if k == 1:
            d = 0
        elif k == T:
            d = 1
        elif k.is_Pow and k.base == T:
            d = int(k.exp)
        else:
            return None
        terms[d] = terms.get(d, 0) + c
    out = sp.Integer(0)
    # T**d + T**-d = 2 cheb_T(d, y)
    for d in sorted(terms):
        if d < 0:
            continue
        if d == 0:
            out += terms[d]
            continue
        if sp.simplify(terms[d] - terms.get(-d, 0)) != 0:
            return None
        out += terms[d] * 2 * sp.chebyshevt(d, y)
    return sp.expand(out)


# ------------------------------------------------------------------------------------------------ elliptic
def _pretty_ell(ctx):
    expr = ctx.expr
    wps = list(expr.atoms(wp)) + list(expr.atoms(wpp))
    if not wps:
        return None
    args = set((a.args[0], a.args[1], a.args[2]) for a in wps)
    if len(args) != 1:
        return None
    u, g2, g3 = list(args)[0]
    g2t, g3t = _tidy(g2), _tidy(g3)
    for a, b in ((g2t, g2), (g3t, g3)):
        if a != b and not _is_zero(sp.together(a - b), z, ctx):
            return None
    P, Pp = sp.Symbol("P_"), sp.Symbol("Pp_")
    e0 = expr.xreplace({wp(u, g2, g3): P, wpp(u, g2, g3): Pp})
    if z in e0.free_symbols:
        return None
    e = sp.cancel(sp.together(e0)) if sp.count_ops(e0) < 600 else e0
    n, d = sp.fraction(sp.together(e))
    linear = (Pp not in e.free_symbols and sp.Poly(d, P).degree() == 0 and sp.Poly(n, P).degree() == 1)
    if linear:
        A = _tidy(sp.cancel(sp.Poly(n, P).coeff_monomial(P) / d))
        B = _tidy(sp.cancel(sp.Poly(n, P).coeff_monomial(1) / d))
        disp_core = A * P + B
    else:
        cands = [e0, e]
        try:
            if sp.count_ops(e) < 300:
                cands.append(sp.factor(e))
        except Exception:
            pass
        disp_core = min(cands, key=sp.count_ops)
    ug2g3 = (u, g2t, g3t)
    disp = disp_core.xreplace({P: wp(*ug2g3), Pp: wpp(*ug2g3)})
    if not _is_zero(sp.together(disp - expr.xreplace({wp(u, g2, g3): wp(*ug2g3), wpp(u, g2, g3): wpp(*ug2g3)})),
                    z, ctx):
        return None
    Pl, Ppl = sp.Symbol("Pl_"), sp.Symbol("Ppl_")
    ul = sp.latex(u)
    names = {Pl: r"\wp\left(%s\right)" % ul, Ppl: r"\wp'\left(%s\right)" % ul}
    if linear:
        choice = _number_choice([A, B, g2t, g3t])
        al = _lx(A, choice)
        wpl = names[Pl]
        if al == "1":
            core = wpl
        elif al == "-1":
            core = "-" + wpl
        elif isinstance(A, sp.Add):
            core = r"\left(%s\right) %s" % (al, wpl)
        else:
            core = "%s %s" % (al, wpl)
        if B != 0:
            core = (core + " + " + _lx(B, choice)).replace("+ -", "- ")
    else:
        choice = {}
        core = None
        try:
            nn, dd = sp.fraction(sp.together(e))
            if not ({P, Pp} & dd.free_symbols):
                pol = sp.Poly(sp.expand(nn), P, Pp)
                terms = sorted(pol.terms(), key=lambda t: (-t[0][0] - 3 * t[0][1] / 2.0))
                pieces = []
                for (i, j), cij in terms:
                    cij = _tidy(sp.cancel(cij / dd))
                    mon = []
                    if i:
                        mon.append(r"\wp%s\left(%s\right)" % ("" if i == 1 else "^{%d}" % i, ul))
                    if j:
                        mon.append(r"\wp'\left(%s\right)%s" % (ul, "" if j == 1 else "^{%d}" % j))
                    mon = " ".join(mon)
                    cl = _lx(cij)
                    if not mon:
                        pieces.append(cl)
                    elif cl == "1":
                        pieces.append(mon)
                    elif cl == "-1":
                        pieces.append("-" + mon)
                    elif isinstance(cij, sp.Add):
                        pieces.append(r"\left(%s\right) %s" % (cl, mon))
                    else:
                        pieces.append("%s %s" % (cl, mon))
                core = " + ".join(pieces).replace("+ -", "- ")
        except Exception:
            core = None
        if core is None:
            core = sp.latex(disp_core.xreplace({P: Pl, Pp: Ppl}), symbol_names=names)
        core = re.sub(r"\\wp\\left\(([^()]*)\\right\)\^\{(\d+)\}", r"\\wp^{\2}\\left(\1\\right)", core)
    def inv_l(name, v):
        if isinstance(v, sp.Symbol) and v.name == name:
            return r"%s_%s \text{ free}" % (name[0], name[1])
        return r"%s_%s = %s" % (name[0], name[1], _lx(v, choice))
    inv = r"%s,\quad %s" % (inv_l("g2", g2t), inv_l("g3", g3t))
    latex = r"\begin{gathered} %s \\ %s \end{gathered}" % (core, inv)
    notes = []
    if g2t == 0:
        notes.append("g2 = 0: equianharmonic case")
    if g3t == 0:
        notes.append("g3 = 0: lemniscatic case")
    Delta = None
    try:
        Delta = _tidy(sp.expand(g2t ** 3 - 27 * g3t ** 2))
        if g2t != 0 and g3t != 0 and Delta.is_number:
            notes.append("discriminant g2^3 - 27 g3^2 = %s" % sp.sstr(Delta))
    except Exception:
        pass
    jac = _jacobi_note(disp_core, P, Pp, g2t, g3t, u)
    if jac:
        notes.append(jac)
    real = None
    if linear:
        try:
            real = _ell_real(ctx, A, B, g2t, g3t, u, Delta, latex, disp)
        except _OutOfTime:
            raise
        except Exception:
            real = None
    return _result(latex, disp, "; ".join(notes), "%s; compared exactly with the formula (wp, wp' as "
                   "generators)" % ("A wp + B" if linear else "rational in wp, wp'"), real)


def _jacobi_note(core, P, Pp, g2, g3, u):
    return ""


def _ell_real(ctx, A, B, g2, g3, u, Delta, latex, disp):
    eq_real = _eq_is_real(ctx)
    if not eq_real:
        return None
    ok, conds = _realness([A, B, g2, g3], ctx.params)
    if not ok:
        return None
    free_inv = [s for s in (g2.free_symbols | g3.free_symbols) if s.name in ("g2", "g3")]
    cond_txt = ("; for real parameters with " + ", ".join(conds)) if conds else ""
    if free_inv:
        note = ("real on the real axis for real z0 and real %s; a member bounded on the real axis exists "
                "when g2^3 - 27 g3^2 > 0 (z0 shifted by the imaginary half-period: wp then stays in [e3, e2]); "
                "for g2^3 - 27 g3^2 < 0 every real solution reaches a pole" % ", ".join(sorted(s.name for s in free_inv)))
        return {"latex": latex, "expr": sp.sstr(disp), "note": note + cond_txt, "bounded": None}
    if Delta is not None and Delta.is_number and not Delta.free_symbols:
        if Delta > 0:
            note = ("real for real z0 (poles on the real axis); z0 -> z0 + omega' (the imaginary half-period; "
                    "g2^3 - 27 g3^2 = %s > 0, rectangular lattice) gives the member bounded on the real axis, "
                    "with wp in [e3, e2]" % sp.sstr(Delta))
            return {"latex": latex, "expr": sp.sstr(disp), "note": note + cond_txt, "bounded": True}
        if Delta < 0:
            note = ("real for real z0, with poles on the real axis; g2^3 - 27 g3^2 = %s < 0: the cubic "
                    "4P^3 - g2 P - g3 has one real root, so every real solution of P'^2 = 4P^3 - g2 P - g3 reaches "
                    "a pole; no member is bounded on the real axis" % sp.sstr(Delta))
            return {"latex": latex, "expr": sp.sstr(disp), "note": note + cond_txt, "bounded": False}
    note = ("real for real z0 (poles on the real axis); a member bounded on the real axis exists when "
            "g2^3 - 27 g3^2 > 0 (z0 shifted by the imaginary half-period) and none when g2^3 - 27 g3^2 < 0")
    return {"latex": latex, "expr": sp.sstr(disp), "note": note + cond_txt, "bounded": None}


# ------------------------------------------------------------------------------------------------ rational etc.
def _pretty_rat(ctx):
    expr = ctx.expr
    if z0 in expr.free_symbols:
        e = sp.expand(expr.xreplace({z: _ZETA + z0}))
        if z0 in e.free_symbols:
            e = sp.cancel(sp.together(expr.xreplace({z: _ZETA + z0})))
        cen = z0
    else:
        e = expr.xreplace({z: _ZETA})
        cen = None
    if z0 in e.free_symbols and cen is not None:
        return None
    try:
        a = sp.apart(sp.together(e), _ZETA) if sp.count_ops(e) < 400 else e
    except Exception:
        a = e
    terms = sp.Add.make_args(a)
    a = sp.Add(*[_tidy(t) for t in terms])
    disp = a.xreplace({_ZETA: z - cen}) if cen is not None else a.xreplace({_ZETA: z})
    if not _is_zero(sp.together(disp - expr), z, ctx):
        return None
    zl = r"\left(z - z_{0}\right)" if cen is not None else "z"
    lt = sp.latex(a, symbol_names={_ZETA: zl}, order="rev-lex") if cen is not None else sp.latex(disp)
    real = None
    try:
        eq_real = _eq_is_real(ctx)
        ok, conds = _realness([t.xreplace({_ZETA: 1}) for t in terms], ctx.params)
        if eq_real and ok and cen is not None:
            real = {"latex": lt, "expr": sp.sstr(disp),
                    "note": "real for real z0, with a pole at z0 on the real axis (a real member has its only "
                            "pole centre on the real axis)" + ("; for " + ", ".join(conds) if conds else ""),
                    "bounded": False}
    except Exception:
        real = None
    return _result(lt, disp, "", "partial fractions in z - z0; compared exactly", real)


def _pretty_poly(ctx):
    expr = ctx.expr
    if z0 in expr.free_symbols:
        e = sp.expand(expr.xreplace({z: _ZETA + z0}))
        if z0 not in e.free_symbols:
            disp = sp.collect(e, _ZETA).xreplace({_ZETA: z - z0})
            lt = sp.latex(sp.collect(e, _ZETA), symbol_names={_ZETA: r"\left(z - z_{0}\right)"})
            if _is_zero(sp.expand(disp - expr), z, ctx):
                return _result(lt, disp, "", "polynomial in z - z0; compared exactly")
    e = sp.collect(sp.expand(expr), z)
    if not _is_zero(sp.expand(e - expr), z, ctx):
        return None
    return _result(sp.latex(e), e, "", "collected; compared exactly")


def _pretty_const(ctx):
    e = _tidy(ctx.expr)
    if not _is_zero(sp.together(e - ctx.expr), z, ctx):
        return None
    return _result(_lx(e) if _num_parts(e) is not None else sp.latex(e), e, "", "simplified constant; compared exactly")


def _pretty_tidy(ctx):
    expr = ctx.expr
    try:
        e = sp.collect(sp.expand(expr, power_exp=False, power_base=False, log=False, multinomial=True),
                       list(expr.atoms(sp.exp))) if sp.count_ops(expr) < 300 else expr
    except Exception:
        e = expr
    try:
        same = _is_zero(sp.together(e - expr), z, ctx)
    except _OutOfTime:
        raise
    except Exception:
        same = False
    if not same and e != expr:
        e = expr
        try:
            same = _is_zero(sp.together(e - expr), z, ctx)
        except _OutOfTime:
            raise
        except Exception:
            same = False
    if not same:
        return None             # the caller returns the plain substituted formula, checked = 'not-run'
    return _result(sp.latex(e), e, "", "tidied (collected); compared exactly")


# ------------------------------------------------------------------------------------------------ main
_ROOT_NOTES = {}
_ROOT_SYMS = set()


def _solve_roots(expr, sol, relations):
    """a constant given as 'any root of a*x**2 - b = 0' is replaced by sqrt(b/a) when the formula is even in
    x (then both roots give the same function); the relation is removed from `relations` (in place)"""
    _ROOT_NOTES.clear()
    _ROOT_SYMS.clear()
    for name, val in (sol.get("constants") or {}).items():
        if isinstance(val, str) and val.startswith("any root of"):
            _ROOT_SYMS.add(name)
    par_syms = {}
    for name, val in (sol.get("constants") or {}).items():
        if not (isinstance(val, str) and val.startswith("any root of")):
            continue
        x = sp.Symbol(name)
        if x not in expr.free_symbols:
            continue
        try:
            P = parse_expression(val[len("any root of"):].split("=")[0], [x])
            P = P.xreplace(dict((s, par_syms.get(s, s)) for s in P.free_symbols))
            Pp = sp.Poly(sp.expand(P), x)
        except Exception:
            continue
        if Pp.degree() != 2 or Pp.coeff_monomial(x) != 0:
            continue
        val_x = sp.sqrt(sp.cancel(-Pp.coeff_monomial(1) / Pp.coeff_monomial(x ** 2)))
        try:
            even = sp.expand(expr - expr.xreplace({x: -x})) == 0 or \
                exact_zero_test(_Identity([]), expr - expr.xreplace({x: -x}), z, [], None, [], 2.0)["status"] == "zero"
        except Exception:
            even = False
        if not even:
            continue
        expr = expr.xreplace({x: val_x})
        keep = []
        for r in relations:
            r2 = sp.expand(sp.sympify(r).xreplace({x: val_x}))
            if r2 != 0 and not (r2.is_number and sp.simplify(r2) == 0):
                keep.append(r)
        relations[:] = keep
        _ROOT_NOTES[name] = "%s = %s (either root of %s = 0; the formula is even in %s)" % (
            name, sp.sstr(val_x), sp.sstr(P), name)
    return expr


def pretty(eq, sol, budget_s=5.0):
    """Display fields of a Solution object (dict).  Never raises."""
    token = _arm_alarm(float(budget_s) + 0.5)
    try:
        try:
            return _pretty(eq, sol, budget_s)
        finally:
            _disarm_alarm(token)
    except _OutOfTime:
        pass
    except Exception as err:
        return {"display_latex": sol.get("latex", "") if isinstance(sol, dict) else "",
                "display_expr": sol.get("expr", "") if isinstance(sol, dict) else "", "display_note": "",
                "real_form": None, "checked": "not-run", "method": "error: %s" % (str(err)[:200],)}
    return {"display_latex": sol.get("latex", "") if isinstance(sol, dict) else "",
            "display_expr": sol.get("expr", "") if isinstance(sol, dict) else "", "display_note": "",
            "real_form": None, "checked": "not-run", "method": "time budget of %.1f s reached" % budget_s}


def _pretty(eq, sol, budget_s):
    budget = _Budget(budget_s)
    _RESERVED.clear()
    _RESERVED.update(str(q) for q in getattr(eq, "params", []))
    try:
        _RESERVED.update(str(s_) for s_ in parse_expression(sol.get("expr") or "0").free_symbols)
    except Exception:
        pass
    try:
        sol = dict(sol)
        consts = {}
        for name, val in (sol.get("constants") or {}).items():
            if isinstance(val, str) and (val.strip().startswith("free") or val.startswith("any root")
                                         or ";" in val):
                if val.startswith("any root"):
                    consts[name] = val
                continue
            consts[name] = val
        sol["constants"] = consts
        expr, psub, relations, _syms, nonzero = solution_expression(eq, sol)
        expr = _solve_roots(expr, sol, relations)
    except Exception as err:
        why = "could not read the solution: %s" % (err,)
        if "RootOf" in str(sol.get("expr", "")):
            why = "a constant given as a root of a polynomial (RootOf): the item's own form is kept"
        return {"display_latex": sol.get("latex", ""), "display_expr": sol.get("expr", ""), "display_note": "",
                "real_form": None, "checked": "not-run", "method": why}
    ctx = _Ctx(eq, sol, expr, psub, relations, nonzero, budget)
    kind = sol.get("kind")
    if _bad_value(expr):
        return _fallback(sol, expr, "the constants of the item make its formula undefined (nan or infinity)")
    res = None
    why = "no rule for this shape"
    try:
        if kind == "simply-periodic":
            res = _pretty_sp(ctx)
            why = "not of a recognised exponential shape"
        elif kind == "elliptic":
            res = _pretty_ell(ctx)
            why = "not of a recognised elliptic shape"
        elif kind == "rational":
            res = _pretty_rat(ctx)
        elif kind == "polynomial":
            res = _pretty_poly(ctx)
        elif kind == "constant":
            res = _pretty_const(ctx)
        if res is None and kind in ("simply-periodic", "elliptic", "entire", "other", "rational", "polynomial"):
            res = _pretty_tidy(ctx)
            if res is not None and kind in ("simply-periodic", "elliptic"):
                res["method"] += " (%s)" % why
    except _OutOfTime:
        res = None
        why = "time budget of %.1f s reached" % budget_s
    except Exception as err:
        res = None
        why = "error: %s" % (str(err)[:200] or repr(err))
    if res is None:
        return _fallback(sol, expr, why)
    extra = []
    for name, txt in _ROOT_NOTES.items():
        extra.append(txt)
    try:
        shown = parse_expression(res["display_expr"]).free_symbols
    except Exception:
        shown = set()
    for name, val in (sol.get("constants") or {}).items():
        if isinstance(val, str) and val.startswith("any root of") and sp.Symbol(name) in shown:
            extra.append("%s is %s" % (name, val))
    if extra:
        res["display_note"] = "; ".join([t for t in [res.get("display_note", "")] + extra if t])
    return res


def _equation_from(d):
    from .equation import Equation
    text = d.get("sympy") if isinstance(d, dict) else None
    if not text:
        return None
    par = [sp.Symbol(p) for p in (d.get("params") or [])]
    E = parse_expression(text, par)
    return Equation(E=E, parameters=par)


def pretty_report(report, budget_s=60.0, per_item_s=5.0, stats=None):
    """Adds display_latex, display_expr, display_note, real_form to every item of `found` (and of the
    sub-reports in strata, substitutions, surfaces).  Existing fields are not touched; items beyond the total
    budget are left unchanged.  Never raises."""
    t_stop = time.monotonic() + float(budget_s)

    def run(rep, eqd):
        try:
            eq = _equation_from(eqd)
        except Exception:
            eq = None
        if eq is None:
            return
        for it in rep.get("found") or []:
            if not isinstance(it, dict) or "display_latex" in it:
                continue
            left = t_stop - time.monotonic()
            if left <= 0.05:
                if stats is not None:
                    stats.append(("skipped", it.get("origin"), it.get("kind"), 0.0, "total budget"))
                continue
            t0 = time.monotonic()
            try:
                out = pretty(eq, it, min(per_item_s, left))
            except Exception as err:            # pretty never raises; belt and braces
                out = None
                if stats is not None:
                    stats.append(("error", it.get("origin"), it.get("kind"), 0.0, str(err)))
            dt = time.monotonic() - t0
            if out is None:
                continue
            for key in ("display_latex", "display_expr", "display_note", "real_form"):
                it.setdefault(key, out[key])
            it.setdefault("display_check", {"status": out["checked"], "method": out["method"]})
            if stats is not None:
                stats.append((out["checked"], it.get("origin"), it.get("kind"), dt,
                              out["method"], bool(out.get("real_form"))))

    try:
        run(report, report.get("equation") or {})
        for key in ("strata", "substitutions", "surfaces"):
            for sub in report.get(key) or []:
                if not isinstance(sub, dict):
                    continue
                eqd = sub.get("equation") or sub.get("reduced") or {}
                if isinstance(eqd, dict) and "params" not in eqd:
                    eqd = dict(eqd, params=(report.get("equation") or {}).get("params", []))
                run(sub, eqd)
    except Exception:
        pass
    return report
