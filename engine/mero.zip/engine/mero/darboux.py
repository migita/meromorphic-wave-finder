"""mero.darboux -- invariant algebraic hypersurfaces (Darboux polynomials) of bounded weight.

Equation solved for the top derivative, w_K = Phi(w_0, ..., w_{K-1}); its companion vector field on C^K is

    X = w_1 d/dw_0 + ... + w_{K-1} d/dw_{K-2} + Phi d/dw_{K-1}.

A Darboux polynomial is a nonconstant polynomial G(w_0..w_{K-1}) with X(G) = L*G, L a polynomial (the
cofactor).  Along every solution, d/dz G(w, w', ...) = L G, so a solution that starts on {G = 0} stays on it
and satisfies the equation G(w, ..., w^(K-1)) = 0 of lower order.

Grading (lemma `darboux`, project file): weight(w_j) = a + b*j with coprime positive
integers a, b (p = a/b, by default the pole order of the dominant balance); every monomial of Phi has weight
<= a + b*K.  Then X raises the weight by at most b and the cofactor has weight <= b: L = ell (a constant) when
p > 1, L = ell + c*w0 when p = 1, L = ell + c_w0*w0 + c_w0_2*w0**2 + ... when p < 1.

Numeric equations with p >= 1: for fixed c, the Darboux polynomials of weight <= m with cofactor ell + c*w0 are
exactly the eigenvectors of X_c = X - c*w0 on U, the largest X_c-invariant subspace of the space V_m of polynomials
of weight <= m; U is found by a Krylov iteration, the admissible ell are the roots of the characteristic polynomial
of X_c on U, the admissible c are the roots of a maximal minor of the top-weight pencil.

Symbolic parameters (or p < 1): the kernel of G -> X(G) - L G on V_m over Q(parameters, cofactor coefficients),
with a recursion over the irreducible factors of the pivots (strata of the parameter space).  Nothing is scanned;
every listed G carries the exact check X(G) - L G = 0.

Pure SymPy (it runs in the browser); budgets via time.monotonic().  Public:

    darboux_polynomials(eq, max_weight=None, budget_s=60, p=None, max_dim=160, explore=True) -> dict
    reduce_on_surface(eq, G) -> (Equation or None, info dict)
    verify_darboux(eq, G, L) -> certificate dict
    lie_derivative(eq, G) -> X(G) as a SymPy expression
"""
import time
from fractions import Fraction

import sympy as sp
from sympy import QQ
from sympy.polys.matrices import DomainMatrix

try:
    from .equation import Equation
except ImportError:                                   # pragma: no cover - before CORE's module existed
    from .bootstrap import Equation

SCHEMA = "mero-darboux/1"
ELL = sp.Symbol("ell")

_TOP_KERNEL_CACHE = {}          # (K, a, b, top part, k) -> list of SymPy polynomials (first integrals of X_0)


class _OutOfTime(Exception):
    pass


# ----------------------------------------------------------------------------------------------- basics
def _phi_dict(eq):
    """Phi as {exponent tuple (e_0..e_{K-1}): SymPy coefficient}"""
    K = eq.K
    gens = eq.w[:K]
    rhs = sp.sympify(eq.rhs)
    if rhs == 0:
        return {}
    P = sp.Poly(sp.expand(rhs), *gens)
    out = {}
    for mon, co in P.terms():
        co = sp.cancel(co)
        if co != 0:
            out[tuple(int(e) for e in mon)] = co
    return out


def _field_parts(eq):
    """(A, Psi) as exponent dicts with A*w_K = Psi; A = {0: 1} for a solved equation; None if E is not linear in
    w_K (or A = 0)"""
    K = eq.K
    zero = tuple([0] * K)
    if getattr(eq, "solved", False) and eq.rhs is not None:
        return {zero: sp.Integer(1)}, _phi_dict(eq)
    E = sp.expand(sp.sympify(eq.E))
    P = sp.Poly(E, eq.w[K])
    if P.degree() != 1:
        return None
    Acoef, B = P.all_coeffs()
    gens = eq.w[:K]

    def todict(x):
        x = sp.expand(x)
        if x == 0:
            return {}
        Q = sp.Poly(x, *gens)
        return dict((tuple(int(t) for t in mon), sp.cancel(co)) for mon, co in Q.terms() if co != 0)
    A = todict(Acoef)
    if not A:
        return None
    return A, todict(-B)


def _is_quasilinear(eq):
    return not (getattr(eq, "solved", False) and eq.rhs is not None)


def _fresh_name(base, taken):
    """base if it is not taken, else base1, base2, ... (auxiliary names never coincide with parameters or jets)"""
    taken = set(taken)
    if base not in taken:
        return base
    i = 1
    while "%s%d" % (base, i) in taken:
        i += 1
    return "%s%d" % (base, i)


def _taken_names(eq):
    """names that auxiliary symbols must avoid: the parameters and the jets w0, ..., w_K (and a few beyond)"""
    names = set(s_.name for s_ in getattr(eq, "params", []))
    names |= set("w%d" % j for j in range(eq.K + 3))
    return names


def _wt(e, weights):
    return sum(ej * wj for ej, wj in zip(e, weights))


def choose_grading(eq, p=None):
    """The grading weight(w_j) = a + b*j.  Returns a dict, or {'error': ...}.

    Default p: the largest admissible value, min over the nonlinear monomials w^e of Phi of
    (K - sum j e_j)/(|e| - 1) (the pole order of the dominant balance); p = 1 for a linear equation."""
    K = eq.K
    phi = _phi_dict(eq)
    bound = None
    for e in phi:
        n = sum(e)
        J = sum(j * ej for j, ej in enumerate(e))
        if n >= 2:
            if J >= K:
                return {"error": "the monomial %s has derivative order %d >= K = %d: no grading weight(w_j) = "
                                 "a + b j with a, b > 0 makes X raise the weight by at most b"
                                 % (sp.Mul(*[w ** ej for w, ej in zip(eq.w, e)]), J, K)}
            r = Fraction(K - J, n - 1)
            bound = r if bound is None else min(bound, r)
    if p is None:
        p = bound if bound is not None else Fraction(1)
    else:
        p = Fraction(p)
        if p <= 0 or (bound is not None and p > bound):
            return {"error": "p = %s is not admissible (need 0 < p <= %s)" % (p, bound)}
    a, b = p.numerator, p.denominator
    weights = [a + b * j for j in range(K)]
    topw = a + b * K
    top = dict((e, c) for e, c in phi.items() if _wt(e, weights) == topw)
    return {"p": p, "a": a, "b": b, "weights": weights, "top_weight": topw, "top_terms": top,
            "p_max": bound}


def choose_grading_ql(eq, parts, max_cof=6, max_dim=160):
    """Grading for a quasi-linear equation A w_K = Psi (statement 9): weight(w_j) = a + b j; Y raises the weight by at
    most delta = max(wt(A-monomial) + b, wt(Psi-monomial) - wt(w_{K-1})); the cofactor has weight <= delta.  Among
    p in {1, 2, 3, 1/2, 3/2} the one with the fewest cofactor monomials (then the smallest V_m) is taken."""
    A, Psi = parts
    K = eq.K
    best = None
    for p in [Fraction(1), Fraction(2), Fraction(3), Fraction(1, 2), Fraction(3, 2)]:
        a, b = p.numerator, p.denominator
        weights = [a + b * j for j in range(K)]
        raises = [_wt(al, weights) + b for al in A] + [_wt(ps, weights) - weights[K - 1] for ps in Psi]
        delta = max(raises)
        cof = _monomials(weights, delta) if delta >= 0 else []
        topw = weights[K - 1] + delta
        m = 2 * topw
        N = len(_monomials(weights, m))
        key = (len(cof), N)
        if best is None or key < best[0]:
            best = (key, p, a, b, weights, delta, cof, topw)
    (ncof, N), p, a, b, weights, delta, cof, topw = best
    if ncof > max_cof:
        return {"error": "quasi-linear equation: the cofactor has %d unknown coefficients in the best grading tried "
                         "(more than %d); not treated" % (ncof, max_cof)}
    Atop = dict((al, co) for al, co in A.items() if _wt(al, weights) + b == delta)
    Ptop = dict((ps, co) for ps, co in Psi.items() if _wt(ps, weights) - weights[K - 1] == delta)
    return {"p": p, "a": a, "b": b, "weights": weights, "top_weight": topw, "top_terms": Ptop, "top_A": Atop,
            "delta": delta, "cof_monomials": cof, "p_max": None, "quasilinear": True}


def _monomials(weights, M):
    """exponent tuples of weight <= M, sorted by weight (descending), then reversed exponents (descending)"""
    out = []
    K = len(weights)

    def rec(j, rem, cur):
        if j == K:
            out.append(tuple(cur))
            return
        for e in range(rem // weights[j] + 1):
            cur.append(e)
            rec(j + 1, rem - e * weights[j], cur)
            cur.pop()

    if M >= 0:
        rec(0, M, [])
    out.sort(key=lambda e: (-_wt(e, weights), tuple(reversed(e))), reverse=False)
    return out


def _mono_expr(e, w):
    r = sp.Integer(1)
    for j, ej in enumerate(e):
        if ej:
            r *= w[j] ** ej
    return r


def _make_domain(params):
    return QQ.frac_field(*params) if params else QQ


def _is_const(dom, v):
    if not getattr(dom, "is_FractionField", False):
        return True
    return v.numer.is_ground and v.denom.is_ground


def _score(dom, v):
    """pivot preference: constants first, then low degree, few terms"""
    if not getattr(dom, "is_FractionField", False):
        return (0, 0, 0)
    n, d = v.numer, v.denom
    if n.is_ground and d.is_ground:
        return (0, 0, 0)
    deg = max([sum(mm) for mm in n.monoms()] or [0]) + max([sum(mm) for mm in d.monoms()] or [0])
    return (1, deg, len(n.terms()) + len(d.terms()))


def _apply_X(e, phi_dom, K, dom, c=None, a_dom=None):
    """X(w^e) - c*w0*w^e as {exponent: domain element}; with a_dom (quasi-linear equation A w_K = Psi, phi_dom = Psi)
    the shift part is multiplied by A: Y = A*(w1 d/dw0 + ...) + Psi d/dw_{K-1}"""
    out = {}
    for j in range(K - 1):
        ej = e[j]
        if ej:
            f = list(e)
            f[j] -= 1
            f[j + 1] += 1
            if a_dom is None:
                f = tuple(f)
                out[f] = out.get(f, dom.zero) + dom.convert(ej)
            else:
                cej = dom.convert(ej)
                for al, co in a_dom.items():
                    g = tuple(f[i] + al[i] for i in range(K))
                    out[g] = out.get(g, dom.zero) + cej * co
    ek = e[K - 1]
    if ek:
        base = list(e)
        base[K - 1] -= 1
        cek = dom.convert(ek)
        for g, co in phi_dom.items():
            f = tuple(base[i] + g[i] for i in range(K))
            out[f] = out.get(f, dom.zero) + cek * co
    if c is not None and c:
        f = list(e)
        f[0] += 1
        f = tuple(f)
        out[f] = out.get(f, dom.zero) - c
    return dict((k, v) for k, v in out.items() if v)


# ----------------------------------------------------------------------------------- exact linear algebra
class _Echelon(object):
    """reduced row echelon basis of a space of sparse row vectors over a field; records the pivots"""

    def __init__(self, dom, record):
        self.dom = dom
        self.rows = {}           # pivot column -> row dict (1 at the pivot, 0 at the other pivots)
        self.record = record

    def reduce(self, v):
        v = dict(v)
        dom = self.dom
        for pc, row in self.rows.items():
            a = v.get(pc)
            if a:
                for k, val in row.items():
                    nv = v.get(k, dom.zero) - a * val
                    if nv:
                        v[k] = nv
                    else:
                        v.pop(k, None)
        return v

    def insert(self, v):
        """v must be reduced and nonzero; returns the normalised row"""
        dom = self.dom
        pc = min(v, key=lambda k: (_score(dom, v[k]), k))
        piv = v[pc]
        if not _is_const(dom, piv):
            self.record.append(piv)
        inv = dom.one / piv
        v = dict((k, val * inv) for k, val in v.items())
        for opc, row in self.rows.items():
            a = row.get(pc)
            if a:
                for k, val in v.items():
                    nv = row.get(k, dom.zero) - a * val
                    if nv:
                        row[k] = nv
                    else:
                        row.pop(k, None)
        self.rows[pc] = v
        return v


def _nullspace(rows, ncols, dom, record, deadline=None):
    """basis of {y : R y = 0} for sparse rows R over dom (list of dicts)"""
    ech = _Echelon(dom, record)
    for r in rows:
        if deadline is not None and time.monotonic() > deadline:
            raise _OutOfTime()
        v = ech.reduce(r)
        if v:
            ech.insert(v)
    free = [j for j in range(ncols) if j not in ech.rows]
    basis = []
    for f in free:
        y = {f: dom.one}
        for pc, row in ech.rows.items():
            val = row.get(f)
            if val:
                y[pc] = -val
        basis.append(y)
    return basis


# ------------------------------------------------------------------------------------ the core computation
def _top_kernel(eq_like_phi_top, K, grad, k, w):
    """first integrals of the truncated field X_0 of weight exactly k (cached per (K, grading, top part, k))"""
    a, b, weights = grad["a"], grad["b"], grad["weights"]
    key = (K, a, b, tuple(sorted((e, str(c)) for e, c in eq_like_phi_top.items())), k)
    if key in _TOP_KERNEL_CACHE:
        return _TOP_KERNEL_CACHE[key]
    params = sorted(set().union(*[sp.sympify(c).free_symbols for c in eq_like_phi_top.values()])
                    if eq_like_phi_top else set(), key=lambda s: s.name)
    dom = _make_domain(params)
    phi_dom = dict((e, dom.from_sympy(sp.sympify(c))) for e, c in eq_like_phi_top.items())
    cols = [e for e in _monomials(weights, k) if _wt(e, weights) == k]
    if not cols:
        _TOP_KERNEL_CACHE[key] = []
        return []
    rows = {}
    for j, e in enumerate(cols):
        for f, v in _apply_X(e, phi_dom, K, dom).items():
            rows.setdefault(f, {})[j] = v
    ns = _nullspace(list(rows.values()), len(cols), dom, [])
    out = []
    for y in ns:
        expr = sum(dom.to_sympy(v) * _mono_expr(cols[j], w) for j, v in y.items())
        out.append(_primitive_expr(expr, w))
    _TOP_KERNEL_CACHE[key] = out
    return out


def _primitive_expr(expr, w):
    """clear denominators of the coefficients and remove the content (as a polynomial in the jets); the leading
    coefficient is made positive (rational) or 1 (algebraic coefficients)"""
    expr = sp.sympify(expr)
    if expr == 0:
        return sp.Integer(0)
    try:
        P = sp.Poly(expr, *w)
        if P.is_zero:
            return sp.Integer(0)
        dom = P.get_domain()
        if dom.is_Field and not dom.is_QQ and not getattr(dom, "is_AlgebraicField", False):
            _, P = P.clear_denoms(convert=True)
        elif dom.is_QQ:
            _, P = P.clear_denoms(convert=True)
        if not getattr(P.get_domain(), "is_AlgebraicField", False):
            P = P.primitive()[1]
        num = P.as_expr()
    except Exception:
        num = sp.fraction(sp.together(sp.expand(expr)))[0]
        num = sp.expand(num)
        P = sp.Poly(num, *w)
    P = sp.Poly(num, *reversed(list(w)))       # leading term: highest jets first (w_{K-1} before w0)
    lc = P.coeffs()[0]
    if lc.is_number:
        if lc.is_Rational:
            if lc < 0:
                num = -num
        else:
            num = num / lc                       # algebraic coefficients: make the leading coefficient 1
    else:
        try:
            if sp.Poly(lc).LC() < 0:
                num = -num
        except Exception:
            pass
    return sp.expand(num)


def _vec_to_expr(y, cols, w, dom):
    return sp.expand(sum(dom.to_sympy(v) * _mono_expr(cols[j], w) for j, v in y.items()))


def _x_c_analysis(phi_dom, dom, K, grad, m, c, deadline, record, w):
    """U = largest X_c-invariant subspace of V_m; the matrix of X_c on U.  Returns dict."""
    weights, b = grad["weights"], grad["b"]
    cols = _monomials(weights, m)
    idx = dict((e, i) for i, e in enumerate(cols))
    N = len(cols)
    Tcols = []                      # Tcols[j] = {i: val}: X_c(col j) restricted to weight <= m
    Trows = [dict() for _ in range(N)]
    hi = {}                         # high monomial -> {j: val}
    for j, e in enumerate(cols):
        if time.monotonic() > deadline:
            raise _OutOfTime()
        col = {}
        for f, v in _apply_X(e, phi_dom, K, dom, c).items():
            i = idx.get(f)
            if i is None:
                hi.setdefault(f, {})[j] = v
            else:
                col[i] = v
                Trows[i][j] = v
        Tcols.append(col)
    # Krylov: W = span{ A_hi T^k }, U = ker W
    ech = _Echelon(dom, record)
    queue = list(hi.values())
    while queue:
        if time.monotonic() > deadline:
            raise _OutOfTime()
        v = ech.reduce(queue.pop())
        if not v:
            continue
        vn = ech.insert(v)
        vt = {}
        for i, vi in vn.items():
            for j, t in Trows[i].items():
                nv = vt.get(j, dom.zero) + vi * t
                if nv:
                    vt[j] = nv
                else:
                    vt.pop(j, None)
        if vt:
            queue.append(vt)
    free = [j for j in range(N) if j not in ech.rows]
    ubasis = []
    for f in free:
        y = {f: dom.one}
        for pc, row in ech.rows.items():
            val = row.get(f)
            if val:
                y[pc] = -val
        ubasis.append(y)
    d = len(free)
    fpos = dict((f, i) for i, f in enumerate(free))
    Mrows = [[dom.zero] * d for _ in range(d)]
    for jf, y in enumerate(ubasis):
        Ty = {}
        for j, yj in y.items():
            for i, t in Tcols[j].items():
                nv = Ty.get(i, dom.zero) + yj * t
                if nv:
                    Ty[i] = nv
                else:
                    Ty.pop(i, None)
        for i, val in Ty.items():
            if i in fpos:
                Mrows[fpos[i]][jf] = val
    return {"cols": cols, "N": N, "free": free, "ubasis": ubasis, "M": Mrows, "d": d}


def _charpoly_expr(Mrows, dom, d):
    if d == 0:
        return sp.Integer(1)
    cp = DomainMatrix(Mrows, (d, d), dom).charpoly()
    return sp.expand(sum(dom.to_sympy(cf) * ELL ** (d - k) for k, cf in enumerate(cp)))


def _poly_factor_key(f, gens):
    P = sp.Poly(f, *gens)
    P = P.primitive()[1]
    if P.LC() < 0:
        P = -P
    return P.as_expr()


def _factor_special(vals, dom, params):
    """irreducible non-constant factors of numerators and denominators of recorded pivots"""
    if not getattr(dom, "is_FractionField", False):
        return []
    polys = {}
    for v in vals:
        for part in (v.numer, v.denom):
            if part.is_ground:
                continue
            polys[str(part)] = part.as_expr()
    out = {}
    for expr in polys.values():
        try:
            _, fl = sp.factor_list(expr, *params)
        except Exception:
            fl = [(expr, 1)]
        for f, _ in fl:
            if f.free_symbols & set(params):
                k = _poly_factor_key(f, params)
                out[str(k)] = k
    return list(out.values())


def _matrix_minus(Mrows, r, dom, d):
    return [dict((j, (Mrows[i][j] - r) if i == j else Mrows[i][j]) for j in range(d)
                 if ((Mrows[i][j] - r) if i == j else Mrows[i][j])) for i in range(d)]


def _matmul_rows(A, B, d, dom):
    """A, B as lists of row dicts (d x d); returns A*B as row dicts"""
    out = []
    for i in range(d):
        row = {}
        for k, aik in A[i].items():
            for j, bkj in B[k].items():
                nv = row.get(j, dom.zero) + aik * bkj
                if nv:
                    row[j] = nv
                else:
                    row.pop(j, None)
        out.append(row)
    return out


def _top_pencil_c_candidates(phi_dom, dom, params, K, grad, m, deadline, w):
    """p = 1: the values c for which X_0 G = c w0 G has a solution G of weight k <= m (exact roots)."""
    weights = grad["weights"]
    topw = grad["top_weight"]
    csym = sp.Dummy("c")
    domc = QQ.frac_field(*(list(params) + [csym]))
    cdom = domc.from_sympy(csym)
    top_dom = {}
    for e, co in phi_dom.items():
        if _wt(e, weights) == topw:
            top_dom[e] = domc.from_sympy(dom.to_sympy(co))
    cands = {}
    nonrat = {}
    incomplete = []
    for k in range(1, m + 1):
        if time.monotonic() > deadline:
            raise _OutOfTime()
        cols = [e for e in _monomials(weights, k) if _wt(e, weights) == k]
        if not cols:
            continue
        rows = {}
        for j, e in enumerate(cols):
            for f, v in _apply_X(e, top_dom, K, domc, cdom).items():
                rows.setdefault(f, {})[j] = v
        rec = []
        ns = _nullspace(list(rows.values()), len(cols), domc, rec, deadline)
        if ns:
            incomplete.append("weight %d: the top-weight pencil is singular (unexpected)" % k)
            continue
        for v in rec:
            num = v.numer.as_expr()
            if csym not in num.free_symbols:
                continue
            _, fl = sp.factor_list(num)
            for f, _ in fl:
                if csym not in f.free_symbols:
                    continue
                P = sp.Poly(f, csym)
                if P.degree() == 1:
                    r = sp.cancel(-P.all_coeffs()[1] / P.all_coeffs()[0])
                    cands[str(r)] = r
                elif not params:
                    nonrat[str(f)] = f.subs(csym, sp.Symbol("c"))
                else:
                    incomplete.append("weight %d: cofactor coefficient c a root of %s (not rational over "
                                      "Q(parameters); not treated)" % (k, sp.factor(f.subs(csym, sp.Symbol("c")))))
    # keep only the candidates for which some top kernel is nonzero
    good = []
    for key, r in cands.items():
        rd = dom.from_sympy(r)
        ok = False
        for k in range(1, m + 1):
            cols = [e for e in _monomials(weights, k) if _wt(e, weights) == k]
            if not cols:
                continue
            rows = {}
            for j, e in enumerate(cols):
                for f, v in _apply_X(e, dict((e2, c2) for e2, c2 in phi_dom.items()
                                             if _wt(e2, weights) == topw), K, dom, rd).items():
                    rows.setdefault(f, {})[j] = v
            if _nullspace(list(rows.values()), len(cols), dom, []):
                ok = True
                break
        if ok and r != 0:
            good.append(r)
    # numeric equation: algebraic values of c (roots in radicals), verified the same way over Q(c)
    csy = sp.Symbol("c")
    for key, f in nonrat.items():
        Pf = sp.Poly(f, csy)
        if Pf.degree() > 2 or time.monotonic() > deadline:
            incomplete.append("cofactor coefficient c a root of %s (degree %d): Darboux polynomials with this w0-part "
                              "may exist; not written out" % (f, Pf.degree()))
            continue
        rts = sp.roots(Pf)
        if sum(rts.values()) < Pf.degree():
            incomplete.append("cofactor coefficient c a root of %s (roots not found in radicals; not treated)" % f)
            continue
        for r in rts:
            try:
                F = QQ.algebraic_field(r)
            except Exception:
                incomplete.append("cofactor coefficient c = %s: algebraic field not available" % r)
                continue
            rd = F.from_sympy(r)
            topF = dict((e2, F.from_sympy(dom.to_sympy(c2))) for e2, c2 in phi_dom.items()
                        if _wt(e2, weights) == topw)
            ok = False
            for k in range(1, m + 1):
                cols = [e for e in _monomials(weights, k) if _wt(e, weights) == k]
                if not cols:
                    continue
                rows = {}
                for j, e in enumerate(cols):
                    for f2, v in _apply_X(e, topF, K, F, rd).items():
                        rows.setdefault(f2, {})[j] = v
                if _nullspace(list(rows.values()), len(cols), F, []):
                    ok = True
                    break
            if ok:
                good.append(r)
    return good, incomplete


def lie_derivative(eq, G):
    """X(G) for a polynomial G in w0..w_{K-1} (w_K replaced by Phi); for a quasi-linear equation A w_K = Psi the
    polynomial field Y = A*(w1 d/dw0 + ...) + Psi d/dw_{K-1} = A*X"""
    K = eq.K
    G = sp.sympify(G)
    parts = _field_parts(eq)
    A, Psi = parts
    Aexpr = sum(co * _mono_expr(e, eq.w) for e, co in A.items())
    Pexpr = sum(co * _mono_expr(e, eq.w) for e, co in Psi.items())
    out = sp.Integer(0)
    for j in range(K - 1):
        out += sp.diff(G, eq.w[j]) * eq.w[j + 1]
    return out * Aexpr + sp.diff(G, eq.w[K - 1]) * Pexpr


def verify_darboux(eq, G, L):
    """exact check X(G) - L*G = 0 (polynomial arithmetic over Q(parameters); independent of the linear algebra)"""
    K = eq.K
    w = list(eq.w[:K])
    G = sp.sympify(G)
    L = sp.sympify(L)
    A, Psi = _field_parts(eq)
    Aexpr = sum(co * _mono_expr(e, eq.w) for e, co in A.items())
    Pexpr = sum(co * _mono_expr(e, eq.w) for e, co in Psi.items())
    syms = set()
    for x in (G, L, sp.sympify(Aexpr), sp.sympify(Pexpr)):
        syms |= x.free_symbols
    pars = sorted(syms - set(eq.w), key=lambda t: t.name)
    ok = None
    detail = ""
    try:
        if not (G.has(sp.I) or G.has(sp.sqrt(2)) or any(not a.is_Rational for a in G.atoms(sp.Number))):
            dom = QQ.frac_field(*pars) if pars else QQ
            Pg = sp.Poly(G, *w, domain=dom)
            Pl = sp.Poly(L, *w, domain=dom)
            Pphi = sp.Poly(Pexpr, *w, domain=dom)
            Pa = sp.Poly(Aexpr, *w, domain=dom)
            sh = sp.Poly(0, *w, domain=dom)
            for j in range(K - 1):
                sh = sh + Pg.diff(w[j]) * sp.Poly(w[j + 1], *w, domain=dom)
            res = sh * Pa + Pg.diff(w[K - 1]) * Pphi - Pl * Pg
            ok = res.is_zero
            detail = "residual 0" if ok else "residual %s" % str(res.as_expr())[:200]
    except Exception:
        ok = None
    if ok is None:
        r = sp.expand(sp.cancel(sp.together(lie_derivative(eq, G) - L * G)))
        ok = (r == 0)
        detail = "residual %s" % ("0" if ok else str(r)[:200])
    field = ("X = sum_j w_{j+1} d/dw_j with w_K = Phi" if not _is_quasilinear(eq) else
             "Y = A*sum_{j<K-1} w_{j+1} d/dw_j + Psi d/dw_{K-1}, A = %s" % Aexpr)
    return {"type": "darboux-identity", "status": "pass" if ok else "fail",
            "method": "symbolic: %s(G) - L*G as a polynomial in the jets over Q(parameters)"
                      % ("Y" if _is_quasilinear(eq) else "X"),
            "detail": field + "; " + detail}


def _latex(expr, eq):
    """LaTeX with the jets written as w, w', w'', ... (Equation.jet_latex) when available"""
    expr = sp.sympify(expr)
    names = {}
    if hasattr(eq, "jet_latex"):
        for j, s_ in enumerate(eq.w):
            try:
                names[s_] = eq.jet_latex(j)
            except Exception:
                pass
    try:
        return sp.latex(expr, symbol_names=names) if names else sp.latex(expr)
    except Exception:
        return sp.latex(expr)


def _jets_in(expr, w):
    return sorted([j for j, s in enumerate(w) if s in sp.sympify(expr).free_symbols])


def reduce_on_surface(eq, G, constant=None):
    """The equation G(w, ..., w^(K-1)) = 0 (or G = C for a first integral, `constant` = name of C).

    Returns (Equation or None, info).  If G is linear in w_{K-1} with a coefficient free of the jets, the returned
    equation is solved: w_{K-1} = -g0/g1 (order K-1)."""
    G = sp.expand(sp.sympify(G))
    w = eq.w
    K = eq.K
    params = list(eq.params)
    level = None
    if constant is not None:
        level = _fresh_name(constant if isinstance(constant, str) else "C_I", _taken_names(eq))
        C = sp.Symbol(level)
        G = G - C
        params = params + [C]
    jets = _jets_in(G, w[:K])
    info = {"order": max(jets) if jets else None, "level_symbol": level}
    if not jets:
        return None, dict(info, note="G is free of the unknown")
    if max(jets) == 0:
        return None, dict(info, note="G depends on w only: the surface consists of constant solutions")
    top = w[max(jets)]
    P = sp.Poly(G, top)
    if P.degree() == 1:
        g1, g0 = P.all_coeffs()
        if not (set(w) & sp.sympify(g1).free_symbols):
            rhs = sp.expand(sp.cancel(-g0 / g1))
            e = Equation(max(jets), rhs, parameters=params, name="reduced")
            return e, dict(info, solved=True, note="solved for w%d" % max(jets))
    num = sp.fraction(sp.together(G))[0]
    e = Equation(E=sp.expand(num), parameters=params, name="reduced")
    return e, dict(info, solved=bool(getattr(e, "solved", False)), note="E = G")


# ------------------------------------------------------------------------------------- one stratum
def _analyse_stratum(eq, grad, m, deadline, log):
    """generic analysis over Q(parameters of eq).  Returns (node dict, special factors)"""
    K = eq.K
    w = eq.w
    params = list(eq.params)
    dom = _make_domain(params)
    phi = _phi_dict(eq)
    weights = grad["weights"]
    for e in phi:
        if _wt(e, weights) > grad["top_weight"]:
            raise ValueError("grading violated by %s" % e)
    phi_dom = dict((e, dom.from_sympy(co)) for e, co in phi.items())
    record = []
    special_extra = []           # SymPy expressions whose zero sets are special
    incomplete = []
    # cofactor classes
    cvals = [sp.Integer(0)]
    if grad["p"] == 1:
        cands, inc = _top_pencil_c_candidates(phi_dom, dom, params, K, grad, m, deadline, w)
        cvals += cands
        incomplete += inc
    elif grad["p"] < 1:
        incomplete.append("pole order p = %s < 1: cofactors of the form ell + c*w0 + ... with the w0-part entering "
                          "below the top weight are not treated; only cofactors ell + 0*w0 were searched" % grad["p"])
    classes = []
    darboux = []
    eigenspaces = []
    first_integrals = []
    time_functions = []
    algebraic = []
    dimU_total = 0
    n_dp = 0
    for c in cvals:
        dom_c, phi_c = dom, phi_dom
        if dom.is_QQ and not c.is_Rational:
            dom_c = QQ.algebraic_field(c)
            phi_c = dict((e, dom_c.from_sympy(co)) for e, co in phi.items())
        cd = dom_c.from_sympy(c) if c != 0 else None
        res = _x_c_analysis(phi_c, dom_c, K, grad, m, cd, deadline, record, w)
        res["dom"] = dom_c
        d = res["d"]
        dimU_total += d
        cols, ubasis = res["cols"], res["ubasis"]
        chi = _charpoly_expr(res["M"], dom_c, d)
        cls = {"c_w0": str(c), "dim_U": d, "charpoly": str(sp.factor(chi)) if d else "1",
               "dimension_V": res["N"]}
        classes.append(cls)
        if d == 0:
            continue
        num = sp.fraction(sp.together(chi))[0]
        if dom_c is not dom:
            _, fl = sp.factor_list(sp.expand(num), ELL, extension=c)
        else:
            _, fl = sp.factor_list(sp.expand(num), ELL, *params) if params else sp.factor_list(sp.expand(num), ELL)
        lin_roots = []
        for f, mult in fl:
            if ELL not in f.free_symbols:
                continue
            P = sp.Poly(f, ELL)
            if P.degree() == 1:
                r = sp.cancel(-P.all_coeffs()[1] / P.all_coeffs()[0])
                lin_roots.append((r, mult, dom_c))
            elif dom_c.is_QQ and not params and P.degree() == 2 and time.monotonic() < deadline:
                # numeric equation: eigenvalues in radicals, eigenvectors over Q(ell)
                for r in sp.roots(P):
                    try:
                        lin_roots.append((r, mult, QQ.algebraic_field(r)))
                    except Exception:
                        algebraic.append({"c_w0": str(c), "factor": str(f), "multiplicity": int(mult),
                                          "latex": sp.latex(f), "note": "eigenvectors not computed"})
            else:
                algebraic.append({"c_w0": str(c), "factor": str(f), "multiplicity": int(mult),
                                  "latex": sp.latex(f),
                                  "note": "every root ell of this factor is a cofactor (ell + c*w0) of a Darboux "
                                          "polynomial with algebraic coefficients; eigenvectors not computed"})
                n_dp += P.degree()
                if params:
                    special_extra.append(sp.discriminant(P.as_expr(), ELL))
                    special_extra.append(P.LC())
        # collisions of rational eigenvalues
        if params:
            for i in range(len(lin_roots)):
                for j in range(i + 1, len(lin_roots)):
                    special_extra.append(sp.fraction(sp.together(lin_roots[i][0] - lin_roots[j][0]))[0])
        for r, mult, dom_r in lin_roots:
            rd = dom_r.from_sympy(r)
            if dom_r is not dom_c:
                Mr = [[dom_r.from_sympy(dom_c.to_sympy(x)) for x in row] for row in res["M"]]
                ubasis_r = [dict((j, dom_r.from_sympy(dom_c.to_sympy(v))) for j, v in y.items()) for y in ubasis]
            else:
                Mr, ubasis_r = res["M"], ubasis
            dd = dom_r
            A = _matrix_minus(Mr, rd, dd, d)
            ys = _nullspace(A, d, dd, record if (dd is dom) else [], deadline)
            L = sp.expand(r + (c * w[0] if c != 0 else 0))
            Gs = []
            for y in ys:
                coef = {}
                for f_i, yv in y.items():
                    for jcol, uv in ubasis_r[f_i].items():
                        nv = coef.get(jcol, dd.zero) + yv * uv
                        if nv:
                            coef[jcol] = nv
                        else:
                            coef.pop(jcol, None)
                Gs.append(_vec_to_expr(coef, cols, w, dd))
            # first integrals: drop the constants
            if c == 0 and r == 0:
                nonconst = []
                for g in Gs:
                    g0 = sp.expand(g - g.subs(dict((s, 0) for s in w[:K])))
                    if g0 != 0:
                        nonconst.append(_primitive_expr(g0, w[:K]))
                Gs_report = nonconst
            else:
                Gs_report = [_primitive_expr(g, w[:K]) for g in Gs]
            eigenspaces.append({"c_w0": str(c), "cofactor": str(L), "cofactor_latex": _latex(L, eq),
                                "algebraic_multiplicity": int(mult), "dimension": len(Gs_report),
                                "basis": [str(g) for g in Gs_report],
                                "note": ("first integrals (constants removed)" if (c == 0 and r == 0) else
                                         ("dimension >= 2: G1/G2 is a rational first integral" if len(Gs_report) >= 2
                                          else ""))})
            n_dp += len(Gs_report)
            if c == 0 and r == 0:
                for g in Gs_report:
                    first_integrals.append(g)
            ext = None if (dd.is_QQ or dd is dom) else (r if dd is not dom_c else c)
            for g in Gs_report:
                darboux.append((g, L, ext))
            # Jordan chains: X(F) = 1 for F = g2/g1
            if mult > len(ys):
                A2 = _matmul_rows(A, A, d, dd)
                ys2 = _nullspace(A2, d, dd, [], deadline)
                if len(ys2) > len(ys):
                    # pick a generalised eigenvector not in ker A
                    for y2 in ys2:
                        Ay = {}
                        for i in range(d):
                            s = dd.zero
                            for jj, val in A[i].items():
                                if jj in y2:
                                    s += val * y2[jj]
                            if s:
                                Ay[i] = s
                        if Ay:
                            def to_poly(yy):
                                coef = {}
                                for f_i, yv in yy.items():
                                    for jcol, uv in ubasis_r[f_i].items():
                                        nv = coef.get(jcol, dd.zero) + yv * uv
                                        if nv:
                                            coef[jcol] = nv
                                        else:
                                            coef.pop(jcol, None)
                                return _vec_to_expr(coef, cols, w, dd)
                            g2, g1 = to_poly(y2), to_poly(Ay)
                            time_functions.append({"c_w0": str(c), "cofactor": str(L), "numerator": str(g2),
                                                   "denominator": str(g1),
                                                   "statement": "X(g2) = L*g2 + g1 and X(g1) = L*g1, so F = g2/g1 has "
                                                                "X(F) = 1: along every solution with g1 != 0, "
                                                                "F(w, w', ...) = z + const"})
                            break
    # irreducible factors of the eigenvectors
    irreducible = {}
    for g, L, ext in darboux:
        num = sp.fraction(sp.together(g))[0]
        try:
            if ext is not None and time.monotonic() > deadline:
                fl = [(num, 1)]                       # out of time: reported unfactored
            elif ext is not None:
                # coefficients in the number field Q(ext): factor over that field
                _, fl = sp.factor_list(sp.expand(num), *w[:K], extension=ext)
            else:
                _, fl = sp.factor_list(sp.expand(num), *(list(w[:K]) + params))
        except Exception:
            fl = [(num, 1)]
        jets_fl = [(f, e) for f, e in fl if set(w[:K]) & f.free_symbols]
        for f, e in jets_fl:
            key = str(_primitive_expr(f, w[:K]))
            if key in irreducible:
                continue
            fexpr = _primitive_expr(f, w[:K])
            q, rmd = sp.div(sp.expand(lie_derivative(eq, fexpr)), fexpr, *w[:K])
            Lf = sp.expand(sp.cancel(q)) if sp.expand(rmd) == 0 else None
            irreducible[key] = (fexpr, Lf, g)
    special = _factor_special(record, dom, params)
    for ex in special_extra:
        ex = sp.sympify(ex)
        if ex.free_symbols & set(params):
            try:
                _, fl = sp.factor_list(sp.expand(sp.fraction(sp.together(ex))[0]), *params)
            except Exception:
                fl = [(ex, 1)]
            for f, _ in fl:
                if f.free_symbols & set(params):
                    special.append(_poly_factor_key(f, params))
    # coefficient denominators of Phi: excluded loci
    excluded = []
    for co in phi.values():
        den = sp.fraction(sp.together(co))[1]
        if den.free_symbols & set(params):
            for f, _ in sp.factor_list(den, *params)[1]:
                if f.free_symbols:
                    excluded.append(_poly_factor_key(f, params))
    exk = set(str(x) for x in excluded)
    uniq = {}
    for f in special:
        if str(f) not in exk:
            uniq[str(f)] = f
    node = {"dim_U": dimU_total, "classes": classes, "eigenspaces": eigenspaces,
            "irreducible": irreducible, "first_integrals": first_integrals,
            "time_functions": time_functions, "algebraic_cofactors": algebraic,
            "n_dp": n_dp, "incomplete": incomplete,
            "excluded": [str(x) for x in excluded]}
    return node, list(uniq.values())


# ------------------------------------------------------------------- direct method (symbolic parameters)
def _cofactor_vars(grad, params):
    """[(symbol, exponent tuple)]: the unknown coefficient of each monomial of weight <= delta in the cofactor
    (statement 1: powers of w0 for a solved equation; statement 9: all monomials for a quasi-linear one)"""
    K = len(grad["weights"])
    names = set(s_.name for s_ in params) | set("w%d" % j for j in range(K + 3))
    if "cof_monomials" in grad:
        mons = grad["cof_monomials"]
    else:
        a, b = grad["a"], grad["b"]
        mons = [tuple([k] + [0] * (K - 1)) for k in range(0, b // a + 1)]
    out = []
    for mon in mons:
        if not any(mon):
            nm = _fresh_name("ell", names)
        else:
            parts = []
            for j, e in enumerate(mon):
                if e:
                    parts.append("w%d" % j if e == 1 else "w%d_%d" % (j, e))
            nm = _fresh_name("c_" + "".join(parts), names)
        names.add(nm)
        out.append((sp.Symbol(nm), mon))
    return out


def _cof_expr(cof, cvars, w):
    return sp.expand(sum((s_ if cof[s_] is None else cof[s_]) * _mono_expr(mon, w) for s_, mon in cvars))


def _direct_node(eq, grad, m, cof, cvars, deadline):
    """kernel of G -> X(G) - L G on V_m with L = sum_k cof_k w0^k, over Q(parameters, free cofactor variables).

    Returns (list of SymPy polynomials, special factors as SymPy expressions)."""
    K = eq.K
    w = eq.w
    params = list(eq.params)
    free = [s for s, mon in cvars if cof[s] is None and s not in params]
    gens = params + free
    dom = _make_domain(gens)
    parts = _field_parts(eq)
    A, phi = parts
    phi_dom = dict((e, dom.from_sympy(co)) for e, co in phi.items())
    a_dom = None if not _is_quasilinear(eq) else dict((e, dom.from_sympy(co)) for e, co in A.items())
    Lterms = []
    for s_, mon in cvars:
        val = s_ if cof[s_] is None else sp.sympify(cof[s_])
        if val != 0:
            Lterms.append((mon, dom.from_sympy(val)))
    weights = grad["weights"]
    cols = _monomials(weights, m)
    rows = {}
    for j, e in enumerate(cols):
        if time.monotonic() > deadline:
            raise _OutOfTime()
        col = _apply_X(e, phi_dom, K, dom, None, a_dom)
        for mon, v in Lterms:
            f = tuple(e[i] + mon[i] for i in range(K))
            nv = col.get(f, dom.zero) - v
            if nv:
                col[f] = nv
            else:
                col.pop(f, None)
        for f, v in col.items():
            rows.setdefault(f, {})[j] = v
    # rows ordered by weight (top first): the triangular structure makes most pivots constants
    order = sorted(rows, key=lambda f: (-_wt(f, weights), tuple(reversed(f))))
    record = []
    ns = _nullspace([rows[f] for f in order], len(cols), dom, record, deadline)
    Gs = [_vec_to_expr(y, cols, w, dom) for y in ns]
    special = _factor_special(record, dom, gens)
    return Gs, special


def _solve_for(f, free_cv, params):
    """how to restrict to f = 0: ('cof', v, value, lc) or ('param', q, value, lc) or None"""
    fs = f.free_symbols
    for v in free_cv:
        if v in fs:
            P = sp.Poly(f, v)
            if P.degree() == 1:
                f1, f0 = P.all_coeffs()
                if not (sp.sympify(f1).free_symbols & (set(params) | set(free_cv))):
                    return ("cof", v, sp.cancel(-f0 / f1), f1)
    sol = _solve_linear_param(f, [q for q in params if q in fs])
    if sol is not None:
        return ("param", sol[0], sol[1], sol[2])
    for v in free_cv:
        if v in fs:
            P = sp.Poly(f, v)
            if P.degree() == 1:
                f1, f0 = P.all_coeffs()
                return ("cof", v, sp.cancel(-f0 / f1), f1)
    return None


def _excluded_factors(eq):
    """irreducible factors of the denominators of the coefficients of Phi (the equation is not defined there)"""
    params = list(eq.params)
    out = {}
    parts = _field_parts(eq)
    allco = list(parts[0].values()) + list(parts[1].values()) if parts else list(_phi_dict(eq).values())
    for co in allco:
        den = sp.fraction(sp.together(co))[1]
        if den.free_symbols & set(params):
            for f, _ in sp.factor_list(den, *params)[1]:
                if f.free_symbols:
                    k = _poly_factor_key(f, params)
                    out[str(k)] = k
    return out


def _cond_str(f):
    return "%s = 0" % sp.factor(f)


def _symbolic_search(eq, grad, m, cvars, deadline, out, max_strata):
    """strata search in (parameters, cofactor coefficients)-space with the direct method; returns found nodes"""
    K = eq.K
    quasi = _is_quasilinear(eq)
    found = []
    queue = [{"eq": eq, "cof": dict((s_, None) for s_, mon in cvars), "conds": [], "cpolys": [], "nonconds": [],
              "subs": {}, "pending": [], "cofpar": [], "ncpolys": []}]
    seen = set()
    explored = 0
    first_conds = out.setdefault("_first_conds", [])

    def L_of(nd):
        return _cof_expr(nd["cof"], cvars, eq.w[:K])

    def label(nd):
        return nd["conds"] + ["L = %s" % L_of(nd)] + [_cond_str(g) for g in nd["pending"]]

    def push_restricted(nd, h):
        """child of nd on the irreducible condition h = 0"""
        e_s = nd["eq"]
        params = list(e_s.params)
        free_cv = [s_ for s_, mon in cvars if nd["cof"][s_] is None]
        how = _solve_for(h, free_cv, params)
        if how is None:
            out["incomplete"].append({"conditions": label(nd) + [_cond_str(h)], "assumptions": nd["nonconds"],
                                      "reason": "the condition is not linear in a parameter or in a cofactor "
                                                "coefficient"})
            return
        kind, v, val, f1 = how
        if sp.sympify(val).has(sp.zoo, sp.nan, sp.oo):
            out["incomplete"].append({"conditions": label(nd) + [_cond_str(h)], "reason": "singular value"})
            return
        const_lc = not (sp.sympify(f1).free_symbols & (set(params) | set(free_cv)))
        nz = [] if const_lc else [str(sp.factor(f1)) + " != 0"]
        nzp = [] if const_lc else [f1]
        if not const_lc:
            queue.append(dict(nd, pending=[f1, h] + list(nd["pending"])))
        if kind == "cof":
            cof2 = dict((s_, (None if x is None else sp.cancel(sp.sympify(x).subs(v, val))))
                        for s_, x in nd["cof"].items())
            cof2[v] = val
            if any(x is not None and sp.sympify(x).has(sp.zoo, sp.nan, sp.oo) for x in cof2.values()):
                out["incomplete"].append({"conditions": label(nd) + [_cond_str(h)],
                                          "reason": "the cofactor is undefined on this stratum; not examined"})
                return
            pend2 = [sp.fraction(sp.together(sp.sympify(g).subs(v, val)))[0] for g in nd["pending"]]
            if any(g != 0 and not (g.free_symbols & (set(params) | set(free_cv))) for g in pend2):
                return
            queue.append(dict(nd, cof=cof2, nonconds=nd["nonconds"] + nz, ncpolys=nd.get("ncpolys", []) + nzp,
                              pending=[g for g in pend2 if g != 0]))
            return
        queue.append({"lazy": (nd, h, v, val, nz, free_cv, nzp)})

    def materialise(item):
        """perform the substitution of a lazily pushed child (parameter q = val on the condition h = 0)"""
        nd, h, q, val, nz, free_cv, nzp = item["lazy"]
        e_s = nd["eq"]
        try:
            e2 = e_s.subs({q: val})
            e2.key()
        except Exception as err:
            if "division by zero" in str(err) or "zoo" in str(err):
                # a coefficient becomes infinite: the condition contradicts an assumption made when an earlier
                # condition was solved (e.g. nu = 1/(2*c_w0) with c_w0 != 0, now c_w0 = 0): the piece is empty
                out.setdefault("excluded", []).append({"conditions": nd["conds"] + [_cond_str(h)],
                                                       "assumptions": nd["nonconds"],
                                                       "reason": "empty: contradicts an assumption (a coefficient "
                                                                 "would be infinite)"})
            else:
                out["incomplete"].append({"conditions": label(nd) + [_cond_str(h)], "assumptions": nd["nonconds"],
                                          "reason": "substitution failed: %s" % err})
            return None
        if e2.K != K or (not e2.solved and not (quasi and _field_parts(e2) is not None)):
            out.setdefault("excluded", []).append({"conditions": nd["conds"] + [_cond_str(h)],
                                                   "reason": "on this stratum the equation changes order"})
            return None
        cof2 = {}
        for s_, x in nd["cof"].items():
            cof2[s_] = None if x is None else sp.cancel(sp.sympify(x).subs(q, val))
        cofpar = list(nd["cofpar"])
        for s_ in free_cv:                       # a cofactor coefficient in the solved value becomes a parameter
            if s_ in sp.sympify(val).free_symbols:
                cof2[s_] = s_
                cofpar.append(s_.name)
        if any(x is not None and sp.sympify(x).has(sp.zoo, sp.nan, sp.oo) for x in cof2.values()):
            out["incomplete"].append({"conditions": label(nd) + [_cond_str(h)],
                                      "reason": "the cofactor is undefined on this stratum; not examined"})
            return None
        subs2 = dict((k, sp.cancel(x.subs(q, val))) for k, x in nd["subs"].items())
        subs2[q] = val
        pend2 = []
        for g in nd["pending"]:
            g2 = sp.fraction(sp.together(sp.cancel(sp.sympify(g).subs(q, val))))[0]
            if g2 == 0:
                continue
            if not (g2.free_symbols & (set(e2.params) | set(free_cv))):
                return None                       # empty sub-stratum
            pend2.append(g2)
        ncp2 = [sp.cancel(sp.sympify(x).subs(q, val)) for x in nd.get("ncpolys", [])] + nzp
        return {"eq": e2, "cof": cof2, "conds": nd["conds"] + [_cond_str(h)], "cpolys": nd["cpolys"] + [h],
                "nonconds": nd["nonconds"] + nz, "subs": subs2, "pending": pend2, "cofpar": cofpar,
                "ncpolys": ncp2}

    while queue:
        nd = queue.pop(0)
        if "lazy" in nd:
            if time.monotonic() > deadline or explored >= max_strata:
                pnd, h = nd["lazy"][0], nd["lazy"][1]
                out["incomplete"].append({"conditions": label(pnd) + [_cond_str(h)], "assumptions": pnd["nonconds"],
                                          "reason": "stratum not explored (budget)"})
                continue
            nd = materialise(nd)
            if nd is None:
                continue
        e_s = nd["eq"]
        try:
            # the conditions and assumptions belong to the key: two strata may specialise to the same equation
            # (b = 1 and b = -1 in 12*w0*w1 + (b**2 - 1)*w0); each must be reported
            key = (e_s.key(), tuple(sorted((k_.name, str(x)) for k_, x in nd["cof"].items())),
                   tuple(str(g) for g in nd["pending"]), tuple(sorted(nd["conds"])), tuple(sorted(nd["nonconds"])))
        except Exception as err:
            out["incomplete"].append({"conditions": nd["conds"], "reason": "degenerate stratum (%s)" % err})
            continue
        if key in seen:
            continue
        seen.add(key)
        if nd["conds"] and nd["conds"][0] not in first_conds:
            first_conds.append(nd["conds"][0])
        if time.monotonic() > deadline or explored >= max_strata:
            out["incomplete"].append({"conditions": label(nd), "assumptions": nd["nonconds"],
                                      "reason": "stratum not explored (budget)"})
            continue
        free_cv = [s_ for s_, mon in cvars if nd["cof"][s_] is None]
        if nd["pending"]:
            g, rest = nd["pending"][0], list(nd["pending"][1:])
            base = dict(nd, pending=rest)
            gens = list(e_s.params) + free_cv
            gnum = sp.fraction(sp.together(sp.sympify(g)))[0]
            if gnum == 0:
                queue.append(base)
                continue
            if not (gnum.free_symbols & set(gens)):
                continue                          # a nonzero constant: the sub-stratum is empty
            for hh, _ in sp.factor_list(gnum, *gens)[1]:
                if hh.free_symbols & set(gens):
                    push_restricted(base, hh)
            continue
        try:
            Gs, special = _direct_node(e_s, grad, m, nd["cof"], cvars, deadline)
        except _OutOfTime:
            out["incomplete"].append({"conditions": label(nd), "assumptions": nd["nonconds"],
                                      "reason": "budget exhausted during the computation on this stratum"})
            continue
        except Exception as err:                      # e.g. a coefficient that is undefined on the stratum
            out["incomplete"].append({"conditions": label(nd), "assumptions": nd["nonconds"],
                                      "reason": "computation failed on this stratum (%s: %s)"
                                                % (type(err).__name__, str(err)[:120])})
            continue
        explored += 1
        L = L_of(nd)
        trivial = 1 if L == 0 else 0
        ndp = len(Gs) - trivial
        excluded = _excluded_factors(e_s)
        gens_all = list(e_s.params) + free_cv
        special = [f for f in special if str(_poly_factor_key(f, gens_all)) not in excluded and str(f) not in excluded]
        if free_cv and Gs:
            # a kernel for generic values of free cofactor coefficients (impossible for p >= 1, statement 6): the free
            # coefficients become coordinates of the stratum
            out["log"].append("kernel with free cofactor coefficients %s on %s" % (free_cv, nd["conds"]))
            nd = dict(nd, cof=dict((s_, (s_ if x is None else x)) for s_, x in nd["cof"].items()),
                      cofpar=list(nd["cofpar"]) + [s_.name for s_ in free_cv])
            free_cv = []
        if not free_cv and Gs:
            Gs = [_primitive_expr(g, e_s.w[:K]) for g in Gs]
            found.append({"eq": e_s, "L": L, "cof": dict(nd["cof"]), "conds": nd["conds"], "cpolys": nd["cpolys"],
                          "nonconds": nd["nonconds"], "ncpolys": nd.get("ncpolys", []), "subs": nd["subs"],
                          "Gs": Gs, "ndp": ndp,
                          "cofpar": list(nd["cofpar"]),
                          "valid_outside": [_cond_str(f).replace(" = 0", "") for f in special],
                          "new": bool(ndp > 0)})
        special.sort(key=lambda f: (0 if (f.free_symbols & set(free_cv)) else 1, sp.Poly(f).total_degree(),
                                    len(sp.Add.make_args(sp.expand(f))), str(f)))
        for f in special:
            push_restricted(nd, f)
    out["searched"]["strata_explored"] = explored
    _mark_redundant(found, out.get("_post_deadline"))
    return found


def _span_contains(Abasis, Bbasis, w, params):
    """True if span(Bbasis) is contained in span(Abasis) (polynomials in w over Q(params))"""
    dom = _make_domain(params)
    mons = {}
    vecs = []
    for g in list(Abasis) + list(Bbasis):
        P = sp.Poly(sp.expand(g), *w)
        v = {}
        for mon, co in P.terms():
            j = mons.setdefault(mon, len(mons))
            v[j] = dom.from_sympy(co)
        vecs.append(v)

    def rank(vs):
        ech = _Echelon(dom, [])
        r = 0
        for v in vs:
            v2 = ech.reduce(v)
            if v2:
                ech.insert(v2)
                r += 1
        return r
    nA = len(Abasis)
    return rank(vecs[:nA]) == rank(vecs)


def _mark_redundant(found, post_deadline=None):
    """a found node is redundant if a found node on a larger stratum, with the same cofactor there, has an
    eigenspace whose specialisation spans its eigenspace (skipped when out of time: then nothing is dropped)"""
    for B in found:
        if post_deadline is not None and time.monotonic() > post_deadline:
            return
        if not B["new"]:
            continue
        for A in found:
            if A is B or len(A["cpolys"]) >= len(B["cpolys"]):
                continue
            try:
                if any(sp.cancel(sp.sympify(f).subs(B["subs"])) != 0 for f in A["cpolys"]):
                    continue
                # A's answer is not valid on B if one of A's assumptions vanishes there
                if any(sp.cancel(sp.sympify(f).subs(B["subs"])) == 0 for f in A.get("ncpolys", [])):
                    continue
                if sp.cancel(sp.sympify(A["L"]).subs(B["subs"]) - B["L"]) != 0:
                    continue
                spec = []
                ok = True
                for g in A["Gs"]:
                    g2 = sp.cancel(sp.together(sp.sympify(g).subs(B["subs"])))
                    if g2.has(sp.zoo, sp.nan, sp.oo):
                        ok = False
                        break
                    spec.append(sp.expand(g2))
                if not ok:
                    continue
                w = B["eq"].w[:B["eq"].K]
                if _span_contains(spec, B["Gs"], w, list(B["eq"].params)):
                    B["new"] = False
                    break
            except Exception:
                continue


# ------------------------------------------------------------------------------------- strata search
def _solve_linear_param(f, params):
    """choose a parameter q with deg_q f = 1; returns (q, value, leading coefficient) or None"""
    best = None
    for q in params:
        if q not in f.free_symbols:
            continue
        P = sp.Poly(f, q)
        if P.degree() != 1:
            continue
        f1, f0 = P.all_coeffs()
        score = (0 if f1.is_number else 1, sp.count_ops(f1), sp.count_ops(f0))
        if best is None or score < best[0]:
            best = (score, q, sp.cancel(-f0 / f1), f1)
    if best is None:
        return None
    return best[1], best[2], best[3]


def _child(eq, f):
    """the equation on the stratum f = 0 (f linear in some parameter), or a reason why not"""
    params = list(eq.params)
    sol = _solve_linear_param(f, params)
    if sol is None:
        return None, "the condition %s = 0 is not linear in any parameter" % sp.factor(f)
    q, val, f1 = sol
    try:
        e2 = eq.subs({q: val})
    except Exception as err:          # pragma: no cover
        return None, "substitution failed: %s" % err
    if e2.K != eq.K or not e2.solved:
        return None, "on %s = 0 the equation changes order or is not solved" % sp.factor(f)
    nonzero = [] if f1.is_number else [str(sp.factor(f1)) + " != 0"]
    return (e2, "%s = %s" % (q, val), nonzero, (q, f1)), None


def _G_record(eq_s, fexpr, Lf, conditions, nonconditions, stratum_id, first_integral=False, level_symbol="C_I"):
    K = eq_s.K
    cert = verify_darboux(eq_s, fexpr, Lf) if Lf is not None else \
        {"type": "darboux-identity", "status": "fail", "method": "division", "detail": "cofactor not polynomial"}
    jets = _jets_in(fexpr, eq_s.w[:K])
    try:
        P = sp.Poly(fexpr, *eq_s.w[:K])
        deg = P.total_degree()
    except Exception:
        deg = None
    red, info = _reduced_dict(eq_s, fexpr, level_symbol if first_integral else None)
    Ls = sp.sympify(Lf) if Lf is not None else None
    if _is_quasilinear(eq_s):
        Ae = sp.expand(sum(co * _mono_expr(e, eq_s.w) for e, co in _field_parts(eq_s)[0].items()))
        divides_A = False
        try:
            divides_A = sp.expand(sp.rem(Ae, fexpr, *eq_s.w[:K])) == 0 if Ae.free_symbols & set(eq_s.w) else False
        except Exception:
            divides_A = False
        if divides_A:
            along = ("G divides A = %s: {G = 0} lies in {A = 0}, which is not part of the phase space of X = Y/A; it is "
                     "an invariant hypersurface of the polynomial field Y only, and says nothing about solutions" % Ae)
            red, info = None, {"note": "G divides A: no reduced equation (not part of the phase space)"}
        else:
            along = ("about the polynomial field Y = A*X, A = %s: Y(G) = L*G. For solutions with A(w, ...) not identically "
                     "zero, dG/dz = (L/A)*G, so such a solution that meets G = 0 at a point with A != 0 stays on it%s; "
                     "solutions inside {A = 0} are not covered" % (Ae, "; L = 0: G = %s along every such solution"
                                                                    % level_symbol
                                                                    if (Ls is not None and Ls == 0) else ""))
    elif first_integral:
        along = "G(w, w', ...) = %s (a constant) along every solution" % level_symbol
    elif Ls is not None and not (set(eq_s.w) & Ls.free_symbols):
        along = ("G(w, w', ...) = C*exp(%s*z) along every solution; C = 0 exactly for the solutions on the surface "
                 "G = 0" % Ls) if Ls != 0 else "G = %s along every solution" % level_symbol
    else:
        along = "dG/dz = L*G along every solution: a solution on G = 0 stays on it"
    rec = {"G": str(fexpr), "latex": _latex(fexpr, eq_s), "cofactor": str(Ls), "cofactor_latex": _latex(Ls, eq_s),
           "degree": deg, "jets": ["w%d" % j for j in jets],
           "conditions": list(conditions),
           "assumptions": list(nonconditions) + [x for x in info.get("requires", []) if x not in nonconditions],
           "stratum": stratum_id,
           "first_integral": bool(first_integral), "along_solutions": along,
           "level_symbol": level_symbol if (first_integral or (Ls is not None and Ls == 0)) else None,
           "field": "Y = A*X (quasi-linear equation)" if _is_quasilinear(eq_s) else "X",
           "certificate": cert,
           "reduced_equation": red,
           "reduced_note": info.get("note"),
           "label": "certificate"}
    return rec


def _reduced_dict(eq_s, G, constant=None):
    """the reduced equation G = 0 (or G = C) as a dict accepted by Equation.from_dict (built without constructing the
    Equation; reduce_on_surface returns the Equation itself)"""
    K = eq_s.K
    w = eq_s.w
    G = sp.expand(sp.sympify(G))
    params = [s_.name for s_ in eq_s.params]
    if constant is not None:
        G = G - sp.Symbol(constant)
        params = params + [constant]
    jets = _jets_in(G, w[:K])
    if not jets:
        return None, {"note": "G is free of the unknown"}
    if max(jets) == 0:
        if _is_quasilinear(eq_s):
            return None, {"note": "G depends on w only; for this quasi-linear equation no conclusion about constant "
                                  "solutions is drawn (check them by substitution)"}
        return None, {"note": "G depends on w only: the surface consists of constant solutions"}
    k = max(jets)
    P = sp.Poly(G, w[k])
    solved = False
    rhs = None
    lead = None
    requires = []
    if P.degree() == 1:
        g1, g0 = P.all_coeffs()
        g1 = sp.factor(g1)
        if not (set(w) & sp.sympify(g1).free_symbols) and g1 != 0:
            # solved for the highest jet: exact when g1 is a nonzero number; a parameter-dependent g1 comes with the
            # assumption g1 != 0 (recorded in 'requires' and in the record's assumptions)
            solved = True
            lead = g1
            rhs = sp.expand(sp.cancel(-g0 / g1))
            if not g1.is_number:
                requires = ["%s != 0" % g1]
    E = (w[k] - rhs) if solved else sp.fraction(sp.together(G))[0]
    d = {"order": k, "E": str(E), "sympy": str(E), "solved": solved, "rhs": None if rhs is None else str(rhs),
         "lead_coefficient": None if lead is None else str(lead),
         "lead_numeric": bool(lead is not None and lead.is_number), "requires": requires,
         "params": params, "name": "reduced", "unknown": eq_s.unknown, "var": eq_s.var,
         "latex": ("%s = %s" % (eq_s.jet_latex(k), _latex(rhs, eq_s))) if solved else ("%s = 0" % _latex(E, eq_s))}
    return d, {"note": (("solved for w%d" % k) + (" (requires %s)" % requires[0] if requires else "")) if solved
               else "E = G" + (" - %s" % constant if constant else ""), "requires": requires}


def darboux_polynomials(eq, max_weight=None, budget_s=60, p=None, max_dim=160, explore=True, max_strata=200,
                        top_extend=3):
    """All Darboux polynomials of weight <= max_weight of the companion field of a solved equation.

    eq            mero Equation (solved for w_K), numeric or symbolic parameters
    max_weight    the bound m (default 2*(a + b*K), reduced until dim V_m <= max_dim)
    budget_s      wall-clock budget (time.monotonic); unfinished strata go to 'incomplete'
    p             grading p = a/b (default: the dominant-balance pole order)
    explore       explore the special parameter strata (else only the generic stratum)
    """
    t0 = time.monotonic()
    deadline = t0 + float(budget_s)
    if isinstance(eq, str):
        eq = Equation(E=eq)
    out = {"schema": SCHEMA, "module": "mero.darboux", "status": "ok", "equation": str(eq.E),
           "order": eq.K, "darboux_polynomials": [], "first_integrals": [], "time_functions": [],
           "strata": [], "incomplete": [], "excluded": [], "algebraic_cofactors": [], "log": []}
    if eq.K < 1:
        out.update(status="unsupported", reason="order 0")
        return out
    quasi = _is_quasilinear(eq)
    if quasi:
        parts = _field_parts(eq)
        if parts is None:
            out.update(status="unsupported", reason="the equation is neither solved for the highest derivative nor "
                                                    "linear in it")
            return out
        grad = choose_grading_ql(eq, parts, max_dim=max_dim)
    else:
        grad = choose_grading(eq, p)
    if "error" in grad:
        out.update(status="unsupported", reason=grad["error"])
        return out
    K = eq.K
    a, b, weights = grad["a"], grad["b"], grad["weights"]
    m_default = 2 * grad["top_weight"]
    m = int(max_weight) if max_weight is not None else m_default
    while max_weight is None and m > 1 and len(_monomials(weights, m)) > max_dim:
        m -= 1
    N = len(_monomials(weights, m))
    cvars0 = _cofactor_vars(grad, list(eq.params))
    level = _fresh_name("C_I", _taken_names(eq) | set(s_.name for s_, mon in cvars0))
    out["_level"] = level
    cof_form = " + ".join(str(s_ * _mono_expr(mon, eq.w)) for s_, mon in cvars0)
    Atop = sum(c * _mono_expr(e, eq.w) for e, c in grad.get("top_A", {}).items()) if quasi else 1
    trunc = sp.expand(sum(c * _mono_expr(e, eq.w) for e, c in grad["top_terms"].items()))
    out["searched"] = {
        "max_weight": m, "default_max_weight": m_default, "dimension_V": N,
        "grading": {"p": str(grad["p"]), "weights": dict(("w%d" % j, wj) for j, wj in enumerate(weights)),
                    "X_raises_weight_by_at_most": grad.get("delta", b), "top_weight_of_Phi": grad["top_weight"],
                    "truncated_equation": ("w%d = %s" % (K, trunc)) if not quasi else
                    ("(%s)*w%d = %s  (top part of the field Y)" % (Atop, K, trunc))},
        "cofactor_form": cof_form,
        "level_symbol": level,
        "parameters": [s.name for s in eq.params],
        "statement": "every Darboux polynomial of weight <= %d (all cofactors) on the strata listed; "
                     "none of higher weight is excluded" % m}
    if quasi:
        A_expr = sum(c * _mono_expr(e, eq.w) for e, c in _field_parts(eq)[0].items())
        out["searched"]["quasilinear"] = {
            "A": str(A_expr), "field": "Y = A*(w1 d/dw0 + ... + w%d d/dw%d) + Psi d/dw%d = A*X" % (K - 1, K - 2, K - 1)
            if K >= 2 else "Y = Psi d/dw0",
            "note": "the equation is A*w%d = Psi with A not constant: Darboux polynomials of the polynomial field Y "
                    "(statement 9); the hypersurface A = 0 is not part of the phase space of X" % K}
    # truncated first integrals (top kernel), cached
    tk = []
    try:
        for k in range(1, m + 1 if not quasi else 1):
            if time.monotonic() > deadline:
                break
            ker = _top_kernel(grad["top_terms"], K, grad, k, eq.w)
            if ker:
                tk.append({"weight": k, "basis": [str(g) for g in ker]})
    except _OutOfTime:
        pass
    out["truncated_first_integrals"] = tk
    # beyond m: weights k at which X_0 has no polynomial first integral carry no Darboux polynomial (p > 1),
    # whatever the lower-order terms are; this extends the bound for free while the kernel stays zero
    m_eff = m
    top_params = set()
    for co in grad["top_terms"].values():
        top_params |= sp.sympify(co).free_symbols
    if top_params:
        out["searched"]["truncated_note"] = ("the top part has the parameters %s: its first integrals are listed for "
                                             "generic values of them, and the bound is not extended beyond m "
                                             "(statement 3 needs fixed top-weight coefficients)"
                                             % sorted(str(x) for x in top_params))
    if grad["p"] > 1 and top_extend and not quasi and not top_params:
        t_cap = time.monotonic() + 0.15 * float(budget_s)
        k = m + 1
        while k <= top_extend * m and time.monotonic() < min(t_cap, deadline):
            cols_k = [e for e in _monomials(weights, k) if _wt(e, weights) == k]
            if len(cols_k) > 400:
                break
            try:
                ker = _top_kernel(grad["top_terms"], K, grad, k, eq.w)
            except _OutOfTime:
                break
            if ker:
                tk.append({"weight": k, "basis": [str(g) for g in ker], "beyond_max_weight": True})
                break
            m_eff = k
            k += 1
    out["searched"]["max_weight_effective"] = m_eff
    if m_eff > m:
        out["searched"]["statement"] += (
            "; moreover the truncated equation has no polynomial first integral of weight k for %d < k <= %d, so "
            "no Darboux polynomial has weight in that range, for every value of the lower-order coefficients: "
            "the list for weight <= %d is the list for weight <= %d" % (m, m_eff, m, m_eff))
    if eq.params or grad["p"] < 1 or quasi:
        # 65 % of the budget for the strata search, the rest for redundancy marking, factorization and records
        search_deadline = min(deadline, time.monotonic() + 0.65 * max(0.0, deadline - time.monotonic()))
        out["_post_deadline"] = deadline
        return _finish_symbolic(eq, grad, m, N, search_deadline, out, max_strata, explore, t0)
    # numeric equation: invariant-subspace method (also gives the characteristic polynomial and Jordan chains)
    queue = [(eq, [], [], 0, None)]          # (equation, conditions, nonconditions, depth, parent n_dp)
    seen = set()
    sid = 0
    explored = 0
    parent_info = {}
    while queue:
        e_s, conds, nonconds, depth, parent = queue.pop(0)
        key = e_s.key() if hasattr(e_s, "key") else str(e_s)
        if key in seen:
            continue
        seen.add(key)
        if time.monotonic() > deadline or explored >= max_strata:
            out["incomplete"].append({"conditions": conds, "assumptions": nonconds,
                                      "reason": "stratum not explored (budget)"})
            continue
        try:
            node, special = _analyse_stratum(e_s, grad, m, deadline, out["log"])
        except _OutOfTime:
            out["incomplete"].append({"conditions": conds, "assumptions": nonconds,
                                      "reason": "budget exhausted during the computation on this stratum"})
            continue
        explored += 1
        sid_str = "S%d" % sid
        sid += 1
        new = parent is None or node["n_dp"] > parent[0] or node["dim_U"] > parent[1]
        stratum = {"id": sid_str, "conditions": conds, "assumptions": nonconds, "generic": parent is None,
                   "codimension": len(conds),
                   "equation": str(e_s.E), "parameters": [s.name for s in e_s.params],
                   "dim_U": node["dim_U"], "classes": node["classes"], "eigenspaces": node["eigenspaces"],
                   "algebraic_cofactors": node["algebraic_cofactors"], "time_functions": node["time_functions"],
                   "new": bool(new), "excluded": node["excluded"],
                   "special_factors": [str(f) for f in special], "darboux": [], "first_integrals": []}
        for inc in node["incomplete"]:
            out["incomplete"].append({"conditions": conds, "assumptions": nonconds, "reason": inc})
        for alg in node["algebraic_cofactors"]:
            # eigenvalues of X_c on U whose eigenvectors are not written out: Darboux polynomials exist (statement 4)
            out.setdefault("algebraic_cofactors", []).append(dict(alg, conditions=conds, stratum=sid_str))
            out["incomplete"].append({"conditions": conds, "assumptions": nonconds,
                                      "reason": "Darboux polynomials exist with cofactor ell + %s*w0, ell a root of %s "
                                                "(multiplicity %s); they are not written out"
                                                % (alg.get("c_w0", "0"), alg["factor"], alg["multiplicity"])})
        fi_keys = set(str(g) for g in node["first_integrals"])
        for key_g, (fexpr, Lf, g) in node["irreducible"].items():
            is_fi = (Lf is not None and sp.sympify(Lf) == 0)
            rec = _G_record(e_s, fexpr, Lf, conds, nonconds, sid_str, first_integral=is_fi,
                            level_symbol=out["_level"])
            stratum["darboux"].append(rec)
            if new:
                out["darboux_polynomials"].append(rec)
        for g in node["first_integrals"]:
            rec = _G_record(e_s, g, 0, conds, nonconds, sid_str, first_integral=True, level_symbol=out["_level"])
            stratum["first_integrals"].append(rec)
            if new:
                out["first_integrals"].append(rec)
        for tf in node["time_functions"]:
            tf = dict(tf, conditions=conds, stratum=sid_str)
            if new:
                out["time_functions"].append(tf)
        out["strata"].append(stratum)
        if not explore:
            if special:
                out["incomplete"].append({"conditions": conds, "assumptions": nonconds,
                                          "reason": "special parameter values not explored (explore=False): "
                                                    + ", ".join("%s = 0" % f for f in special)})
            continue
        special.sort(key=lambda f: (sp.Poly(f, *e_s.params).total_degree(), len(sp.Add.make_args(sp.expand(f))),
                                    str(f)))
        for f in special:
            ch, why = _child(e_s, f)
            if ch is None:
                out["incomplete"].append({"conditions": conds + ["%s = 0" % sp.factor(f)], "assumptions": nonconds,
                                          "reason": why})
                continue
            e2, subst, nz, (q, f1) = ch
            queue.append((e2, conds + ["%s = 0" % f], nonconds + nz, depth + 1, (node["n_dp"], node["dim_U"])))
            if nz:
                # the branch where the leading coefficient vanishes as well: lower-dimensional
                out["incomplete"].append({"conditions": conds + ["%s = 0" % f, "%s = 0" % sp.factor(f1)],
                                          "assumptions": nonconds,
                                          "reason": "sub-stratum where the solved parameter's coefficient vanishes: "
                                                    "not explored"})
    out["searched"]["strata_explored"] = explored
    out["searched"]["complete_over_parameters"] = (not out["incomplete"]) and bool(explore)
    gen = out["strata"][0] if out["strata"] else None
    out["generic"] = None if gen is None else {"dim_U": gen["dim_U"],
                                               "darboux": [d["G"] for d in gen["darboux"]],
                                               "first_integrals": [d["G"] for d in gen["first_integrals"]],
                                               "algebraic_cofactors": [x["factor"] for x in
                                                                       gen.get("algebraic_cofactors", [])]}
    if out["incomplete"] and out["status"] == "ok":
        out["status"] = "partial"
    out["certificate"] = {
        "type": "darboux-search", "label_found": "certificate", "label_absence": "search",
        "how_to_check": "each listed G: expand X(G) - L*G (verify_darboux); completeness up to weight m: recompute "
                        "U = largest invariant subspace of V_m (project file)",
        "grading": out["searched"]["grading"], "max_weight": m, "dimension_V": N,
        "generic_dim_U": None if gen is None else gen["dim_U"],
        "all_pass": all(d["certificate"]["status"] == "pass" for d in out["darboux_polynomials"] +
                        out["first_integrals"])}
    _dedupe_first_integrals(out)
    out["summary"] = _summary(out)
    out.pop("_level", None)
    out["elapsed_s"] = round(time.monotonic() - t0, 3)
    return out


def _irreducible_factors(eq_s, G):
    """[(f, cofactor of f)] for the jet-dependent irreducible factors (over Q(parameters)) of G"""
    K = eq_s.K
    w = eq_s.w[:K]
    params = list(eq_s.params)
    num = sp.fraction(sp.together(G))[0]
    try:
        _, fl = sp.factor_list(sp.expand(num), *(list(w) + params))
    except Exception:
        fl = [(num, 1)]
    res = []
    for f, e in fl:
        if not (set(w) & f.free_symbols):
            continue
        fexpr = _primitive_expr(f, w)
        q, rmd = sp.div(sp.expand(lie_derivative(eq_s, fexpr)), fexpr, *w)
        Lf = sp.expand(sp.cancel(q)) if sp.expand(rmd) == 0 else None
        res.append((fexpr, Lf))
    return res


def _finish_symbolic(eq, grad, m, N, deadline, out, max_strata, explore, t0):
    K = eq.K
    params = list(eq.params)
    cvars = _cofactor_vars(grad, params)
    if not explore:
        max_strata = 1
    out.setdefault("_post_deadline", deadline)
    found = _symbolic_search(eq, grad, m, cvars, deadline, out, max_strata)
    # group the nodes by the parameter conditions
    groups = {}
    order = []
    redundant = 0
    for nd in found:
        gk = (tuple(nd["conds"]), tuple(nd["nonconds"]))
        if nd["conds"] and not nd["new"]:
            redundant += 1
            continue
        if gk not in groups:
            groups[gk] = []
            order.append(gk)
        groups[gk].append(nd)
    if ((), ()) not in groups:
        groups[((), ())] = []
        order.insert(0, ((), ()))
    order.sort(key=lambda g: (len(g[0]), len(g[1])))
    for i, gk in enumerate(order):
        nodes = groups[gk]
        sid_str = "S%d" % i
        conds, nonconds = list(gk[0]), list(gk[1])
        generic = not conds
        new = generic or any(nd["new"] for nd in nodes)
        e_s = nodes[0]["eq"] if nodes else eq
        vo = []
        for nd in nodes:
            for x in nd.get("valid_outside", []):
                if x not in vo:
                    vo.append(x)
        if generic:
            vo = [x.replace(" = 0", "") for x in out.get("_first_conds", [])]
        stratum = {"id": sid_str, "conditions": conds, "assumptions": nonconds, "generic": generic,
                   "valid_outside": vo,
                   "substitution": dict((str(k), str(v)) for k, v in (nodes[0]["subs"].items() if nodes else [])),
                   "equation": str(e_s.E), "parameters": [s.name for s in e_s.params],
                   "eigenspaces": [], "new": bool(new), "darboux": [], "first_integrals": [],
                   "time_functions": [], "algebraic_cofactors": [], "classes": []}
        seen_g = set()
        cofpar = []
        for nd in nodes:
            L = sp.expand(nd["L"])
            c = sp.Poly(L, eq.w[0]).coeff_monomial(eq.w[0]) if L != 0 else sp.Integer(0)
            trivial = (L == 0)
            for x in nd["cofpar"]:
                if x not in cofpar:
                    cofpar.append(x)
            if trivial:
                Gs = []
                for g in nd["Gs"]:
                    g0 = sp.expand(g - g.subs(dict((s, 0) for s in nd["eq"].w[:K])))
                    if g0 != 0:
                        Gs.append(_primitive_expr(g0, nd["eq"].w[:K]))
            else:
                Gs = [_primitive_expr(g, nd["eq"].w[:K]) for g in nd["Gs"]]
            stratum["eigenspaces"].append({"c_w0": str(c), "cofactor": str(L), "cofactor_latex": _latex(L, eq),
                                           "dimension": len(Gs), "basis": [str(g) for g in Gs],
                                           "note": ("first integrals (constants removed)" if trivial else
                                                    ("dimension >= 2: G1/G2 is a rational first integral"
                                                     if len(Gs) >= 2 else ""))})
            for g in Gs:
                if trivial:
                    rec = _G_record(nd["eq"], g, 0, conds, nonconds, sid_str, first_integral=True,
                                    level_symbol=out["_level"])
                    stratum["first_integrals"].append(rec)
                    if new:
                        out["first_integrals"].append(rec)
                if time.monotonic() > out["_post_deadline"]:
                    q, rmd = sp.div(sp.expand(lie_derivative(nd["eq"], g)), g, *nd["eq"].w[:K])
                    facs = [(g, sp.expand(q) if sp.expand(rmd) == 0 else None)]
                    out["log"].append("not factored (budget): %s" % str(g)[:80])
                else:
                    facs = _irreducible_factors(nd["eq"], g)
                for fexpr, Lf in facs:
                    if Lf is not None and sp.sympify(Lf) == 0:
                        # first integrals: G and G + const are the same integral
                        fk = str(_primitive_expr(sp.expand(fexpr - fexpr.subs(dict((s_, 0) for s_ in nd["eq"].w[:K]))),
                                                 nd["eq"].w[:K]))
                    else:
                        fk = str(fexpr)
                    if fk in seen_g:
                        continue
                    seen_g.add(fk)
                    is_fi = (Lf is not None and sp.sympify(Lf) == 0)
                    rec = _G_record(nd["eq"], fexpr, Lf, conds, nonconds, sid_str, first_integral=is_fi,
                                    level_symbol=out["_level"])
                    stratum["darboux"].append(rec)
                    if new:
                        out["darboux_polynomials"].append(rec)
        stratum["dim_U"] = None
        stratum["codimension"] = len(conds) - len(cofpar)
        if cofpar:
            stratum["cofactor_parameters"] = cofpar
            stratum["note"] = ("%s: coefficient(s) of the cofactor that serve as parameters of this stratum; the "
                               "conditions relate them to the equation's parameters. Each parameter value has "
                               "finitely many cofactors of bounded weight, so the stratum has codimension %d in the "
                               "parameter space%s" % (", ".join(cofpar), stratum["codimension"],
                                                      " (it covers generic parameter values, with a cofactor "
                                                      "algebraic over Q(parameters))"
                                                      if stratum["codimension"] == 0 else ""))
        out["strata"].append(stratum)
    out["searched"]["redundant_substrata"] = redundant
    out["searched"]["method"] = ("direct: kernel of X - L on V_m, L = ell + c_w0*w0 + ..., over Q(parameters, "
                                 "cofactor coefficients); strata by recursion over the pivot factors")
    out["searched"]["cofactor_variables"] = [str(s_ * _mono_expr(mon, eq.w)) for s_, mon in cvars]
    out["searched"]["complete_over_parameters"] = (not out["incomplete"]) and bool(explore)
    gen = out["strata"][0]
    out["generic"] = {"dim_U": None, "darboux": [d["G"] for d in gen["darboux"]],
                      "first_integrals": [d["G"] for d in gen["first_integrals"]],
                      "cofactors": [es["cofactor"] for es in gen["eigenspaces"] if es["dimension"]]}
    if out["incomplete"] and out["status"] == "ok":
        out["status"] = "partial"
    out["certificate"] = {
        "type": "darboux-search", "label_found": "certificate", "label_absence": "search",
        "how_to_check": "each listed G: expand X(G) - L*G (verify_darboux); completeness up to weight m: recompute "
                        "the kernel of X - L on V_m (project file)",
        "grading": out["searched"]["grading"], "max_weight": m, "dimension_V": N,
        "all_pass": all(d["certificate"]["status"] == "pass" for d in out["darboux_polynomials"] +
                        out["first_integrals"])}
    _dedupe_first_integrals(out)
    out["summary"] = _summary(out)
    out.pop("_level", None)
    out.pop("_post_deadline", None)
    out.pop("_first_conds", None)
    out["elapsed_s"] = round(time.monotonic() - t0, 3)
    return out


def _dedupe_first_integrals(out):
    """a first integral is listed once (in 'first_integrals'); irreducible ones that are not in that list stay in
    'darboux_polynomials'"""
    def key(rec):
        try:
            loc = dict((n, sp.Symbol(n)) for n in _names_in(rec["G"]))
            G = sp.sympify(rec["G"], locals=loc)
            jets = sorted([x for x in G.free_symbols if _jet_name(x)], key=lambda t: t.name)
            G0 = sp.expand(G - G.subs(dict((x, 0) for x in jets)))
            return (rec.get("stratum"), str(_primitive_expr(G0, jets)))
        except Exception:
            return (rec.get("stratum"), rec["G"])
    fik = set(key(r) for r in out.get("first_integrals", []))
    kept = []
    seen = set()
    for r in out.get("darboux_polynomials", []):
        k = key(r) if r.get("first_integral") else (r.get("stratum"), r["G"])
        if (r.get("first_integral") and k in fik) or k in seen:
            continue
        seen.add(k)
        kept.append(r)
    out["darboux_polynomials"] = kept


def _names_in(text):
    import re
    return set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", text)) - {"I", "sqrt", "E", "pi"}


def _jet_name(sym):
    import re
    return bool(re.match(r"^w[0-9]+$", getattr(sym, "name", "")))


def _summary(out):
    s = out["searched"]
    gen = out.get("generic") or {}
    parts = ["Darboux polynomials of weight <= %d (weights %s) were searched exactly."
             % (s["max_weight"], ", ".join("%s: %s" % kv for kv in s["grading"]["weights"].items()))]
    if gen:
        if gen.get("darboux"):
            parts.append("Generic parameters: %d irreducible Darboux polynomial(s)." % len(gen["darboux"]))
        else:
            parts.append("Generic parameters: none.")
    alg = [st for st in out["strata"] if not st["generic"] and st.get("codimension") == 0 and st["darboux"]]
    if alg:
        parts.append("For generic parameters there are moreover %d Darboux polynomial(s) whose cofactor is algebraic "
                     "over Q(parameters) (strata %s)." % (sum(len(st["darboux"]) for st in alg),
                                                         ", ".join(st["id"] for st in alg)))
    nspecial = sum(1 for st in out["strata"] if not st["generic"] and st["new"] and st.get("codimension", 1) != 0)
    if nspecial:
        parts.append("%d special parameter stratum/strata with additional invariant hypersurfaces." % nspecial)
    if out.get("algebraic_cofactors"):
        parts.append("Darboux polynomials whose cofactor is a root of an irreducible polynomial of degree >= 3 exist "
                     "but are not written out (%s)." % "; ".join(sorted(set(x["factor"] for x in
                                                                          out["algebraic_cofactors"]))))
    if out["incomplete"]:
        parts.append("%d item(s) not decided (see 'incomplete')." % len(out["incomplete"]))
    return " ".join(parts)
