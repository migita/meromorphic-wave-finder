"""mero.classes -- which theorems of the registry apply to an equation, and what they give.

Public functions (project note section 1):

    classify(eq, local=None) -> list of {"id", "holds", "witness"}      structural facts
    tier(eq, local=None)     -> dict                                    the strongest statement the registry gives
    check_<theorem>(eq, local=None) -> {"id", "holds": True|False|None, "hypotheses": [...], "witness": {...}}

`eq` is a mero.equation.Equation (or the bootstrap class): only eq.K and eq.terms are used.
`local` is the dictionary of mero.laurent.local_analysis (SCHEMA section 1); if it is None the module calls
mero.laurent.local_analysis when it exists and otherwise a small reference computation with mero.bootstrap.

Rules of this module
  * A hypothesis has the status "verified", "fails" or "not verified", and a sentence `how`.
  * holds = True only if every hypothesis is verified; False if one fails; None if none fails but one could not be
    verified.
  * With symbolic parameters every statement is for GENERIC parameter values: a coefficient that is a nonzero
    expression in the parameters is treated as nonzero.  The conditions used are collected in witness["conditions"]
    and repeated by tier().  Substitute numbers and call again to decide a special locus.
  * Nothing here proves anything: the functions only check the hypotheses of the registry entries
    (registry/theorems.json) for the given equation.

Only SymPy is needed.
"""
import sympy as sp

VERIFIED, FAILS, UNKNOWN = "verified", "fails", "not verified"

W_CLASS = "W∪rational"
W_WORDS = "rational, simply periodic or elliptic"

# Registry entry T-PUREPOWER: k = 2 for n <= 5 (proved, Theorem 4.6(c) of the project's second note on the
# pure-power theorem).  Computed values of the least k for n >= 6, even K <= 12; key (n, pole order p).
_K_TABLE_COMPUTED = {(7, 1): 3, (9, 1): 4, (6, 2): 3, (11, 1): 5, (7, 2): 3, (13, 1): 5}


# ----------------------------------------------------------------------------------------------- helpers
def _s(e):
    return str(e)


def _hyp(key, text, status, how, **extra):
    d = {"key": key, "text": text, "status": status, "how": how}
    d.update(extra)
    return d


def _result(tid, hyps, witness):
    statuses = [h["status"] for h in hyps]
    if any(s == FAILS for s in statuses):
        holds = False
    elif all(s == VERIFIED for s in statuses):
        holds = True
    else:
        holds = None
    conds = []
    for h in hyps:
        for c in h.get("conditions", []):
            if c not in conds:
                conds.append(c)
    witness = dict(witness)
    witness["conditions"] = conds
    witness["generic"] = bool(conds)
    return {"id": tid, "holds": holds, "hypotheses": hyps, "witness": witness}


def _ff(x, j):
    r = sp.Integer(1)
    for i in range(j):
        r *= (x - i)
    return r


def _is_zero(c):
    c = sp.sympify(c)
    if c == 0:
        return True
    if c.is_number:
        return sp.simplify(c) == 0
    return sp.simplify(sp.together(c)) == 0


_IDENT = None


def _parse(text, st=None):
    """SymPy expression from a string of the local analysis.  Parameter names, a0 and the free coefficients h<k>
    are read as symbols (so that names like gamma, beta, lambda, E, I, S, N are not taken for SymPy objects)."""
    global _IDENT
    import re as _re
    if _IDENT is None:
        _IDENT = _re.compile(r"[A-Za-z_][A-Za-z_0-9]*")
    if not isinstance(text, str):
        return sp.sympify(text)
    keep = {"sqrt", "CRootOf", "RootOf", "Rational", "Integer", "exp", "pi"}
    names = set(_IDENT.findall(text))
    loc = {}
    pnames = set(s.name for s in st.params) if st is not None else set()
    for nm in names:
        if nm in pnames or nm == "a0" or _re.match(r"^h\d+$", nm) or nm not in keep and nm != "I":
            loc[nm] = sp.Symbol(nm)
    if "I" in names and "I" not in pnames:
        loc.pop("I", None)
    return sp.sympify(text, locals=loc)


def _mono_str(mon):
    parts = []
    for j, e in enumerate(mon):
        if e == 1:
            parts.append("w%d" % j)
        elif e > 1:
            parts.append("w%d**%d" % (j, e))
    return "*".join(parts) if parts else "1"


class _Struct(object):
    """Structural data of E, for generic parameter values."""

    def __init__(self, eq):
        self.K = int(eq.K)
        K = self.K
        self.terms = {}
        for m, c in eq.terms.items():
            m = tuple(int(e) for e in m)
            m = m + (0,) * (K + 1 - len(m))
            if not _is_zero(c):
                self.terms[m] = sp.sympify(c)
        self.params = sorted(set().union(*[c.free_symbols for c in self.terms.values()]) if self.terms else set(),
                             key=lambda s: s.name)
        self.deg = dict((m, sum(m)) for m in self.terms)
        self.ndiff = dict((m, sum(j * e for j, e in enumerate(m))) for m in self.terms)
        self.D = max(self.deg.values()) if self.terms else 0
        self.top = sorted(m for m in self.terms if self.deg[m] == self.D)
        eK = tuple([0] * K + [1])
        self.eK = eK
        self.solved = bool(K >= 1 and eK in self.terms and all(m[K] == 0 for m in self.terms if m != eK))
        self.lead = self.terms.get(eK) if self.solved else None
        self.phi = {}
        if self.solved:
            for m, c in self.terms.items():
                if m != eK:
                    self.phi[m] = sp.cancel(-c / self.lead)
        self.linear = self.D <= 1

    def symbolic(self, c):
        return bool(sp.sympify(c).free_symbols)

    def nz_condition(self, c, what):
        """[] if c is a nonzero number, else the genericity condition as a list with one string"""
        c = sp.sympify(c)
        if c.free_symbols:
            return ["%s != 0   (%s)" % (_s(sp.factor(c)), what)]
        return []

    def weight(self, m, p):
        return self.deg[m] * p + self.ndiff[m]

    def is_power_of_w(self, m):
        return all(e == 0 for e in m[1:])

    def is_single_jet(self, m):
        return sum(m) == 1


def _struct(eq):
    st = getattr(eq, "_mero_struct", None)
    if st is None:
        st = _Struct(eq)
        try:
            eq._mero_struct = st
        except Exception:
            pass
    return st


# ----------------------------------------------------------------------------------------------- pole orders
def pole_orders(eq):
    """All integers p >= 1 at which a pole of order p is possible, for generic parameters.

    On w = a0*z**(-p) + ... a monomial m contributes  c_m * a0**deg(m) * prod_j ff(-p, j)**e_j * z**(-weight),
    weight = deg(m)*p + (number of differentiations).  A Laurent series with a pole of order p needs the terms of
    the largest weight to cancel with a0 != 0.  For each integer p the monomials of the largest weight are grouped
    by degree; G_d(p) is the sum of their coefficients.  Then
        two or more groups with G_d != 0     -> the leading polynomial sum_d G_d a0**d has nonzero roots: "balance";
        exactly one group with G_d != 0      -> no pole of order p;
        all groups vanish                    -> "degenerate": the leading terms cancel for every a0 (a0 is free).
    The list is complete: beyond the largest crossing point of two weight lines the top line is the one of the
    largest degree and the largest number of differentiations, and its G is a polynomial in p whose positive
    integer roots are found exactly.

    Returns {"orders": [{"p", "kind": "balance"|"degenerate", "degrees": [...], "leading_poly": str,
                         "n_roots": int}], "complete": bool, "conditions": [...], "notes": [...], "p_break": int}
    """
    st = _struct(eq)
    out = {"orders": [], "complete": True, "conditions": [], "notes": [], "p_break": 0}
    if not st.terms:
        out["complete"] = False
        out["notes"].append("the equation is 0 = 0")
        return out
    lines = {}
    for m in st.terms:
        lines.setdefault((st.deg[m], st.ndiff[m]), []).append(m)
    keys = sorted(lines)
    pbreak = sp.Integer(0)
    for (d1, s1) in keys:
        for (d2, s2) in keys:
            if d1 > d2:
                x = sp.Rational(s2 - s1, d1 - d2)
                if x > pbreak:
                    pbreak = x
    plast = int(sp.floor(pbreak)) + 1
    out["p_break"] = plast
    a0 = sp.Symbol("a0")

    def group_sums(p):
        wmax = max(d * p + s for (d, s) in keys)
        groups = {}
        for (d, s) in keys:
            if d * p + s == wmax:
                tot = sp.Integer(0)
                for m in lines[(d, s)]:
                    term = st.terms[m]
                    for j, e in enumerate(m):
                        if e:
                            term *= _ff(-p, j) ** e
                    tot += term
                groups[d] = groups.get(d, 0) + tot
        return wmax, groups

    for p in range(1, plast + 1):
        wmax, groups = group_sums(sp.Integer(p))
        nz = dict((d, sp.factor(g)) for d, g in groups.items() if not _is_zero(g))
        sym = [g for g in nz.values() if g.free_symbols]
        if len(nz) >= 2:
            dmin, dmax = min(nz), max(nz)
            poly = sum(g * a0 ** (d - dmin) for d, g in nz.items())
            out["orders"].append({"p": p, "kind": "balance", "weight": int(wmax), "degrees": sorted(nz),
                                  "leading_poly": _s(sp.factor(poly)), "n_roots": int(dmax - dmin),
                                  "_poly": sp.expand(poly)})
            for g in sym:
                c = "%s != 0   (coefficient of the leading polynomial at p = %d)" % (_s(g), p)
                if c not in out["conditions"]:
                    out["conditions"].append(c)
        elif len(nz) == 0:
            out["orders"].append({"p": p, "kind": "degenerate", "weight": int(wmax), "degrees": sorted(groups),
                                  "leading_poly": "0", "n_roots": None})
        else:
            # exactly one group: no pole of order p for generic parameters
            if len(groups) >= 2 or sym:
                for g in sym:
                    c = "%s != 0   (otherwise the balance at p = %d changes)" % (_s(g), p)
                    if c not in out["conditions"]:
                        out["conditions"].append(c)
    # p > plast: the top line is (D, smax)
    smax = max(s for (d, s) in keys if d == st.D)
    P = sp.Symbol("p_order")
    G = sp.Integer(0)
    for m in lines[(st.D, smax)]:
        term = st.terms[m]
        for j, e in enumerate(m):
            if e:
                term *= _ff(-P, j) ** e
        G += term
    G = sp.factor(sp.expand(G))
    if _is_zero(G):
        out["complete"] = False
        out["notes"].append("the terms of top degree with the most differentiations cancel on a0*z**(-p) for every p: "
                            "the pole orders are not determined by the leading terms")
    elif G.has(P):
        num = sp.numer(sp.together(G))
        try:
            fl = sp.factor_list(num)
        except Exception:
            fl = (1, [(num, 1)])
        for fac, mult in fl[1]:
            if not fac.has(P):
                continue
            others = fac.free_symbols - {P}
            if others:
                # a root p that depends on the parameters: for generic parameters it is not an integer > plast,
                # but for special values it can be
                c = "%s != 0 for every integer p_order > %d   (otherwise a pole of that order with a free leading " \
                    "coefficient becomes possible)" % (_s(fac), plast)
                out["conditions"].append(c)
                continue
            try:
                rts = sp.roots(sp.Poly(fac, P))
            except Exception:
                rts = None
            if rts is None or sum(rts.values()) != sp.Poly(fac, P).degree():
                # irreducible factor over Q of degree >= 2 has no integer root; a degree-1 factor is solved above
                if sp.Poly(fac, P).degree() == 1:
                    out["complete"] = False
                continue
            for r in rts:
                if r.is_integer and r > plast:
                    out["orders"].append({"p": int(r), "kind": "degenerate", "weight": None, "degrees": [st.D],
                                          "leading_poly": "0", "n_roots": None})
    return out


def positive_integer_indices(eq, p, a0=None, a0_minpoly=None):
    """Positive integers k that are Fuchs indices of the balance at the pole order p, computed independently of
    mero.laurent: the roots of the indicial polynomial of the terms of largest weight,
        I(k) = sum_m c_m a0**deg(m) prod_j ff(-p, j)**e_j * sum_j e_j ff(k - p, j)/ff(-p, j),
    for the leading coefficient a0 (an expression, or any root of the polynomial a0_minpoly in the symbol a0).
    Only integers that are indices for all parameter values are returned (parameter-dependent roots are not).
    Returns a sorted list, or None if the computation could not be done."""
    st = _struct(eq)
    a0s, k = sp.Symbol("a0"), sp.Symbol("k_index")
    p = sp.Integer(p)
    wmax = max(st.weight(m, p) for m in st.terms)
    I = sp.Integer(0)
    for m, c in st.terms.items():
        if st.weight(m, p) != wmax:
            continue
        base = c * a0s ** sum(m)
        for j, e in enumerate(m):
            base *= _ff(-p, j) ** e
        lin = sp.Integer(0)
        for j, e in enumerate(m):
            if e:
                lin += e * _ff(k - p, j) / _ff(-p, j)
        I += base * lin
    I = sp.expand(I)
    try:
        if a0_minpoly is not None:
            R = sp.resultant(sp.numer(sp.together(I)), sp.numer(sp.together(a0_minpoly)), a0s)
        elif a0 is not None:
            R = sp.numer(sp.together(I.subs(a0s, a0)))
        else:
            return None
        R = sp.expand(R)
        if _is_zero(R) or not R.has(k):
            return None
        out = set()
        for f, _m in sp.factor_list(R)[1]:
            if not f.has(k) or (f.free_symbols - {k}):
                continue
            pf = sp.Poly(f, k)
            if pf.degree() == 1:
                r = -pf.all_coeffs()[1] / pf.all_coeffs()[0]
                if r.is_integer and r > 0:
                    out.add(int(r))
            else:
                for r in sp.roots(pf):                 # irreducible over Q of degree >= 2: no rational root,
                    if r.is_integer and r > 0:         # kept for safety if the factorisation is incomplete
                        out.add(int(r))
        return sorted(out)
    except Exception:
        return None


# ----------------------------------------------------------------------------------------------- local analysis
def _bootstrap_local(eq, max_index=40):
    """Reference local analysis with mero.bootstrap (slow, exact); used only when mero.laurent cannot be imported.
    Same keys as mero.laurent.local_analysis; one entry per leading coefficient."""
    from . import bootstrap as B
    st = _struct(eq)
    po = pole_orders(eq)
    out = {"balances": [], "non_integer_balances": [], "finiteness": None, "no_pole_possible": None, "strata": [],
           "notes": [], "origin": "mero.classes reference computation (mero.bootstrap)"}
    ok = po["complete"]
    a0s = sp.Symbol("a0")
    kk = sp.Symbol("k")
    counts = []
    for o in po["orders"]:
        if o["kind"] != "balance":
            ok = False
            out["notes"].append("p = %d: the leading coefficient is free; not analysed" % o["p"])
            continue
        p = o["p"]
        pol = sp.Poly(sp.numer(sp.together(o["_poly"])), a0s)
        try:
            roots = [r for r in sp.roots(pol) if r != 0]
        except Exception:
            roots = []
        distinct = sp.Poly(sp.sqf_part(pol.as_expr()), a0s).degree()
        if len(roots) != distinct:
            if not (pol.free_symbols - {a0s}):
                roots = [r for r in set(sp.CRootOf(pol, i) for i in range(pol.degree())) if r != 0]
            else:
                ok = False
                out["notes"].append("p = %d: roots of the leading polynomial not computed" % p)
                continue
        for a0 in roots:
            ind = B.indicial(eq, p, a0, kk)
            pos = [k0 for k0 in range(1, max_index + 1) if _is_zero(ind.subs(kk, k0))]
            N = (max(pos) if pos else 0) + 1
            L = B.laurent(eq, p, a0, N)
            hs = set(L["free"].values())
            solved, nfree, count = {}, len(L["free"]), None
            first_fail = None
            for k in sorted(L["conditions"]):
                e = sp.simplify(sp.sympify(L["conditions"][k]).subs(solved))
                if _is_zero(e):
                    continue
                inv = e.free_symbols & hs
                if not inv:
                    count = "0"
                    first_fail = k
                    break
                num = sp.numer(sp.together(e))
                done = False
                for h in sorted(inv, key=lambda x: x.name):
                    if sp.Poly(num, h).degree() == 1:
                        solved[h] = sp.solve(num, h)[0]
                        nfree -= 1
                        done = True
                        break
                if not done:
                    count = "not determined"
                    break
            if count is None:
                count = "family: %d free coefficient(s)" % nfree if nfree > 0 else "finite: 1"
            counts.append(count)
            out["balances"].append({
                "p": p, "a0": _s(a0), "a0_minpoly": None, "a0_degree": 1, "a0_free": False, "weight": o["weight"],
                "indicial": _s(ind), "positive_integer_indices": pos,
                "coeffs": [_s(c) for c in L["coeffs"]],
                "free": dict((str(k), str(v)) for k, v in L["free"].items()),
                "conditions": dict((str(k), _s(v)) for k, v in L["conditions"].items()),
                "series_count": count})
    if ok and all(c != "not determined" for c in counts):
        out["no_pole_possible"] = all(c == "0" for c in counts)
        out["finiteness"] = not any(c.startswith("family") for c in counts)
    return out


LOCAL_BUDGET_S = 30          # time budget of the local analysis when tier() has to compute it itself


def _get_local(eq, local):
    """the local analysis: the one given; else mero.laurent.local_analysis (time budget LOCAL_BUDGET_S); the
    reference computation with mero.bootstrap only if mero.laurent cannot be imported"""
    if local is not None:
        return local
    cached = getattr(eq, "_mero_local", None)
    if cached is not None:
        return cached
    try:
        from . import laurent
    except ImportError:
        laurent = None
    try:
        if laurent is not None:
            try:
                res = laurent.local_analysis(eq, budget_s=LOCAL_BUDGET_S)
            except TypeError:
                res = laurent.local_analysis(eq)
        else:
            res = _bootstrap_local(eq)
    except Exception as exc:                           # the checks then report "not verified"
        res = {"balances": [], "finiteness": None, "no_pole_possible": None, "error": repr(exc)}
    try:
        eq._mero_local = res
    except Exception:
        pass
    return res


def _count_of(b):
    """series count of one entry of local['balances'] (a class of conjugate leading coefficients):
       (kind, n) with kind in {"zero", "finite", "family", "unknown"}; n = number of series of the class"""
    sc = b.get("series_count")
    if isinstance(sc, int):
        return ("zero", 0) if sc == 0 else ("finite", sc)
    if not isinstance(sc, str):
        return ("unknown", None)
    t = sc.strip().lower()
    if t == "0" or t.startswith("0 "):
        return ("zero", 0)
    if t.startswith("finite"):
        try:
            return ("finite", int(t.split(":")[1].split()[0]))
        except Exception:
            return ("unknown", None)
    if t.startswith("family"):
        return ("family", None)
    return ("unknown", None)


def _series_summary(eq, local):
    """cached _series_summary_compute (the same equation object and the same local analysis)"""
    cache = getattr(eq, "_mero_series", None)
    if cache is not None and cache[0] is local:
        return cache[1]
    res = _series_summary_compute(eq, local)
    try:
        eq._mero_series = (local, res)
    except Exception:
        pass
    return res


def _series_summary_compute(eq, local):
    """What the local analysis says about formal Laurent series with a pole (generic parameters).

    Returns {"status": "ok"|"unavailable", "why", "n_series": int|None, "family": bool, "zero": bool,
             "conditions": [...], "orders": [...], "entries": [...]}.
    The list of pole orders is computed here (pole_orders) and must agree with the one of the local analysis."""
    st = _struct(eq)
    po = pole_orders(eq)
    res = {"status": "ok", "why": "", "n_series": None, "family": False, "zero": False, "conditions": [],
           "orders": sorted(o["p"] for o in po["orders"]), "pole_orders": po, "entries": []}

    def fail(why):
        res["status"] = "unavailable"
        res["why"] = why
        return res

    if not po["complete"]:
        return fail("the list of pole orders could not be completed: " + "; ".join(po["notes"]))
    res["conditions"] = list(po["conditions"])
    if not po["orders"]:
        res["zero"] = True
        res["n_series"] = 0
        res["why"] = "for every integer p >= 1 a single group of monomials has the largest weight on a0*z**(-p), so " \
                     "its leading term cannot cancel (p = 1..%d compared directly, larger p by the top line)" % po["p_break"]
        return res
    local = _get_local(eq, local)
    if not local or local.get("error"):
        return fail("no local analysis available" + (": " + str(local.get("error")) if local else ""))
    for note in local.get("notes") or []:
        if "not analysed" in note or "series not computed" in note or "time budget exhausted" in note:
            return fail("the local analysis is incomplete: " + note)
    have = {}
    for b in local.get("balances") or []:
        try:
            pb = sp.Rational(str(b.get("p")))
        except Exception:
            continue
        if pb.is_integer:
            have.setdefault(int(pb), []).append(b)
    need = dict((o["p"], o) for o in po["orders"])
    missing = sorted(set(need) - set(have))
    extra = sorted(set(have) - set(need))
    if missing:
        return fail("the local analysis has no entry for the pole order(s) p = %s" % ", ".join(map(str, missing)))
    if extra:
        return fail("the local analysis lists the pole order(s) p = %s, which the enumeration of mero.classes does "
                    "not find" % ", ".join(map(str, extra)))
    a0s = sp.Symbol("a0")
    total, family, unknown = 0, False, None
    for p in sorted(need):
        o = need[p]
        covered, free_a0 = 0, False
        for b in have[p]:
            kind, n = _count_of(b)
            covered += int(b.get("a0_degree") or 1)
            free_a0 = free_a0 or bool(b.get("a0_free"))
            conds = {}
            for k, v in (b.get("conditions") or {}).items():
                try:
                    conds[int(k)] = _parse(v, st)
                except Exception:
                    unknown = "a compatibility condition of the local analysis could not be read"
            entry = {"p": p, "a0": b.get("a0"), "a0_minpoly": b.get("a0_minpoly"), "kind": kind, "n": n,
                     "positive_integer_indices": b.get("positive_integer_indices"),
                     "conditions": dict((str(k), _s(v)) for k, v in sorted(conds.items())), "failing": None}
            res["entries"].append(entry)
            # the positive integer Fuchs indices, recomputed here, must be those of the local analysis
            if not b.get("a0_free"):
                try:
                    mp_ = _parse(b["a0_minpoly"], st) if b.get("a0_minpoly") else None
                    av = _parse(b["a0"], st) if (mp_ is None and b.get("a0") is not None) else None
                    mine = positive_integer_indices(eq, p, av, mp_)
                except Exception:
                    mine = None
                entry["indices_cross_check"] = "not computed" if mine is None else "agree"
                if mine is not None:
                    theirs = sorted(int(x) for x in (b.get("positive_integer_indices") or []))
                    if mine != theirs:
                        entry["indices_cross_check"] = "disagree"
                        unknown = "at p = %d, a0 = %s the positive integer Fuchs indices recomputed by mero.classes " \
                                  "are %s, those of the local analysis are %s" % (p, b.get("a0"), mine, theirs)
            if b.get("truncated"):
                unknown = "the series at p = %d was not computed far enough" % p
            if b.get("indices_depend_on_parameters"):
                c = "no further positive integer becomes a Fuchs index at p = %d   (the indices depend on the " \
                    "parameters)" % p
                if c not in res["conditions"]:
                    res["conditions"].append(c)
            if kind == "zero":
                hsyms = set(sp.Symbol(str(h)) for h in (b.get("free") or {}).values())
                first = None
                for k in sorted(conds):
                    if not _is_zero(conds[k]) and not (conds[k].free_symbols & hsyms):
                        first = (k, conds[k])
                        break
                if first is not None:
                    entry["failing"] = {"index": first[0], "value": _s(sp.factor(first[1]))}
                    try:
                        facs = [f for f, _m in sp.factor_list(sp.numer(sp.together(first[1])))[1]
                                if f.free_symbols - {a0s}]
                    except Exception:
                        facs = [first[1]] if first[1].free_symbols - {a0s} else []
                    if facs:
                        prod = sp.Integer(1)
                        for f in facs:
                            prod *= f
                        mp_txt = b.get("a0_minpoly")
                        if prod.has(a0s) and mp_txt:
                            try:
                                nrm = sp.resultant(sp.numer(sp.together(prod)),
                                                   sp.numer(sp.together(_parse(mp_txt, st))), a0s)
                                if _is_zero(nrm):
                                    raise ValueError("the norm vanishes")
                                nf = [f for f, _m in sp.factor_list(nrm)[1] if f.free_symbols]
                                prod2 = sp.Integer(1)
                                for f in nf:
                                    prod2 *= f
                                c = "%s != 0   (compatibility condition at the Fuchs index %d, p = %d: its norm over " \
                                    "the roots a0 of %s)" % (_s(prod2), first[0], p, mp_txt) if nf else ""
                            except Exception:
                                c = "for each root a0 of %s: %s != 0   (compatibility condition at the Fuchs index " \
                                    "%d, p = %d)" % (mp_txt, _s(prod), first[0], p)
                        else:
                            c = "%s != 0   (compatibility condition at the Fuchs index %d, p = %d, a0 = %s)" % (
                                _s(prod), first[0], p, b.get("a0"))
                        if c and c not in res["conditions"]:
                            res["conditions"].append(c)
                else:
                    entry["failing"] = {"index": None, "value": "the compatibility conditions have no common "
                                                                "solution in the free coefficients (elimination)"}
                    if st.params:
                        c = "generic parameter values   (elimination of the free coefficients at p = %d)" % p
                        if c not in res["conditions"]:
                            res["conditions"].append(c)
            elif kind == "finite":
                total += n
            elif kind == "family":
                family = True
            else:
                unknown = "the local analysis does not give the number of Laurent series at p = %d, a0 = %s (%s)" % (
                    p, b.get("a0"), b.get("series_count"))
        if o["kind"] == "balance" and not free_a0:
            try:
                distinct = sp.Poly(sp.sqf_part(sp.numer(sp.together(o["_poly"]))), a0s).degree()
            except Exception:
                distinct = o["n_roots"]
            if covered < distinct:
                unknown = "at p = %d the local analysis covers %d of the %d nonzero roots of the leading polynomial" % (
                    p, covered, distinct)
        if o["kind"] == "degenerate" and not free_a0:
            unknown = "at p = %d the leading terms cancel for every a0, and the local analysis has no entry with a " \
                      "free leading coefficient" % p
    for sb in local.get("special_balances") or []:
        cond = str(sb.get("condition", ""))
        if cond.endswith("== 0"):
            c = "%s != 0   (otherwise a pole of order %s with a free leading coefficient becomes possible)" % (
                cond[:-4].strip(), sb.get("p"))
            if c not in res["conditions"]:
                res["conditions"].append(c)
    if unknown:
        return fail(unknown)
    res["family"] = family
    res["n_series"] = None if family else total
    res["zero"] = (not family) and total == 0
    return res


# ----------------------------------------------------------------------------------------------- checks
def _one_top(st):
    """hypothesis 'exactly one monomial of the largest total degree'"""
    text = "E has exactly one monomial of the largest total degree"
    if len(st.top) == 1:
        m = st.top[0]
        c = st.terms[m]
        conds = st.nz_condition(c, "coefficient of the top-degree monomial %s" % _mono_str(m))
        how = "total degree %d; the only monomial of this degree is %s (coefficient %s)" % (st.D, _mono_str(m), _s(c))
        if conds:
            how += "; for generic parameter values"
        return _hyp("one_top_monomial", text, VERIFIED, how, conditions=conds)
    how = "total degree %d; monomials of this degree: %s" % (st.D, ", ".join(_mono_str(m) for m in st.top))
    sym = [m for m in st.top if st.symbolic(st.terms[m])]
    if sym:
        how += " (for generic parameter values; the count changes where a coefficient vanishes: %s)" % ", ".join(
            "%s = 0" % _s(st.terms[m]) for m in sym)
    return _hyp("one_top_monomial", text, FAILS, how)


def _finiteness_hyp(eq, local, key="finiteness"):
    text = "finiteness property: only finitely many formal Laurent series with a pole satisfy the equation"
    ss = _series_summary(eq, local)
    if ss["status"] != "ok":
        return _hyp(key, text, UNKNOWN, ss["why"]), ss
    if ss["family"]:
        fam = [e for e in ss["entries"] if e["kind"] == "family"]
        how = "the Laurent series at p = %s contain arbitrary coefficients (positive integer Fuchs indices with " \
              "satisfied compatibility conditions)" % ", ".join(sorted(set(str(e["p"]) for e in fam)))
        return _hyp(key, text, FAILS, how), ss
    how = "pole orders possible: %s; number of formal Laurent series: %d" % (
        ", ".join(map(str, ss["orders"])) if ss["orders"] else "none", ss["n_series"])
    if ss["conditions"]:
        how += " (for generic parameter values)"
    return _hyp(key, text, VERIFIED, how, conditions=list(ss["conditions"])), ss


def check_eremenko(eq, local=None):
    st = _struct(eq)
    h1 = _hyp("autonomous_polynomial", "E is a polynomial in w and its derivatives with constant coefficients",
              VERIFIED, "by construction of the Equation object")
    h2 = _one_top(st)
    h3, ss = _finiteness_hyp(eq, local)
    wit = {"top_degree": st.D, "top_monomials": [_mono_str(m) for m in st.top],
           "n_laurent_series": ss.get("n_series"), "pole_orders": ss.get("orders"),
           "pole_bound": ss.get("n_series") if h3["status"] == VERIFIED else None}
    return _result("T-EREMENKO", [h1, h2, h3], wit)


def _pure_power_data(st):
    """(n, lambda, p) if the equation is solved and Phi has the single top-degree monomial lambda*w0**n, n >= 2"""
    if not st.solved or not st.phi:
        return None
    n = max(sum(m) for m in st.phi)
    pure = tuple([n] + [0] * st.K)
    if n < 2 or pure not in st.phi:
        return None
    return n, st.phi[pure], sp.Rational(st.K, n - 1)


def pure_power_bound(K, n):
    """Bound on the number of Laurent series at the poles of one solution under T-PUREPOWER.
    Returns (bound or None, k or None, status, basis)."""
    p = sp.Rational(K, n - 1)
    if K % 2 == 1:
        return n - 1, None, "proved", "Lemma 6(a) of the project's note on the pure-power theorem: one Laurent series for each of the n - 1 " \
                                      "leading coefficients"
    if n <= 5:
        return 2 * (n - 1), 2, "proved", "Theorem 4.6(c) of the project's second note on the pure-power theorem: at most k = 2 values of the arbitrary " \
                                         "coefficient for each of the n - 1 leading coefficients (n <= 5)"
    if p.is_integer and (n, int(p)) in _K_TABLE_COMPUTED and K <= 12:
        k = _K_TABLE_COMPUTED[(n, int(p))]
        return k * (n - 1), k, "computed", "Theorem 4.6(b) of the project's second note on the pure-power theorem, with the " \
                                           "computed value k = %d (exact arithmetic)" % k
    return None, None, "not recorded", "Theorem 4.6 of the project's second note on the pure-power theorem: a bound k*(n-1) exists, the value of k is not recorded " \
                                       "for n >= 6, K > 12"


def check_pure_power(eq, local=None):
    st = _struct(eq)
    K = st.K
    hyps = []
    wit = {"K": K}
    t_solved = "the equation is solved for the highest derivative: E = c*wK - Phi(w0, ..., w_{K-1}), c != 0 constant"
    t_pp = "Phi = lambda*w0**n + Psi with n >= 2 and lambda != 0"
    t_wb = "(H): every monomial of Psi has weight sum e_j*(p + j) < n*p, where p = K/(n - 1)"
    t_ord = "K >= 3"
    if not st.solved:
        bad = [m for m in st.terms if m[K] > 0 and m != st.eK]
        how = "wK occurs in %s" % ", ".join(_mono_str(m) for m in bad) if bad else "E does not contain wK linearly"
        hyps.append(_hyp("solved", t_solved, FAILS, how))
        hyps.append(_hyp("pure_power", t_pp, UNKNOWN, "not examined: the equation is not solved"))
        hyps.append(_hyp("weight_bound", t_wb, UNKNOWN, "not examined"))
        hyps.append(_hyp("order", t_ord, VERIFIED if K >= 3 else FAILS, "K = %d" % K))
        return _result("T-PUREPOWER", hyps, wit)
    hyps.append(_hyp("solved", t_solved, VERIFIED, "c = %s" % _s(st.lead) + ("; for generic parameter values" if st.symbolic(st.lead) else ""),
                     conditions=st.nz_condition(st.lead, "coefficient of w%d" % K)))
    if not st.phi:
        hyps.append(_hyp("pure_power", t_pp, FAILS, "Phi = 0"))
        hyps.append(_hyp("weight_bound", t_wb, UNKNOWN, "not examined"))
        hyps.append(_hyp("order", t_ord, VERIFIED if K >= 3 else FAILS, "K = %d" % K))
        return _result("T-PUREPOWER", hyps, wit)
    n = max(sum(m) for m in st.phi)
    pure = tuple([n] + [0] * K)
    topphi = sorted(m for m in st.phi if sum(m) == n)
    wit["n"] = n
    if n < 2:
        hyps.append(_hyp("pure_power", t_pp, FAILS, "Phi has degree %d: the equation is linear" % n))
        hyps.append(_hyp("weight_bound", t_wb, UNKNOWN, "not examined"))
        hyps.append(_hyp("order", t_ord, VERIFIED if K >= 3 else FAILS, "K = %d" % K))
        return _result("T-PUREPOWER", hyps, wit)
    p = sp.Rational(K, n - 1)
    wit["p"] = _s(p)
    wit["p_is_integer"] = bool(p.is_integer)
    if pure not in st.phi:
        how = "Phi has degree n = %d but no monomial w0**%d; its monomials of degree %d: %s" % (
            n, n, n, ", ".join(_mono_str(m) for m in topphi))
        hyps.append(_hyp("pure_power", t_pp, FAILS, how))
        hyps.append(_hyp("weight_bound", t_wb, FAILS, "a monomial of degree n other than w0**n has weight >= n*p"))
        hyps.append(_hyp("order", t_ord, VERIFIED if K >= 3 else FAILS, "K = %d" % K))
        return _result("T-PUREPOWER", hyps, wit)
    lam = st.phi[pure]
    wit["lambda"] = _s(lam)
    hyps.append(_hyp("pure_power", t_pp, VERIFIED,
                     "n = %d, lambda = %s" % (n, _s(lam)) + ("; for generic parameter values" if st.symbolic(lam) else ""),
                     conditions=st.nz_condition(lam, "coefficient lambda of w0**%d" % n)))
    viol = [(m, st.weight(m, p)) for m in sorted(st.phi) if m != pure and st.weight(m, p) >= n * p]
    lower = [(m, st.weight(m, p)) for m in sorted(st.phi) if m != pure]
    wit["weights"] = dict((_mono_str(m), _s(w)) for m, w in lower)
    wit["top_weight"] = _s(n * p)
    if viol:
        how = "p = %s, n*p = %s; monomials of Psi of weight >= n*p: %s" % (
            _s(p), _s(n * p), ", ".join("%s (weight %s)" % (_mono_str(m), _s(w)) for m, w in viol))
        sym = [m for m, w in viol if st.symbolic(st.phi[m])]
        extra = {}
        if sym and len(sym) == len(viol):
            how += "; for generic parameter values. (H) holds on the locus " + ", ".join(
                "%s = 0" % _s(sp.factor(st.phi[m])) for m in sym) + " (substitute and call again)"
            extra["holds_if"] = ["%s == 0" % _s(sp.factor(st.phi[m])) for m in sym]
        hyps.append(_hyp("weight_bound", t_wb, FAILS, how, **extra))
    else:
        mx = max([w for m, w in lower], default=None)
        how = "p = %s, n*p = %s; " % (_s(p), _s(n * p)) + (
            "largest weight of a monomial of Psi: %s" % _s(mx) if mx is not None else "Psi = 0")
        hyps.append(_hyp("weight_bound", t_wb, VERIFIED, how))
    hyps.append(_hyp("order", t_ord, VERIFIED if K >= 3 else FAILS, "K = %d" % K))
    res = _result("T-PUREPOWER", hyps, wit)
    if res["holds"]:
        w = res["witness"]
        if not p.is_integer:
            w["only_constants"] = True
            w["pole_bound"] = 0
            w["pole_bound_status"] = "proved"
            w["pole_bound_basis"] = "p = K/(n-1) = %s is not an integer: the only meromorphic solutions are constants " \
                                    "(Theorem 1, last sentence)" % _s(p)
        else:
            b, k, status, basis = pure_power_bound(K, n)
            w["only_constants"] = False
            w["pole_bound"] = b
            w["k"] = k
            w["pole_bound_status"] = status
            w["pole_bound_basis"] = basis
            w["fuchs_index_free_coefficient"] = (K + 2 * int(p)) if K % 2 == 0 else None
            w["leading_coefficient_equation"] = "lambda*a0**(n-1) = (-1)**K * p*(p+1)*...*(p+K-1) = %s" % _s(
                (-1) ** K * sp.rf(p, K))
    return res


def _structure_form(st):
    """Data of the form  c_K wK + sum_{j<K} c_j wj + c_n w0**n (+ c_00 if n = 2); None if E is not of this form."""
    K = st.K
    lin, pw, const = {}, {}, None
    for m, c in st.terms.items():
        d = sum(m)
        if d == 0:
            const = c
        elif d == 1:
            lin[m.index(1)] = c
        elif st.is_power_of_w(m):
            pw[m[0]] = c
        else:
            return None
    if K not in lin or len(pw) != 1:
        return None
    n = list(pw)[0]
    return {"n": n, "lin": lin, "c_n": pw[n], "const": const, "c_K": lin[K]}


def _check_structure(eq, tid):
    st = _struct(eq)
    K = st.K
    t_form = "after a scaling of w (and a shift of w if n = 2) the equation is P(D)w + w**n/n = 0, P monic of degree K"
    t_ord = "K >= 3"
    f = _structure_form(st)
    wit = {"K": K}
    hyps = []
    if f is None:
        other = [m for m in st.terms if sum(m) >= 2 and not st.is_power_of_w(m)]
        pws = sorted(m[0] for m in st.terms if sum(m) >= 2 and st.is_power_of_w(m))
        if other:
            how = "E contains products with derivatives: %s" % ", ".join(_mono_str(m) for m in other)
        elif len(pws) != 1:
            how = "E contains the powers w0**k for k in %s: exactly one power k >= 2 is required" % pws
        else:
            how = "E does not contain w%d linearly" % K
        hyps.append(_hyp("form", t_form, FAILS, how))
    else:
        n = f["n"]
        wit["n"] = n
        p = sp.Rational(K, n - 1)
        wit["p"] = _s(p)
        conds = st.nz_condition(f["c_K"], "coefficient of w%d" % K) + st.nz_condition(f["c_n"], "coefficient of w0**%d" % n)
        if f["const"] is not None and n >= 3:
            how = "n = %d and E has the constant term %s: a shift of w that removes it creates the powers w0**2, ..., " \
                  "w0**%d" % (n, _s(f["const"]), n - 1)
            extra = {}
            if st.symbolic(f["const"]):
                how += "; the form holds on the locus %s = 0" % _s(f["const"])
                extra["holds_if"] = ["%s == 0" % _s(f["const"])]
            hyps.append(_hyp("form", t_form, FAILS, how, **extra))
        else:
            odd = dict((j, c) for j, c in f["lin"].items() if j % 2 == 1 and j < K)
            even_op = (K % 2 == 0) and not odd
            wit["P_even"] = even_op
            wit["scaling"] = "w = kappa*v with kappa**%d = %s" % (n - 1, _s(sp.cancel(f["c_K"] / (n * f["c_n"]))))
            how = "n = %d; linear terms %s; power term (%s)*w0**%d" % (
                n, " + ".join("(%s)*w%d" % (_s(c), j) for j, c in sorted(f["lin"].items())), _s(f["c_n"]), n)
            if f["const"] is not None:
                s = sp.Symbol("s")
                wit["shift"] = "w = v + s with (%s)*s**2 + (%s)*s + (%s) = 0; the shift changes only the coefficient " \
                               "of w0" % (_s(f["c_n"]), _s(f["lin"].get(0, 0)), _s(f["const"]))
                how += "; n = 2: the constant term %s is removed by a shift of w" % _s(f["const"])
            hyps.append(_hyp("form", t_form, VERIFIED, how + ("; for generic parameter values" if conds else ""),
                             conditions=conds))
            wit["pole_order_integer"] = bool(p.is_integer)
            if tid == "T-STRUCTURE-A":
                wit["poles_modulo_twisted_periods"] = 1
                wit["pole_bound"] = (n - 1) if p.is_integer else 0
                wit["pole_bound_basis"] = "Theorem A: exactly one pole modulo twisted periods, hence at most n - 1 = %d " \
                                          "pole(s) modulo ordinary periods" % (n - 1) if p.is_integer else \
                    "K/(n-1) is not an integer: every meromorphic solution is constant (Proposition 4.3)"
            else:
                if not p.is_integer:
                    mx, why = 0, "K/(n-1) is not an integer: every meromorphic solution is constant (Proposition 4.3)"
                elif n <= 3 and even_op:
                    mx, why = 2, "n <= 3 and P is even"
                elif n <= 3 and K % 2 == 0 and odd and all(st.symbolic(c) for c in odd.values()):
                    mx, why = 1, "P is not even for generic parameter values (odd-order coefficients %s); if they all " \
                                 "vanish the bound is 2" % ", ".join(_s(c) for c in odd.values())
                    wit["count_conditions"] = [" or ".join("%s != 0" % _s(c) for c in odd.values()) +
                                               "   (otherwise P is even and the bound is 2)"]
                else:
                    mx, why = 1, "n >= 4 or P is not even"
                wit["max_solutions_up_to_symmetry"] = mx
                wit["max_solutions_basis"] = why
    hyps.append(_hyp("order", t_ord, VERIFIED if K >= 3 else FAILS, "K = %d" % K))
    res = _result(tid, hyps, wit)
    for c in wit.get("count_conditions", []):
        if c not in res["witness"]["conditions"]:
            res["witness"]["conditions"].append(c)
            res["witness"]["generic"] = True
    return res


def check_structure_A(eq, local=None):
    return _check_structure(eq, "T-STRUCTURE-A")


def check_structure_B(eq, local=None):
    return _check_structure(eq, "T-STRUCTURE-B")


def _semilinear(st):
    """E = sum_j c_j wj + N(w0): returns {"lin": {j: c}, "N": {k: c}} (k = power of w0, including 0 and 1) or None"""
    lin, N = {}, {}
    for m, c in st.terms.items():
        d = sum(m)
        if st.is_power_of_w(m):
            N[m[0]] = c
        elif d == 1:
            lin[m.index(1)] = c
        else:
            return None
    return {"lin": lin, "N": N}


def check_structure_E(eq, local=None):
    st = _struct(eq)
    K = st.K
    t1 = "E = c_K*wK + sum_{1<=j<K} c_j*wj + N(w0), c_K != 0, N a polynomial of degree n >= 2"
    t2 = "K is odd, or P is even (c_j = 0 for every odd j)"
    sl = _semilinear(st)
    wit = {"K": K}
    hyps = []
    if sl is None or K not in sl["lin"] or K < 1 or not sl["N"] or max(sl["N"]) < 2:
        if sl is None:
            other = [m for m in st.terms if sum(m) >= 2 and not st.is_power_of_w(m)]
            how = "E contains products with derivatives: %s" % ", ".join(_mono_str(m) for m in other)
        elif K not in sl["lin"]:
            how = "E does not contain w%d linearly" % K
        else:
            how = "the nonlinearity N has degree < 2"
        hyps.append(_hyp("semilinear", t1, FAILS, how))
        hyps.append(_hyp("odd_or_even", t2, UNKNOWN, "not examined"))
        return _result("T-STRUCTURE-E", hyps, wit)
    n = max(sl["N"])
    wit["n"] = n
    p = sp.Rational(K, n - 1)
    wit["p"] = _s(p)
    conds = st.nz_condition(sl["lin"][K], "coefficient of w%d" % K) + st.nz_condition(sl["N"][n], "coefficient of w0**%d" % n)
    hyps.append(_hyp("semilinear", t1, VERIFIED, "n = %d; N(w0) has the powers %s" % (n, sorted(sl["N"])) + (
        "; for generic parameter values" if conds else ""), conditions=conds))
    odd = dict((j, c) for j, c in sl["lin"].items() if j % 2 == 1 and j < K)
    if K % 2 == 1:
        hyps.append(_hyp("odd_or_even", t2, VERIFIED, "K = %d is odd" % K))
    elif not odd:
        hyps.append(_hyp("odd_or_even", t2, VERIFIED, "K = %d is even and no derivative of odd order occurs" % K))
    else:
        how = "K = %d is even and E contains %s" % (K, ", ".join("(%s)*w%d" % (_s(c), j) for j, c in sorted(odd.items())))
        extra = {}
        if all(st.symbolic(c) for c in odd.values()):
            extra["holds_if"] = ["%s == 0" % _s(c) for c in odd.values()]
            how += "; for generic parameter values (the hypothesis holds where these coefficients vanish)"
        hyps.append(_hyp("odd_or_even", t2, FAILS, how, **extra))
    res = _result("T-STRUCTURE-E", hyps, wit)
    if res["holds"]:
        res["witness"]["pole_bound"] = (n - 1) if p.is_integer else 0
        res["witness"]["pole_bound_basis"] = "proof of Theorem E.2: at most one Laurent series for each of the n - 1 " \
                                             "leading coefficients among the poles of one solution"
    return res


def check_structure_entire(eq, local=None):
    st = _struct(eq)
    K = st.K
    t1 = "E = sum_{j<=K} c_j*wj + B(w0) with c_K != 0, K >= 1, and a polynomial B of degree n >= 2"
    sl = _semilinear(st)
    wit = {"K": K}
    if sl is None or K < 1 or K not in sl["lin"] or not sl["N"] or max(sl["N"]) < 2:
        return _result("T-STRUCTURE-ENTIRE", [_hyp("semilinear", t1, FAILS, "E is not of this form")], wit)
    n = max(sl["N"])
    p = sp.Rational(K, n - 1)
    conds = st.nz_condition(sl["lin"][K], "coefficient of w%d" % K) + st.nz_condition(sl["N"][n], "coefficient of w0**%d" % n)
    wit.update({"n": n, "p": _s(p), "entire_solutions": "constants",
                "all_solutions_constant": not p.is_integer})
    return _result("T-STRUCTURE-ENTIRE", [_hyp("semilinear", t1, VERIFIED, "n = %d, K/(n-1) = %s" % (n, _s(p)),
                                               conditions=conds)], wit)


def check_first_order(eq, local=None):
    st = _struct(eq)
    t = "K = 1: E is a polynomial in w0 and w1 with constant coefficients, and w1 occurs"
    ok = st.K == 1 and any(m[1] > 0 for m in st.terms)
    return _result("T-FIRSTORDER", [_hyp("order_one", t, VERIFIED if ok else FAILS, "K = %d" % st.K)], {"K": st.K})


def check_eln2009(eq, local=None):
    st = _struct(eq)
    K = st.K
    t = "E is a polynomial in w0 and wK only, K >= 1"
    bad = [m for m in st.terms if any(m[j] for j in range(1, K))]
    ok = K >= 1 and not bad and any(m[K] > 0 for m in st.terms)
    how = "K = %d" % K + ("; intermediate derivatives occur in %s" % ", ".join(_mono_str(m) for m in bad) if bad else "")
    wit = {"K": K, "covers": "all meromorphic solutions" if K <= 2 else "meromorphic solutions with at least one pole"}
    return _result("T-ELN2009", [_hyp("two_variables", t, VERIFIED if ok else FAILS, how)], wit)


def check_conservative(eq, local=None):
    st = _struct(eq)
    t = "E = c*w2 - F(w0) with a constant c != 0 and a polynomial F"
    ok = st.K == 2 and st.solved and all(st.is_power_of_w(m) for m in st.phi)
    wit = {"K": st.K}
    conds = []
    how = "K = %d" % st.K
    if ok:
        n = max([m[0] for m in st.phi], default=0)
        wit["n"] = n
        w0, w1, C = sp.Symbol("w0"), sp.Symbol("w1"), sp.Symbol("C_first_integral")
        F = sum(c * w0 ** m[0] for m, c in st.phi.items())
        G2 = sp.expand(2 * sp.integrate(F, w0))
        wit["first_integral"] = "w1**2 = %s + C" % _s(G2)
        wit["existence"] = ("deg F = %d >= 4: every meromorphic solution is constant" % n if n >= 4 else
                            "deg F = %d: the general solution is meromorphic" % n if n in (2, 3) else
                            "deg F = %d: linear equation, the solutions are entire" % n)
        conds = st.nz_condition(st.lead, "coefficient of w2")
        if n >= 1:
            conds += st.nz_condition(st.phi[tuple([n, 0, 0])], "coefficient of w0**%d" % n)
        how = "F = %s" % _s(sp.expand(F))
        # pole bound: T-EREMENKO for the first-order equation w1**2 = 2G(w0) + C, C a parameter
        try:
            from .equation import Equation
            eq1 = Equation(E=w1 ** 2 - G2 - C)
            r1 = check_eremenko(eq1, None)
            if r1["holds"] and not any("C_first_integral" in c for c in r1["witness"].get("conditions", [])):
                wit["pole_bound"] = r1["witness"].get("pole_bound")
                wit["pole_bound_basis"] = "T-EREMENKO for the first integral w1**2 = 2*G(w0) + C: %s formal Laurent " \
                                          "series for generic C" % r1["witness"].get("pole_bound")
                wit["first_integral_conditions"] = r1["witness"].get("conditions")
        except Exception:
            pass
    elif st.K == 2:
        how = "E contains w1 or is not solved for w2"
    return _result("T-CONSERVATIVE", [_hyp("form", t, VERIFIED if ok else FAILS, how, conditions=conds)], wit)


def check_clunie(eq, local=None):
    st = _struct(eq)
    h1 = _one_top(st)
    t2 = "the top-degree monomial is c*w0**N with N >= 2"
    if len(st.top) == 1 and st.is_power_of_w(st.top[0]) and st.D >= 2:
        h2 = _hyp("pure_power", t2, VERIFIED, "N = %d" % st.D)
    elif len(st.top) == 1:
        h2 = _hyp("pure_power", t2, FAILS, "the top-degree monomial is %s" % _mono_str(st.top[0]) + (
            " (degree < 2)" if st.D < 2 else ""))
    else:
        h2 = _hyp("pure_power", t2, FAILS, "there are %d monomials of top degree" % len(st.top))
    wit = {"N": st.D, "top_monomials": [_mono_str(m) for m in st.top],
           "excluded": ["transcendental entire solutions",
                        "transcendental meromorphic solutions with finitely many poles"]}
    return _result("T-CLUNIE", [h1, h2], wit)


def check_wv(eq, local=None):
    st = _struct(eq)
    h1 = _one_top(st)
    hyps = [h1]
    if st.D < 1:
        hyps.append(_hyp("nontrivial", "E depends on w", FAILS, "E is a constant"))
    wit = {"top_degree": st.D, "top_monomials": [_mono_str(m) for m in st.top],
           "excluded": ["transcendental entire solutions"]}
    return _result("T-WV", hyps, wit)


def check_poly_purepower(eq, local=None):
    """L-POLY-PUREPOWER: the top-degree part of E contains c*w0**N, c != 0  =>  polynomial solutions are constant"""
    st = _struct(eq)
    t = "the homogeneous part of E of the largest degree N >= 1 contains the monomial c*w0**N with c != 0"
    N = st.D
    pure = tuple([N] + [0] * st.K)
    wit = {"N": N, "top_monomials": [_mono_str(m) for m in st.top]}
    if N >= 1 and pure in st.terms:
        c = st.terms[pure]
        conds = st.nz_condition(c, "coefficient of w0**%d" % N)
        wit["degree_count"] = "on a polynomial of degree e >= 1 the monomial w0**%d has degree %d*e in z; a monomial of " \
                              "degree %d that contains a derivative has degree <= %d*e - 1, a monomial of degree d < %d " \
                              "has degree <= d*e" % (N, N, N, N, N)
        wit["polynomial_solutions"] = "constants"
        h = _hyp("top_part_contains_pure_power", t, VERIFIED,
                 "N = %d, c = %s" % (N, _s(c)) + ("; for generic parameter values" if conds else ""), conditions=conds)
    else:
        h = _hyp("top_part_contains_pure_power", t, FAILS,
                 "the monomials of top degree %d are %s" % (N, ", ".join(_mono_str(m) for m in st.top)))
    return _result("L-POLY-PUREPOWER", [h], wit)


def _demina_form(st):
    """(l, lambda, mu) if the top-degree part of E is lambda*w0**l*(w1 - mu*w0), l >= 1, else None"""
    if len(st.top) != 2:
        return None
    D = st.D
    l = D - 1
    if l < 1:
        return None
    m1 = tuple([l, 1] + [0] * (st.K - 1)) if st.K >= 1 else None
    m0 = tuple([l + 1] + [0] * st.K)
    if m1 is None or m1 not in st.terms or m0 not in st.terms:
        return None
    lam = st.terms[m1]
    mu = sp.cancel(-st.terms[m0] / lam)
    return l, lam, mu


def check_demina2019(eq, local=None):
    st = _struct(eq)
    t0 = "standing assumptions of the source: the order is at least 2 and E is irreducible"
    t1 = "E has exactly two monomials of the largest total degree, and their sum is lambda*w0**l*(w1 - m*w0), " \
         "lambda*m != 0, l >= 1 (m is the number called mu in the source)"
    f = _demina_form(st)
    wit = {"top_degree": st.D, "top_monomials": [_mono_str(m) for m in st.top]}
    if st.K < 2:
        h0 = _hyp("order_and_irreducible", t0, FAILS, "K = %d (first-order equations: T-FIRSTORDER)" % st.K)
    elif st.solved:
        h0 = _hyp("order_and_irreducible", t0, VERIFIED, "K = %d; E is linear in w%d with a constant coefficient, "
                                                         "hence irreducible" % (st.K, st.K))
    else:
        try:
            E = sum(c * sp.Mul(*[sp.Symbol("w%d" % j) ** e for j, e in enumerate(m)]) for m, c in st.terms.items())
            fl = sp.factor_list(sp.numer(sp.together(E)))[1]
            nfac = sum(mult for fac, mult in fl if any(str(s).startswith("w") for s in fac.free_symbols))
        except Exception:
            nfac = None
        if nfac == 1:
            h0 = _hyp("order_and_irreducible", t0, VERIFIED, "K = %d; E is irreducible over the field of its "
                                                             "coefficients (irreducibility over C not tested)" % st.K)
        elif nfac is None:
            h0 = _hyp("order_and_irreducible", t0, UNKNOWN, "the factorisation of E was not computed")
        else:
            h0 = _hyp("order_and_irreducible", t0, FAILS, "E is a product of %d factors: treat each factor" % nfac)
    if f is None:
        how = "monomials of top degree %d: %s" % (st.D, ", ".join(_mono_str(m) for m in st.top))
        h1 = _hyp("two_dominant_monomials", t1, FAILS, how)
        h2 = _hyp("finiteness", "finiteness property", UNKNOWN, "not examined")
        wit["part_i_applies"] = False
        return _result("T-DEMINA2019", [h0, h1, h2], wit)
    l, lam, mu = f
    conds = st.nz_condition(lam, "coefficient lambda of w0**%d*w1" % l) + \
        st.nz_condition(mu, "the rate m of T-DEMINA2019; otherwise w0**%d does not occur" % (l + 1))
    wit.update({"l": l, "lambda": _s(lam), "rate": _s(mu), "part_i_applies": h0["status"] == VERIFIED,
                "part_i": "a transcendental meromorphic solution with finitely many poles is h0 + h1*exp(m*z), "
                          "m = %s (dissertation Theorem 5.1)" % _s(mu)})
    h1 = _hyp("two_dominant_monomials", t1, VERIFIED, "l = %d, lambda = %s, m = %s" % (l, _s(lam), _s(mu)) + (
        "; for generic parameter values" if conds else ""), conditions=conds)
    h2, ss = _finiteness_hyp(eq, local)
    h2["text"] = "finiteness property (for part (ii)): exactly M formal Laurent series with a pole"
    wit["n_laurent_series"] = ss.get("n_series")
    wit["pole_bound"] = ss.get("n_series") if h2["status"] == VERIFIED else None
    return _result("T-DEMINA2019", [h0, h1, h2], wit)


def _nz_factors(expr):
    """the non-constant irreducible factors of the numerator and of the denominator of expr"""
    num, den = sp.fraction(sp.together(sp.sympify(expr)))
    out = []
    for part in (num, den):
        try:
            fl = sp.factor_list(part)[1]
        except Exception:
            fl = [(part, 1)]
        for f, _m in fl:
            if f.free_symbols:
                out.append(f)
    return out


def _same_factor(f, g):
    try:
        q = sp.cancel(f / g)
        return bool(q.is_number) and q != 0
    except Exception:
        return False


def _reduce_locus(equalities, inequalities, standing):
    """Conditions of a parameter locus as strings, with factors that are nonzero on the locus removed from the
    equalities.  Returns None if the locus is empty (an equality that cannot hold, an inequality that cannot)."""
    nz = list(standing)
    conds = []
    for x in inequalities:
        x = sp.sympify(x)
        if _is_zero(x):
            return None
        nz += _nz_factors(x)
        if x.free_symbols:
            conds.append("%s != 0" % _s(sp.factor(sp.numer(sp.together(x)))))
    for x in equalities:
        x = sp.sympify(x)
        if _is_zero(x):
            continue
        try:
            fl = [f for f, _m in sp.factor_list(sp.numer(sp.together(x)))[1] if f.free_symbols]
        except Exception:
            fl = [sp.numer(sp.together(x))]
        fl = [f for f in fl if not any(_same_factor(f, g) for g in nz)]
        if not fl:
            return None
        prod = sp.Integer(1)
        for f in fl:
            prod *= f
        conds.append("%s = 0" % _s(prod))
    return conds


def _entire_factor_form(st):
    """(n, c, rho) if the part of E of the largest degree n >= 2 is c*w0**(n-1)*(w1 - rho*w0), c != 0"""
    D = st.D
    if D < 2 or st.K < 1:
        return None
    m1 = tuple([D - 1, 1] + [0] * (st.K - 1))
    m0 = tuple([D] + [0] * st.K)
    if m1 not in st.terms or (set(st.top) - {m1, m0}):
        return None
    c = st.terms[m1]
    rho = sp.cancel(-st.terms[m0] / c) if m0 in st.terms else sp.Integer(0)
    return D, c, rho


def check_entire_factor(eq, local=None):
    """L-ENTIRE-FACTOR: top part c*w**(n-1)*(w' - rho*w); transcendental solutions with finitely many poles.
    The candidate C*exp(rho*z) + c0 is substituted into E: witness `candidate_status` is "solution",
    "not a solution" or "conditional" (then `candidate_conditions` lists the equations on the parameters)."""
    st = _struct(eq)
    t = "the part of E of the largest degree n >= 2 is c*w0**(n-1)*(w1 - rho*w0) with c != 0"
    f = _entire_factor_form(st)
    wit = {"top_degree": st.D, "top_monomials": [_mono_str(m) for m in st.top]}
    if f is None:
        return _result("L-ENTIRE-FACTOR", [_hyp("factor_form", t, FAILS, "monomials of top degree %d: %s" % (
            st.D, ", ".join(_mono_str(m) for m in st.top)))], wit)
    n, c, rho = f
    conds = st.nz_condition(c, "coefficient c of w0**%d*w1" % (n - 1))
    wit.update({"n": n, "c": _s(c), "rho": _s(rho), "rho_is_zero": bool(_is_zero(rho))})
    if _is_zero(rho):
        wit["form"] = None
        wit["candidate_status"] = "none"
        wit["candidate_conditions"] = []
    else:
        conds = conds + st.nz_condition(rho, "the rate rho; for rho = 0 there is no such solution")
        tau = sp.Integer(0)
        for m, co in st.terms.items():
            if sum(m) == n - 1:
                tau += co * rho ** st.ndiff[m]
        h0 = sp.factor(sp.cancel(tau / (c * rho)))
        wit["constant"] = _s(h0)
        wit["form"] = "C*exp(m*z) + c0 with m = %s, c0 = %s" % (_s(rho), _s(h0))
        # substitution: E(c0 + X, rho*X, rho**2*X, ...) is a polynomial in X = C*exp(rho*z)
        X = sp.Symbol("X_exp")
        expr = sp.Integer(0)
        for m, co in st.terms.items():
            term = co
            for j, e in enumerate(m):
                if e:
                    term *= ((h0 + X) if j == 0 else rho ** j * X) ** e
            expr += term
        num = sp.numer(sp.together(sp.expand(expr)))
        try:
            coeffs = sp.Poly(num, X).all_coeffs()
        except Exception:
            coeffs = [num]
        standing = _nz_factors(c) + _nz_factors(rho)
        status, needed = "solution", []
        for cf in coeffs:
            if _is_zero(cf):
                continue
            red = _reduce_locus([cf], [], standing)
            if red is None:
                status = "not a solution"
                needed = []
                break
            for r in red:
                if r not in needed:
                    needed.append(r)
        if status == "solution" and needed:
            status = "conditional"
        wit["candidate_status"] = status
        wit["candidate_conditions"] = needed
        wit["candidate_check"] = "E(c0 + X, m*X, m**2*X, ...) expanded in X = C*exp(m*z): " + (
            "all coefficients vanish" if status == "solution" else
            "a coefficient is a nonzero constant under the standing conditions" if status == "not a solution" else
            "the coefficients vanish exactly where " + " and ".join(needed))
    how = "n = %d, c = %s, rho = %s" % (n, _s(c), _s(rho)) + ("; for generic parameter values" if conds else "")
    return _result("L-ENTIRE-FACTOR", [_hyp("factor_form", t, VERIFIED, how, conditions=conds)], wit)


def check_nopole(eq, local=None):
    st = _struct(eq)
    t1 = "the list of all integers p >= 1 at which a pole of order p is possible is complete"
    t2 = "for each such p and each nonzero root a0 of the leading polynomial the Laurent recursion has no solution"
    po = pole_orders(eq)
    wit = {"pole_orders": [o["p"] for o in po["orders"]], "leading_polynomials": dict(
        (str(o["p"]), o["leading_poly"]) for o in po["orders"])}
    if not po["complete"]:
        return _result("T-NOPOLE", [_hyp("all_pole_orders", t1, UNKNOWN, "; ".join(po["notes"])),
                                    _hyp("no_series", t2, UNKNOWN, "not examined")], wit)
    how1 = "weights compared for p = 1..%d and, for larger p, by the top line (degree %d): pole orders possible: %s" % (
        po["p_break"], st.D, ", ".join(str(o["p"]) for o in po["orders"]) or "none")
    h1 = _hyp("all_pole_orders", t1, VERIFIED, how1 + ("; for generic parameter values" if po["conditions"] else ""),
              conditions=list(po["conditions"]))
    if not po["orders"]:
        h2 = _hyp("no_series", t2, VERIFIED, "no integer p >= 1 admits a cancellation of the leading terms")
        return _result("T-NOPOLE", [h1, h2], wit)
    ss = _series_summary(eq, local)
    if ss["status"] != "ok":
        return _result("T-NOPOLE", [h1, _hyp("no_series", t2, UNKNOWN, ss["why"])], wit)
    wit["series"] = [{"p": e["p"], "a0": e["a0"], "count": e["kind"] if e["kind"] != "finite" else e["n"],
                      "failing_condition": e["failing"]} for e in ss["entries"]]
    if ss["zero"]:
        parts = []
        for e in ss["entries"]:
            f = e["failing"] or {}
            if f.get("index") is not None:
                parts.append("p = %s, a0 = %s: the compatibility condition at the Fuchs index %s is %s, not 0" % (
                    e["p"], e["a0"], f["index"], f["value"]))
            else:
                parts.append("p = %s, a0 = %s: %s" % (e["p"], e["a0"], f.get("value", "no series")))
        cs = [c for c in ss["conditions"] if c not in po["conditions"]]
        h2 = _hyp("no_series", t2, VERIFIED, "; ".join(parts) + ("; for generic parameter values" if cs else ""),
                  conditions=cs)
    else:
        ex = [e for e in ss["entries"] if e["kind"] in ("finite", "family")]
        how = "formal Laurent series exist: " + "; ".join(
            "p = %s, a0 = %s (%s)" % (e["p"], e["a0"], "%s series" % e["n"] if e["kind"] == "finite" else
                                      "a family with arbitrary coefficients") for e in ex)
        h2 = _hyp("no_series", t2, FAILS, how)
    return _result("T-NOPOLE", [h1, h2], wit)


def _family_F_data(st):
    """Normalised coefficients of the third-order family of the registry entry T-FAMILY-F, or None.
    E = c*(w3 - A*w0*w1 - alpha*w2 - beta'*w0**2 - gamma*w1 - delta*w0 - eps)."""
    if st.K != 3 or not st.solved:
        return None
    allowed = {(1, 1, 0, 0): "A", (0, 0, 1, 0): "alpha", (2, 0, 0, 0): "beta", (0, 1, 0, 0): "gamma",
               (1, 0, 0, 0): "delta", (0, 0, 0, 0): "eps"}
    c = dict((v, sp.Integer(0)) for v in allowed.values())
    for m, co in st.phi.items():
        if m not in allowed:
            return None
        c[allowed[m]] = co
    if _is_zero(c["A"]):
        return None
    s = sp.cancel(12 / c["A"])                      # w = s*v  gives the coefficient 12 of v*v'
    alpha, gamma, delta = c["alpha"], c["gamma"], c["delta"]
    beta = sp.cancel(c["beta"] * s)
    eps = sp.cancel(c["eps"] / s)
    mu = sp.cancel(-beta / 6)
    rho = sp.Symbol("rho")
    P = rho ** 3 - alpha * rho ** 2 - gamma * rho - delta
    Pmu = sp.factor(sp.cancel(P.subs(rho, mu)))
    a = sp.cancel(alpha - mu)
    b = sp.cancel(gamma + mu * a)
    return {"scale": s, "alpha": alpha, "beta": beta, "gamma": gamma, "delta": delta, "epsilon": eps, "mu": mu,
            "P_mu": Pmu, "a": a, "b": b, "P": P, "rho": rho}


def check_family_F(eq, local=None):
    st = _struct(eq)
    t = "after multiplying w by a constant: E = w3 - 12*w0*w1 - alpha*w2 - beta*w0**2 - gamma*w1 - delta*w0 - epsilon"
    d = _family_F_data(st)
    if d is None:
        return _result("T-FAMILY-F", [_hyp("form", t, FAILS, "E is not of this form")], {})
    conds = st.nz_condition(st.lead, "coefficient of w3") + st.nz_condition(st.phi[(1, 1, 0, 0)], "coefficient of w0*w1")
    standing = _nz_factors(st.lead) + _nz_factors(st.phi[(1, 1, 0, 0)])
    mu, alpha, Pmu = d["mu"], d["alpha"], d["P_mu"]
    a, b, eps, delta = d["a"], d["b"], d["epsilon"], d["delta"]
    pole_cond = sp.factor(sp.cancel((alpha - 6 * mu) * Pmu))
    red = _reduce_locus([pole_cond], [], standing)
    pc_str = red[0].replace(" = 0", "") if red else _s(pole_cond)
    wit = {"normalisation": "the entry is stated for the unknown w divided by %s; the coefficients below are those of "
                            "the equation for that unknown, written in the parameters of the given equation" % _s(d["scale"]),
           "alpha": _s(alpha), "beta": _s(d["beta"]), "gamma": _s(d["gamma"]), "delta": _s(delta),
           "epsilon": _s(eps), "mu": _s(mu), "P(mu)": _s(Pmu),
           "pole_condition_expr": pc_str,
           "pole_condition": "a solution with a pole exists only if %s = 0 (T-FAMILY-F, Theorem 1(b))" % pc_str,
           "laurent": "pole order 2, Fuchs indices -1, 4, 6"}
    kind13 = "next to solutions that are rational, simply periodic or elliptic there are solutions of the kind " \
             "exp(2*k*z)*Y(exp(k*z)), up to an additive and a multiplicative constant, with Y a Weierstrass function " \
             "or a first Painleve transcendent; k = %s"
    kind4 = "every solution with a pole is a first Painleve transcendent in z"
    loci = []
    if not _is_zero(mu):
        chi = sp.factor(sp.cancel(36 * a ** 4 - 625 * b ** 2 - 15000 * eps / mu))
        wit["chi"] = _s(chi)
        loci.append(("Table 1, rows 1-3", [Pmu, chi], [mu, a], kind13 % _s(sp.factor(sp.cancel(a / 5)))))
    else:
        chi = None
    loci.append(("Table 1, row 1 with mu = 0", [mu, delta, eps], [alpha], kind13 % _s(sp.factor(sp.cancel(alpha / 5)))))
    loci.append(("Table 1, row 4", [mu, alpha, delta], [eps], kind4))
    out_loci = []
    for name, eqs, ineqs, kind in loci:
        r = _reduce_locus(eqs, ineqs, standing)
        if r is not None:
            out_loci.append({"where": name, "conditions": r, "kind": kind})
    wit["loci_outside_W"] = out_loci
    symbolic = bool(pole_cond.free_symbols)
    if _is_zero(pole_cond):
        on = [L for L in out_loci if not L["conditions"]]
        if on:
            wit["stratum"] = "outside-W"
            wit["stratum_text"] = "%s: %s" % (on[0]["where"], on[0]["kind"])
        elif any(L["conditions"] for L in out_loci):
            wit["stratum"] = "undetermined"
            wit["stratum_text"] = "poles are possible; solutions outside W exist exactly on the loci listed in `strata`"
        else:
            wit["stratum"] = "in-W"
            wit["stratum_text"] = "every solution with poles is rational, simply periodic or elliptic, with one pole " \
                                  "in a period (Theorem 1(d), Table 2)"
    elif symbolic:
        wit["stratum"] = "generic-no-pole"
        wit["stratum_text"] = "for generic parameter values no solution has a pole (Theorem 1(b))"
        conds = conds + ["%s != 0   (T-FAMILY-F, Theorem 1(b): a solution with a pole requires this to vanish)" % pc_str]
    else:
        wit["stratum"] = "no-pole"
        wit["stratum_text"] = "no solution has a pole (Theorem 1(b))"
    return _result("T-FAMILY-F", [_hyp("form", t, VERIFIED, "the unknown is divided by %s" % _s(d["scale"]) + (
        "; for generic parameter values" if conds else ""), conditions=conds)], wit)


def check_linear(eq, local=None):
    st = _struct(eq)
    t = "E has total degree 1 in the jets: E = sum_j c_j*wj + c"
    ok = st.D == 1
    wit = {"degree": st.D}
    if ok:
        wit["solutions"] = "every solution is entire: a particular polynomial solution plus sum of q_i(z)*exp(r_i*z), " \
                           "r_i the roots of the characteristic polynomial"
    return _result("L-LINEAR", [_hyp("linear", t, VERIFIED if ok else FAILS, "total degree %d" % st.D)], wit)


CHECKS = [
    ("T-PUREPOWER", check_pure_power),
    ("T-EREMENKO", check_eremenko),
    ("T-DEMINA2019", check_demina2019),
    ("T-STRUCTURE-A", check_structure_A),
    ("T-STRUCTURE-B", check_structure_B),
    ("T-STRUCTURE-E", check_structure_E),
    ("T-STRUCTURE-ENTIRE", check_structure_entire),
    ("T-FIRSTORDER", check_first_order),
    ("T-ELN2009", check_eln2009),
    ("T-CONSERVATIVE", check_conservative),
    ("T-NOPOLE", check_nopole),
    ("T-CLUNIE", check_clunie),
    ("T-WV", check_wv),
    ("L-POLY-PUREPOWER", check_poly_purepower),
    ("L-ENTIRE-FACTOR", check_entire_factor),
    ("T-FAMILY-F", check_family_F),
    ("L-LINEAR", check_linear),
]


def run_checks(eq, local=None):
    """{theorem id: result of its check}; a check that raises is reported as holds = None"""
    out = {}
    for tid, fn in CHECKS:
        try:
            out[tid] = fn(eq, local)
        except Exception as exc:
            out[tid] = {"id": tid, "holds": None, "hypotheses": [
                _hyp("check", "the check ran", UNKNOWN, "the check raised %r" % (exc,))], "witness": {"conditions": [], "generic": False}}
    return out


# ----------------------------------------------------------------------------------------------- classify
def classify(eq, local=None):
    """Structural facts about the equation, as a list of {"id", "holds", "witness"} (SCHEMA section 3, `classes`)."""
    st = _struct(eq)
    out = []
    out.append({"id": "solved", "holds": st.solved,
                "witness": {"lead": _s(st.lead)} if st.solved else {}})
    out.append({"id": "linear", "holds": st.linear, "witness": {"degree": st.D}})
    out.append({"id": "top-degree-part", "holds": True,
                "witness": {"degree": st.D, "monomials": [_mono_str(m) for m in st.top],
                            "coefficients": [_s(st.terms[m]) for m in st.top],
                            "number_of_dominant_monomials": len(st.top)}})
    pp = _pure_power_data(st)
    if pp:
        n, lam, p = pp
        viol = [m for m in st.phi if m != tuple([n] + [0] * st.K) and st.weight(m, p) >= n * p]
        out.append({"id": "pure-power", "holds": True,
                    "witness": {"n": n, "p": _s(p), "lambda": _s(lam), "K": st.K,
                                "p_is_integer": bool(p.is_integer)}})
        mx = max([st.weight(m, p) for m in st.phi if m != tuple([n] + [0] * st.K)], default=None)
        out.append({"id": "weight-bound", "holds": not viol,
                    "witness": {"top_weight": _s(n * p), "largest_lower_weight": None if mx is None else _s(mx),
                                "violating_monomials": [_mono_str(m) for m in viol]}})
    else:
        out.append({"id": "pure-power", "holds": False, "witness": {}})
    f = _structure_form(st)
    out.append({"id": "linear-lower-terms", "holds": bool(f) and (f["const"] is None or f["n"] == 2),
                "witness": {"n": f["n"]} if f else {}})
    sl = _semilinear(st)
    out.append({"id": "semilinear", "holds": bool(sl) and st.K in (sl or {"lin": {}})["lin"],
                "witness": {"powers_of_w": sorted(sl["N"])} if sl else {}})
    df = _demina_form(st)
    out.append({"id": "two-dominant-monomials", "holds": df is not None,
                "witness": {"l": df[0], "lambda": _s(df[1]), "mu": _s(df[2])} if df else {}})
    out.append({"id": "first-order", "holds": st.K == 1, "witness": {}})
    po = pole_orders(eq)
    out.append({"id": "pole-orders", "holds": po["complete"],
                "witness": {"orders": [{"p": o["p"], "kind": o["kind"], "leading_poly": o["leading_poly"]}
                                       for o in po["orders"]], "conditions": po["conditions"], "notes": po["notes"]}})
    try:
        ss = _series_summary(eq, local)
    except Exception as exc:
        ss = {"status": "unavailable", "why": repr(exc)}
    if ss["status"] == "ok":
        out.append({"id": "finiteness", "holds": not ss["family"],
                    "witness": {"n_laurent_series": ss["n_series"], "conditions": ss["conditions"]}})
        out.append({"id": "no-pole", "holds": bool(ss["zero"]), "witness": {"conditions": ss["conditions"]}})
    else:
        out.append({"id": "finiteness", "holds": None, "witness": {"why": ss.get("why", "")}})
        out.append({"id": "no-pole", "holds": None, "witness": {"why": ss.get("why", "")}})
    out.append({"id": "family-F", "holds": _family_F_data(st) is not None, "witness": {}})
    return out


# ----------------------------------------------------------------------------------------------- tier
def _registry_index():
    try:
        from . import registry
        return dict((e["id"], e) for e in registry.load_registry())
    except Exception:
        return {}


def _theorem_block(tid, res, reg, cavs=None):
    e = reg.get(tid, {})
    concl = e.get("conclusion") or {}
    src = e.get("source") or {}
    cav = (cavs or {}).get(tid)
    return {"id": tid, "label": e.get("label", "certificate" if tid.startswith("L-") else None),
            "name": e.get("name", tid),
            "applies": res["holds"] is True, "holds": res["holds"],
            "hypotheses": [dict((k, h[k]) for k in h if k in ("key", "text", "status", "how", "conditions", "holds_if"))
                           for h in res["hypotheses"]],
            "conclusion": (concl.get("text", "") + (" " + cav if cav else "")).strip(),
            "source": ("%s — %s" % (src.get("citation", ""), src.get("where", ""))).strip(" —"),
            "statement_verified_against_source": e.get("statement_verified_against_source"),
            "second_reading": e.get("second_reading"), "label_note": e.get("label_note"),
            "proof_status": e.get("proof_status"),
            "caveat": cav,
            "witness": res["witness"]}


def _factor_conditions(conds, st):
    """The conditions 'expr != 0   (reason)' split into irreducible factors: a short list for display."""
    out = []
    for c in conds:
        head = c.split("   ")[0].strip()
        if not head.endswith("!= 0") or " or " in head or head.startswith("for each") or head.count("!=") != 1:
            if head not in out:
                out.append(head)
            continue
        try:
            e = _parse(head[:-4].strip(), st)
            num = sp.numer(sp.together(e))
            facs = [f for f, _m in sp.factor_list(num)[1] if f.free_symbols]
        except Exception:
            facs = None
        if facs is None:
            if head not in out:
                out.append(head)
            continue
        for f in facs:
            if f.could_extract_minus_sign():
                f = -f
            t = "%s != 0" % _s(f)
            if t not in out:
                out.append(t)
    return out


def _caveat(tids, cavs):
    """the caveats of the theorems named (cavs: {id: sentence}), as one string ('' if none)"""
    if isinstance(tids, str):
        tids = [tids]
    out = []
    for tid in tids:
        c = (cavs or {}).get(tid)
        if c and c not in out:
            out.append(c)
    return " ".join(out)


def _basis(tids, reg, cavs=None):
    """basis object of a ruled-out item: the first theorem, the others under 'with'"""
    if isinstance(tids, str):
        tids = [tids]
    items = []
    for tid in tids:
        e = reg.get(tid, {})
        b = {"theorem": tid, "label": e.get("label", "certificate")}
        if e.get("statement_verified_against_source") is False:
            b["statement_verified_against_source"] = False
        if e.get("second_reading") not in (None, True):
            b["second_reading"] = e.get("second_reading")
        if (cavs or {}).get(tid):
            b["caveat"] = cavs[tid]
        items.append(b)
    out = dict(items[0])
    if len(items) > 1:
        out["with"] = items[1:]
    return out


EREMENKO_PROOF_STATUS = ("The source states the theorem for any single monomial of top degree and gives the proof for "
                         "the Kuramoto–Sivashinsky equation.")


def tier(eq, local=None):
    """The strongest statement that the registry gives for this equation.

    Returns a dict with the keys
      class_of_all_meromorphic_solutions   "W∪rational" | "entire only" | "entire (not classified)" |
                                           "entire (linear equation)" | "listed (not all in W)" | "unknown"
      entire_solutions                     what registry theorems establish about solutions without poles (a candidate
                                           exponential is named only after it was substituted into the equation)
      d_le_1                               True: a theorem gives that every meromorphic solution is rational, simply
                                           periodic or elliptic; False: solutions outside this class exist; None: open
      d_ge_2                               {"status": "ruled out" | "ruled out for generic parameter values" |
                                           "occurs" | "not ruled out", "basis", "conditions"}: use this, not the
                                           class string, to say whether solutions with d >= 2 are excluded
      pole_bound, pole_bound_basis, pole_bounds     bound on the number of poles in a period, the theorem that
                                           gives it, and the bounds of all theorems that apply
      solution_count, solution_count_conditions   bound on the number of nonconstant solutions up to symmetry
                                           (T-STRUCTURE-B) and the parameter conditions under which it holds
      laurent_series_count                 the number N of formal Laurent series with a pole if the finiteness
                                           property was verified (then at most N meromorphic solutions with a pole
                                           up to translation, T-SERIES-PERIOD), else None
      generic, conditions, conditions_factored   the class statement is for generic parameters, under these conditions
      without_genericity                   what holds without the conditions of T-NOPOLE (or None)
      strata                               for families with a registry theorem: the answer on the special loci
      text                                 one or two sentences built from the fields above
      caveats                              {theorem id: sentence} attached to the statements that rest on it
      theorems                             one block per registry check (SCHEMA section 3)
      used, used_labels, also_apply        the theorems on which the statements rest (one for the class - a published
                                           one if there is one -, the one for the pole bound, those for the solutions
                                           without poles and for the counts); the other theorems that hold
      ruled_out, not_decided               lists ready to be shown (SCHEMA section 3); every ruled-out item has its
                                           own `conditions`, `conditions_factored` and, where it applies, `caveat`
    "entire only" is returned only when registry theorems also restrict the solutions without poles to constants,
    polynomials or explicit exponentials: in all these cases d <= 1.
    """
    reg = _registry_index()
    R = run_checks(eq, local)
    st = _struct(eq)
    H = dict((tid, R[tid]["holds"] is True) for tid in R)
    W = dict((tid, R[tid]["witness"]) for tid in R)
    # caveats: registry entries whose wording was not verified in the source; T-EREMENKO when the single top-degree
    # monomial contains a derivative (the source proves the case of the Kuramoto-Sivashinsky equation)
    cavs = dict((tid, e["caveat"]) for tid, e in reg.items() if e.get("caveat"))
    if H["T-EREMENKO"] and not (len(st.top) == 1 and st.is_power_of_w(st.top[0])):
        cavs["T-EREMENKO"] = reg.get("T-EREMENKO", {}).get("proof_status") or EREMENKO_PROOF_STATUS
    theorems = [_theorem_block(tid, R[tid], reg, cavs) for tid, _ in CHECKS]
    used, top_used, ruled_out, not_decided, conditions = [], [], [], [], []
    cls, d_le_1 = "unknown", None
    pole_bound, pole_basis, pole_bounds, sol_count, sol_count_conditions = None, None, {}, None, []
    without = None
    text = ""
    NOT_RESTRICTED = "not restricted by a theorem of the registry"

    def conds_of(tids):
        out = []
        for tid in tids:
            for c in W[tid].get("conditions", []):
                if c not in out:
                    out.append(c)
        return out

    def use(tids, top=True):
        for tid in ([tids] if isinstance(tids, str) else tids):
            if tid not in used:
                used.append(tid)
            if top:
                if tid not in top_used:
                    top_used.append(tid)
                for c in W[tid].get("conditions", []):
                    if c not in conditions:
                        conditions.append(c)

    def cert(tids):
        return {"hypotheses": [{"theorem": tid, "key": h["key"], "status": h["status"], "how": h["how"]}
                               for tid in tids for h in R[tid]["hypotheses"]]}

    def rule(what, tids):
        tids = [tids] if isinstance(tids, str) else list(tids)
        cs = conds_of(tids)
        cav = _caveat(tids, cavs)
        sep = " " if cav.startswith("(") else ". "
        item = {"what": (what + sep + cav) if cav else what, "basis": _basis(tids, reg, cavs),
                "certificate": cert(tids), "conditions": cs, "conditions_factored": _factor_conditions(cs, st)}
        if cav:
            item["caveat"] = cav
        ruled_out.append(item)

    # ---- (1) solutions without poles: transcendental ones and polynomial ones are restricted separately
    poly_const = H["L-POLY-PUREPOWER"]
    base = "constants" if poly_const else "polynomials"
    entire, entire_basis, candidate = NOT_RESTRICTED, [], None
    if st.linear:
        pass
    elif H["T-CLUNIE"] or H["T-WV"] or (H["L-ENTIRE-FACTOR"] and W["L-ENTIRE-FACTOR"].get("rho_is_zero")):
        entire = base
        entire_basis = ["T-CLUNIE" if H["T-CLUNIE"] else "T-WV"] + (["L-POLY-PUREPOWER"] if poly_const else [])
    elif H["L-ENTIRE-FACTOR"]:
        ef = W["L-ENTIRE-FACTOR"]
        entire_basis = ["L-ENTIRE-FACTOR"] + (["L-POLY-PUREPOWER"] if poly_const else [])
        status = ef.get("candidate_status")
        if status == "solution":
            candidate = ef.get("form")
            entire = "%s and the functions %s (C arbitrary)" % (base, candidate)
        elif status == "conditional":
            candidate = ef.get("form")
            entire = "%s; in addition the functions %s exactly where %s" % (
                base, candidate, " and ".join(ef.get("candidate_conditions", [])))
        else:
            entire = base
    elif W["T-DEMINA2019"].get("part_i_applies"):
        entire = "polynomials, or h0 + h1*exp(m*z) with m = %s" % W["T-DEMINA2019"].get("rate")
        entire_basis = ["T-DEMINA2019"]
    elif H["T-FIRSTORDER"] or H["T-CONSERVATIVE"] or (H["T-ELN2009"] and st.K <= 2):
        entire = W_WORDS
        entire_basis = [t for t in ("T-FIRSTORDER", "T-CONSERVATIVE", "T-ELN2009") if H[t]][:1]
    entire_d1 = entire != NOT_RESTRICTED

    # ---- (2) the class when poles are possible
    wres = None
    fam_stratum = W["T-FAMILY-F"].get("stratum") if H["T-FAMILY-F"] else None
    w_theorems = [tid for tid in ("T-FIRSTORDER", "T-CONSERVATIVE", "T-EREMENKO", "T-DEMINA2019", "T-PUREPOWER",
                                  "T-STRUCTURE-A", "T-STRUCTURE-E") if H[tid]]
    if H["T-ELN2009"] and st.K <= 2 and "T-FIRSTORDER" not in w_theorems:
        w_theorems.append("T-ELN2009")
    if fam_stratum == "outside-W":
        wres = {"class": "listed (not all in W)", "d_le_1": False, "basis": ["T-FAMILY-F"], "pole_bound": None,
                "pole_bound_basis": None, "pole_bounds": {}}
    elif fam_stratum == "in-W":
        wres = {"class": W_CLASS, "d_le_1": True, "basis": ["T-FAMILY-F"], "pole_bound": 1,
                "pole_bound_basis": "T-FAMILY-F", "pole_bounds": {"T-FAMILY-F": 1}, "main": "T-FAMILY-F"}
    elif w_theorems and fam_stratum != "undetermined":
        pb = dict((tid, W[tid]["pole_bound"]) for tid in w_theorems if W[tid].get("pole_bound") is not None)
        best = min(pb.values()) if pb else None
        order = ["T-EREMENKO", "T-DEMINA2019", "T-CONSERVATIVE", "T-STRUCTURE-A", "T-STRUCTURE-E", "T-PUREPOWER"]
        # for the class prefer a published theorem whose statement was verified and that carries no caveat here
        clean = [t for t in w_theorems if reg.get(t, {}).get("label") == "published"
                 and reg.get(t, {}).get("statement_verified_against_source") is not False and t not in cavs]
        published = [t for t in w_theorems if reg.get(t, {}).get("label") == "published"
                     and reg.get(t, {}).get("statement_verified_against_source") is not False]
        no_cav = [t for t in w_theorems if t not in cavs]
        wres = {"class": W_CLASS, "d_le_1": True, "basis": w_theorems, "pole_bound": best,
                "pole_bound_basis": ([t for t in order if pb.get(t) == best and t not in cavs] or
                                     [t for t in order if pb.get(t) == best] or [None])[0] if pb else None,
                "pole_bounds": pb, "main": (clean or no_cav or published or w_theorems)[0]}

    # ---- (3) assemble
    strata = []
    if st.linear and st.D == 1:
        cls = "entire (linear equation)"
        entire = W["L-LINEAR"].get("solutions", "exponential polynomials")
        use("L-LINEAR")
        text = "The equation is linear with constant coefficients: every solution is entire (a polynomial plus " \
               "polynomials times exponentials)."
        rule("solutions with a pole", "L-LINEAR")
        not_decided.append({"kind": "d", "what": "the number d of a solution",
                            "why": "a sum of exponentials whose rates are not commensurable is not a rational "
                                   "function of one exponential",
                            "partial": "every solution is an explicit exponential polynomial"})
    else:
        if wres is not None:
            pole_bounds = dict(wres["pole_bounds"])
        if H["T-PUREPOWER"] and W["T-PUREPOWER"].get("only_constants"):
            cls, d_le_1, entire = "entire only", True, "constants"
            pole_bound, pole_basis = 0, "T-PUREPOWER"
            use("T-PUREPOWER")
            rule("nonconstant meromorphic solutions (the pole order K/(n-1) = %s is not an integer)" %
                 W["T-PUREPOWER"].get("p"), "T-PUREPOWER")
            text = "Every meromorphic solution is constant: the pole order K/(n-1) = %s is not an integer." % \
                   W["T-PUREPOWER"].get("p")
        elif H["T-NOPOLE"]:
            pole_bound, pole_basis = 0, "T-NOPOLE"
            use("T-NOPOLE")
            rule("meromorphic solutions with a pole", "T-NOPOLE")
            if entire_d1:
                cls, d_le_1 = "entire only", True
                use(entire_basis)
                text = "No meromorphic solution has a pole; the solutions without poles are: %s." % entire
            else:
                cls = "entire (not classified)"
                text = "No meromorphic solution has a pole. No theorem of the registry restricts the entire solutions."
                not_decided.append({"kind": "entire",
                                    "what": "entire solutions other than polynomials and exponential polynomials",
                                    "why": "the top-degree part of the equation is neither a single monomial nor of "
                                           "the form c*w**(n-1)*(w' - rho*w), so T-CLUNIE, T-WV and L-ENTIRE-FACTOR do "
                                           "not apply",
                                    "partial": "every meromorphic solution is entire (T-NOPOLE)"})
            nop_conds = set(conds_of(["T-NOPOLE"]))
            robust = []
            if wres is not None and wres["d_le_1"] and nop_conds:
                robust = [t for t in wres["basis"] if not (set(conds_of([t])) & nop_conds)]
                robust = [t for t in robust if t not in cavs] or robust
            if robust:
                rb = dict((t, wres["pole_bounds"][t]) for t in robust if t in wres["pole_bounds"])
                best = min(rb.values()) if rb else None
                without = {"class": wres["class"], "pole_bound": best,
                           "pole_bound_basis": ([t for t in robust if rb.get(t) == best] or [None])[0] if rb else None,
                           "basis": robust, "conditions": conds_of(robust),
                           "text": "Where a condition of T-NOPOLE fails: every meromorphic solution is still %s%s (%s)." % (
                               W_WORDS, ", with at most %d pole%s in a period" % (best, "" if best == 1 else "s")
                               if best is not None else "", ", ".join(robust))}
                wc = _caveat([robust[0], without["pole_bound_basis"]], cavs)
                if wc:
                    without["text"] += " " + wc
                    without["caveat"] = wc
        elif wres is not None:
            cls, d_le_1 = wres["class"], wres["d_le_1"]
            pole_bound, pole_basis = wres["pole_bound"], wres["pole_bound_basis"]
            use([wres["main"]] if wres.get("main") else wres["basis"])
            if pole_basis:
                use(pole_basis)
            if cls == W_CLASS:
                text = "Every meromorphic solution is %s" % W_WORDS + (
                    ", with at most %d pole%s in a period." % (pole_bound, "" if pole_bound == 1 else "s")
                    if pole_bound is not None else ". No bound on the number of poles in a period is available here.")
                if pole_bound is None:
                    not_decided.append({"kind": "pole-count", "what": "the number of poles in a period",
                                        "why": "the theorems that apply give the class but no numerical bound",
                                        "partial": "all solutions with a given number of poles can be computed"})
            else:
                text = "All meromorphic solutions of this equation are listed in the project's note on the third-order " \
                       "family (Theorem 1). " + W["T-FAMILY-F"].get("stratum_text", "") + \
                       ". They are not all %s." % W_WORDS
        else:
            text = "No theorem of the registry gives the class of all meromorphic solutions of this equation."

        # exclusions that hold with their own conditions
        only_const = H["T-PUREPOWER"] and W["T-PUREPOWER"].get("only_constants")
        if wres is not None and wres["d_le_1"] and not only_const:
            if H["T-NOPOLE"]:
                # only the theorems that hold on a larger set of parameters add information
                if without is not None:
                    use(without["basis"][0], top=False)
                    if without["pole_bound_basis"]:
                        use(without["pole_bound_basis"], top=False)
                    rule("meromorphic solutions that are not %s" % W_WORDS, without["basis"][0])
                    if without["pole_bound"] is not None:
                        b = without["pole_bound"]
                        rule("%s solutions with more than %d pole%s in a period (in the plane, for a rational "
                             "solution)" % (W_WORDS, b, "" if b == 1 else "s"), without["pole_bound_basis"])
            else:
                rule("meromorphic solutions that are not %s" % W_WORDS, wres["main"])
                if wres["pole_bound"] is not None:
                    b = wres["pole_bound"]
                    rule("%s solutions with more than %d pole%s in a period (in the plane, for a rational solution)" % (
                        W_WORDS, b, "" if b == 1 else "s"), wres["pole_bound_basis"])
        top_entire = (cls == "entire only")
        if entire_basis and entire_basis[0] in ("T-CLUNIE", "T-WV"):
            use(entire_basis, top=top_entire)
            rule("nonconstant solutions without poles (entire solutions)" if poly_const else
                 "transcendental entire solutions", entire_basis)
        elif entire_basis and entire_basis[0] == "L-ENTIRE-FACTOR":
            use(entire_basis, top=top_entire)
            ef = W["L-ENTIRE-FACTOR"]
            if candidate is None:
                rule("transcendental meromorphic solutions with finitely many poles (the only candidate, %s, does "
                     "not satisfy the equation)" % ef.get("form"), "L-ENTIRE-FACTOR")
            else:
                rule("transcendental meromorphic solutions with finitely many poles other than %s" % candidate,
                     "L-ENTIRE-FACTOR")
            if poly_const:
                rule("nonconstant polynomial solutions", "L-POLY-PUREPOWER")
        elif entire_basis == ["T-DEMINA2019"]:
            use("T-DEMINA2019", top=top_entire)
            rule("transcendental meromorphic solutions with finitely many poles other than h0 + h1*exp(m*z), "
                 "m = %s" % W["T-DEMINA2019"].get("rate"), "T-DEMINA2019")
        if H["T-CLUNIE"] and not H["T-NOPOLE"]:
            use("T-CLUNIE", top=False)
            rule("transcendental meromorphic solutions with finitely many poles", "T-CLUNIE")
        if H["T-STRUCTURE-B"]:
            use("T-STRUCTURE-B", top=False)
            sol_count = W["T-STRUCTURE-B"].get("max_solutions_up_to_symmetry")
            sol_count_conditions = _factor_conditions(conds_of(["T-STRUCTURE-B"]), st)
            n = W["T-STRUCTURE-B"].get("n")
            rule("more than %s nonconstant meromorphic solution%s up to translation%s (%s)" % (
                sol_count, "" if sol_count == 1 else "s",
                " and multiplication by a root of unity of degree %d" % (n - 1) if n and n > 2 else "",
                W["T-STRUCTURE-B"].get("max_solutions_basis", "")), "T-STRUCTURE-B")
        if H["T-ELN2009"] and st.K >= 3 and cls == "unknown":
            use("T-ELN2009")
            rule("meromorphic solutions with at least one pole that are not %s" % W_WORDS, "T-ELN2009")
            not_decided.append({"kind": "entire", "what": "entire solutions that are not %s" % W_WORDS,
                                "why": "T-ELN2009 covers only solutions with at least one pole",
                                "partial": "every meromorphic solution with a pole is %s" % W_WORDS})

        if cls == "unknown":
            reasons = []
            for tid in ("T-PUREPOWER", "T-EREMENKO", "T-DEMINA2019", "T-STRUCTURE-E"):
                bad = [h for h in R[tid]["hypotheses"] if h["status"] != VERIFIED]
                if bad:
                    reasons.append("%s: %s (%s)" % (tid, bad[0]["key"], bad[0]["how"]))
            partial = []
            if H["T-CLUNIE"]:
                partial.append("a transcendental meromorphic solution has infinitely many poles (T-CLUNIE)")
            elif entire in ("polynomials", "constants"):
                partial.append("the solutions without poles are %s (%s)" % (entire, ", ".join(entire_basis)))
            elif entire_basis and entire_basis[0] == "L-ENTIRE-FACTOR":
                partial.append("the solutions without poles are: %s (L-ENTIRE-FACTOR)" % entire)
            if H["T-FAMILY-F"]:
                partial.append("the equation belongs to the family of T-FAMILY-F, where all meromorphic solutions are "
                               "listed: " + W["T-FAMILY-F"].get("stratum_text", ""))
            not_decided.append({"kind": "class",
                                "what": "whether meromorphic solutions exist that are not %s (d >= 2)" % W_WORDS,
                                "why": "no theorem of the registry applies. " + " | ".join(reasons),
                                "partial": "; ".join(partial) if partial else
                                "only the local data (pole orders, Fuchs indices, compatibility conditions)"})

        if H["T-FAMILY-F"]:
            use("T-FAMILY-F", top=(fam_stratum in ("generic-no-pole", "no-pole")))
            fw = W["T-FAMILY-F"]
            if fam_stratum in ("generic-no-pole", "undetermined"):
                pc = fw.get("pole_condition_expr")
                if fam_stratum == "generic-no-pole":
                    strata.append({"conditions": ["%s != 0" % pc], "class": "entire only",
                                   "basis": ["T-NOPOLE", "T-FAMILY-F"], "text": "no solution has a pole"})
                    strata.append({"conditions": ["%s = 0" % pc, "outside the loci of the entries below"],
                                   "class": W_CLASS, "pole_bound": 1, "basis": ["T-FAMILY-F"],
                                   "text": "every solution with poles is %s and has one pole in a period" % W_WORDS})
                for L in fw.get("loci_outside_W", []):
                    if L["conditions"]:
                        strata.append({"conditions": L["conditions"], "class": "listed (not all in W)",
                                       "basis": ["T-FAMILY-F"], "text": L["kind"]})

    # ---- one meromorphic solution for each Laurent series (T-SERIES-PERIOD), when their number is finite
    n_series = None
    fin = [h for h in R["T-EREMENKO"]["hypotheses"] if h["key"] == "finiteness"]
    if fin and fin[0]["status"] == VERIFIED and not st.linear:
        n_series = W["T-EREMENKO"].get("n_laurent_series")
        if n_series:
            fc = list(fin[0].get("conditions", []))
            ruled_out.append({
                "what": "more than %d meromorphic solution%s with a pole, up to translation (at most one for each "
                        "formal Laurent series)" % (n_series, "" if n_series == 1 else "s"),
                "basis": _basis("T-SERIES-PERIOD", reg, cavs),
                "certificate": {"hypotheses": [{"theorem": "T-SERIES-PERIOD", "key": "finiteness",
                                                "status": fin[0]["status"], "how": fin[0]["how"]}]},
                "conditions": fc, "conditions_factored": _factor_conditions(fc, st)})
            if "T-SERIES-PERIOD" not in used:
                used.append("T-SERIES-PERIOD")

    # ---- caveats of the theorems on which the class statement rests
    cav_top = _caveat(top_used, cavs)
    if cav_top:
        text = text.rstrip() + " " + cav_top

    generic = bool(conditions)
    factored = _factor_conditions(conditions, st)
    if generic:
        short = "; ".join(factored)
        text += " This holds for generic values of the parameters (conditions: %s)." % short
        partial = "on these loci the answer can change; substitute the values and analyse the equation again"
        if strata:
            partial = "for this family the answer on the special loci is given by T-FAMILY-F (see `strata`)"
        elif without is not None:
            partial = without["text"] + (" (conditions: %s)" % "; ".join(_factor_conditions(without["conditions"], st))
                                         if without["conditions"] else " This holds for all parameter values.")
        not_decided.append({"kind": "parameter-locus",
                            "what": "parameter values at which one of the conditions fails: " + short,
                            "why": "the hypotheses were verified for generic parameter values only",
                            "partial": partial})
    class_basis = [t for t in used if t not in ("T-STRUCTURE-B", "T-SERIES-PERIOD")]
    if d_le_1 is True:
        d_ge_2 = {"status": "ruled out for generic parameter values" if generic else "ruled out",
                  "basis": class_basis, "conditions": factored}
    elif d_le_1 is False:
        d_ge_2 = {"status": "occurs", "basis": class_basis, "conditions": []}
    else:
        d_ge_2 = {"status": "not ruled out", "basis": [], "conditions": []}
    return {"class_of_all_meromorphic_solutions": cls,
            "entire_solutions": entire,
            "d_le_1": d_le_1,
            "d_ge_2": d_ge_2,
            "pole_bound": pole_bound, "pole_bound_basis": pole_basis, "pole_bounds": pole_bounds,
            "solution_count": sol_count, "solution_count_conditions": sol_count_conditions,
            "laurent_series_count": n_series,
            "generic": generic, "conditions": conditions, "conditions_factored": factored,
            "without_genericity": without,
            "strata": strata,
            "text": text.strip(),
            "caveats": dict((t, c) for t, c in cavs.items() if t in used),
            "theorems": theorems,
            "used": used,
            "used_labels": dict((tid, _basis(tid, reg, cavs)) for tid in used),
            "also_apply": [tid for tid, _ in CHECKS if H[tid] and tid not in used],
            "ruled_out": ruled_out, "not_decided": not_decided}


