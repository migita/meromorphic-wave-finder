"""mero.report -- assemble the report for one equation (project note section 3).

`analyze(text_or_eq, mode='light'|'heavy', budget_s=..., **options)` calls every available module of the
package, each one optional and time-limited, and returns a JSON-able dict.  The three lists (found, ruled out,
not decided) and the verdict are put together here and nowhere else.

Rules of this module (they are what the site promises):

* "complete" is said only when (a) a decision module for low order says so, or (b) a registry theorem gives the
  class of all meromorphic solutions and a bound on the poles in a period, and the solver has finished every form
  that this class and this bound allow, and the solutions without poles are known, or (c) an earlier record of the
  project with a completeness label contains the equation (then the label of that record is shown);
* with symbolic parameters every statement names its scope: "for generic values of the parameters" comes with the
  list of conditions, and the special loci are analysed separately when they can be reached by substituting a value
  (field `strata`), otherwise they are listed as not decided;
* nothing found is shown unless its substitution check passed.

Pure Python + SymPy: this module runs in the browser.
"""
import importlib
import json
import re
import time
import traceback

import sympy as sp

ENGINE_VERSION = "mero 0.2 (6 October 2026)"
W_CLASSES = ("W\u222arational", "W")
KINDS = ("rational", "simply-periodic", "elliptic")

z = sp.Symbol("z")


# ----------------------------------------------------------------------------------------------- optional modules
def _mod(name):
    """import mero.<name> if it exists and imports cleanly; otherwise None"""
    try:
        return importlib.import_module("mero." + name)
    except Exception:
        return None


class _Timeout(Exception):
    pass


class _SoftTimeout(BaseException):
    """raised inside a step of the light version when the time limit of the step has passed (see _soft_call);
    a BaseException, so that the `except Exception` clauses of the modules let it through to _call"""


_SOFT = {"deadline": None}
_SKIP = [frozenset()]      # labels of the steps that the caller asked to leave out (option `skip_steps`)


# steps that are short as a rule but where a single SymPy call (factor, heuristic gcd, simplify) was seen to run far
# beyond the limit; the garbage collector does not run inside such a call (its allocations balance), so these steps
# are traced from their start (cost: about a factor 2 on steps that normally take a second or two).  "readable
# forms": in the browser mero.pretty has no signal.setitimer, and the step took 53-60 s in three catalogue entries.
_TRACE_FROM_START = ("free coefficients", "readable forms", "copies in the list",
                     "earlier records", "degenerate loci of listed solutions")
# ("ends" and "pole bound" were in this list; since its referee round mero.ends keeps its own deadline)


def _soft_call(fn, args, kwargs, limit, full=False):
    """the light version (no processes): run fn with a cooperative time limit.  A garbage-collector callback
    checks the clock; once the deadline has passed it installs a trace function (called by the interpreter at each
    new Python frame; it returns None, so there is no line tracing) that raises _SoftTimeout.  Before the deadline
    nothing is traced (full=True: the trace function is installed at once).  Nested steps keep the earlier of the
    two deadlines; the trace function that was installed before is restored afterwards."""
    import gc
    import sys
    outer = _SOFT["deadline"]
    deadline = time.monotonic() + float(limit)
    if outer is not None:
        deadline = min(deadline, outer)
    prev = sys.gettrace()
    clock = time.monotonic

    def arm(phase, info):
        if clock() > deadline and sys.gettrace() is not tracer:
            sys.settrace(tracer)
    arm_code = arm.__code__

    def tracer(frame, event, arg):
        if frame.f_code is not arm_code and clock() > deadline:
            raise _SoftTimeout()
        return None
    _SOFT["deadline"] = deadline
    gc.callbacks.append(arm)
    if full:
        sys.settrace(tracer)
    try:
        return fn(*args, **kwargs)
    finally:
        try:
            gc.callbacks.remove(arm)
        except ValueError:
            pass
        sys.settrace(prev)
        _SOFT["deadline"] = outer


def _hard_call(fn, args, kwargs, timeout):
    """run fn(*args, **kwargs) in a forked child with a hard wall-clock limit (heavy version only)"""
    import os
    import pickle
    import select
    import signal
    rfd, wfd = os.pipe()
    pid = os.fork()
    if pid == 0:                                                  # the child
        try:
            os.close(rfd)
            try:
                if os.environ.get("MERO_IN_STEP") != "1":         # a nested step stays in the outer group, so that
                    os.setpgid(0, 0)                              # everything dies with the outer step
                    os.environ["MERO_IN_STEP"] = "1"
            except Exception:
                pass
            try:
                data = pickle.dumps(("ok", fn(*args, **kwargs)), protocol=pickle.HIGHEST_PROTOCOL)
            except BaseException as exc:                          # noqa: reported to the parent
                data = pickle.dumps(("err", "%s: %s" % (type(exc).__name__, str(exc)[:400])))
            with os.fdopen(wfd, "wb") as fh:
                fh.write(data)
        finally:
            os._exit(0)
    os.close(wfd)
    chunks, deadline = [], time.monotonic() + timeout
    try:
        while True:
            left = deadline - time.monotonic()
            if left <= 0:
                raise _Timeout()
            ready, _, _ = select.select([rfd], [], [], min(left, 1.0))
            if ready:
                b = os.read(rfd, 1 << 20)
                if not b:
                    break
                chunks.append(b)
    except _Timeout:
        for sig_target in (os.killpg, os.kill):
            try:
                sig_target(pid, signal.SIGKILL)
            except Exception:
                pass
        try:
            os.waitpid(pid, 0)
        except Exception:
            pass
        os.close(rfd)
        raise
    os.close(rfd)
    try:
        os.waitpid(pid, 0)
    except Exception:
        pass
    try:
        try:
            os.killpg(pid, signal.SIGKILL)                        # anything the child left behind
        except Exception:
            pass
        status, out = pickle.loads(b"".join(chunks))
    except Exception as exc:
        raise RuntimeError("the result of the step could not be read (%s)" % str(exc)[:200])
    if status == "err":
        raise RuntimeError(out)
    return out


def _call(ctx, label, fn, *args, **kwargs):
    """run fn; never raise; record time and failures in the log.  In the heavy version every step runs in a
    child process with a hard time limit (`_timeout` seconds, default: what is left of the budget, at most 90)."""
    log = ctx["log"]
    cap = kwargs.pop("_timeout", None)
    soft = kwargs.pop("_soft", False)
    least = kwargs.pop("_min", 2.0)          # seconds this step gets even when the budget of the analysis is used up
    if ctx.get("progress"):
        try:
            ctx["progress"]("step: " + label)
        except Exception:
            pass
    if label in _SKIP[0]:
        log.append("%s: skipped (it did not end within the time limit in an earlier attempt of this analysis)"
                   % label)
        ctx["timeouts"].append(label)
        return None
    t0 = time.monotonic()
    left = ctx["budget_s"] - (t0 - ctx["t0"])
    soft_limits = not ctx.get("hard") and ctx.get("soft_limits", True)
    if (ctx.get("hard") or soft_limits) and left < 1.0 and label not in (
            "earlier records", "normal form", "readable forms", "copies in the list",
            "copies in the list: second look", "degenerate loci of listed solutions",
            "ruled-out items against the lists"):
        log.append("%s: skipped (time limit of the analysis reached)" % label)
        ctx["timeouts"].append(label)
        return None
    try:
        if ctx.get("hard") and not soft:
            limit = max(float(least), min(cap if cap else 90.0, left + 3.0))
            try:
                out = _hard_call(fn, args, kwargs, limit)
            except _Timeout:
                log.append("%s: stopped at its time limit (%.0f s)" % (label, limit))
                ctx["timeouts"].append(label)
                return None
        elif soft_limits and not soft:
            limit = max(min(float(least), 5.0), min(cap if cap else 90.0, left + 3.0))
            try:
                out = _soft_call(fn, args, kwargs, limit, full=label in _TRACE_FROM_START)
            except _SoftTimeout:
                log.append("%s: stopped at its time limit (%.0f s)" % (label, limit))
                ctx["timeouts"].append(label)
                return None
        else:
            out = fn(*args, **kwargs)
        log.append("%s: %.2f s" % (label, time.monotonic() - t0))
        return out
    except Exception as exc:                                    # a module failure is reported, not hidden
        log.append("%s: FAILED after %.2f s: %s: %s" % (label, time.monotonic() - t0, type(exc).__name__,
                                                          str(exc)[:300]))
        tb = traceback.format_exc(limit=4).strip().splitlines()
        log.append("  " + " | ".join(t.strip() for t in tb[-4:])[:500])
        ctx["failures"].append(label)
        return None


def _light(ctx, heavy_value, frac, least=3.0):
    """a time cap: heavy_value in the heavy version; frac * budget (at least `least` seconds) in the light version"""
    if ctx.get("hard"):
        return heavy_value
    return max(least, frac * ctx["budget_s"])


def _left(ctx, reserve=0.0):
    return max(1.0, ctx["budget_s"] - (time.monotonic() - ctx["t0"]) - reserve)


# ----------------------------------------------------------------------------------------------- fallback parser
_PRIME = re.compile(r"\b([A-Za-z])\s*('+)")


def _fallback_parse(text, unknown=None):
    """A very small parser used only when mero.parse is not available: primes and jets, '^', one '='."""
    from mero.bootstrap import Equation
    s = text.replace("\u2212", "-").replace("^", "**").replace("\u2032", "'").replace("\u2033", "''")
    if "=" in s:
        lhs, rhs = s.split("=", 1)
        s = "(%s) - (%s)" % (lhs, rhs)
    if unknown is None:
        m = _PRIME.search(s)
        unknown = m.group(1) if m else "w"
    s = _PRIME.sub(lambda m: "%s%d" % (m.group(1), len(m.group(2))) if m.group(1) == unknown else m.group(0), s)
    s = re.sub(r"\b%s\b(?!\d)" % unknown, unknown + "0", s)
    s = re.sub(r"\b%s(\d+)\b" % unknown, r"w\1", s)
    s = re.sub(r"(\d)\s*([A-Za-z(])", r"\1*\2", s)
    order = max([int(k) for k in re.findall(r"\bw(\d+)\b", s)] or [0])
    jets = sp.symbols("w0:%d" % (order + 1))
    loc = dict((str(j), j) for j in jets)
    for name in set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", s)):          # every other name is a parameter
        if name not in loc and name not in ("sqrt", "I", "pi", "Rational"):
            loc[name] = sp.Symbol(name)
    expr = sp.expand(sp.sympify(s, locals=loc))
    params = sorted(expr.free_symbols - set(jets), key=str)
    poly = sp.Poly(expr, jets[order])
    if poly.degree() != 1 or (poly.LC().free_symbols & set(jets)):
        raise ValueError("unsupported by the fallback parser: the equation is not solved for the highest derivative")
    rhs = sp.expand(-poly.coeff_monomial(1) / poly.LC())
    eq = Equation(order, rhs, [str(q) for q in params])
    eq.unknown, eq.var = unknown, "z"
    return eq


# ----------------------------------------------------------------------------------------------- small helpers
def _s(e):
    return sp.sstr(e) if not isinstance(e, str) else e


def _E(eq):
    E = getattr(eq, "E", None)
    if E is None:
        E = eq.w[eq.K] - eq.rhs
    return E


def _fresh(eq, base="q"):
    """a symbol name that is neither a parameter nor a jet of the equation"""
    used = set(str(s) for s in _E(eq).free_symbols) | set(str(p) for p in eq.params)
    name, i = base, 0
    while name in used:
        i += 1
        name = "%s%d" % (base, i)
    return sp.Symbol(name)


def _jet_latex(eq, expr):
    name = getattr(eq, "unknown", "w")
    rep = {}
    for j, wj in enumerate(eq.w):
        if j == 0:
            rep[wj] = sp.Symbol(name)
        elif j <= 3:
            rep[wj] = sp.Symbol(name + "'" * j)
        else:
            rep[wj] = sp.Symbol("%s^{(%d)}" % (name, j))
    return sp.latex(expr.subs(rep))


def _equation_block(eq):
    E = _E(eq)
    solved = getattr(eq, "solved", True)
    ltx = None
    if hasattr(eq, "latex"):
        try:
            ltx = eq.latex()
        except Exception:
            ltx = None
    if ltx is None:
        if solved and getattr(eq, "rhs", None) is not None:
            ltx = _jet_latex(eq, eq.w[eq.K]) + " = " + _jet_latex(eq, eq.rhs)
        else:
            ltx = _jet_latex(eq, E) + " = 0"
    deg = getattr(eq, "degree", None)
    if deg is None:
        deg = max(sum(m) for m in eq.terms)
    return {"order": eq.K, "degree": int(deg), "solved": bool(solved), "sympy": _s(sp.expand(E)), "latex": ltx,
            "params": [str(q) for q in eq.params], "unknown": getattr(eq, "unknown", "w"),
            "var": getattr(eq, "var", "z")}


def _bootstrap_local(eq, budget_s=20):
    """local analysis with the reference implementation (used only if mero.laurent is missing)"""
    from mero import bootstrap as B
    out = {"balances": [], "non_integer_balances": [], "finiteness": None, "no_pole_possible": None, "strata": [],
           "note": "reference implementation"}
    if not getattr(eq, "solved", True):
        return out
    for b in B.balances(eq):
        for a0 in b["a0"]:
            kk = sp.Symbol("k")
            ind = B.indicial(eq, b["p"], a0, kk)
            roots = sp.roots(sp.Poly(sp.numer(sp.together(ind)), kk))
            pos = sorted(int(r) for r in roots if r.is_integer and r > 0)
            L = B.laurent(eq, b["p"], a0, max((max(pos) if pos else 0) + 2, b["p"] + 2))
            fail = [k for k, v in L["conditions"].items() if v != 0]
            count = "0" if fail else ("family: %d free coefficient(s)" % len(L["free"]) if L["free"] else "finite: 1")
            out["balances"].append({"p": b["p"], "a0": _s(a0), "weight": b["W"], "indicial": _s(ind),
                                    "indices": [_s(r) for r in roots], "positive_integer_indices": pos,
                                    "coeffs": [_s(c) for c in L["coeffs"]],
                                    "free": dict((str(k), str(v)) for k, v in L["free"].items()),
                                    "conditions": dict((str(k), _s(v)) for k, v in L["conditions"].items()),
                                    "series_count": count})
    return out


def _constants(eq):
    """constant solutions: the roots of E(q, 0, ..., 0)"""
    q = _fresh(eq, "q")
    e0 = sp.expand(_E(eq).subs(dict((wj, 0) for wj in eq.w[1:])).subs(eq.w[0], q))
    if e0 == 0:
        return {"all": True, "symbol": str(q)}
    if q not in e0.free_symbols:
        return {"all": False, "none": True, "poly": _s(e0), "symbol": str(q)}
    P = sp.Poly(e0, q)
    roots = []
    if len(P.terms()) == 1:                        # c*q**k: the only constant solution is 0
        return {"all": False, "poly": _s(P.as_expr()), "poly_latex": sp.latex(P.as_expr()), "degree": P.degree(),
                "symbol": str(q), "roots": ["0"], "roots_latex": ["0"]}
    if P.degree() <= 2:
        try:
            roots = [sp.simplify(r) for r in sp.roots(P, multiple=True)]
        except Exception:
            roots = []
    return {"all": False, "poly": _s(P.as_expr()), "poly_latex": sp.latex(P.as_expr()), "degree": P.degree(),
            "symbol": str(q), "roots": [_s(r) for r in roots], "roots_latex": [sp.latex(r) for r in roots]}


def _constants_identically(eq):
    """parameter values at which every constant is a solution: E(q, 0, ..., 0) vanishes identically in q there.
    -> found items "w = q, q free" with these values as conditions; [] if a coefficient of the polynomial in q is
    a nonzero number"""
    q = _fresh(eq, "q")
    e0 = sp.expand(_E(eq).subs(dict((wj, 0) for wj in eq.w[1:])).subs(eq.w[0], q))
    if e0 == 0:
        return []
    coeffs = [c for c in (sp.Poly(e0, q).coeffs() if q in e0.free_symbols else [e0]) if c != 0]
    if not coeffs or any(not c.free_symbols for c in coeffs):
        return []
    pset = set(eq.params)
    used = sorted(set().union(*[c.free_symbols for c in coeffs]), key=str)
    if not set(used) <= pset:
        return []

    def deg(sym):
        try:
            return max(sp.Poly(c, sym).degree() for c in coeffs if sym in c.free_symbols)
        except Exception:
            return 99
    used.sort(key=lambda sym: (deg(sym), str(sym)))
    brs = []
    for unknowns in (used[:len(coeffs)], used):   # as many unknowns as equations, of lowest degree; then all
        try:
            brs = sp.solve(coeffs, unknowns, dict=True)
        except Exception:
            brs = []
        if brs:
            break
    out, seen = [], set()
    for br in brs[:8]:
        if not br or any(v.free_symbols - pset for v in br.values()):
            continue
        try:
            if sp.expand(e0.subs(br)) != 0:
                continue
        except Exception:
            continue
        conds = sorted("%s == %s" % (k, _s(v)) for k, v in br.items())
        if tuple(conds) in seen:
            continue
        seen.add(tuple(conds))
        out.append({"id": "constq%d" % (len(out) + 1), "kind": "constant", "d": 0, "expr": str(q),
                    "latex": sp.latex(q), "free": [str(q)], "constants": {str(q): "free"}, "conditions": conds,
                    "note": "on these parameter values every constant is a solution",
                    "certificate": {"type": "substitution", "method": "symbolic", "status": "pass",
                                    "detail": "E(%s, 0, ..., 0) vanishes identically when %s"
                                              % (q, " and ".join(conds))},
                    "origin": "live:constants-locus"})
    return out


def _const_items(consts):
    cert = {"type": "substitution", "method": "symbolic", "status": "pass"}
    if consts.get("all"):
        return [{"id": "const", "kind": "constant", "d": 0, "expr": consts["symbol"], "latex": consts["symbol"],
                 "free": [consts["symbol"]], "conditions": [], "note": "every constant is a solution",
                 "certificate": dict(cert, detail="E(q, 0, ..., 0) vanishes identically"),
                 "origin": "live:constants"}]
    if consts.get("none"):
        return []
    if consts.get("roots"):
        return [{"id": "const%d" % (i + 1), "kind": "constant", "d": 0, "expr": r, "latex": consts["roots_latex"][i],
                 "free": [], "conditions": [],
                 "certificate": dict(cert, detail="root of E(%s, 0, ..., 0) = %s" % (consts["symbol"], consts["poly"])),
                 "origin": "live:constants"} for i, r in enumerate(consts["roots"])]
    if consts.get("degree", 0) > 2:
        return [{"id": "const", "kind": "constant", "d": 0,
                 "expr": "RootOf(%s, %s)" % (consts["poly"], consts["symbol"]),
                 "latex": "%s:\\quad %s = 0" % (consts["symbol"], consts.get("poly_latex", "")),
                 "free": [], "conditions": [],
                 "note": "the constant solutions are the roots of this polynomial",
                 "certificate": dict(cert, detail="E(%s, 0, ..., 0) = %s" % (consts["symbol"], consts["poly"])),
                 "origin": "live:constants"}]
    return []


def _add_found(report, sol, origin=None):
    if not isinstance(sol, dict):
        return
    cert = sol.get("certificate") or {}
    status = cert.get("status")
    if status in ("fail", "FAIL"):
        report["rejected"].append({"expr": sol.get("expr"), "why": "substitution check failed",
                                   "origin": sol.get("origin") or origin})
        return
    if status != "pass":
        cand = dict(sol)
        cand["why"] = "the substitution check did not run (%s)" % status
        if origin and not cand.get("origin"):
            cand["origin"] = origin
        report.setdefault("candidates", []).append(cand)
        return
    sol = dict(sol)
    sol["conditions"] = _tidy_conditions(sol.get("conditions"))
    sol = _std_roots(sol, (report.get("equation") or {}).get("params") or [])
    sol = _unclash(sol, (report.get("equation") or {}).get("params") or [])
    key = _sol_key(sol)
    for old in report["found"]:
        if _sol_key(old) == key:
            return
    if origin and not sol.get("origin"):
        sol["origin"] = origin
    if "id" not in sol or any(o.get("id") == sol["id"] for o in report["found"]):
        sol["id"] = "s%d" % (len(report["found"]) + 1)
    report["found"].append(sol)


_ROOT_OF = re.compile(r"^\s*(?:(?:any|a|each|every|the)\s+)?root of (.+?)(?:\s*=\s*0)?\s*$")


def _std_roots(sol, param_names):
    """A constant given as a root of a polynomial is written "any root of P(name) = 0" with P in the constant's own
    name (a polynomial written in a variable of its own is rewritten); constants that share a polynomial are the
    distinct roots, which the note says.  Texts that cannot be read are left as they are."""
    consts = sol.get("constants")
    if not isinstance(consts, dict) or not any("root of" in str(v) for v in consts.values()):
        return sol
    known = set(str(q) for q in param_names) | set(str(k) for k in consts) | set(str(f) for f in sol.get("free") or [])
    try:
        known |= set(str(x) for x in sp.sympify(str(sol.get("expr")), locals=_locals_for(known)).free_symbols)
    except Exception:
        pass
    out, share = dict(consts), {}
    for name, val in consts.items():
        m = _ROOT_OF.match(str(val))
        if not m:
            continue
        try:
            names = set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", m.group(1)))
            pol = sp.sympify(m.group(1), locals=_locals_for(names | known))
            me = sp.Symbol(str(name))
            if me not in pol.free_symbols:
                own = [x for x in pol.free_symbols if str(x) not in known]
                if len(own) != 1:
                    continue
                share.setdefault(sp.sstr(pol), []).append(str(name))
                pol = pol.subs(own[0], me)
            out[name] = "any root of %s = 0" % sp.sstr(pol)
        except Exception:
            continue
    if out == consts:
        return sol
    sol = dict(sol)
    sol["constants"] = out
    several = [v for v in share.values() if len(v) > 1]
    if several:
        note = "; ".join("%s are distinct roots of the same polynomial" % ", ".join(v) for v in several)
        sol["note"] = ("%s; %s" % (sol["note"], note)) if sol.get("note") else note
    return sol


def _locals_for(names):
    return dict((str(n), sp.Symbol(str(n))) for n in names)


def _unclash(sol, param_names):
    """A solution found on a locus where a parameter is fixed (`p == value`) was computed for the equation without
    that parameter, and one of its auxiliary constants may carry the parameter's name.  The constant is renamed
    (`p_`), so that the letter in the formula cannot be read as the parameter."""
    consts = sol.get("constants") or {}
    names = set(str(q) for q in param_names)
    clash = [k for k in consts if str(k) in names]
    if not clash:
        return sol
    fixed = set()
    for c in sol.get("conditions") or []:
        m = re.match(r"^\s*([A-Za-z_][A-Za-z_0-9]*)\s*==", str(c))
        if m:
            fixed.add(m.group(1))
    if not all(str(k) in fixed for k in clash):
        return sol
    out = dict(sol)
    for k in clash:
        new = str(k) + "_"
        while new in names or new in consts:
            new += "_"
        rx = re.compile(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(str(k)))
        if isinstance(out.get("expr"), str):
            out["expr"] = rx.sub(new, out["expr"])
        out["constants"] = dict(((new if str(kk) == str(k) else kk), (rx.sub(new, vv) if isinstance(vv, str) else vv))
                                for kk, vv in (out.get("constants") or {}).items())
        out["free"] = [new if str(f_) == str(k) else f_ for f_ in out.get("free") or []]
        if isinstance(out.get("relations"), list):
            out["relations"] = [rx.sub(new, r_) if isinstance(r_, str) else r_ for r_ in out["relations"]]
        out.pop("latex", None)                 # written for the old name; the readable form is made again later
    return out


def _tidy_conditions(conds):
    """the list of conditions without repetitions; a condition `monomial != 0` is written with its base"""
    out = []
    for c in conds or []:
        c = str(c).strip()
        m = re.match(r"^-?\s*([A-Za-z_][A-Za-z_0-9]*)(?:\*\*\d+)?(?:\s*/\s*\d+)?\s*!=\s*0$", c)
        if m:
            c = "%s != 0" % m.group(1)
        if c and c not in out:
            out.append(c)
    return out


def _norm_cond(c):
    c = str(c)
    if len(c) > 160:
        return c.replace(" ", "")
    try:
        for op in ("==", "!="):
            if op in c:
                a, b = c.split(op, 1)
                names = set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", c)) - {"sqrt", "I", "pi", "exp"}
                loc = dict((n, sp.Symbol(n)) for n in names)
                e = sp.factor(sp.sympify(a, locals=loc) - sp.sympify(b, locals=loc))
                num = sp.numer(sp.together(e))
                if num.could_extract_minus_sign():
                    num = -num
                co = sp.Poly(num, *sorted(num.free_symbols, key=str)).LC() if num.free_symbols else 1
                return op + sp.sstr(sp.expand(num / co))
    except Exception:
        pass
    return c.replace(" ", "")


def _combine_order2(dA, dB, same=None):
    """Two independent decision procedures for A(w) w'' + B(w) w'^2 + C(w) = 0 (mero.order2, mero.order2b).
    The answer says "complete" only if the second one does and if the first one, when it also says "complete",
    lists the same numbers of families of each kind; otherwise the union of the two lists is shown at the level
    "partial"."""
    def level(d):
        return ((d or {}).get("verdict") or {}).get("level")

    def kinds(d):
        out = {}
        for x in (d or {}).get("found") or []:
            if x.get("kind") != "constant":
                out[x.get("kind")] = out.get(x.get("kind"), 0) + 1
        return out
    warn = False
    lvA, lvB = level(dA), level(dB)
    if dA is None:
        if warn and lvB == "complete":
            dB = dict(dB, verdict=dict(dB["verdict"], level="partial", text=dB["verdict"].get("text", "") +
                                       " (The first integral has a multiple root for every level; the special "
                                       "levels were not all examined, so completeness is not claimed.)"))
        return dB
    agree = kinds(dA) == kinds(dB) or same is True   # same: the two lists are the same set of functions (dedupe)
    if lvB == "complete" and not warn and (lvA != "complete" or agree):
        out = dict(dB)
        if lvA == "complete":
            out["basis"] = list(dict.fromkeys(list(dB.get("basis") or []) + list(dA.get("basis") or [])))
            out["verdict"] = dict(dB["verdict"], text=dB["verdict"].get("text", "") +
                                  " (Two independent procedures give the same list.)")
            return out
        # the second procedure states its list for generic parameter values; families that the first one found on
        # special parameter values are kept, and those values are named
        keys = set(_sol_key(x) for x in out.get("found") or [])
        extra, loci = [], []
        for x in dA.get("found") or []:
            eqs = [str(c) for c in x.get("conditions") or [] if "==" in str(c)]
            if x.get("kind") == "constant" or not eqs or _sol_key(x) in keys or \
                    (x.get("certificate") or {}).get("status") != "pass":
                continue
            extra.append(x)
            if eqs not in loci:
                loci.append(eqs)
        if extra:
            out["found"] = list(out.get("found") or []) + extra
            nd = list(out.get("not_decided") or [])
            sc0 = (dB.get("verdict") or {}).get("scope")
            named = set()                       # loci that the second procedure names itself (explored or not)
            for c in ((sc0.get("explored_strata") or []) if isinstance(sc0, dict) else []):
                for part in str(c).split(" and "):
                    named.add(_norm_cond(part))
            for it0 in nd:
                for c in _item_conditions(it0):
                    named.add(_norm_cond(c))
            for eqs in loci:
                if all(_norm_cond(c) in named for c in eqs):
                    continue
                nd.append({"what": "parameter values with %s" % " and ".join(eqs), "kind": "parameter-locus",
                           "conditions": list(eqs),
                           "why": "the list is stated for generic parameter values; on these values the first of the "
                                  "two procedures found the solutions that are listed with these conditions, and "
                                  "nothing more was established there",
                           "partial": "the solutions listed with these conditions"})
            out["not_decided"] = nd
            sc = (dB.get("verdict") or {}).get("scope")
            generic = isinstance(sc, dict) and str(sc.get("parameters", "")).startswith("generic") or \
                (isinstance(sc, str) and sc.startswith("generic"))
            if not generic:
                out["verdict"] = dict(dB["verdict"], level="partial", text=dB["verdict"].get("text", "") +
                                      " (A second procedure found further solutions on special parameter values; "
                                      "completeness is not claimed.)")
        return out
    found = list(dB.get("found") or [])
    keys = set(_sol_key(x) for x in found)
    for x in dA.get("found") or []:
        if _sol_key(x) not in keys:
            found.append(x)
    nd = list(dB.get("not_decided") or []) + [x for x in (dA.get("not_decided") or [])
                                               if x not in (dB.get("not_decided") or [])]
    nd.append({"what": "whether the list is complete",
               "why": "two independent procedures for equations of this shape (the first integral in w'^2) were run "
                      "and do not give the same complete list (%s: %s; %s: %s); the union is shown"
                      % ("first", lvA, "second", lvB + (" with a warning" if warn else "")),
               "partial": "every listed solution passed its substitution check"})
    return {"applies": True, "found": found, "ruled_out": [], "not_decided": nd,
            "verdict": {"level": "partial",
                        "text": "The solutions listed were obtained from the first integral in w'^2 by two "
                                "independent procedures, which do not agree on the complete list; the union is "
                                "shown and completeness is not claimed.",
                        "basis": list(dict.fromkeys(list(dB.get("basis") or []) + list(dA.get("basis") or [])))},
            "basis": list(dict.fromkeys(list(dB.get("basis") or []) + list(dA.get("basis") or []))),
            "first_integral": dB.get("first_integral"), "module": "mero.order2 + mero.order2b"}


def _hard_numbers(eq):
    """True if a coefficient of the equation contains an algebraic number beyond square roots of rationals and i
    (a nested radical, a cube root, a root of a polynomial): the exact arithmetic of the decision modules for
    orders one and two is then not guaranteed"""
    try:
        for co in eq.terms.values():
            co = sp.sympify(co)
            if co.has(sp.CRootOf):
                return True
            for a in co.atoms(sp.Pow):
                ex = a.exp
                if ex.is_Rational and not ex.is_Integer:
                    if ex.q != 2 or not a.base.is_Rational:
                        if not a.base.free_symbols:          # a number: nested radical or higher root
                            return True
        return False
    except Exception:
        return False


def _item_conditions(it):
    """the conditions of a not-decided item, as a list of strings (from the field or from the sentence)"""
    cs = it.get("conditions")
    if cs:
        return [str(c) for c in cs]
    w = str(it.get("what", ""))
    m = re.search(r"(?:stratum|locus)\s+(.*)$", w)
    if not m:
        return []
    out = []
    for part in re.split(r"\s+and\s+|,\s+(?=[^()]*(?:==|!=))", m.group(1)):
        part = re.sub(r"\s*\(inside .*$", "", part.strip())
        if "==" in part or "!=" in part:
            out.append(part)
    return out


def _is_special_locus(it):
    """a not-decided item that concerns only a proper closed subset of the parameter space"""
    cs = it.get("conditions")
    if cs:
        return any("==" in str(c) for c in cs)
    w = str(it.get("what", ""))
    # the strata of a decision tree are enumerated generic stratum first: what an interrupted enumeration leaves
    # out are special strata
    return "==" in w or w.startswith("further special strata")


def _generic_upgrade(decided, symbolic):
    """A decision module (order one or two) answers "partial" as soon as one parameter stratum is left open.  If
    every open item is a special locus (it carries an equality between the parameters), the module's lists are
    complete for all other parameter values: the verdict is then "complete" with the scope "generic parameter
    values", and the open loci stay in the list of what is not decided."""
    v = (decided or {}).get("verdict") or {}
    if not symbolic or v.get("level") != "partial" or not decided.get("applies"):
        return decided
    if str(decided.get("module", "")).startswith("mero.order2 +"):
        return decided
    nd = decided.get("not_decided") or []
    if not nd or not all(_is_special_locus(it) for it in nd):
        return decided
    if not any(x.get("certificate", {}).get("status") == "pass" for x in decided.get("found") or []) and \
            not decided.get("ruled_out"):
        return decided
    out = dict(decided)
    out["not_decided"] = [dict(it, kind=it.get("kind") or "parameter-locus") for it in nd]
    n_open = len([it for it in nd if not it.get("degenerate")])
    text = "For generic values of the parameters every meromorphic solution is listed"
    if len(decided.get("strata") or []) > 1:
        text += " (on each of the parameter strata shown, generic stratum first)"
    text += ". Not analysed: %s." % (
        "the special parameter values listed under 'not decided'" if n_open else
        "the parameter values at which the equation loses order or degree")
    out["verdict"] = dict(v, level="complete", text=text, scope="generic parameter values", generic_upgrade=True)
    return out


def _cond_holds(c, pt, loc):
    c = str(c)
    if " or " in c:
        parts = [_cond_holds(x, pt, loc) for x in c.split(" or ")]
        if any(x is True for x in parts):
            return True
        return None if any(x is None for x in parts) else False
    op = "==" if "==" in c else ("!=" if "!=" in c else None)
    if op is None:
        return None
    a, b = c.split(op, 1)
    try:
        va = complex(sp.N(sp.sympify(a, locals=loc).subs(pt), 30))
        vb = complex(sp.N(sp.sympify(b, locals=loc).subs(pt), 30))
    except Exception:
        return None
    small = abs(va - vb) <= 1e-9 * (1.0 + abs(va) + abs(vb))
    return small if op == "==" else (not small)


def _match_open_strata(sols, items, params):
    """for each solution (conditions on the parameters), the indices of the open strata on which it lies; decided
    at a random numeric point of the solution's parameter locus"""
    import random
    rnd = random.Random(20261006)
    loc = dict((str(q), q) for q in params)
    out = []
    for sol in sols:
        conds = [str(c) for c in sol.get("conditions") or []]
        eqs = [c for c in conds if "==" in c]
        hits = []
        if eqs:
            for _try in range(2):
                pt = _locus_point(conds, params, rnd)
                if pt is None:
                    break
                for i, it in enumerate(items):
                    cs = _item_conditions(it)
                    if cs and all(_cond_holds(c, pt, loc) is True for c in cs) and i not in hits:
                        hits.append(i)
        out.append(hits)
    return out


def _supplement_open_strata(report, eq, local, ctx, mode, budget_s, decided):
    """direct search (one pole in a period) on the parameter strata that a decision module left open: the solutions
    found there are listed with their conditions; nothing is concluded about completeness on those strata"""
    items = [it for it in report["not_decided"] if it.get("_src") == "low_order" and _is_special_locus(it)
             and not it.get("degenerate") and _item_conditions(it)]
    wsolve = _mod("wsolve")
    if not items or wsolve is None or not hasattr(wsolve, "find_w_solutions") or not (local.get("balances") or []):
        return
    b = max(5.0, min(_left(ctx) / 3.0, 60.0 if mode == "heavy" else 10.0))
    kw = {}
    if mode == "heavy":
        kw["limits"] = {"MAX_FACTOR_TERMS": 600, "MAX_FACTOR_DEGREE": 30, "MAX_STATE_TERMS": 6000,
                        "MAX_EQ_TERMS": 1500, "MAX_SUBST_COST": 1000000, "MAX_VALUE_OPS": 800,
                        "MAX_VERIFY_CHARS": 12000}
    kw["reserved_names"] = list(ctx.get("reserved_names") or [])
    ws = _call(ctx, "direct search on the open parameter strata", wsolve.find_w_solutions, eq, local,
               max_poles=1, budget_s=b, _timeout=2.5 * b + 30.0, **kw)
    if not ws:
        return
    sols = [x for x in ws.get("solutions", []) or []
            if isinstance(x, dict) and x.get("kind") != "constant"
            and (x.get("certificate") or {}).get("status") == "pass"
            and any("==" in str(c) for c in x.get("conditions") or [])]
    if not sols:
        return
    hits = _call(ctx, "open parameter strata: which solutions lie on them", _match_open_strata, sols, items,
                 list(eq.params), _timeout=40.0)
    if not hits:
        return
    added = {}
    for sol, hs in zip(sols, hits):
        if not hs:
            continue
        sol = dict(sol)
        note = "found by a direct search on parameter values that the decision procedure did not analyse"
        sol["note"] = (str(sol["note"]) + "; " + note) if sol.get("note") else note
        n0 = len(report["found"])
        _add_found(report, sol, "live:wsolve")
        if len(report["found"]) > n0:
            for i in hs:
                added.setdefault(i, []).append(report["found"][-1]["id"])
    if not added:
        return
    for i, ids in added.items():
        it = items[i]
        it["partial"] = "solutions with one pole in a period found on these parameter values by a direct search: " \
            + ", ".join(ids) + " (the list there is not claimed complete)"
    v = decided.get("verdict") or {}
    v["text"] = str(v.get("text", "")).rstrip() + " On the parameter values that were not analysed, the solutions " \
        "found by a direct search (one pole in a period) are listed with their conditions."
    v["supplement"] = sum(len(x) for x in added.values())


_CANON = {}


def _canon_conds(conds):
    """the conditions of an item in a normal form that does not depend on how its parameter values are described:
    equalities `name == expression` are substituted into the other conditions (repeatedly), trivial conditions are
    dropped, the rest is normalised by _norm_cond"""
    raw = tuple(str(c) for c in conds or [])
    if raw in _CANON:
        return _CANON[raw]
    out = sorted(_norm_cond(c) for c in raw)
    try:
        if len([c for c in raw if "==" in c]) >= 2 and all(len(c) <= 200 for c in raw):
            names = set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", " ".join(raw))) - {"sqrt", "I", "pi", "exp"}
            loc = dict((n, sp.Symbol(n)) for n in names)
            vals = {}
            for c in raw:
                m = re.match(r"^\s*([A-Za-z_][A-Za-z_0-9]*)\s*==\s*(.+)$", c)
                if m and m.group(1) in loc and loc[m.group(1)] not in vals:
                    v = sp.sympify(m.group(2), locals=loc)
                    if loc[m.group(1)] not in v.free_symbols:
                        vals[loc[m.group(1)]] = v
            for _ in range(6):                      # resolve values that contain other fixed names
                new = dict((k, sp.cancel(v.subs(vals))) for k, v in vals.items())
                if any(k in v.free_symbols for k, v in new.items()):
                    new = None
                    break
                if new == vals:
                    break
                vals = new
            if new is not None and vals:
                res = ["==" + sp.sstr(sp.expand(k - v)) for k, v in vals.items()]
                ok = True
                for c in raw:
                    op = "==" if "==" in c else ("!=" if "!=" in c else None)
                    if op is None:
                        res.append(c.replace(" ", ""))
                        continue
                    a, b = c.split(op, 1)
                    e = sp.cancel((sp.sympify(a, locals=loc) - sp.sympify(b, locals=loc)).subs(vals))
                    if e == 0:
                        if op == "!=":
                            ok = False              # an inequality that fails: leave the item as it is
                        continue
                    if not e.free_symbols:
                        if op == "==":
                            ok = False
                        continue
                    num = sp.numer(sp.together(e))
                    res.append(_norm_cond("%s %s 0" % (sp.sstr(num), op)))
                if ok:
                    out = sorted(set(res))
    except Exception:
        pass
    _CANON[raw] = out
    if len(_CANON) > 5000:
        _CANON.clear()
    return out


def _sol_key(sol):
    conds = _canon_conds(sol.get("conditions") or [])
    consts = sol.get("constants") or {}
    return (sol.get("kind"), str(sol.get("expr")).replace(" ", ""),
            json.dumps(dict((str(k), str(v)) for k, v in consts.items()), sort_keys=True), tuple(conds))


def _add_item(report, key, item, src=None):
    if isinstance(item, str):
        item = {"what": item}
    if not isinstance(item, dict):
        return
    sig = (item.get("what"), json.dumps(item.get("conditions"), sort_keys=True, default=str))
    for old in report[key]:
        if (old.get("what"), json.dumps(old.get("conditions"), sort_keys=True, default=str)) == sig:
            return
    if src:
        item = dict(item, _src=src)
    report[key].append(item)


def _merge_lists(report, part, origin=None, src=None):
    for sol in part.get("found", []) or []:
        _add_found(report, sol, origin)
    for key in ("ruled_out", "not_decided"):
        for item in part.get(key, []) or []:
            _add_item(report, key, item, src)


# ----------------------------------------------------------------------------------------------- the report
def analyze(text_or_eq, mode="light", budget_s=30, **options):
    t_start = time.monotonic()
    log, warnings = [], []
    hard = bool(options.get("hard", mode == "heavy"))
    if hard:
        try:
            import os
            hard = hasattr(os, "fork")
        except Exception:
            hard = False
    _FAST_ONLY[0] = not hard
    ctx = {"log": log, "t0": t_start, "budget_s": float(budget_s), "failures": [], "timeouts": [], "hard": hard,
           "progress": None if hard else options.get("progress"),
           "soft_limits": bool(options.get("soft_limits", True))}
    depth = int(options.get("_depth", 0))
    if depth == 0:
        _SKIP[0] = frozenset(str(x) for x in (options.get("skip_steps") or ()))
        if _SKIP[0]:
            warnings.append("left out, because it did not end within the time limit in an earlier attempt: %s; "
                            "the answer may be weaker than the one of the full analysis"
                            % "; ".join(sorted(_SKIP[0])))
    # with a long budget (heavy version) the fixed time caps of the early steps grow in proportion
    ctx["scale"] = min(6.0, max(1.0, float(budget_s) / 300.0)) if (hard and mode == "heavy" and depth == 0) else 1.0
    report = {"schema": "mero-report/1", "engine": ENGINE_VERSION, "mode": mode,
              "input": {"text": text_or_eq if isinstance(text_or_eq, str) else None, "kind": "ode"},
              "found": [], "ruled_out": [], "not_decided": [], "theorems": [], "classes": [], "rejected": [],
              "warnings": warnings, "log": log}

    # 1. the equation ----------------------------------------------------------------------------------------
    if isinstance(text_or_eq, str):
        text = text_or_eq.strip()
        pde, parse = _mod("pde"), _mod("parse")
        kind = "ode"
        if pde is not None and hasattr(pde, "detect_kind"):
            kind = _call(ctx, "detect kind", pde.detect_kind, text, _soft=True) or "ode"
            # an evolution equation written in LaTeX that the detector does not recognise: the same text in plain
            # notation (helpers of mero.parse) is tried
            if kind != "pde" and parse is not None and hasattr(parse, "looks_like_pde") and \
                    hasattr(parse, "latex_to_plain"):
                try:
                    if parse.looks_like_pde(text):
                        plain = parse.latex_to_plain(text)
                        if plain and plain != text and (pde.detect_kind(plain) or "") == "pde":
                            report["input"]["read_as"] = plain
                            text, kind = plain, "pde"
                except Exception:
                    pass
        report["input"]["kind"] = kind
        try:
            if kind == "pde" and pde is not None:
                reds = pde.travelling_wave(pde.parse_pde(text))
                red = reds[min(int(options.get("reduction_index", 0)), len(reds) - 1)]
                eq = red["equation"]
                report["input"]["reduction"] = {
                    "ansatz": red.get("ansatz"), "integrated": red.get("integrated"),
                    "constants": [str(c) for c in red.get("constants", []) or []], "note": red.get("note", ""),
                    "constraints": [str(c) for c in red.get("constraints", []) or []],
                    "conditions": [str(c) for c in red.get("conditions", []) or []],
                    "chirp": red.get("chirp"), "mode": red.get("mode"),
                    "sign_convention": red.get("sign_convention"),
                    "coefficients": dict((str(k), str(v)) for k, v in (red.get("coefficients") or {}).items())
                    if isinstance(red.get("coefficients"), dict) else red.get("coefficients"),
                    "lowered": red.get("lowered"),
                    "assumed": [dict((k, str(v)) for k, v in a.items()) for a in (red.get("assumed") or [])
                                if isinstance(a, dict)],
                    "warnings": [str(w_) for w_ in (red.get("warnings") or [])],
                    "alternatives": [{"index": i, "integrated": r.get("integrated"), "ansatz": r.get("ansatz"),
                                      "order": getattr(r.get("equation"), "K", None)} for i, r in enumerate(reds)]}
                for w_ in red.get("warnings") or []:
                    if str(w_) not in warnings:
                        warnings.append(str(w_))
            elif parse is not None and hasattr(parse, "parse_ode"):
                eq = parse.parse_ode(text, unknown=options.get("unknown"), var=options.get("var"))
            else:
                eq = _fallback_parse(text, unknown=options.get("unknown"))
                warnings.append("fallback parser in use")
        except Exception as exc:
            report["verdict"] = {"level": "unsupported", "text": "The input could not be read: %s" % exc, "basis": []}
            report["elapsed_s"] = round(time.monotonic() - t_start, 3)
            return report
    else:
        eq = text_or_eq
    for wmsg in getattr(eq, "warnings", []) or []:
        warnings.append(str(wmsg))
    report["equation"] = _equation_block(eq)
    symbolic = len(eq.params) > 0
    reserved = list(dict.fromkeys([str(x) for x in (options.get("reserved_names") or [])] +
                                  [str(q) for q in eq.params]))
    ctx["reserved_names"] = reserved

    # 2. local analysis ---------------------------------------------------------------------------------------
    laurent = _mod("laurent")
    local = None
    if laurent is not None and hasattr(laurent, "local_analysis"):
        local = _call(ctx, "local analysis", laurent.local_analysis, eq,
                      budget_s=max(5.0, min(40.0, 0.2 * budget_s)), _timeout=max(8.0, min(60.0, 0.3 * budget_s)))
        if local is None and ctx.get("hard"):                    # second try without the special loci
            local = _call(ctx, "local analysis (without special loci)", laurent.local_analysis, eq,
                          budget_s=max(5.0, min(30.0, 0.15 * budget_s)), depth=-1,
                          _timeout=max(8.0, min(45.0, 0.2 * budget_s)))
    if local is None:
        local = _call(ctx, "local analysis (reference implementation)", _bootstrap_local, eq) or {"balances": []}
    report["local"] = local

    # 3. constants --------------------------------------------------------------------------------------------
    consts = _call(ctx, "constant solutions", _constants, eq, _timeout=20.0) or {}
    for item in _const_items(consts):
        _add_found(report, item)
    if eq.params and depth == 0 and not consts.get("all"):
        for item in _call(ctx, "constants on special parameter values", _constants_identically, eq,
                          _timeout=15.0) or []:
            _add_found(report, item)

    # 4. theorems ---------------------------------------------------------------------------------------------
    classes = _mod("classes")
    tier = None
    if classes is not None:
        if hasattr(classes, "classify"):
            report["classes"] = _call(ctx, "classify", classes.classify, eq, local) or []
        if hasattr(classes, "tier"):
            tier = _call(ctx, "theorems", classes.tier, eq, local, _timeout=40.0 * ctx["scale"])
    if tier:
        report["theorems"] = tier.get("theorems", []) or []
        for item in tier.get("ruled_out", []) or []:
            _add_item(report, "ruled_out", item, "tier")
        for item in tier.get("not_decided", []) or []:
            _add_item(report, "not_decided", item, "tier")
        report["tier"] = dict((k, v) for k, v in tier.items() if k not in ("theorems", "ruled_out", "not_decided"))

    # 5. decision modules for orders one and two --------------------------------------------------------------
    decided = None
    if eq.K == 1:
        m1 = _mod("order1")
        if m1 is not None and hasattr(m1, "order1_answer"):
            decided = _call(ctx, "order one", m1.order1_answer, eq)
    elif eq.K == 2:
        m2, m2b = _mod("order2"), _mod("order2b")
        if m2 is not None and hasattr(m2, "order2_answer"):
            decided = _call(ctx, "order two", m2.order2_answer, eq,
                            budget_s=min(_left(ctx), 40.0 if mode == "heavy" else max(15.0, 0.6 * budget_s)),
                            _timeout=_light(ctx, max(20.0, min(120.0, 0.4 * budget_s)), 1.0))
        conservative = bool(getattr(eq, "solved", False)) and not any(m[1] for m in eq.terms)
        if not conservative and m2b is not None and hasattr(m2b, "order2b_answer"):
            d2 = _call(ctx, "order two, even in w'", m2b.order2b_answer, eq, budget_s=min(_left(ctx), 30.0),
                       _timeout=_light(ctx, max(15.0, min(60.0, 0.25 * budget_s)), 0.9))
            if d2 and d2.get("applies"):
                dA = decided if (decided and decided.get("applies")) else None
                same = None
                dd = _mod("dedupe")
                if dA is not None and dd is not None and hasattr(dd, "same_lists") and \
                        ((dA.get("verdict") or {}).get("level") == "complete") and \
                        ((d2.get("verdict") or {}).get("level") == "complete"):
                    lim = 25.0 if mode == "heavy" else 5.0
                    res_s = _call(ctx, "comparison of the two lists", dd.same_lists,
                                  [x for x in dA.get("found") or [] if x.get("kind") != "constant"],
                                  [x for x in d2.get("found") or [] if x.get("kind") != "constant"],
                                  [str(q) for q in eq.params], lim, _timeout=lim + 20.0)
                    same = (res_s or {}).get("equal") if isinstance(res_s, dict) else None
                decided = _combine_order2(dA, d2, same)
    low_complete = low_applies = False
    if decided and decided.get("applies"):
        def _unpassed(dec):
            return [x for x in dec.get("found") or [] if x.get("expr") and x.get("kind") != "constant"
                    and (x.get("certificate") or {}).get("status") != "pass"]
        bad_ = _unpassed(decided)
        if bad_ and ctx.get("hard") and mode == "heavy":
            # a check that failed inside the module (for instance on nested radicals): one more exact check
            redo = []
            for x in decided.get("found") or []:
                if any(x is y for y in bad_[:8]) and _left(ctx) > 30.0:
                    again = _call(ctx, "exact check of a solution left unchecked", _recheck, eq, x, 15.0,
                                  _timeout=60.0)
                    if isinstance(again, dict) and (again.get("certificate") or {}).get("status") == "pass":
                        x = again
                redo.append(x)
            decided = dict(decided, found=redo)
            bad_ = _unpassed(decided)
        if bad_ and (decided.get("verdict") or {}).get("level") in ("complete", "complete-W"):
            decided = dict(decided)
            decided["verdict"] = dict(decided["verdict"], level="partial")
            decided["not_decided"] = list(decided.get("not_decided") or []) + [{
                "what": "%d famil%s of the decision procedure whose substitution check did not pass" % (
                    len(bad_), "y" if len(bad_) == 1 else "ies"),
                "why": "an item without a passed check is not listed as found, so the list is not known to be "
                       "complete", "partial": "they are shown below the list, among the candidates that are not "
                                              "verified or that the check rejected"}]
            decided["ruled_out"] = [x for x in decided.get("ruled_out") or []
                                    if "other than" not in str(x.get("what", ""))]
        if _hard_numbers(eq) and (decided.get("verdict") or {}).get("level") in ("complete", "complete-W"):
            decided = dict(decided)
            decided["ruled_out"] = [x for x in decided.get("ruled_out") or []
                                    if "other than" not in str(x.get("what", ""))]
            decided["verdict"] = dict(decided["verdict"], level="partial")
            decided["not_decided"] = list(decided.get("not_decided") or []) + [{
                "what": "whether the list is complete",
                "why": "the coefficients of the equation contain nested radicals or higher roots; the decision "
                       "procedure tests multiple roots exactly only over fields generated by square roots of "
                       "rational numbers and i, so special cases may have been missed or mislabelled",
                "partial": "every listed solution passed its substitution check"}]
        decided = _generic_upgrade(decided, symbolic)
        if any(x.get("kind") == "constant" for x in decided.get("found") or []):
            report["found"] = [x for x in report["found"] if x.get("origin") != "live:constants"]
        _merge_lists(report, decided, src="low_order")
        report["low_order"] = dict((k, v) for k, v in decided.items()
                                   if k not in ("found", "ruled_out", "not_decided", "applies"))
        low_level = (decided.get("verdict") or {}).get("level")
        low_complete = low_level == "complete"
        low_applies = low_level in ("complete", "complete-W", "partial")
        if low_applies:
            for key in ("ruled_out", "not_decided"):
                report[key] = [it for it in report[key] if it.get("_src") != "tier"]
        if low_complete:                 # the decision module supersedes the general statements of the theorems
            report["not_decided"] = [it for it in report["not_decided"] if it.get("_src") != "tier"]
        if low_applies and symbolic and depth == 0 and options.get("supplement", True):
            try:
                _supplement_open_strata(report, eq, local, ctx, mode, budget_s, decided)
            except Exception as exc:
                log.append("direct search on open strata: %s" % str(exc)[:200])

    ent = ends = bound = fc = ws = None
    linear = report["equation"]["degree"] <= 1
    if linear:
        low_applies = True                      # nothing below applies to a linear equation
        entire = _mod("entire")
        if entire is not None and hasattr(entire, "entire_solutions"):
            ent = _call(ctx, "solutions without poles", entire.entire_solutions, eq,
                        budget_s=min(_left(ctx), _light(ctx, 30.0 * ctx["scale"], 0.2)),
                        _timeout=_light(ctx, 50.0 * ctx["scale"], 0.25))
            if ent:
                for key in ("polynomials", "exponentials", "implicit"):
                    for sol in ent.get(key, []) or []:
                        _add_found(report, sol, "live:entire")
    if not low_applies:
        # 6. solutions without poles --------------------------------------------------------------------------
        entire = _mod("entire")
        if entire is not None and hasattr(entire, "entire_solutions"):
            ent = _call(ctx, "solutions without poles", entire.entire_solutions, eq,
                        budget_s=min(_left(ctx), _light(ctx, 30.0 * ctx["scale"], 0.2)),
                        _timeout=_light(ctx, 50.0 * ctx["scale"], 0.25))
            if ent:
                for key in ("polynomials", "exponentials", "implicit"):
                    for sol in ent.get(key, []) or []:
                        _add_found(report, sol, "live:entire")
                for item in ent.get("not_decided", []) or []:
                    _add_item(report, "not_decided", item)
                for item in ent.get("ruled_out", []) or []:
                    if isinstance(item, dict) and item.get("what"):
                        _add_item(report, "ruled_out", item)
                report["entire"] = {"complete": ent.get("complete"), "basis": ent.get("basis"),
                                    "complete_conditions": ent.get("complete_conditions"),
                                    "growth": ent.get("growth"), "strata": ent.get("strata"),
                                    "implicit": ent.get("implicit"), "certificate": ent.get("certificate")}

        # 7. ends, pole bound, free coefficients --------------------------------------------------------------
        ends_mod = _mod("ends")
        if ends_mod is not None:
            if hasattr(ends_mod, "end_exponents"):
                ends = _call(ctx, "ends", ends_mod.end_exponents, eq,
                             budget_s=min(_left(ctx), _light(ctx, 20.0 * ctx["scale"], 0.15)),
                             _timeout=_light(ctx, 35.0 * ctx["scale"], 0.25))
            if hasattr(ends_mod, "pole_bound"):
                bound = _call(ctx, "pole bound", ends_mod.pole_bound, eq, local,
                              budget_s=min(_left(ctx), _light(ctx, 20.0 * ctx["scale"], 0.15)),
                              _timeout=_light(ctx, 40.0 * ctx["scale"], 0.25))
        report["ends"] = ends
        report["pole_bound"] = bound
        fc_mod = _mod("freecoeff")
        if fc_mod is not None and hasattr(fc_mod, "free_coefficient_values") and getattr(eq, "solved", True) \
                and eq.K >= 3:
            fc = _call(ctx, "free coefficients", fc_mod.free_coefficient_values, eq, local,
                       budget_s=min(_left(ctx), 60.0 if mode == "heavy" else _light(ctx, 15.0, 0.1)),
                       _timeout=_light(ctx, 75.0, 0.15))
            report["free_coefficients"] = fc

        # 8. rational / simply periodic / elliptic solutions --------------------------------------------------
        wsolve = _mod("wsolve")
        if wsolve is not None and hasattr(wsolve, "find_w_solutions") and (local.get("balances") or []):
            n_bound, _n_src = _pole_bound(tier, fc, bound)
            # two poles in a period: never when there is exactly one Laurent series; in the heavy version whenever
            # the bound is 2 or more or unknown; in the browser only for numeric equations with time to spare
            # when no meromorphic solution has a pole for generic parameter values, the search is only for the
            # special values on which a Laurent series exists: one pole is enough there
            single = (tier or {}).get("laurent_series_count") == 1 or n_bound == 1 or \
                str((tier or {}).get("class_of_all_meromorphic_solutions") or "").startswith("entire")
            if "max_poles" in options:
                cap = int(options["max_poles"])
            elif single:
                cap = 1
            elif mode == "heavy":
                cap = 2
            else:
                cap = 2 if (not symbolic and budget_s >= 30) else 1
            max_poles = max(1, min(cap, n_bound if n_bound else cap))
            ws_kwargs = {}
            if mode == "heavy":
                ws_kwargs["limits"] = {"MAX_FACTOR_TERMS": 600, "MAX_FACTOR_DEGREE": 30, "MAX_STATE_TERMS": 6000,
                                       "MAX_EQ_TERMS": 1500, "MAX_SUBST_COST": 1000000, "MAX_VALUE_OPS": 800,
                                       "MAX_VERIFY_CHARS": 12000}
            ws_kwargs["reserved_names"] = list(reserved)
            reserve = (_light(ctx, 15.0, 0.1, 0.0) if options.get("atlas", True) else 0.0) + \
                (0.25 * budget_s if symbolic and depth == 0 else 0.0)
            nfs = _mod("nfsolve") if (symbolic and options.get("normal_form_solver", True) and
                                      ((mode == "heavy" and ctx.get("hard")) or
                                       (not ctx.get("hard") and options.get("light_normal_form", True)))) else None
            use_nf = False
            if nfs is not None and hasattr(nfs, "find_w_solutions_nf") and getattr(eq, "solved", True):
                use_nf = bool(_call(ctx, "normal form of the equation", _nf_probe, eq, _timeout=30.0))

            def search(label, mp, b):
                """one call of the solver: in the normal form when it has fewer parameters; the plain form when
                that is not so, or when the normal-form call failed or ran out of time"""
                if use_nf:
                    out = _call(ctx, label, nfs.find_w_solutions_nf, eq, local, max_poles=mp, ends=ends,
                                budget_s=b, cover_degenerate=(mode == "heavy"), _timeout=2.5 * b + 30.0,
                                **ws_kwargs)
                    if out is not None or _left(ctx, reserve) < 20.0:
                        return out
                    b = max(5.0, min(_left(ctx, reserve) / 2.6, b))
                    out = _call(ctx, label + ", plain form", wsolve.find_w_solutions, eq, local, max_poles=mp,
                                ends=ends, budget_s=b, _timeout=2.5 * b + 30.0, **ws_kwargs)
                    if out is not None:             # the plain form answered: the first attempt is not a gap
                        for lst in (ctx["failures"], ctx["timeouts"]):
                            while label in lst:
                                lst.remove(label)
                    return out
                return _call(ctx, label, wsolve.find_w_solutions, eq, local, max_poles=mp, ends=ends,
                             budget_s=b, _timeout=2.5 * b + 30.0, **ws_kwargs)

            # the solver's budget bounds the solving only; its checks may take as long again
            if max_poles > 1 and ctx.get("hard"):
                b1 = max(5.0, min(_left(ctx, reserve) / 2.6, 0.15 * budget_s))
                ws1 = search("rational, simply periodic and elliptic solutions (one pole)", 1, b1)
                ws = None
                if _left(ctx, reserve) > 20.0:
                    b2 = max(5.0, min(_left(ctx, reserve) / 2.6, 0.22 * budget_s))
                    ws = search("rational, simply periodic and elliptic solutions (two poles)", max_poles, b2)
                if ws is None:
                    ws, max_poles = ws1, 1
                elif ws1:
                    ws = _merge_searches(ws1, ws)
            else:
                ws_budget = max(5.0, min(_left(ctx, reserve) / 2.6,
                                         0.22 * budget_s if max_poles > 1 else 0.3 * budget_s))
                ws = search("rational, simply periodic and elliptic solutions", max_poles, ws_budget)
            if ws:
                ws = _tidy_search(ws)
                verify_mod = _mod("verify")
                unlisted, rechecks = [], 0
                for sol in ws.get("solutions", []) or []:
                    st = (sol.get("certificate") or {}).get("status")
                    if st not in ("pass", "fail", "FAIL") and sol.get("kind") != "constant" and ctx.get("hard") \
                            and mode == "heavy" and rechecks < 16 and _left(ctx) > 45.0:
                        # the solver ran out of time for its checks: one more exact check of this solution
                        rechecks += 1
                        b_c = max(10.0, min(60.0, _left(ctx) / 4.0))
                        again = _call(ctx, "exact check of a solution left unchecked", _recheck, eq, sol, b_c,
                                      _timeout=3.0 * b_c + 40.0)
                        if isinstance(again, dict):
                            sol = again
                            st = (sol.get("certificate") or {}).get("status")
                    # a second look at forms verified "modulo relations" or with several poles (found necessary)
                    if verify_mod is not None and hasattr(verify_mod, "numeric_check") and \
                            (sol.get("relations") or (sol.get("poles_per_period") or 1) > 1) and st == "pass":
                        nc = _call(ctx, "numerical second check of a solution", _second_check, eq, sol,
                                   _timeout=25.0)
                        ok_nc = nc.get("ok", nc.get("pass", nc.get("status") in ("pass", "zero"))) \
                            if isinstance(nc, dict) else (bool(nc) if nc is not None else None)
                        if ok_nc is False:
                            report["rejected"].append({"expr": sol.get("expr"), "conditions": sol.get("conditions"),
                                                       "why": "the numerical second check failed",
                                                       "origin": "live:wsolve"})
                            unlisted.append((sol, "its numerical second check failed"))
                            continue
                        if nc is None and ctx["timeouts"] and \
                                ctx["timeouts"][-1] == "numerical second check of a solution":
                            # the check did not run: the form is not finished (the solution stays listed)
                            unlisted.append((sol, "its numerical second check did not run (time limit)"))
                    _add_found(report, sol, "live:wsolve")
                    if st != "pass" and sol.get("kind") != "constant":
                        unlisted.append((sol, "its substitution check did not run" if st not in ("fail", "FAIL")
                                         else "its substitution check failed"))
                nf0 = ws.get("nf") if isinstance(ws.get("nf"), dict) else None
                deg = set(_norm_cond(d_.get("condition")) for d_ in (nf0 or {}).get("degenerate_loci") or []
                          if isinstance(d_, dict) and d_.get("condition"))
                if use_nf and deg and _left(ctx, reserve) > 30.0:
                    b_p = max(5.0, min(_left(ctx, reserve) / 3.0, 0.1 * budget_s))
                    plain = _call(ctx, "one-pole solutions on special parameter values (plain form)",
                                  wsolve.find_w_solutions, eq, local, max_poles=1, ends=ends, budget_s=b_p,
                                  _timeout=2.5 * b_p + 30.0, **ws_kwargs)
                    have = set((x.get("kind"), frozenset(_norm_cond(c) for c in x.get("conditions") or []
                                                         if "==" in str(c))) for x in report["found"])
                    for sol in (plain or {}).get("solutions") or []:
                        eqs = [_norm_cond(c) for c in sol.get("conditions") or [] if "==" in str(c)]
                        if sol.get("kind") == "constant" or (sol.get("certificate") or {}).get("status") != "pass":
                            continue
                        if len(eqs) < 2 or not (set(eqs) & deg) or (sol.get("kind"), frozenset(eqs)) in have:
                            continue
                        sol = dict(sol)
                        note = "found by a direct search on special parameter values at which the normal form " \
                               "is not defined"
                        sol["note"] = (str(sol["note"]) + "; " + note) if sol.get("note") else note
                        _add_found(report, sol, "live:wsolve")
                # a form with a solution that is not in the list is not a finished form (audit R1)
                for sol, why in unlisted:
                    poles = list(sol.get("pole_orders") or [1] * int(sol.get("poles_per_period") or 1))
                    entry = {"ansatz": "%s, %s (a solution of this form is not in the list: %s)" % (
                        sol.get("kind"), "one pole" if len(poles) <= 1 else "%d poles" % len(poles), why),
                        "kind": sol.get("kind"), "poles": poles, "reason": why}
                    if sol.get("locus"):
                        ws.setdefault("locus_incomplete", []).append(dict(entry, locus=sol.get("locus")))
                    else:
                        ws.setdefault("incomplete", []).append(entry)
                cov0 = _coverage(ws, local, ends, ent)
                ctx["one_pole_complete"] = bool(cov0.get("one_pole") and cov0.get("growth_ok") and cov0.get("poly_ok"))
                report["w_search"] = {"certificates": ws.get("certificates"), "incomplete": ws.get("incomplete"),
                                      "max_poles": max_poles}
                nf = ws.get("nf")
                if isinstance(nf, dict):
                    report["w_search"]["normal_form"] = dict(
                        (k, nf.get(k)) for k in ("reduced_equation", "symbols", "map", "conditions", "statement",
                                                 "degenerate_loci", "loci_not_covered") if nf.get(k) is not None)
                    report["w_search"]["normal_form"]["note"] = ws.get("nf_note")
                if ws.get("locus_certificates") or ws.get("locus_incomplete"):
                    loci = {}
                    for c in ws.get("locus_certificates") or []:
                        row_ = loci.setdefault(str(c.get("locus")), {"finished": [], "unfinished": []})
                        row_["finished"].append("%s, poles %s" % (c.get("kind"), c.get("poles")))
                        for a_ in c.get("locus_assumed") or []:
                            if str(a_) not in row_.setdefault("under", []):
                                row_["under"].append(str(a_))
                    for c in ws.get("locus_incomplete") or []:
                        loci.setdefault(str(c.get("locus")), {"finished": [], "unfinished": []})["unfinished"].append(
                            "%s, poles %s" % (c.get("kind"), c.get("poles")))
                    sl = []
                    ploc = dict((str(q), q) for q in eq.params)
                    for k, v_ in loci.items():
                        row = dict(v_, conditions=k)
                        try:
                            sub_ = {}
                            for c in k.split(", "):
                                a_, b_ = c.split("==", 1)
                                if a_.strip() in ploc:
                                    sub_[ploc[a_.strip()]] = sp.sympify(b_, locals=ploc)
                            if sub_ and _degenerate(eq, eq.subs(sub_)):
                                row["degenerate"] = True
                                row["note"] = "the equation has lower order or degree on these values: it is a " \
                                              "different equation, and its solutions are not listed"
                                row["finished"], row["unfinished"] = [], []
                        except Exception:
                            pass
                        sl.append(row)
                    report["w_search"]["special_loci"] = sl
                    ctx["nf_loci"] = [set(_norm_cond(c) for c in k.split(", ")) for k in loci]
                    for k, v in loci.items():
                        if v["unfinished"]:
                            _add_item(report, "not_decided", {
                                "what": "parameter values with %s" % k.replace(", ", " and "),
                                "kind": "parameter-locus", "conditions": k.split(", "),
                                "why": "on these values the search did not finish for: %s"
                                       % "; ".join(v["unfinished"]),
                                "partial": "the solutions found there are listed with these conditions"})
                for cnd in (nf or {}).get("loci_not_covered") or []:
                    if isinstance(cnd, dict):
                        cl = [re.sub(r"\s*\([^()]*\)\s*$", "", str(c)) for c in cnd.get("conditions") or []]
                        why = str(cnd.get("why") or "these values were not reached")
                    else:
                        cl = [re.sub(r"\s*\([^()]*\)\s*$", "", str(cnd))]
                        why = "these values were not reached"
                    if not cl:
                        continue
                    _add_item(report, "not_decided", {
                        "what": "parameter values with %s" % " and ".join(cl), "kind": "parameter-locus",
                        "conditions": cl,
                        "why": "the change of variables to the normal form is not defined there: " + why,
                        "partial": "solutions found on these values by the direct search are listed with their "
                                   "conditions"})
                for cnd in (nf or {}).get("loci_undefined") or []:
                    cl = [c.strip() for c in str(cnd).split(",") if c.strip()]
                    _add_item(report, "not_decided", {
                        "what": "parameter values with %s" % " and ".join(cl), "kind": "parameter-locus",
                        "conditions": cl, "degenerate": True,
                        "why": "a coefficient of the equation is not defined there", "partial": ""})

    # 9. invariant surfaces (solutions with d < K) -------------------------------------------------------------
    darboux = _mod("darboux")
    inv_info = None
    if darboux is not None and hasattr(darboux, "darboux_polynomials") and options.get("darboux", True) \
            and eq.K >= 3 and getattr(eq, "solved", True) and not low_applies and depth == 0:
        dp = _call(ctx, "invariant surfaces", darboux.darboux_polynomials, eq,
                   budget_s=min(_left(ctx, 15.0), 45.0 if mode == "heavy" else 10.0), _timeout=60.0)
        if dp:
            report["invariants"] = dict((k, v) for k, v in dp.items()
                                        if k in ("status", "darboux_polynomials", "first_integrals", "time_functions",
                                                 "incomplete", "searched", "summary", "certificate"))
            inv_info = dp

    # 10. the earlier atlas ------------------------------------------------------------------------------------
    atlasdb = _mod("atlasdb")
    at = None
    if atlasdb is not None and hasattr(atlasdb, "lookup") and options.get("atlas", True) and depth == 0 \
            and report["equation"]["degree"] >= 2:
        at = _call(ctx, "earlier records", atlasdb.lookup, eq, mode=("exact" if mode == "heavy" else "fast"),
                   budget_s=min(30.0 if mode == "heavy" else 12.0, max(5.0, _left(ctx))), _timeout=50.0)
        if at:
            report["atlas"] = at

    # 10b. solutions of the earlier records that the engine does not derive itself (d >= 2) -------------------
    if at:
        _atlas_found(report, at)

    # 10c. changes of variables ---------------------------------------------------------------------------------
    transform = _mod("transform")
    if transform is not None and depth == 0:
        if hasattr(transform, "normal_form_block"):
            nf = _call(ctx, "normal form", transform.normal_form_block, eq, _timeout=25.0)
            if nf:
                report["normal_form"] = nf
        if options.get("twist", True) and not low_applies and hasattr(transform, "exponential_twist") \
                and getattr(eq, "solved", True):
            _twists(report, eq, transform, ctx, mode, options, depth)

    # 11. verdict ----------------------------------------------------------------------------------------------
    try:
        _verdict(report, eq, local, tier, decided, ent, ws, ends, fc, bound, at)
    except Exception as exc:
        log.append("verdict: FAILED: %s: %s" % (type(exc).__name__, str(exc)[:300]))
        ctx["failures"].append("verdict")
        nonc = any(x.get("kind") != "constant" for x in report["found"])
        report["verdict"] = {"level": "partial" if nonc else "formal",
                             "text": "The solutions listed were found and verified; the step that puts the verdict "
                                     "together failed, so nothing is said about completeness." if nonc else
                                     "Local analysis only: the step that puts the verdict together failed.",
                             "basis": [], "scope": "the parameter strata listed" if symbolic else "this equation",
                             "conditions": []}

    if inv_info:
        info = _invariants(report, eq, inv_info, ctx, mode, options, depth)
        if info:
            _first_integral_upgrade(report, info)

    # 11b. power substitutions: w has no pole of integer order, a power of w may have ---------------------------
    if transform is not None and depth == 0 and options.get("substitutions", True) \
            and hasattr(transform, "power_substitution") and (local.get("non_integer_balances") or []):
        _power_substitutions(report, eq, transform, ctx, mode, options, depth)

    # 12. special parameter loci -------------------------------------------------------------------------------
    if symbolic and options.get("strata", True) and depth < int(options.get("max_depth", 1)) \
            and report["verdict"]["level"] != "unsupported" and not low_applies:
        _strata(report, eq, local, tier, ctx, mode, options, depth)

    try:
        _drop_degenerate(report, eq)
        _degenerate_strata_items(report, eq)
    except Exception as exc:
        log.append("degenerate loci: %s" % str(exc)[:200])
    for sf in report.get("surfaces") or []:
        if isinstance(sf, dict):
            sf.pop("_items", None)
    if depth == 0 and len(report["found"]) > 1:
        dd = _mod("dedupe")
        if dd is not None and hasattr(dd, "copies"):
            # the comparison has its own deadline `lim`; the step is given that time even when the budget of the
            # analysis is used up (a list with repetitions is worse than a few more seconds)
            lim = min(120.0, max(60.0, 0.3 * budget_s)) if mode == "heavy" else 4.0
            res_c = _call(ctx, "copies in the list", dd.copies, report["found"], [str(q) for q in eq.params],
                          lim, _timeout=lim + 20.0, _min=(lim + 15.0) if mode == "heavy" else 5.0)
            dropped = (res_c or {}).get("drop") if isinstance(res_c, dict) else None
            if dropped:
                kept_by = dict((int(k), int(v_)) for k, v_ in ((res_c or {}).get("kept_by") or {}).items()
                               if str(k).lstrip("-").isdigit() and str(v_).lstrip("-").isdigit())
                ok_ = _call(ctx, "copies in the list: second look", _confirm_drops, report["found"],
                            [int(i) for i in dropped], kept_by, [str(q) for q in eq.params],
                            25.0 if mode == "heavy" else 3.0, _timeout=45.0, _min=30.0 if mode == "heavy" else 4.0)
                dropped = [int(i) for i in dropped if isinstance(ok_, (list, tuple)) and int(i) in ok_]
            if dropped and isinstance(res_c, dict):
                why_ = dict((int(k), v_) for k, v_ in (res_c.get("why") or {}).items()
                            if str(k).lstrip("-").isdigit())
                report["copies_removed"] = [
                    {"kind": report["found"][i].get("kind"), "conditions": report["found"][i].get("conditions"),
                     "expr": str(report["found"][i].get("expr"))[:160], "why": str(why_.get(i, ""))[:200]}
                    for i in sorted(dropped) if i < len(report["found"])]
        else:
            dropped = _call(ctx, "copies in the list", _copies, report["found"], [str(q) for q in eq.params],
                            20.0 if mode == "heavy" else 4.0, _timeout=40.0, _min=12.0)
        if dropped:
            ids = set(int(i) for i in dropped)
            report["found"] = [it for i, it in enumerate(report["found"]) if i not in ids]
    if depth == 0 and symbolic:
        try:
            _drop_degenerate_points(report, eq, ctx)
        except Exception as exc:
            log.append("degenerate loci (points): %s" % str(exc)[:200])
        try:
            _equation_degenerate_loci(report, eq)
            _prune_degenerate_loci(report)
            _name_degenerate_loci(report)
        except Exception as exc:
            log.append("degenerate loci (equation): %s" % str(exc)[:200])
        try:
            _drop_empty_items(report, eq)
        except Exception as exc:
            log.append("items that denote nothing: %s" % str(exc)[:200])
        try:
            lim_r = 30.0 if mode == "heavy" else 4.0
            res_r = _call(ctx, "ruled-out items against the lists", _refine_job,
                          dict((k_, report.get(k_)) for k_ in ("found", "ruled_out", "not_decided", "verdict")),
                          eq, lim_r, _timeout=lim_r + 20.0, _min=(lim_r + 15.0) if mode == "heavy" else 5.0)
            if isinstance(res_r, dict):
                for k_ in ("ruled_out", "not_decided", "verdict"):
                    report[k_] = res_r[k_]
                log.extend(res_r.get("log") or [])
        except Exception as exc:
            log.append("ruled-out items against the lists: %s" % str(exc)[:200])
    if depth == 0:
        try:
            _fix_pole_labels(report)
        except Exception as exc:
            log.append("pole labels: %s" % str(exc)[:200])
    _d_summary(report)
    pretty = _mod("pretty")
    if pretty is not None and hasattr(pretty, "pretty_report") and options.get("pretty", True) and depth == 0:
        b_p = min(60.0, max(5.0, 0.15 * budget_s)) if mode == "heavy" else min(8.0, max(3.0, 0.15 * budget_s))
        pr = _call(ctx, "readable forms", pretty.pretty_report, report, budget_s=b_p, _timeout=b_p + 30.0,
                   _min=12.0)
        if isinstance(pr, dict) and pr.get("found") is not None:
            for key in ("found", "strata", "substitutions", "surfaces"):
                if key in pr:
                    report[key] = pr[key]
    for key in ("ruled_out", "not_decided"):
        for it in report[key]:
            it.pop("_src", None)
    try:
        v0 = report.get("verdict") or {}
        if v0.get("level") == "formal" and any(x.get("kind") != "constant" for x in report["found"]):
            v0["level"] = "partial"
            v0["text"] = re.sub(
                r"[Ll]ocal analysis only: no theorem of the registry decides this equation, and no solution other "
                r"than constants was found\.",
                "no theorem of the registry gives the class of all meromorphic solutions of this equation. The "
                "solutions listed were found (on invariant surfaces or on special parameter values); other "
                "meromorphic solutions are not decided.", str(v0.get("text", "")))
            report["verdict"] = v0
    except Exception as exc:
        log.append("level of a report with listed solutions: %s" % str(exc)[:200])
    try:
        vc = [str(c) for c in (report.get("verdict") or {}).get("conditions") or []]
        for it in report["not_decided"]:
            w = str(it.get("what", ""))
            if w.startswith("parameter values at which one of the conditions fails") and vc:
                it["what"] = "parameter values at which one of the conditions fails: " + "; ".join(vc)
    except Exception as exc:
        log.append("scope item: %s" % str(exc)[:200])
    try:
        red0 = (report.get("input") or {}).get("reduction") or {}
        if red0 and report.get("verdict") and depth == 0:
            vv = report["verdict"]
            assumed = [("$%s = %s$" if re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", str(a.get("constant")))
                        else "%s = %s") % (a.get("constant"), a.get("value"))
                       for a in red0.get("assumed") or [] if a.get("constant")]
            vv["about"] = "the reduced equation" + (
                " (obtained under the condition %s)" % ", ".join(assumed) if assumed else "")
            sentence = "This is a statement about the reduced ordinary differential equation for the profile " \
                       "$w$ of the ansatz"
            def _covered(a):
                cb = a.get("covered_by")
                return bool(cb) and str(cb) != "None" and a.get("kind", "integration-constant") == \
                    "integration-constant"
            other = any(_covered(a) for a in red0.get("assumed") or []) or (
                not any("covered_by" in a for a in red0.get("assumed") or [])
                and len(red0.get("alternatives") or []) > 1)
            if assumed:
                sentence += ", which was obtained under the condition %s; solutions of the equation entered that " \
                            "do not satisfy this condition are not covered%s" % (
                                ", ".join(assumed),
                                " (they satisfy another reduction in the list of reductions)" if other else "")
            vv["reduction_scope"] = sentence + "."
            if assumed and not other:
                _add_item(report, "not_decided", {
                    "what": "solutions of the equation entered that do not satisfy %s" % ", ".join(
                        "%s = %s" % (a.get("constant"), a.get("value")) for a in red0.get("assumed") or []),
                    "kind": "reduction",
                    "why": "; ".join(str(a.get("why")) for a in red0.get("assumed") or [] if a.get("why"))
                           or "the reduction assumes it",
                    "partial": ""})
            elif assumed:
                _add_item(report, "not_decided", {
                    "what": "travelling waves of the equation entered with a non-zero integration constant "
                            "(%s set to 0 in this reduction)" % ", ".join(str(a.get("constant")) for a in
                                                                          red0.get("assumed") or []),
                    "kind": "reduction",
                    "why": "the reduction used here integrates more than once, which is possible only when the "
                           "earlier integration constants vanish",
                    "partial": "choose the reduction that is integrated once less: it covers them"})
    except Exception as exc:
        log.append("scope of the reduction: %s" % str(exc)[:200])
    try:
        _scope_item(report)
        _normalise_labels(report)
        _standard_text(report, eq)
        _typeset_items(report)
    except Exception as exc:
        log.append("wording: %s" % str(exc)[:200])
    try:
        _finish_verdict(report, tier)
        _mark_complex(report, eq)
        v1 = report.get("verdict") or {}
        dl1 = report.get("degenerate_loci")
        if depth == 0 and isinstance(dl1, dict) and dl1.get("loci") and v1.get("text") and \
                v1.get("level") in ("complete", "complete-W", "partial") and \
                v1.get("scope") != "generic parameter values" and \
                "keeps its order and degree" not in str(v1.get("text")) and \
                not str(v1.get("text")).startswith("For generic values"):
            v1["text"] = str(v1["text"]).rstrip() + " This is said for the parameter values at which the " \
                "equation keeps its order and degree; the other values are named under \"not decided\"."
    except Exception as exc:
        log.append("verdict label: %s" % str(exc)[:200])
    try:                                                     # AUDIT-3 D-7: denominators cleared by the parser
        dens = [str(d_) for d_ in (getattr(eq, "cleared_denominators", None) or [])]
        if dens and depth == 0:
            jl = dict(("w%d" % j, sp.Symbol("w%d" % j)) for j in range(eq.K + 1))
            jl.update(dict((str(q), q) for q in eq.params))
            keep, gone = [], []
            for it in report["found"]:
                bad = False
                if it.get("kind") == "constant" and it.get("expr") and "RootOf" not in str(it.get("expr")):
                    try:
                        val = sp.sympify(str(it["expr"]), locals=dict((str(q), q) for q in eq.params))
                        sub0 = dict((jl["w%d" % j], (val if j == 0 else 0)) for j in range(eq.K + 1))
                        bad = any(sp.simplify(sp.sympify(d_, locals=jl).subs(sub0)) == 0 for d_ in dens)
                    except Exception:
                        bad = False
                (gone if bad else keep).append(it)
            if gone:
                report["found"] = keep
                warnings.append("the equation as typed has the denominator %s; the constant%s %s annul%s it and "
                                "%s not listed" % (", ".join(dens), "" if len(gone) == 1 else "s",
                                                   ", ".join("w = %s" % g.get("expr") for g in gone),
                                                   "s" if len(gone) == 1 else "", "is" if len(gone) == 1 else "are"))
            report["equation"]["cleared_denominators"] = dens
    except Exception as exc:
        log.append("cleared denominators: %s" % str(exc)[:200])
    for it in report["found"]:                               # no exception text in public fields
        nc_ = it.get("numeric_check")
        if isinstance(nc_, dict) and nc_.get("error"):
            nc_["error"] = "the numerical check could not be evaluated"
    seen_ids = set()
    for i, it in enumerate(report["found"]):                 # ids unique within the list
        if not it.get("id") or it["id"] in seen_ids:
            n = i + 1
            while "s%d" % n in seen_ids or any(o.get("id") == "s%d" % n for o in report["found"]):
                n += 1
            it["id"] = "s%d" % n
        seen_ids.add(it["id"])
    if ctx["failures"]:
        warnings.append("a part of the analysis failed and was skipped: " + "; ".join(ctx["failures"]))
    if ctx["timeouts"]:
        warnings.append("stopped at the time limit: " + "; ".join(ctx["timeouts"]))
        if report["verdict"].get("level") != "complete":
            _add_item(report, "not_decided", {
                "what": "the parts of the analysis that did not finish: " + "; ".join(ctx["timeouts"]),
                "why": "time limit", "partial": "a longer time limit may decide more"})
    if not report["rejected"]:
        report.pop("rejected")
    report["elapsed_s"] = round(time.monotonic() - t_start, 3)
    return report


# ----------------------------------------------------------------------------------------------- verdict
def _nf_probe(eq):
    """True if the normal form of the equation has fewer parameters (then the solver works in the normal form)"""
    from mero import nfsolve
    try:
        nfsolve.reduce_equation(eq, time_budget=15.0)
        return True
    except Exception:
        return False


def _recheck(eq, sol, budget):
    """the exact substitution check of a solution whose check did not run (symbolic, then exact at rational points,
    then floating point: the checks of mero.nfsolve / mero.wsolve); returns the solution with its new certificate"""
    from mero import nfsolve
    s = dict(sol)
    nfsolve._verify(eq, s, budget)
    return s


def _second_check(eq, sol):
    """the numerical second check of mero.verify; a form that it cannot sample is "not checked", not a failure"""
    from mero import verify
    try:
        return verify.numeric_check(eq, sol)
    except Exception as exc:
        return {"ok": None, "why": "%s: %s" % (type(exc).__name__, str(exc)[:120])}


def _tidy_search(ws):
    """(1) a certificate of the external solver with the warning "special parameter values not examined" is not a
    certificate: its form is moved to the unfinished ones; (2) certificates and unfinished forms on a special
    locus of the normal form are kept apart (`locus_certificates`, `locus_incomplete`)"""
    certs, inc, lc, li = [], [], [], []
    for c in ws.get("certificates") or []:
        hw = [w for w in ((c.get("heavy") or {}).get("warnings") or []) if "not examined" in str(w)] \
            if isinstance(c, dict) else []
        if hw:
            c = dict(c, reason="the list of this form holds for generic parameter values only: special parameter "
                               "values were not examined within the time limit")
            (li if c.get("locus") else inc).append(c)
        elif isinstance(c, dict) and c.get("locus"):
            lc.append(c)
        else:
            certs.append(c)
    for i in ws.get("incomplete") or []:
        (li if isinstance(i, dict) and i.get("locus") else inc).append(i)
    out = dict(ws)
    out["certificates"], out["incomplete"] = certs, inc
    out["locus_certificates"], out["locus_incomplete"] = lc, li
    return out


def _merge_searches(ws1, ws2):
    """results of the one-pole search (ws1) put into the results of the search with two poles (ws2): solutions and
    certificates that the second call did not reproduce are added, and a one-pole form that the first call finished
    is not listed as unfinished"""
    out = dict(ws2)
    sols = list(ws2.get("solutions") or [])
    have = set(_sol_key(x) for x in sols if isinstance(x, dict))
    for x in ws1.get("solutions") or []:
        if isinstance(x, dict) and _sol_key(x) not in have:
            sols.append(x)
    certs = list(ws2.get("certificates") or [])

    def ckey(c):
        return (c.get("kind"), tuple(sorted(c.get("poles") or [])), str(c.get("locus") or ""))

    def weak(c):
        return any("not examined" in str(w) for w in ((c.get("heavy") or {}).get("warnings") or []))
    havec = set(ckey(c) for c in certs)
    done1 = set()
    for c in ws1.get("certificates") or []:
        if weak(c):
            continue
        done1.add(ckey(c))
        if ckey(c) not in havec:
            certs.append(c)
    inc = []
    for i in ws2.get("incomplete") or []:
        if isinstance(i, dict) and len(i.get("poles") or [0]) <= 1 and ckey(i) in done1:
            continue
        inc.append(i)
    if not ws2.get("nf") and ws1.get("nf"):
        out["nf"], out["nf_note"] = ws1.get("nf"), ws1.get("nf_note")
    out["solutions"], out["certificates"], out["incomplete"] = sols, certs, inc
    return out


def _pole_bound(tier, fc, bound):
    """(N, source): the smallest proved bound on the number of poles in a period, and where it comes from"""
    cands = []
    if tier and isinstance(tier.get("pole_bound"), int):
        cands.append((tier["pole_bound"], str(tier.get("pole_bound_basis") or "theorems")))
    if fc and isinstance(fc.get("bound_poles_per_period"), int) and fc.get("status") not in ("error",):
        cands.append((fc["bound_poles_per_period"], "T-FREECOEFF"))
    if bound:
        bs = [(bound.get(k) or {}).get("bound") if isinstance(bound.get(k), dict) else None
              for k in ("simply_periodic", "elliptic", "rational")]
        if all(isinstance(b, int) for b in bs):
            cands.append((max(bs), "L-ENDS"))
    if not cands:
        return None, None
    return min(cands, key=lambda t: t[0])


def _coverage(ws, local, ends, ent):
    """what the solver finished: returns a dict used by the verdict"""
    out = {"one_pole": False, "two_pole": False, "missing": [], "growth_ok": False, "poly_ok": False,
           "assumed_nonzero": [], "multi": [], "ran": bool(ws)}
    out["growth_ok"] = bool(ends) and ends.get("growth_possible") is False and \
        ends.get("growth_list_complete") is not False
    # "no growth at the ends" holds off the strata that the lemma names (REF-ENDS, D8): they join the conditions
    for st in (ends or {}).get("strata") or []:
        c = str(st.get("condition") if isinstance(st, dict) else st)
        if "==" in c and out["growth_ok"]:
            a, b = c.split("==", 1)
            e_ = (a.strip() + " - (" + b.strip() + ")") if b.strip() not in ("0", "0.0") else a.strip()
            if e_ not in out["assumed_nonzero"]:
                out["assumed_nonzero"].append(e_)
    cert = (ent or {}).get("certificate") or {}
    pdb = cert.get("polynomial_degree_bound") or {}
    out["poly_ok"] = pdb.get("bound") == 0
    if not ws:
        out["missing"].append("the search for rational, simply periodic and elliptic solutions did not run")
        return out
    certs = ws.get("certificates") or []
    incomplete = ws.get("incomplete") or []
    orders = sorted(set(int(b["p"]) for b in (local.get("balances") or []) if isinstance(b.get("p"), int)))
    have = set((c.get("kind"), tuple(sorted(c.get("poles") or []))) for c in certs)
    need1 = [(k, (p,)) for k in KINDS for p in orders]
    need2 = [(k, (p1, p2)) for k in KINDS for i, p1 in enumerate(orders) for p2 in orders[i:]]
    lack1 = [n for n in need1 if n not in have]
    lack2 = [n for n in need2 if n not in have]
    for c in certs:
        for a in c.get("assumed_nonzero") or []:
            a = re.sub(r"\s*!=\s*0\s*$", "", str(a))        # the expression that is assumed not to vanish
            if a not in out["assumed_nonzero"]:
                out["assumed_nonzero"].append(a)
    inc1 = [i for i in incomplete if not isinstance(i, dict) or len(i.get("poles") or [0]) <= 1]
    inc2 = [i for i in incomplete if isinstance(i, dict) and len(i.get("poles") or []) == 2]
    out["one_pole"] = bool(orders) and not lack1 and not inc1
    out["two_pole"] = out["one_pole"] and not lack2 and not inc2
    for k, ps in lack1:
        out["missing"].append("%s solutions with one pole of order %d in a period" % (k, ps[0]))
    for inc in incomplete:
        if isinstance(inc, dict):
            name_ = inc.get("ansatz") or "%s, poles %s" % (inc.get("kind"), inc.get("poles"))
        else:
            name_ = inc
        out["missing"].append("unfinished: %s" % str(name_)[:200])
    out["multi"] = sorted(set(len(c.get("poles") or []) for c in certs))
    return out


def _qualifier(cov):
    """the restriction under which the one-pole forms of the solver are exhaustive"""
    q = []
    if not cov.get("growth_ok"):
        q.append("simply periodic ones with finite limits at both ends of the period strip")
    if not cov.get("poly_ok"):
        q.append("rational ones with a finite limit at infinity")
    return q


def _verdict(report, eq, local, tier, decided, ent, ws, ends, fc, bound, at):
    """The only place where a level is assigned."""
    symbolic = len(eq.params) > 0
    found_nonconst = [s for s in report["found"] if s.get("kind") != "constant"]

    if decided and decided.get("applies") and decided.get("verdict") and \
            (decided.get("verdict") or {}).get("level") in ("complete", "complete-W", "partial") and \
            (tier or {}).get("class_of_all_meromorphic_solutions") != "entire (linear equation)":
        v = dict(decided["verdict"])
        v.setdefault("basis", decided.get("basis") or [])
        sc = v.get("scope")
        if isinstance(sc, dict):
            v["scope_detail"] = sc
            gen = str(sc.get("parameters", "")).startswith("generic")
            if gen and symbolic and not (sc.get("explored_strata") or sc.get("unexplored")) and \
                    not any(_is_special_locus(it) or it.get("kind") == "parameter-locus"
                            for it in report["not_decided"]):
                _add_item(report, "not_decided", {
                    "what": "special values of the parameters", "kind": "parameter-locus",
                    "why": "the statement is for generic values of the parameters; the values at which the analysis "
                           "changes were not enumerated",
                    "partial": "substitute numbers for the parameters to get the answer at a particular point"})
            sc = "generic parameter values" if gen else None
        if not symbolic:
            sc = "this equation"
        elif sc not in ("generic parameter values", "all parameter values", "the parameter strata listed"):
            sc = "the parameter strata listed"
        if symbolic and v.get("level") in ("complete", "complete-W") and any(
                _is_special_locus(it) and not it.get("degenerate") for it in report["not_decided"]):
            sc = "generic parameter values"          # open parameter values are named under "not decided"
        v["scope"] = sc
        if isinstance(v.get("text"), str):
            v["text"] = re.sub(r"\s*\(labels?: [^)]*\)", "", v["text"])
        report["verdict"] = v
        _record_note(report, at)
        return

    tier = tier or {}
    cls = tier.get("class_of_all_meromorphic_solutions")
    used = list(tier.get("used") or [])
    generic = bool(tier.get("generic"))
    conds = list(tier.get("conditions_factored") or tier.get("conditions") or [])
    n_bound, n_src = _pole_bound(tier, fc, bound)
    ent_complete = bool(ent) and ent.get("complete") is True
    ent_const = tier.get("entire_solutions") == "constants"
    entire_ok = ent_complete or ent_const
    cov = _coverage(ws, local, ends, ent) if cls != "entire only" else {"assumed_nonzero": [], "ran": False}
    for a in cov.get("assumed_nonzero") or []:
        c = "%s != 0" % a
        if c not in conds:
            conds.append(c)
    if ent_complete and not ent_const and cls != "entire (linear equation)":
        for c in ent.get("complete_conditions") or []:
            c = str(c)
            if c not in conds:
                conds.append(c)
    scope_generic = symbolic and (generic or bool(conds))
    if conds and not symbolic:                    # a numeric equation: the conditions are facts, not a scope
        conds_note = conds
        conds = []
    else:
        conds_note = []
    prefix = ""
    if scope_generic:
        prefix = "For generic values of the parameters (%s): " % _conds_phrase(conds) \
            if conds else "For generic values of the parameters: "
    basis, level, text = list(used), None, None
    head = "every meromorphic solution is rational, simply periodic or elliptic"
    if n_bound is not None:
        head += ", with at most %d pole%s in a period" % (n_bound, "" if n_bound == 1 else "s") if n_bound else \
            ", and has no pole"
        if n_src and n_src not in basis:
            basis.append(n_src)
        if tier.get("pole_bound") != n_bound and cls in W_CLASSES:
            _add_item(report, "ruled_out", {
                "what": ("rational, simply periodic or elliptic solutions with more than %d pole%s in a period"
                         % (n_bound, "" if n_bound == 1 else "s")) if n_bound else
                        "rational, simply periodic or elliptic solutions with a pole",
                "basis": {"theorem": n_src, "label": "agent-proof"}, "conditions": list(conds)})

    if cls == "listed (not all in W)" and tier.get("text"):
        level = "partial"
        text = prefix + _lower_first(tier["text"], prefix) + " The solutions with closed forms that were computed " \
            "here are listed below; the others are described in the statement cited."
        _add_item(report, "not_decided", {
            "what": "closed forms for the solutions that are not rational, simply periodic or elliptic",
            "why": "they are described by the theorem cited in the verdict, not computed here",
            "partial": tier["text"]})
    elif cls == "entire (linear equation)":
        r = _fresh(eq, "r")
        chi = sp.expand(sum(co * r ** j for j, co in enumerate(
            [eq.terms.get(tuple(1 if i == j else 0 for i in range(eq.K + 1)), 0) for j in range(eq.K + 1)])))
        report["found"].append({
            "id": "lin", "kind": "entire", "d": None, "expr": None,
            "description": "the general solution: a particular polynomial solution plus the sum of "
                           "q_i(z)*exp(r_i*z) over the roots r_i of chi(%s) = %s, with arbitrary polynomials q_i "
                           "of degree less than the multiplicity of r_i" % (r, _s(chi)),
            "latex": "w = w_{p}(z) + \\sum_i q_i(z)\\,e^{r_i z},\\qquad \\chi(%s) = %s = 0" % (r, sp.latex(chi)),
            "free": ["the coefficients of the q_i"], "conditions": [], "label": "certificate",
            "certificate": {"type": "linear equation", "status": "pass",
                            "detail": "linear equation with constant coefficients"},
            "origin": "live:linear"})
        level = "complete"
        text = prefix + _lower_first(tier.get("text") or "The equation is linear with constant coefficients: every "
                                     "solution is entire.", prefix) + " The general solution is described in the list."
        report["not_decided"] = [it for it in report["not_decided"] if it.get("_src") != "tier"]
    elif str(cls or "").startswith("entire") and cls != "entire (linear equation)" and entire_ok:
        level = "complete"
        text = prefix + _lower_first("No meromorphic solution has a pole, and the solutions without poles are the "
                                     "ones listed.", prefix)
        if ent and ent.get("basis"):
            basis += [b for b in ent["basis"] if b not in basis]
        report["not_decided"] = [it for it in report["not_decided"]
                                 if it.get("kind") != "entire" and it.get("_src") != "tier"]
    elif cls in W_CLASSES:
        can1 = cov["one_pole"] and cov["growth_ok"] and cov["poly_ok"] and entire_ok
        if n_bound is not None and n_bound <= 1 and can1:
            level = "complete"
        elif n_bound is not None and n_bound == 2 and can1 and cov["two_pole"]:
            level = "complete"
        if level == "complete":
            text = prefix + _cap(head, prefix) + ". All of them are listed" + \
                (" (each family with the conditions on the parameters under which it exists)." if symbolic else ".")
            basis.append("certificate: the systems for %s in a period" %
                         ("one pole" if n_bound <= 1 else "one and two poles"))
            if "L-ENDS" not in basis:
                basis.append("L-ENDS")           # no growth at the ends of the period strip: the forms are exhaustive
            for b_ in (ent or {}).get("basis") or []:
                if b_ not in basis:
                    basis.append(b_)             # the solutions without poles
            if isinstance((ws or {}).get("nf"), dict):
                basis.append("L-NORMALFORM")     # the systems were solved in the normal form and transported back
            _certificate_ruled_out(report, ws, symbolic, cov, conds)
        else:
            level = "partial"
            done, missing = [], list(cov["missing"])
            both = bool(cov["one_pole"] and cov.get("two_pole"))
            if cov["one_pole"]:
                q = _qualifier(cov)
                done.append("all such solutions with %s in a period are listed" %
                            ("one or two poles" if both and (n_bound is None or n_bound >= 2) else "one pole") +
                            (" (%s)" % "; ".join(q) if q else ""))
            if n_bound is None:
                missing.append("solutions with more than %s in a period (no bound on the number of poles is "
                               "available here)" % ("two poles" if both else "one pole"))
            elif n_bound >= 2 and not cov.get("two_pole"):
                missing.append("solutions with %s poles in a period" % ("2" if n_bound == 2 else "2 to %d" % n_bound))
            elif n_bound >= 3:
                missing.append("solutions with 3 to %d poles in a period" % n_bound)
            if not cov["growth_ok"] and cov.get("ran"):
                missing.append("simply periodic solutions that grow exponentially at an end of the period strip")
            if not cov["poly_ok"] and cov.get("ran"):
                missing.append("rational solutions that grow at infinity")
            if not entire_ok:
                missing.append("transcendental solutions without poles")
            if not missing:
                missing.append("the completeness of the list was not established")
            text = prefix + _cap(head, prefix) + ". " + ("; ".join(done).capitalize() + ". " if done else "") + \
                "Not computed: " + "; ".join(missing) + "."
            for m in missing:
                _add_item(report, "not_decided", {"what": m, "why": "not computed in this run",
                                                  "partial": head + " (" + ", ".join(basis) + ")"})
            if cov["one_pole"]:
                _certificate_ruled_out(report, ws, symbolic, cov, conds)
    else:
        cov_ok = bool(ws) and cov.get("one_pole")
        if str(cls or "").startswith("entire"):
            level = "partial"
            text = prefix + _lower_first("No meromorphic solution has a pole. Solutions without poles: the ones "
                                         "listed; other transcendental solutions without poles are not decided.",
                                         prefix)
            report["verdict"] = {"level": level, "text": text, "basis": basis,
                                 "scope": ("generic parameter values" if scope_generic else
                                           ("all parameter values" if symbolic else "this equation")),
                                 "conditions": conds if scope_generic else []}
            if not any(it.get("kind") == "entire" for it in report["not_decided"]):
                _add_item(report, "not_decided", {
                    "kind": "entire", "what": "transcendental solutions without poles other than those listed",
                    "why": "the statements of the registry do not classify them for this equation",
                    "partial": "no meromorphic solution has a pole"})
            if conds_note:
                report["verdict"]["facts_used"] = conds_note
            _record_note(report, at)
            return
        elif found_nonconst or cov_ok:
            level = "partial"
            q = _qualifier(cov) if cov_ok else []
            text = prefix + _lower_first(
                "No theorem of the registry gives the class of all meromorphic solutions of this equation. "
                + ("All rational, simply periodic and elliptic solutions with %s in a period are listed%s; "
                   % ("one or two poles" if cov.get("two_pole") else "one pole",
                      " (%s)" % "; ".join(q) if q else "") if cov_ok else "The solutions listed were found; ")
                + "other meromorphic solutions are not decided.", prefix)
            if cov_ok:
                _certificate_ruled_out(report, ws, symbolic, cov, conds)
        else:
            level = "formal"
            text = prefix + _lower_first("Local analysis only: no theorem of the registry decides this equation, and "
                                         "no solution other than constants was found.", prefix)
        _add_item(report, "not_decided", {
            "what": "meromorphic solutions other than the ones listed (%s in a period; solutions that are "
                    % ("more than two poles" if (cov_ok and cov.get("two_pole")) else "several poles") +
                    "not rational, simply periodic or elliptic)",
            "why": "no theorem of the registry gives the class of all meromorphic solutions of this equation",
            "partial": "the local analysis restricts every meromorphic solution: pole orders, leading coefficients, "
                       "Fuchs indices and compatibility conditions are listed below"})
    full = _full_series(local, eq.K) if cls not in W_CLASSES and not str(cls or "").startswith("entire") else []
    if full and level in ("partial", "formal"):
        b0 = full[0]
        fact = ("The Laurent series at a pole of order %s%s contains %d arbitrary coefficients besides the position "
                "of the pole — the full number for an equation of order %d — and all its compatibility conditions "
                "hold identically." % (b0["p"], (" (leading coefficient $%s$)" % b0["a0_tex"]) if b0.get("a0_tex")
                                       else "", eq.K - 1, eq.K))
        text = text.rstrip() + " " + fact + " Whether these formal series are solutions meromorphic in the plane " \
            "is not decided here; if they are, the general solution is meromorphic and depends on %d constants." \
            % eq.K
        for it in report["not_decided"]:
            if str(it.get("what", "")).startswith("whether meromorphic solutions exist that are not rational"):
                prev = str(it.get("partial") or "").strip()
                it["partial"] = ((prev.rstrip(".") + ". ") if prev else "") + fact
        report["local"]["full_series"] = full
    report["verdict"] = {"level": level, "text": text, "basis": basis,
                         "scope": ("generic parameter values" if scope_generic else
                                   ("all parameter values" if symbolic else "this equation")),
                         "conditions": conds if scope_generic else []}
    if conds_note:
        report["verdict"]["facts_used"] = conds_note
    _record_note(report, at)


def _full_series(local, K):
    """balances whose Laurent series has K - 1 free coefficients with all compatibility conditions identically
    satisfied (the leading coefficient not free)"""
    out = []
    for b in (local or {}).get("balances") or []:
        free = b.get("free") or {}
        ok = b.get("conditions_identically_zero") or {}
        if K >= 3 and len(free) == K - 1 and all(ok.get(k) is True for k in free) and not b.get("a0_free") \
                and not b.get("truncated"):
            out.append({"p": b.get("p"), "a0": b.get("a0"), "a0_tex": b.get("a0_latex"),
                        "indices": sorted(int(k) for k in free)})
    return out


def _cap(s, prefix):
    return s if prefix else s[:1].upper() + s[1:]


def _lower_first(s, prefix):
    return (s[:1].lower() + s[1:]) if prefix else s


def _certificate_ruled_out(report, ws, symbolic, cov, conds):
    """for every form that the solver finished: what it excludes, with the scope of the form"""
    by = {}
    for c in (ws or {}).get("certificates") or []:
        npoles = len(c.get("poles") or [])
        if npoles not in (1, 2):
            continue
        if npoles == 2 and not cov.get("two_pole"):
            continue
        by.setdefault((c.get("kind"), npoles), []).append(c)
    extra = ["%s != 0" % a for a in cov.get("assumed_nonzero") or []]
    for (kind, npoles), cs in sorted(by.items(), key=lambda t: (t[0][1], str(t[0][0]))):
        n = sum(len(c.get("solutions") or []) for c in cs)
        orders = sorted(set(tuple(sorted(c["poles"])) for c in cs))
        scope = ""
        if kind == "simply-periodic" and not cov.get("growth_ok"):
            scope = " and finite limits at both ends of the period strip"
        if kind == "rational" and not cov.get("poly_ok"):
            scope = " and a finite limit at infinity"
        poles_txt = "one pole" if npoles == 1 else "two poles"
        if n == 0:
            what = "%s solutions with %s in a period%s" % (kind, poles_txt, scope)
        else:
            what = "%s solutions with %s in a period%s other than those listed" % (kind, poles_txt, scope)
            if symbolic:
                what += " (for parameter values outside the conditions of the listed families none exist"
                what += ("; assumed: %s)" % ", ".join(extra)) if extra else ")"
        _add_item(report, "ruled_out", {
            "what": what, "basis": {"theorem": None, "label": "certificate"},
            "certificate": {"type": "system", "detail": "the general form with %s (orders %s) was substituted and the "
                            "resulting polynomial system solved completely (%s)" %
                            (poles_txt, ", ".join(str(list(o)) for o in orders),
                             "; ".join(sorted(set(str(c.get("method", ""))[:120] for c in cs)))),
                            "scope": "; ".join(sorted(set(str(c.get("scope", "")) for c in cs)))[:400]},
            "conditions": list(dict.fromkeys(list(conds) + extra))})


def _record_note(report, at):
    """an earlier record with a completeness label that contains the equation: noted, never used to raise the level"""
    if not at:
        return
    summ = at.get("summary") or {}
    if summ.get("complete") and summ.get("by"):
        rec = summ["by"]
        label = None
        for m in at.get("matches") or []:
            if m.get("id") == rec:
                label = m.get("label")
        report["verdict"]["record"] = {
            "id": rec, "label": label or "agent-proof", "complete": True,
            "text": "An earlier record of the project (%s, label %s) states the complete list of meromorphic solutions "
                    "for this equation, in the record's own variables; it is shown under 'Earlier records' and was "
                    "not used for the level above." % (rec, label or "agent-proof")}


# ----------------------------------------------------------------------------------------------- changes of variables
def _atlas_found(report, at):
    """solutions with d >= 2 described in the earlier records that contain the equation exactly"""
    seen, seen_d = set(), set()
    matches = sorted(at.get("matches") or [], key=lambda m: (("@" in str(m.get("id"))) or ("COST" in str(m.get("id"))),
                                                               len(str(m.get("id")))))
    for m in matches:
        if m.get("match") != "exact" or m.get("kind") != "wave":
            continue
        site = m.get("site")
        if isinstance(site, str):
            try:
                site = json.loads(site)
            except Exception:
                site = None
        for sol in (site or {}).get("found") or []:
            d = sol.get("d")
            if not (isinstance(d, int) and d >= 2):
                continue
            desc = sol.get("description") or sol.get("closed_form_card") or ""
            if desc in seen or d in seen_d:
                continue
            seen.add(desc)
            seen_d.add(d)
            item = {"id": "rec%d" % (len(seen)), "kind": "other", "d": d, "expr": None,
                    "description": desc, "closed_form_record": sol.get("closed_form_card"),
                    "conditions": [], "free": [], "label": m.get("label") or "agent-proof",
                    "note": "from record %s of the project's earlier atlas, in the variables of the record "
                            "(change of variables: %s)" % (m.get("id"), json.dumps(m.get("change") or {})),
                    "certificate": {"type": "record", "status": "not-run",
                                    "detail": "described in the record; not derived again here"},
                    "origin": "atlas:%s" % m.get("id")}
            at.setdefault("described", []).append(item)


def _solve_conditions(conds, params):
    """conditions of the form 'expr = 0' and 'expr != 0' -> list of substitutions {param: value} (branches)"""
    eqs, neq = [], []
    for c in conds or []:
        c = str(c)
        if "!=" in c:
            neq.append(c)
            continue
        lhs = c.split("=")[0]
        rhs = c.split("=")[-1] if "=" in c else "0"
        try:
            e = sp.sympify(lhs, locals=dict((str(q), q) for q in params)) - \
                sp.sympify(rhs, locals=dict((str(q), q) for q in params))
        except Exception:
            return None, neq
        if e != 0:
            eqs.append(e)
    if not eqs:
        return [{}], neq
    syms = sorted(set().union(*[e.free_symbols for e in eqs]), key=str)
    # prefer to solve for the symbols that occur with the lowest degree
    best = None
    import itertools
    for k in range(len(eqs), 0, -1):
        for combo in itertools.combinations(syms, min(k, len(syms))):
            if len(combo) != len(eqs):
                continue
            try:
                sol = sp.solve(eqs, list(combo), dict=True)
            except Exception:
                sol = []
            sol = [br for br in sol if all(sp.simplify(e.subs(br)) == 0 for e in eqs)]
            if sol and all(not any(v.has(sp.RootOf) for v in br.values()) for br in sol):
                size = sum(sp.count_ops(v) for br in sol for v in br.values())
                if best is None or size < best[0]:
                    best = (size, sol)
        if best:
            break
    return (best[1] if best else None), neq


def _twists(report, eq, transform, ctx, mode, options, depth):
    """w = c + (kappa s)^p Y(s), s = exp(kappa z): solutions through an autonomous equation in s"""
    tws = _call(ctx, "exponential changes of variable", transform.exponential_twist, eq, _soft=True) or []
    special = _mod("special")
    verify = _mod("verify")
    if not tws or special is None or verify is None or not hasattr(verify, "verify_expr"):
        return
    out = []
    S = sp.Symbol("S_twist")
    for tw in tws[:3]:
        target = tw.get("equation")
        ex = (tw.get("map") or {}).get("_exact") or {}
        if target is None or not ex:
            continue
        branches, neq = _branches(ctx, tw.get("conditions"), eq.params)
        entry = {"map": dict((k, v) for k, v in (tw.get("map") or {}).items() if k != "_exact"),
                 "conditions": tw.get("conditions"), "note": tw.get("note"), "solutions": 0}
        out.append(entry)
        if branches is None:
            entry["status"] = "the conditions could not be solved for a parameter; no solution was built"
            continue
        sub = _call(ctx, "equation after the exponential change of variable", analyze, target, mode=mode,
                    reserved_names=list(ctx.get("reserved_names") or []),
                    budget_s=min(30.0, _left(ctx, 10.0)), _depth=depth + 1, atlas=False, strata=False, twist=False,
                    substitutions=False, darboux=False)
        if not sub:
            continue
        entry["target"] = sub.get("equation")
        entry["target_verdict"] = sub.get("verdict")
        loc = {"wp": getattr(special, "wp", None), "wpp": getattr(special, "wpp", None), "z": z}
        loc = dict((k, v) for k, v in loc.items() if v is not None)
        for ysol in sub.get("found") or []:
            if ysol.get("kind") in ("constant",) or not ysol.get("expr"):
                continue
            try:
                names = set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", ysol["expr"]))
                l2 = dict(loc)
                for nme in names:
                    if nme not in l2 and nme not in ("exp", "sqrt", "I", "pi", "tanh", "coth", "sinh", "cosh"):
                        l2[nme] = sp.Symbol(nme)
                Y = sp.sympify(ysol["expr"], locals=l2)
                for cname, cval in (ysol.get("constants") or {}).items():
                    if isinstance(cval, str) and not cval.startswith("free"):
                        Y = Y.subs(sp.Symbol(cname), sp.sympify(cval, locals=l2))
                if ysol.get("conditions"):
                    continue                       # the target has no parameters; a conditional solution is skipped
                Y = Y.subs(sp.Symbol("z0"), sp.Symbol("s0")).subs(z, S)
            except Exception:
                continue
            for br in branches:
                try:
                    kap = sp.sympify(ex["kappa"]).subs(br)
                    cc = sp.sympify(ex["c"]).subs(br)
                    pp = sp.sympify(ex["p"])
                    if sp.simplify(kap) == 0:
                        continue
                    bad = False
                    for c in neq:
                        lhs = sp.sympify(str(c).split("!=")[0], locals=dict((str(q), q) for q in eq.params))
                        if sp.simplify(lhs.subs(br)) == 0:
                            bad = True
                    if bad:
                        continue                       # the branch contradicts a condition of the change of variable
                    wexpr = cc + (kap * S) ** pp * Y
                    wexpr = wexpr.subs(S, sp.exp(kap * z))
                    if z not in wexpr.free_symbols:
                        continue
                    eq_b = eq.subs(br) if br else eq
                    chk = _call(ctx, "check of a solution built by a change of variable", verify.verify_expr, eq_b,
                                sp.sstr(wexpr), _timeout=30.0)
                except Exception as exc:
                    ctx["log"].append("twist: a candidate could not be checked: %s" % str(exc)[:200])
                    continue
                if (chk or {}).get("status") != "zero":
                    report["rejected"].append({"expr": sp.sstr(wexpr), "why": "substitution check: %s" %
                                               (chk or {}).get("status"), "origin": "live:twist"})
                    continue
                rational_in_s = ysol.get("kind") == "rational"
                if rational_in_s and ctx.get("one_pole_complete"):
                    entry["note2"] = "a solution rational in s gives a simply periodic solution; the solver lists " \
                                     "those itself"
                    continue
                conds = ["%s == %s" % (k, _s(v)) for k, v in br.items()] + [c.replace(" = ", " == ") if "!=" not in c
                                                                             else c for c in neq]
                item = {"kind": "simply-periodic" if rational_in_s else "other", "d": 1 if rational_in_s else 2,
                        "expr": sp.sstr(wexpr), "latex": sp.latex(wexpr),
                        "free": ["s0"] + [f for f in (ysol.get("free") or []) if f not in ("z0",)],
                        "conditions": conds,
                        "note": "w = c + (kappa s)^p Y(s) with s = exp(kappa z); Y(s) is a %s solution of %s"
                                % (ysol.get("kind"), (sub.get("equation") or {}).get("sympy")),
                        "certificate": {"type": "substitution", "method": "symbolic", "status": "pass",
                                        "detail": (chk or {}).get("detail", "exact substitution")},
                        "origin": "live:twist"}
                _add_found(report, item)
                entry["solutions"] += 1
    if out:
        report["twists"] = out


def _power_substitutions(report, eq, transform, ctx, mode, options, depth):
    """u = w^m when w has a balance of non-integer order: analyse the equation for u"""
    subs = _call(ctx, "power substitutions", transform.power_substitution, eq, _soft=True) or []
    out = []
    for sb in subs[:2]:
        target = sb.get("equation")
        if target is None or _left(ctx) < 5.0:
            continue
        sub = _call(ctx, "equation after the substitution %s" % (sb.get("map") or {}).get("u", ""), analyze, target,
                    reserved_names=list(ctx.get("reserved_names") or []),
                    mode=mode, budget_s=min(40.0, _left(ctx, 2.0)), _depth=depth + 1, atlas=False, strata=False,
                    twist=False, substitutions=False, darboux=False)
        if not sub:
            continue
        out.append({"name": sb.get("name"), "map": sb.get("map"), "note": sb.get("note"),
                    "conditions": sb.get("conditions"), "equation": sub.get("equation"),
                    "verdict": sub.get("verdict"), "found": sub.get("found"), "ruled_out": sub.get("ruled_out"),
                    "not_decided": sub.get("not_decided"), "local": sub.get("local")})
    if out:
        report["substitutions"] = out
        v = report["verdict"]
        best = out[0]
        v["after_substitution"] = {"map": best.get("map"), "level": (best.get("verdict") or {}).get("level"),
                                   "text": (best.get("verdict") or {}).get("text"),
                                   "found": len([x for x in (best.get("found") or []) if x.get("kind") != "constant"])}


def _drop_degenerate(report, eq):
    """found items that live on a parameter locus where the equation loses order or degree are not listed:
    there the visitor's equation is a different equation"""
    params = dict((str(q), q) for q in eq.params)
    if not params:
        return
    cache, keep, loci = {}, [], []
    for it in report["found"]:
        subs = {}
        for c in it.get("conditions") or []:
            c = str(c)
            if "==" not in c:
                continue
            a, b = [x.strip() for x in c.split("==", 1)]
            if a in params:
                try:
                    val = sp.sympify(b, locals=params)
                except Exception:
                    continue
                if not (val.free_symbols - set(params.values())) and params[a] not in val.free_symbols:
                    subs[params[a]] = val
        key = tuple(sorted((str(k), sp.sstr(v)) for k, v in subs.items()))
        if not key:
            keep.append(it)
            continue
        if key not in cache:
            try:
                cache[key] = _degenerate(eq, eq.subs(subs))
            except Exception:
                cache[key] = False
        if cache[key]:
            txt = " and ".join("%s = %s" % kv for kv in key)
            if txt not in loci:
                loci.append(txt)
        else:
            keep.append(it)
    if loci:
        report["found"] = keep
        report["degenerate_loci"] = {
            "loci": loci,
            "note": "on these parameter loci the equation has lower order or lower degree (a coefficient of a "
                    "leading term vanishes); it is then a different equation, and its solutions are not listed here"}


_FAST_ONLY = [False]      # True in the browser: no general solving of parameter conditions without a time limit


def _locus_point(conds, params, rnd, tries=4):
    """a numeric point of the parameter space on which the equalities among `conds` hold and the inequalities too
    ({symbol: number}), or None"""
    conds = [str(c) for c in conds or []]
    eqs = [c for c in conds if "==" in c]
    loc = dict((str(q), q) for q in params)
    brs = None
    # fast path: every equality reads "parameter == expression in the other parameters"
    direct = {}
    for c in eqs:
        m = re.match(r"^\s*([A-Za-z_][A-Za-z_0-9]*)\s*==\s*(.+)$", c)
        if not m or m.group(1) not in loc or loc[m.group(1)] in direct:
            direct = None
            break
        try:
            val = sp.sympify(m.group(2), locals=loc)
        except Exception:
            direct = None
            break
        if loc[m.group(1)] in val.free_symbols or (val.free_symbols & set(direct)):
            direct = None
            break
        direct[loc[m.group(1)]] = val
    if direct is not None:
        # a value may contain a parameter that is fixed by an earlier condition only if that one is substituted
        if not any(v.free_symbols & set(direct) for v in direct.values()):
            brs = [direct]
    if brs is None and not _FAST_ONLY[0]:
        try:
            brs, _neq = _solve_conditions(eqs, params) if eqs else ([{}], [])
        except Exception:
            brs = None
    for br in (brs or [])[:2]:
        for _ in range(tries):
            vals = dict((q, sp.Rational(rnd.randint(2, 40), rnd.randint(3, 17)) * rnd.choice([1, -1]))
                        for q in params if q not in br)
            try:
                cand = dict(vals)
                for q, val in br.items():
                    cand[q] = sp.N(sp.sympify(val).subs(vals), 40)
                if all(abs(complex(x)) < 1e12 for x in cand.values()) and \
                        all(_cond_holds(c, cand, loc) is not False for c in conds):
                    return cand
            except Exception:
                continue
    return None


def _drop_degenerate_points(report, eq, ctx):
    """found items whose conditions (several equalities, not of the form parameter == value) put them on a locus
    where the equation loses order or degree: decided at a numeric point of the locus"""
    import random
    params = list(eq.params)
    pnames = set(str(q) for q in params)

    def par_eqs(it):
        """the equalities of an item that involve the equation's parameters only"""
        out = []
        for c in it.get("conditions") or []:
            c = str(c)
            if "==" not in c:
                continue
            names = set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", c)) - {"sqrt", "I", "pi", "exp"}
            if names and names <= pnames:
                out.append(c)
        return tuple(sorted(out))
    items = [(i, it) for i, it in enumerate(report["found"]) if len(par_eqs(it)) >= 2]
    if not items or not params:
        return
    seen = {}
    todo = []
    for i, it in items:
        key = par_eqs(it)
        if key not in seen:
            seen[key] = None
            todo.append(key)
    cheap = set()
    try:
        d0 = max(sum(m) for m in eq.terms)
        top_o = [c for m, c in eq.terms.items() if m[eq.K] > 0]
        top_d = [c for m, c in eq.terms.items() if sum(m) == d0]
        ploc = dict((str(q), q) for q in params)
        for key in todo:
            es = []
            for c in key:
                a, b = c.split("==", 1)
                es.append(sp.numer(sp.together(sp.sympify(a, locals=ploc) - sp.sympify(b, locals=ploc))))
            vals = {}
            for _ in range(8):
                progress = False
                for e in es:
                    e2 = sp.expand(e.subs(vals))
                    if e2 == 0:
                        continue
                    for q in sorted(e2.free_symbols, key=str):
                        P = sp.Poly(e2, q)
                        if P.degree() == 1 and not P.LC().free_symbols and q not in vals:
                            vals[q] = sp.cancel(-P.TC() / P.LC())
                            vals = dict((k, sp.cancel(sp.sympify(v_).subs({q: vals[q]})) if k != q else v_)
                                        for k, v_ in vals.items())
                            progress = True
                            break
                if not progress:
                    break
            if vals and (all(sp.expand(sp.sympify(c).subs(vals)) == 0 for c in top_o) or
                         all(sp.expand(sp.sympify(c).subs(vals)) == 0 for c in top_d)):
                cheap.add(tuple(key))
    except Exception as exc:
        ctx["log"].append("degenerate loci (substitution): %s" % str(exc)[:200])
    todo = [k for k in todo if tuple(k) not in cheap]
    terms = dict((m, sp.sstr(c)) for m, c in eq.terms.items())
    res = _call(ctx, "degenerate loci of listed solutions", _degenerate_points, terms, [list(k) for k in todo],
                [str(q) for q in params], eq.K, _timeout=30.0, _min=20.0)
    bad = set(cheap)
    if res:
        bad |= set(tuple(k) for k, flag in zip(todo, res) if flag)
    if not bad:
        return
    keep = []
    dl = report.setdefault("degenerate_loci", {
        "loci": [],
        "note": "on these parameter loci the equation has lower order or lower degree (a coefficient of a "
                "leading term vanishes); it is then a different equation, and its solutions are not listed here"})
    for it in report["found"]:
        key = par_eqs(it)
        if key in bad:
            txt = ", ".join(key)
            if txt not in dl["loci"]:
                dl["loci"].append(txt)
        else:
            keep.append(it)
    report["found"] = keep


def _degenerate_points(terms, cond_lists, param_names, K):
    import random
    rnd = random.Random(7)
    params = [sp.Symbol(n) for n in param_names]
    loc = dict((n, q) for n, q in zip(param_names, params))
    coeffs = dict((m, sp.sympify(c, locals=loc)) for m, c in terms.items())
    d0 = max(sum(m) for m in coeffs)
    top_order = [c for m, c in coeffs.items() if m[K] > 0]
    top_degree = [c for m, c in coeffs.items() if sum(m) == d0]
    t_end = time.time() + 14.0
    out = [None] * len(cond_lists)
    # first the algebraic test for every list (fast): the leading coefficients reduce to zero modulo the equalities
    for i, conds in enumerate(cond_lists):
        try:
            gens = []
            for c in conds:
                a, b = str(c).split("==", 1)
                gens.append(sp.numer(sp.together(sp.sympify(a, locals=loc) - sp.sympify(b, locals=loc))))
            if gens and all(g.is_polynomial(*params) and g.free_symbols <= set(params) for g in gens):
                G = sp.groebner(gens, *params, order="grevlex")

                def in_ideal(cs):
                    return bool(cs) and all(G.reduce(sp.expand(sp.numer(sp.together(c))))[1] == 0 for c in cs)
                if in_ideal(top_order) or in_ideal(top_degree):
                    out[i] = True
        except Exception:
            pass
    # then, while time is left, the numeric test at a point of the locus
    for i, conds in enumerate(cond_lists):
        if out[i] is not None:
            continue
        if time.time() > t_end:
            out[i] = False
            continue
        pt = _locus_point(conds, params, rnd)
        if pt is None:
            out[i] = False
            continue

        def zero(cs):
            try:
                return all(abs(complex(sp.N(c.subs(pt), 30))) < 1e-12 for c in cs)
            except Exception:
                return False
        out[i] = bool(zero(top_order) or zero(top_degree))
    return out


def _copies(found, param_names, limit_s=20.0):
    """indices of found items that repeat another item: the same function (after its conditions are substituted)
    as an item with fewer conditions, or the same function with other names for the free constants.  Decided
    numerically at random points; an item is dropped only if a more general or earlier item covers it."""
    import random
    rnd = random.Random(11)
    params = [sp.Symbol(n) for n in param_names]
    loc = dict((n, q) for n, q in zip(param_names, params))
    z = sp.Symbol("z")
    funcs = {}
    special = _mod("special")

    def build(it):
        expr = it.get("expr")
        if not expr or it.get("kind") == "constant" or len(str(expr)) > 600:
            return None
        names = set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", str(expr)))
        if names & {"wp", "wpp", "zeta_w", "RootOf", "any"}:
            return None                      # elliptic forms and implicit constants are not compared here
        try:
            l2 = dict(loc)
            l2["z"] = z
            e = sp.sympify(str(expr), locals=l2)
            consts = it.get("constants") or {}
            for _ in range(3):
                sub = {}
                for k, val in consts.items():
                    ks = sp.Symbol(str(k))
                    if ks in e.free_symbols:
                        desc = str(val).strip().lower()
                        if desc.startswith(("free", "arbitrary")):
                            continue                    # a free constant: stays a symbol
                        if not re.match(r"^[-+0-9A-Za-z_*/(). ]+$", str(val)) or \
                                desc.startswith(("any", "a root", "root", "one of", "the ")):
                            return None                 # a constant given in words: the item is not compared
                        try:
                            vv = sp.sympify(str(val), locals=l2)
                        except Exception:
                            return None
                        if not isinstance(vv, sp.Expr):
                            return None
                        sub[ks] = vv
                if not sub:
                    break
                e = e.subs(sub)
            return e
        except Exception:
            return None

    t_end = time.time() + float(limit_s)
    exprs = [build(it) for it in found]
    conds = [[_norm_cond(c) for c in (it.get("conditions") or [])] for it in found]
    drop = []
    points = {}
    for i, it in enumerate(found):
        if exprs[i] is None or i in drop:
            continue
        if time.time() > t_end:
            break
        pkey = tuple(sorted(conds[i]))
        if pkey not in points:
            points[pkey] = _locus_point(it.get("conditions"), params, rnd)
        pt = points[pkey]
        if pt is None:
            continue
        for j, other in enumerate(found):
            if j == i or exprs[j] is None or j in drop or other.get("kind") != it.get("kind"):
                continue
            ci, cj = set(conds[i]), set(conds[j])
            # j covers i if the conditions of j hold on the locus of i (at a numeric point of it) and either the
            # locus of j is larger, or the two loci are the same and j comes first
            if not (cj < ci or (cj == ci and j < i)):
                cjl = [str(c) for c in other.get("conditions") or []]
                if not all(_cond_holds(c, pt, loc) is True for c in cjl):
                    continue
                ne_i = len([c for c in conds[i] if c.startswith("==")])
                ne_j = len([c for c in conds[j] if c.startswith("==")])
                if not (ne_j < ne_i or (ne_j == ne_i and j < i)):
                    continue
            fi, fj = exprs[i], exprs[j]
            free_i = sorted((fi.free_symbols - set(params)) - {z}, key=str)
            free_j = sorted((fj.free_symbols - set(params)) - {z}, key=str)
            if len(free_i) != len(free_j):
                continue
            import itertools
            # the free constants of the two items are matched by name, or else in every order (at most three)
            if set(free_i) == set(free_j):
                orders = [list(free_i)]
            elif len(free_j) <= 3:
                orders = [list(o) for o in itertools.permutations(free_j)]
            else:
                orders = [list(free_j)]
            same = False
            for order_j in orders:
                same = True
                for _ in range(3):
                    vals = dict(pt)
                    vals[z] = sp.Rational(rnd.randint(3, 50), rnd.randint(7, 23))
                    cv = [sp.Rational(rnd.randint(3, 50), rnd.randint(7, 23)) for _ in free_i]
                    vi = dict(vals)
                    vi.update(zip(free_i, cv))
                    vj = dict(vals)
                    vj.update(zip(order_j, cv))
                    try:
                        a = complex(sp.N(fi.subs(vi), 30))
                        b = complex(sp.N(fj.subs(vj), 30))
                    except Exception:
                        same = False
                        break
                    if not (abs(a - b) <= 1e-12 * (1.0 + abs(a) + abs(b))):
                        same = False
                        break
                if same:
                    break
            if same:
                drop.append(i)
                break
    return drop


def _confirm_drops(found, drop, kept_by, param_names, limit_s=25.0):
    """the removals proposed by mero.dedupe that pass a second, independent test of the parameter values: at two
    numeric points of the dropped item's conditions every condition of the keeping item holds"""
    import random
    rnd = random.Random(97)
    t_end = time.monotonic() + float(limit_s)
    params = [sp.Symbol(n) for n in param_names]
    loc = dict((n, q) for n, q in zip(param_names, params))
    pset = set(param_names)

    def idents(c):
        return set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", c)) - {"sqrt", "I", "pi", "exp"}

    def size(i):
        return sum(len(str(c)) for c in (found[i].get("conditions") or [])) if 0 <= i < len(found) else 0
    ok = []
    for i in sorted(drop, key=size):                     # the simple ones first: the step has a deadline
        if time.monotonic() > t_end:
            break
        j = kept_by.get(i)
        if j is None or not (0 <= j < len(found)) or not (0 <= i < len(found)):
            continue
        ci = [str(c) for c in found[i].get("conditions") or []]
        cj = [str(c) for c in found[j].get("conditions") or []]
        # a constant that is free in the dropped item must not be fixed in the keeper
        ki, kj = found[i].get("constants") or {}, found[j].get("constants") or {}
        free_i = set(str(x) for x in found[i].get("free") or []) | \
            set(str(k) for k, v_ in ki.items() if str(v_).startswith("free"))
        if any(str(name) in free_i and not str(val).startswith(("free", "any")) for name, val in kj.items()):
            continue
        if set(_canon_conds(cj)) <= set(_canon_conds(ci)):
            ok.append(i)                                 # every condition of the keeper is one of the dropped item
            continue
        have = set(_norm_cond(c) for c in ci)
        refuse = False
        for c in cj:
            names = idents(c)
            if names <= pset:
                continue                                 # a condition in the parameters: tested at points below
            if _norm_cond(c) in have:
                continue                                 # the dropped item carries the same condition
            if re.fullmatch(r"\s*[A-Za-z_][A-Za-z_0-9]*\s*!=\s*0\s*", c) and not (names & pset):
                continue                                 # "K != 0" on a constant of the keeper
            refuse = True                                # another condition on constants that the dropped item lacks
            break
        if not refuse:
            # a constant that is free in the dropped item must not be fixed in the keeper
            ki, kj = found[i].get("constants") or {}, found[j].get("constants") or {}
            free_i = set(str(x) for x in found[i].get("free") or []) | \
                set(str(k) for k, v_ in ki.items() if str(v_).startswith("free"))
            for name, val in kj.items():
                if str(name) in free_i and not str(val).startswith(("free", "any")):
                    refuse = True
                    break
        if refuse:
            continue
        cj_par = [c for c in cj if idents(c) <= pset]
        ci_par = [c for c in ci if idents(c) <= pset]
        if not cj_par:
            ok.append(i)
            continue
        pts = _locus_points(ci_par, params, rnd)        # two points on every branch of the dropped item's values
        if not pts or not all(all(_cond_holds(c, pt, loc) is True for c in cj_par) for pt in pts):
            continue
        # an inequality of the keeper must hold on ALL the dropped item's values, not only at random points
        new_ineq = [c for c in cj_par if "!=" in c and " or " not in c and _norm_cond(c) not in have]
        if new_ineq and not _ineqs_implied(new_ineq, ci_par, params):
            continue
        ok.append(i)
    return ok


def _ineqs_implied(ineqs, conds, params):
    """True if every inequality g != 0 of `ineqs` holds at every parameter value that satisfies `conds`: on each
    branch of the solved equalities of `conds`, g is a nonzero number or every factor of g is a factor of one of
    the inequalities of `conds`.  False when this cannot be shown."""
    loc = dict((str(q), q) for q in params)
    eqs = [c for c in conds if "==" in c and " or " not in c]
    try:
        brs = _solve_conditions(eqs, params)[0] if eqs else [{}]
    except Exception:
        return False
    if not brs:
        return False

    def expr(c, op):
        a, b = c.split(op, 1)
        return sp.sympify(a, locals=loc) - sp.sympify(b, locals=loc)

    def factors(e):
        e = sp.together(e)
        out = set()
        for part in (sp.numer(e), sp.denom(e)):
            for f, _m in sp.factor_list(part)[1]:
                if f.free_symbols:
                    try:
                        out.add(sp.Poly(f, *sorted(f.free_symbols, key=str)).monic().as_expr())
                    except Exception:
                        out.add(f)
        return out
    try:
        base = set()                              # nonzero on all the values: the factors of the inequalities as
        for c in conds:                           # written, and the denominators of the equalities
            if " or " in c:
                continue
            if "!=" in c:
                base |= factors(expr(c, "!="))
            elif "==" in c:
                d_ = sp.denom(sp.together(expr(c, "==")))
                if d_.free_symbols:
                    base |= factors(d_)
        for br in brs[:6]:
            have = set(base)
            for c in conds:
                if "!=" in c and " or " not in c:
                    have |= factors(expr(c, "!=").subs(br))
            for g in ineqs:
                e = sp.simplify(expr(g, "!=").subs(br))
                if e == 0:
                    return False
                if not e.free_symbols:
                    continue
                if not factors(e) <= have:
                    return False
    except Exception:
        return False
    return True


def _locus_points(conds, params, rnd, per_branch=2, max_branches=6):
    """numeric points of the parameter values described by `conds`: `per_branch` points on every branch of the
    solved equalities (a**2 == 1 has two branches, a*b == 0 has two); [] if a branch has no point or the
    conditions cannot be solved"""
    conds = [str(c) for c in conds or []]
    eqs = [c for c in conds if "==" in c and " or " not in c]
    if not eqs:
        out = [_locus_point(conds, params, rnd) for _ in range(per_branch)]
        return [] if any(x is None for x in out) else out
    try:
        brs, _neq = _solve_conditions(eqs, params)
    except Exception:
        brs = None
    if not brs:
        return []
    loc = dict((str(q), q) for q in params)
    out = []
    for br in brs[:max_branches]:
        got = 0
        for _try in range(4 * per_branch):
            vals = dict((q, sp.Rational(rnd.randint(2, 40), rnd.randint(3, 17)) * rnd.choice([1, -1]))
                        for q in params if q not in br)
            try:
                cand = dict(vals)
                for q, val in br.items():
                    cand[q] = sp.N(sp.sympify(val).subs(vals), 40)
                if not all(abs(complex(x)) < 1e12 for x in cand.values()):
                    continue
            except Exception:
                continue
            if all(_cond_holds(c, cand, loc) is not False for c in conds):
                out.append(cand)
                got += 1
                if got >= per_branch:
                    break
        if got == 0:
            # a branch without an admissible point (its inequalities fail everywhere on it) is not a branch
            continue
    return out


def _locus_text(polys, pset):
    """'p = v and q = u' for the common zeros of polynomials in the parameters (each written as 'p = value' when
    it is linear in one parameter that the value does not contain, as 'f = 0' otherwise)"""
    parts = []
    for f in polys:
        f = sp.factor(f)
        done = False
        for q in sorted(f.free_symbols & pset, key=str):
            try:
                P = sp.Poly(f, q)
            except Exception:
                continue
            if P.degree() == 1 and not (P.all_coeffs()[0].free_symbols):
                parts.append("%s = %s" % (q, _s(sp.simplify(-P.all_coeffs()[1] / P.all_coeffs()[0]))))
                done = True
                break
        if not done:
            parts.append("%s = 0" % _s(f))
    return " and ".join(sorted(set(parts)))


def _equation_degenerate_loci(report, eq):
    """the parameter values at which the equation itself has lower order or lower degree, read from its
    coefficients: every coefficient of a term with the highest derivative vanishes, or every coefficient of a term
    of top degree.  They are added to `degenerate_loci` (the verdict then says "at which the equation keeps its
    order and degree"), unless a coefficient is a nonzero number."""
    pset = set(eq.params)
    if not pset:
        return
    K = eq.K
    top = max(sum(m) for m in eq.terms)
    groups = [[c for m, c in eq.terms.items() if m[K] > 0], [c for m, c in eq.terms.items() if sum(m) == top]]
    single, joint = [], []
    for cs in groups:
        cs = [sp.factor(sp.sympify(c)) for c in cs if c != 0]
        if not cs or any(not (c.free_symbols & pset) for c in cs):
            continue
        # the common zeros: the factors of the greatest common divisor (hypersurfaces), then what is left
        g = cs[0]
        for c in cs[1:]:
            g = sp.gcd(g, c)
        for f, _m in sp.factor_list(g)[1]:
            if f.free_symbols & pset:
                single.append(_locus_text([f], pset))
        if len(cs) == 1:
            continue
        rest = []
        for c in cs:
            fs = [f for f, _m in sp.factor_list(sp.cancel(c / g))[1] if f.free_symbols & pset]
            if not fs:
                rest = None                        # this coefficient vanishes only on the hypersurfaces above
                break
            rad = sp.Mul(*fs)
            if rad not in rest:
                rest.append(rad)
        if rest:
            joint.append(_locus_text(rest, pset))
    single = list(dict.fromkeys(single))
    loci = list(single)
    for t in dict.fromkeys(joint):
        parts = t.split(" and ")
        if any(q in single for q in parts):
            continue                               # inside a hypersurface that is named
        loci.append(t if len(t) <= 100 else "the common zeros of the coefficients of the leading terms "
                                            "(%d equations in the parameters)" % len(parts))
    if not loci:
        return
    dl = report.setdefault("degenerate_loci", {
        "loci": [],
        "note": "on these parameter loci the equation has lower order or lower degree (a coefficient of a "
                "leading term vanishes); it is then a different equation, and its solutions are not listed here"})
    have = set(str(x).replace(" ", "") for x in dl.get("loci") or [])
    for t in loci:
        if t.replace(" ", "") not in have:
            dl["loci"].append(t)
            have.add(t.replace(" ", ""))


def _prune_degenerate_loci(report):
    """a locus that lies inside another locus of the list ("a = 0 and c = 0" inside "a = 0") is not named twice"""
    dl = report.get("degenerate_loci")
    if not isinstance(dl, dict):
        return
    loci = [str(x) for x in dl.get("loci") or []]
    parts = [frozenset(q.replace(" ", "") for q in t.split(" and ")) for t in loci]
    keep = []
    for i, t in enumerate(loci):
        if any(j != i and parts[j] < parts[i] for j in range(len(loci))):
            continue
        if any(j < i and parts[j] == parts[i] for j in range(len(loci))):
            continue
        keep.append(t)
    dl["loci"] = keep


def _fix_pole_labels(report):
    """a listed family whose formula has no z in a denominator has no pole: `poles_per_period` 0 (families such as
    c + exp(z)/K were labelled with one pole in a period)"""
    zz = sp.Symbol("z")
    for it in report["found"]:
        ex = it.get("expr")
        if not ex or not it.get("poles_per_period") or len(str(ex)) > 300 or \
                it.get("kind") not in ("simply-periodic", "rational", "other", "polynomial"):
            continue
        if re.search(r"wp|zeta|sigma|tan|cot|sec|csc|coth|sech|csch|tanh|bessel|airy|gamma", str(ex)):
            continue
        try:
            names = set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", str(ex))) - {"exp", "sqrt", "I", "pi", "z", "log"}
            e = sp.sympify(str(ex), locals=dict([(n, sp.Symbol(n)) for n in names] + [("z", zz)]))
            den = sp.denom(sp.together(e.rewrite(sp.exp)))
            # an exponential does not vanish: only the other factors of the denominator can give poles
            rest = [f for f in sp.Mul.make_args(sp.factor(den))
                    if zz in f.free_symbols and not (f.func is sp.exp or (f.is_Pow and f.base.func is sp.exp))]
        except Exception:
            continue
        if not rest:
            it["poles_per_period"] = 0
            it["pole_orders"] = []


def _simple_point(conds, params, rnd, tries=4):
    """a numeric point of the parameter values described by `conds` when every equality reads "parameter ==
    expression in the other parameters" (chains are substituted into each other); None otherwise.  No general
    solving: this is used where a step must not run long."""
    loc = dict((str(q), q) for q in params)
    sub = {}
    for c in conds:
        c = str(c)
        if "==" not in c or " or " in c:
            continue
        m = re.match(r"^\s*([A-Za-z_][A-Za-z_0-9]*)\s*==\s*(.+)$", c)
        if not m or m.group(1) not in loc or loc[m.group(1)] in sub:
            return None
        try:
            val = sp.sympify(m.group(2), locals=loc)
        except Exception:
            return None
        if loc[m.group(1)] in val.free_symbols or (val.free_symbols - set(params)):
            return None
        sub[loc[m.group(1)]] = val
    for _ in range(4):
        sub = dict((k, sp.sympify(v_).subs(sub)) for k, v_ in sub.items())
    if any(sp.sympify(v_).free_symbols & set(sub) for v_ in sub.values()):
        return None
    for _ in range(tries):
        vals = dict((q, sp.Rational(rnd.randint(2, 40), rnd.randint(3, 17)) * rnd.choice([1, -1]))
                    for q in params if q not in sub)
        try:
            cand = dict(vals)
            for q, val in sub.items():
                cand[q] = sp.N(sp.sympify(val).subs(vals), 40)
            if not all(abs(complex(x)) < 1e12 for x in cand.values()):
                continue
        except Exception:
            continue
        if all(_cond_holds(c, cand, loc) is not False for c in conds):
            return cand
    return None


def _name_degenerate_loci(report):
    """every locus of `degenerate_loci` also stands under "not decided" (kind degenerate-locus): there the page
    says nothing about the solutions, and the visitor is told how to get them"""
    dl = report.get("degenerate_loci")
    if not isinstance(dl, dict):
        return
    have = set()
    named = set(frozenset(q.replace(" ", "") for q in str(t).split(" and ")) for t in dl.get("loci") or [])
    v_ = report.get("verdict") or {}
    if named and v_.get("scope") == "all parameter values":
        v_["scope"] = "the parameter strata listed"      # not all values: the degenerate loci are excluded
    for it in report["not_decided"]:
        key_ = frozenset(str(c).replace(" ", "").replace("==", "=") for c in it.get("conditions") or [])
        if it.get("kind") == "parameter-locus" and key_ and key_ in named and \
                str(it.get("what", "")).startswith("parameter values with"):
            # the same locus as a degenerate one: one statement about it
            it["kind"], it["degenerate"] = "degenerate-locus", True
            it["what"] = "the degenerate stratum %s" % " and ".join(str(c) for c in it["conditions"])
            it["why"] = "on these values it is a different equation; its solutions are not listed on this page"
            it["partial"] = "enter the equation with these values to have it analysed"
    for it in report["not_decided"]:
        if it.get("kind") == "degenerate-locus" or it.get("degenerate"):
            have.add(frozenset(str(c).replace(" ", "").replace("==", "=") for c in it.get("conditions") or []))
        m = re.match(r"^the degenerate stratum\s+(.+)$", str(it.get("what", "")))
        if m:                                      # the same kind of item, written by an earlier step
            it["kind"] = it.get("kind") or "degenerate-locus"
            it["degenerate"] = True
            if not it.get("partial"):
                it["partial"] = "enter the equation with these values to have it analysed"
            if not it.get("conditions"):
                it["conditions"] = [q.strip() for q in m.group(1).split(" and ")]
            have.add(frozenset(str(c).replace(" ", "").replace("==", "=") for c in it.get("conditions") or []))
    for t in dl.get("loci") or []:
        t = str(t)
        if " = " not in t:
            continue
        parts = [q.strip() for q in t.split(" and ")]
        key = frozenset(q.replace(" ", "") for q in parts)
        if key in have:
            continue
        have.add(key)
        conds = [re.sub(r"\s=\s", " == ", q, count=1) for q in parts]
        _add_item(report, "not_decided", {
            "what": "the degenerate stratum %s" % " and ".join(conds),
            "kind": "degenerate-locus", "degenerate": True, "conditions": conds,
            "why": "on these values it is a different equation; its solutions are not listed on this page",
            "partial": "enter the equation with these values to have it analysed"})


def _refine_job(part, eq, limit_s):
    """`_refine_ruled_out` as a step: works on a copy of the lists and returns them"""
    rep_ = {"found": part.get("found") or [], "ruled_out": list(part.get("ruled_out") or []),
            "not_decided": list(part.get("not_decided") or []), "verdict": dict(part.get("verdict") or {}),
            "log": []}
    _refine_ruled_out(rep_, eq, limit_s)
    return {"ruled_out": rep_["ruled_out"], "not_decided": rep_["not_decided"], "verdict": rep_["verdict"],
            "log": rep_["log"]}


def _drop_empty_items(report, eq):
    """items that denote nothing: (1) a found item whose conditions in the parameters contradict each other (an
    inequality is zero or undefined once the item's own equalities are substituted); (2) a nonconstant found item
    whose formula does not contain z; (3) a not-decided parameter stratum whose equalities have no common
    solution, or whose solution is one of the strata that were analysed (also taken out of the scope record)."""
    params = list(eq.params)
    if not params:
        return
    loc = dict((str(q), q) for q in params)
    pset = set(loc)

    def idents(c):
        return set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", str(c))) - {"sqrt", "I", "pi", "exp", "or"}

    def contradictory(conds):
        conds = [str(c) for c in conds or [] if idents(c) and idents(c) <= pset and " or " not in str(c)]
        sub = {}
        for c in conds:
            if "==" in c:
                a, b = [x.strip() for x in c.split("==", 1)]
                if a in loc:
                    try:
                        val = sp.sympify(b, locals=loc)
                    except Exception:
                        continue
                    if loc[a] not in val.free_symbols:
                        sub[loc[a]] = val
        if not sub:
            return False
        try:
            for _ in range(3):
                sub = dict((k, sp.sympify(v_).subs(sub)) for k, v_ in sub.items())
            for c in conds:
                if "!=" not in c:
                    continue
                a, b = c.split("!=", 1)
                e = (sp.sympify(a, locals=loc) - sp.sympify(b, locals=loc)).subs(sub)
                if e.has(sp.zoo, sp.nan, sp.oo, -sp.oo):
                    return True
                if not e.free_symbols and sp.simplify(e) == 0:
                    return True
                if e.free_symbols and sp.simplify(e) == 0:
                    return True
        except Exception:
            return False
        return False

    keep = []
    for it in report["found"]:
        try:
            if contradictory(it.get("conditions")):
                continue
            if it.get("kind") not in ("constant", None) and it.get("expr") and len(str(it["expr"])) < 400 and \
                    not re.search(r"(?<![A-Za-z_0-9])z(?![A-Za-z_0-9])", str(it["expr"])):
                continue
        except Exception:
            pass
        keep.append(it)
    report["found"] = keep

    def canon(conds):
        """the solved form of a set of equalities in the parameters: frozenset of 'p == v' texts, 'empty' if they
        have no common solution, None if not decided"""
        exprs = []
        for c in conds:
            c = str(c)
            if "==" not in c or " or " in c or not (idents(c) <= pset) or len(c) > 120:
                return None
            a, b = c.split("==", 1)
            try:
                exprs.append(sp.sympify(a, locals=loc) - sp.sympify(b, locals=loc))
            except Exception:
                return None
        exprs = [e for e in exprs if e != 0]
        if not exprs:
            return None
        if any(not e.free_symbols for e in exprs):
            return "empty"
        syms = sorted(set().union(*[e.free_symbols for e in exprs]), key=str)
        try:
            if not all(e.is_polynomial(*syms) for e in exprs):
                return None
            sol = sp.solve(exprs, syms, dict=True)
        except Exception:
            return None
        if not sol:
            return "empty"
        if len(sol) != 1:
            return None
        return frozenset("%s == %s" % (k, _s(v_)) for k, v_ in sol[0].items())

    v = report.get("verdict") or {}
    sd = v.get("scope_detail") if isinstance(v.get("scope_detail"), dict) else {}
    explored = set()
    for t in sd.get("explored_strata") or []:
        c_ = canon([x for x in re.split(r"\s+and\s+", str(t)) if "==" in x])
        if isinstance(c_, frozenset):
            explored.add(c_)
    keep, gone = [], 0
    for it in report["not_decided"]:
        if it.get("kind") in ("parameter-locus", "degenerate-locus") and it.get("conditions"):
            eqs_ = [str(c) for c in it["conditions"] if "==" in str(c)]
            if len(eqs_) >= 2 and len(eqs_) == len(it["conditions"]):
                c_ = canon(eqs_)
                if c_ == "empty" or (isinstance(c_, frozenset) and c_ in explored):
                    gone += 1
                    continue
        keep.append(it)
    report["not_decided"] = keep
    if gone and sd.get("unexplored"):
        left = []
        for t in sd["unexplored"]:
            c_ = canon([x for x in re.split(r"\s+and\s+", str(t)) if "==" in x])
            if c_ == "empty" or (isinstance(c_, frozenset) and c_ in explored):
                continue
            left.append(t)
        sd["unexplored"] = left


def _refine_ruled_out(report, eq, limit_s=30.0):
    """A ruled-out item is printed with the parameter values on which it holds.
    (1) An item whose equalities put it on a locus where the equation loses order or degree is removed: nothing is
        listed there (it is a different equation), so "other than those listed" would be false as printed.
    (2) An item that excludes nonconstant solutions (or everything not listed) on a stratum, while an undecided
        parameter locus lies inside that stratum, gets the locus excluded from its conditions; the same for a
        listed nonconstant family inside the stratum of an item that excludes every nonconstant solution.  A
        listed family on the very same stratum contradicts such an item: the item is withdrawn, the stratum is
        named as not decided, and a "complete" verdict is lowered."""
    import random
    params = list(eq.params)
    if not params:
        return
    loc = dict((str(q), q) for q in params)
    pset = set(loc)
    rnd = random.Random(4711)
    t_end = time.monotonic() + float(limit_s)

    def idents(c):
        return set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", str(c))) - {"sqrt", "I", "pi", "exp", "or"}

    def par(conds):
        return [str(c) for c in conds or [] if idents(c) and idents(c) <= pset]

    def degenerate(conds):
        sub = {}
        for c in conds:
            if "==" not in c or " or " in c:
                continue
            a, b = [x.strip() for x in c.split("==", 1)]
            if a in loc:
                try:
                    val = sp.sympify(b, locals=loc)
                except Exception:
                    continue
                if loc[a] not in val.free_symbols:
                    sub[loc[a]] = val
        try:
            for _ in range(3):                     # values may contain parameters fixed by another equality
                sub = dict((k, sp.sympify(v_).subs(sub)) for k, v_ in sub.items())
            return bool(sub) and _degenerate(eq, eq.subs(sub))
        except Exception:
            return False

    keep = []
    for it in report["ruled_out"]:
        if degenerate(par(it.get("conditions"))):
            continue
        keep.append(it)
    report["ruled_out"] = keep

    inner = []
    for f in report["found"]:
        if f.get("kind") == "constant":
            continue
        pc = par(f.get("conditions"))
        if any("==" in c for c in pc):
            inner.append((pc, "found", len(pc) == len(f.get("conditions") or [])))
    for nd in report["not_decided"]:
        pc = par(nd.get("conditions"))
        if any("==" in c and " or " not in c for c in pc) and nd.get("kind") in ("parameter-locus",
                                                                                "degenerate-locus"):
            inner.append((pc, "open", True))
    points = {}
    inner.sort(key=lambda t_: sum(len(c) for c in t_[0]))        # the simple loci first: there is a deadline

    def point(pc):
        key = tuple(pc)
        if key not in points:
            if time.monotonic() > t_end or sum(len(c) for c in pc) > 700:
                return None                       # not decided in time: the item stays as the module wrote it
            try:
                points[key] = _simple_point(list(pc), params, rnd)
            except Exception:
                points[key] = None
        return points[key]

    withdrawn = []
    out = []
    for it in report["ruled_out"]:
        what = str(it.get("what", ""))
        excl_all = what.startswith("every nonconstant meromorphic solution") or \
            what.startswith("nonconstant meromorphic solutions of ")
        excl_rest = what.startswith(("meromorphic solutions other than", "nonconstant meromorphic solutions",
                                     "nonconstant solutions"))
        conds = [str(c) for c in it.get("conditions") or []]
        rc = par(conds)
        if not (excl_all or excl_rest) or len(rc) != len(conds):
            out.append(it)
            continue
        req = set(_norm_cond(c) for c in rc if "==" in c)
        add, clash = [], False
        for pc, kind, pure in inner:
            if kind == "found" and not excl_all:
                continue                           # "other than those listed" cannot contradict a listed family
            extra = [c for c in pc if "==" in c and " or " not in c and _norm_cond(c) not in req]
            if not set(rc) <= set(pc):             # (when every condition of the item is one of the locus, the
                pt = point(pc)                     # locus lies inside the item's stratum: no point is needed)
                if pt is None or not all(_cond_holds(c, pt, loc) is True for c in rc):
                    continue
            if not extra:
                if kind == "found" and pure:
                    clash = True
                continue
            neg = " or ".join(sorted(c.replace("==", "!=") for c in extra))
            if neg not in add and neg not in conds:
                add.append(neg)
        if clash:
            withdrawn.append(it)
            continue
        if add:
            it = dict(it, conditions=conds + add,
                      conditions_note="the special parameter values that are listed or named as not decided on "
                                      "this page are excluded")
        out.append(it)
    pname = "p" if "p" not in pset else "m"
    for it in out:
        if any("p_order" in str(c) for c in it.get("conditions") or []):
            it["conditions"] = [re.sub(r"\bp_order\b", pname, str(c)) for c in it["conditions"]]
    for it in out:
        w = str(it.get("what", ""))
        if w.endswith(" with h arbitrary"):
            it["what"] = w[:-len(" with h arbitrary")] + " (for every value of the constant h of the first integral)"
        else:
            m = re.match(r"^(.*) with h not in \{(.*)\}$", w)
            if m:
                it["what"] = "%s for values of the constant h of the first integral other than h = %s" % (
                    m.group(1), m.group(2).replace(", ", ", h = "))
    report["ruled_out"] = out
    v = report.get("verdict") or {}
    for it in withdrawn:
        rc = [str(c) for c in it.get("conditions") or []]
        report.setdefault("log", []).append(
            "a ruled-out item was withdrawn: a listed family lies on its parameter values (%s)"
            % (", ".join(rc) or "all values"))
        _add_item(report, "not_decided", {
            "what": "parameter values with %s" % (" and ".join(rc) if rc else "no condition (all values)"),
            "kind": "parameter-locus", "conditions": rc,
            "why": "two procedures disagree there: one excludes every nonconstant solution, the other lists one",
            "partial": "the listed solutions passed their substitution checks"})
        if v.get("level") in ("complete", "complete-W"):
            if any("==" in c for c in rc):
                v["overall"] = "complete-generic" if v.get("level") == "complete" else v.get("overall")
                v["special_min"] = "not analysed"
                if v.get("scope") != "generic parameter values":
                    v["scope"] = "generic parameter values"
            else:
                v["level"] = "partial"
                v["overall"] = "partial"
                v.pop("label", None)
                v.pop("label_rests_on", None)
                v["text"] = "The solutions listed were found and verified; the list is not known to be complete: " \
                            "two procedures disagree on the parameter values named under \"not decided\"."
    report["verdict"] = v


def _degenerate_strata_items(report, eq):
    """not-decided items of the form 'the stratum p == 0' for a locus where the equation loses order or degree"""
    params = dict((str(q), q) for q in eq.params)
    keep = []
    for it in report["not_decided"]:
        m = re.match(r"^the stratum\s+([A-Za-z_][A-Za-z_0-9]*)\s*==\s*(\S+)\s*$", str(it.get("what", "")))
        if m and m.group(1) in params:
            try:
                val = sp.sympify(m.group(2), locals=params)
                if _degenerate(eq, eq.subs({params[m.group(1)]: val})):
                    dl = report.setdefault("degenerate_loci", {
                        "loci": [],
                        "note": "on these parameter loci the equation has lower order or lower degree (a coefficient "
                                "of a leading term vanishes); it is then a different equation, and its solutions "
                                "are not listed here"})
                    txt = "%s = %s" % (m.group(1), m.group(2))
                    if txt not in dl["loci"]:
                        dl["loci"].append(txt)
                    continue
            except Exception:
                pass
        keep.append(it)
    report["not_decided"] = keep


def _degenerate(eq, sub_eq):
    """True if the specialised equation has lower order or lower degree than the original"""
    try:
        d0 = max(sum(m) for m in eq.terms)
        d1 = max(sum(m) for m in sub_eq.terms)
        return sub_eq.K < eq.K or d1 < d0
    except Exception:
        return False


# ----------------------------------------------------------------------------------------------- invariant surfaces
def _reduced_analysis(eq, red, br, mode, budget_s, depth, reserved=None):
    """build the reduced equation on an invariant surface and analyse it (runs inside a time-limited step)"""
    from mero.equation import Equation
    red_eq = Equation.from_dict(red)
    if br:
        if _degenerate(eq, eq.subs(br)):
            return {"degenerate": True}
        red_eq = red_eq.subs(br)
    return analyze(red_eq, mode=mode, budget_s=budget_s, _depth=depth + 1, atlas=False, strata=True, twist=False,
                   reserved_names=list(reserved or []),
                   substitutions=False, darboux=False)


def _conditions_step(conds, params):
    branches, neq = _solve_conditions(conds, params)
    if branches is None:
        return {"branches": None, "neq": neq}
    return {"branches": [dict((str(k), sp.sstr(v)) for k, v in br.items()) for br in branches], "neq": neq}


def _branches(ctx, conds, params):
    """conditions -> (list of substitutions or None, inequalities); time-limited"""
    if not conds:
        return [{}], []
    out = _call(ctx, "conditions of a special locus", _conditions_step, conds, params, _timeout=20.0)
    if not out or out.get("branches") is None:
        return None, (out or {}).get("neq") or []
    loc = dict((str(q), q) for q in params)
    brs = []
    for br in out["branches"]:
        brs.append(dict((loc.get(k, sp.Symbol(k)), sp.sympify(v, locals=loc)) for k, v in br.items()))
    return brs, out.get("neq") or []


def _invariants(report, eq, dp, ctx, mode, options, depth):
    """solutions on invariant algebraic surfaces G = 0 (and on the levels G = C of a first integral)"""
    equation_mod = _mod("equation")
    if equation_mod is None or not hasattr(equation_mod, "Equation"):
        return None
    info = {"first_integral": None}
    surfaces = list(dp.get("first_integrals") or []) + list(dp.get("darboux_polynomials") or [])
    done = 0
    seen = set()
    for g in surfaces:
        red = g.get("reduced_equation")
        if not red or done >= 3 or _left(ctx) < 8.0:
            continue
        if not red.get("solved"):
            continue
        if int(red.get("order") or 99) > 2 and (mode != "heavy" or _left(ctx) < 60.0):
            report.setdefault("surfaces", []).append({
                "G": g.get("G"), "latex": g.get("latex"), "cofactor": g.get("cofactor"),
                "first_integral": bool(g.get("first_integral")), "conditions": g.get("conditions"),
                "reduced": red, "status": "the reduced equation was not analysed here (order %s)" % red.get("order")})
            continue
        key = red.get("sympy") or red.get("E")
        if key in seen:
            continue
        seen.add(key)
        if _left(ctx) < 8.0:
            continue
        if (g.get("certificate") or {}).get("status") != "pass":
            continue
        branches, neq = _branches(ctx, g.get("conditions"), eq.params)
        if branches is None:
            continue
        neq = list(neq) + [str(a) for a in (g.get("assumptions") or [])]
        for br in branches[:2]:
            is_fi = bool(g.get("first_integral"))
            b_s = min(40.0 if mode == "heavy" else 12.0, _left(ctx, 5.0))
            sub = _call(ctx, "equation on the %s %s" % ("levels of the first integral" if is_fi else "invariant surface",
                                                         str(g.get("G"))[:60]), _reduced_analysis, eq, red, br, mode,
                        b_s, depth, list(ctx.get("reserved_names") or []), _timeout=b_s + 10.0)
            if sub and sub.get("degenerate"):
                continue                     # the equation itself changes type on this locus
            done += 1
            if not sub:
                continue
            conds = ["%s == %s" % (k, _s(v)) for k, v in br.items()] + list(neq)
            entry = {"G": g.get("G"), "latex": g.get("latex"), "cofactor": g.get("cofactor"),
                     "first_integral": is_fi, "conditions": conds, "reduced": sub.get("equation"),
                     "verdict": sub.get("verdict"), "found": sub.get("found"), "ruled_out": sub.get("ruled_out"),
                     "not_decided": sub.get("not_decided")}
            report.setdefault("surfaces", []).append(entry)
            lsym = str(g.get("level_symbol") or "C_I")
            entry["level_symbol"] = lsym if is_fi else None
            for sol in sub.get("found") or []:
                if sol.get("kind") == "constant" and not is_fi:
                    continue
                item = dict(sol)
                item.pop("id", None)
                item["conditions"] = conds + list(sol.get("conditions") or [])
                item["note"] = ((sol.get("note") or "") + " Solution of the reduced equation %s = %s (%s)." % (
                    g.get("G"), lsym if is_fi else "0",
                    "a first integral" if is_fi else "an invariant surface with cofactor %s" % g.get("cofactor"))).strip()
                item["origin"] = "live:invariant-surface"
                d_sol = sol.get("d")
                covered = report.get("verdict", {}).get("level") == "complete" or \
                    (ctx.get("one_pole_complete") and sol.get("poles_per_period") == 1)
                if is_fi and any(re.search(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(lsym), str(c))
                                 for c in item["conditions"]):
                    item["constants"] = dict(item.get("constants") or {})
                    item["constants"][lsym] = "free; the value of the first integral"
                if sol.get("origin") == "live:linear" or sol.get("id") == "lin":
                    # the general solution of a reduced linear equation: explicit items of the same analysis say it
                    if any(o.get("kind") != "constant" and o is not sol and o.get("expr")
                           for o in sub.get("found") or []):
                        continue
                    if item.get("description"):
                        item["description"] = "on %s = %s the equation reduces to a linear equation; there: %s" % (
                            g.get("G"), lsym if is_fi else "0", item["description"])
                if sol.get("kind") != "constant":
                    entry.setdefault("_items", []).append(item)
                    if not covered or (isinstance(d_sol, int) and d_sol >= 2):
                        _add_found(report, item)
            if is_fi and not br and info["first_integral"] is None and not (g.get("conditions") or []):
                try:
                    jets = sp.symbols("w0:%d" % eq.K)
                    Gx = sp.sympify(str(g.get("G")), locals=dict([(str(j), j) for j in jets] +
                                                                  [(str(q), q) for q in eq.params]))
                    lead = sp.Poly(Gx, jets[eq.K - 1])
                    if lead.degree() == 1 and not lead.LC().free_symbols and lead.LC() != 0:
                        info["first_integral"] = entry
                except Exception:
                    pass
    return info


def _first_integral_upgrade(report, info):
    fi = info.get("first_integral")
    if not fi:
        return
    v = report["verdict"]
    sv = fi.get("verdict") or {}
    if v.get("level") == "complete" or sv.get("level") != "complete":
        return
    if str(sv.get("scope") or "").startswith("generic") or sv.get("generic_upgrade"):
        return
    for item in fi.get("_items") or []:         # the list must contain what the statement speaks about
        _add_found(report, item)
    lsym = str(fi.get("level_symbol") or "C_I")
    open_sub = []
    for it in fi.get("not_decided") or []:
        if not (it.get("kind") == "parameter-locus" or _is_special_locus(it)):
            return                               # something else is open in the reduced report: no upgrade
        names = set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", " ".join(_item_conditions(it)) or str(it.get("what"))))
        if lsym in names and len(names - {"sqrt", "I"}) == 1:
            return                               # a level of the first integral is open: the family is not decided
        open_sub.append(it)
    report["verdict"] = {
        "level": "complete",
        "text": "The equation has the polynomial first integral %s = %s: every solution satisfies, for some value "
                "of the constant %s, the equation of lower order obtained from it. All meromorphic solutions of "
                "that equation are listed, for every value of %s%s."
                % (fi.get("G"), lsym, lsym, lsym,
                   (" (and for generic values of the parameters)" if open_sub else
                    " and of the parameters") if report["equation"]["params"] else ""),
        "detail": sv.get("detail") or sv.get("text"),
        "basis": ["certificate: first integral"] + list(sv.get("basis") or []),
        "scope": ("generic parameter values" if open_sub else "all parameter values")
        if report["equation"]["params"] else "this equation",
        "conditions": [], "level_before": v.get("level"), "text_before": v.get("text")}
    for it in open_sub:
        _add_item(report, "not_decided", dict(it, kind="parameter-locus"))
    report["not_decided"] = [it for it in report["not_decided"]
                             if not str(it.get("what", "")).startswith("meromorphic solutions other than")
                             and it.get("_src") != "tier" and it.get("why") != "not computed in this run"
                             and not str(it.get("what", "")).startswith("the parts of the analysis that did not")]


# ----------------------------------------------------------------------------------------------- strata
def _strata(report, eq, local, tier, ctx, mode, options, depth):
    """special parameter loci that can be reached by substituting a value: analyse the equation there"""
    strata = [s for s in (local.get("strata") or []) if isinstance(s, dict) and s.get("substitution")]
    seen, todo = set(), []
    for s in strata:
        key = json.dumps(s.get("substitution"), sort_keys=True)
        if key in seen:
            continue
        seen.add(key)
        todo.append(s)
    if not todo:
        return
    out = []
    max_n = int(options.get("max_strata", 6))
    share = max(5.0, 0.25 * ctx["budget_s"] / max(1, min(len(todo), max_n)))
    for s in todo[:max_n]:
        if _left(ctx) < 3.0:
            out.append({"conditions": s.get("conditions"), "status": "not analysed (time limit)"})
            continue
        try:
            ploc = dict((str(q), q) for q in eq.params)
            subs = dict((ploc.get(str(k), sp.Symbol(str(k))), sp.sympify(str(v), locals=ploc))
                        for k, v in s["substitution"].items())
            sub_eq = eq.subs(subs) if hasattr(eq, "subs") else None
        except Exception as exc:
            log.append("special locus %s: %s" % (s.get("conditions"), str(exc)[:200]))
            out.append({"conditions": s.get("conditions"), "status": "not analysed (the values could not be read)"})
            continue
        if sub_eq is None:
            continue
        if _degenerate(eq, sub_eq):
            out.append({"conditions": s.get("conditions"), "substitution": s.get("substitution"),
                        "status": "degenerate: on this locus the equation has lower order or degree; "
                                  "it is a different equation and is not analysed here",
                        "equation": _equation_block(sub_eq)})
            continue
        sub = _call(ctx, "special locus %s" % ", ".join(s.get("conditions") or []), analyze, sub_eq, mode=mode,
                    reserved_names=list(ctx.get("reserved_names") or []),
                    budget_s=min(share, _left(ctx)), _depth=depth + 1, atlas=False,
                    max_poles=options.get("max_poles", 1), strata=False)
        if not sub:
            out.append({"conditions": s.get("conditions"), "status": "not analysed (failed)"})
            continue
        out.append({"conditions": s.get("conditions"), "substitution": s.get("substitution"),
                    "status": "analysed", "equation": sub.get("equation"), "verdict": sub.get("verdict"),
                    "found": sub.get("found"), "ruled_out": sub.get("ruled_out"),
                    "not_decided": sub.get("not_decided"),
                    "tier_text": (sub.get("tier") or {}).get("text")})
        nf_covered = set(_norm_cond(c) for c in (s.get("conditions") or [])) in (ctx.get("nf_loci") or [])
        for sol in sub.get("found") or []:
            if sol.get("kind") == "constant":
                continue
            if nf_covered and not any("==" in str(c) for c in sol.get("conditions") or []):
                continue                # generic on this locus: listed already by the normal-form solver
            sol = dict(sol)
            sol["conditions"] = list(s.get("conditions") or []) + list(sol.get("conditions") or [])
            sol["origin"] = (sol.get("origin") or "live") + " (special locus)"
            sol.pop("id", None)
            _add_found(report, sol)
    if len(todo) > max_n:
        out.append({"conditions": ["%d further loci" % (len(todo) - max_n)], "status": "not analysed (limit)"})
    report["strata"] = out
    v = report["verdict"]
    done = [o for o in out if o.get("status") == "analysed"]
    if done:
        v["special_loci"] = [{"conditions": o["conditions"], "level": (o.get("verdict") or {}).get("level"),
                              "text": (o.get("verdict") or {}).get("text")} for o in done]
    rest = [o for o in out if o.get("status") != "analysed" and not str(o.get("status")).startswith("degenerate")]
    for o in rest:
        _add_item(report, "not_decided", {"what": "parameter values with " + ", ".join(o.get("conditions") or []),
                                          "why": o.get("status"), "partial": ""})
    # the generic statement of the theorems left the special loci open: say what was done there
    for item in report["not_decided"]:
        w = item.get("what", "")
        if w.startswith("parameter values at which one of the conditions fails") and done:
            item["partial"] = (item.get("partial") or "") + " Analysed here: " + "; ".join(
                "%s: %s" % (", ".join(o["conditions"]), (o.get("verdict") or {}).get("level")) for o in done) + \
                " (see the field 'strata')."


LABEL_RANK = {"agent-proof": 0, "preprint": 1, "published": 2, "certificate": 3}


def _tex_cond(c):
    """a condition "lhs == rhs" / "lhs != rhs" as inline TeX ($...$); words and very long conditions stay as they are"""
    c = str(c).strip()
    if len(c) > 160 or "$" in c:
        return c
    for op, sym in (("==", "="), ("!=", "\\ne")):
        if op in c:
            a, b = c.split(op, 1)
            try:
                names = set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", c)) - {"sqrt", "exp", "I", "pi"}
                loc = dict((n, sp.Symbol(n)) for n in names)
                return "$%s %s %s$" % (sp.latex(sp.sympify(a, locals=loc)), sym, sp.latex(sp.sympify(b, locals=loc)))
            except Exception:
                return c
    return c


def _conds_phrase(conds):
    """the conditions of a generic verdict inside its sentence: short ones typeset, long ones counted (they are
    written out in the not-decided item that names the excluded parameter values)"""
    short = [_tex_cond(c) for c in conds if len(str(c)) <= 160]
    n_long = len([c for c in conds if len(str(c)) > 160])
    if n_long:
        short.append("%s further polynomial condition%s on the parameters, written out under \"not decided\""
                     % ("one" if n_long == 1 else str(n_long), "" if n_long == 1 else "s"))
    return ", ".join(short)


METHOD_TEXT = {
    "order1": "a first-order equation: the classical theory decides each factor of the equation",
    "conservative": "an equation $w'' = F(w)$: every solution satisfies $w'^2 = 2G(w) + C$ with $G' = F$, and each "
                    "level $C$ is decided by the first-order theory",
    "lienard": "an equation $w'' + (a w + b) w' = \\text{cubic}(w)$: the classification of its meromorphic "
               "solutions, applied on each stratum of the parameter space",
    "first_integral": "an equation $A(w) w'' + B(w) w'^2 + C(w) = 0$: it has a first integral in $w'^2$, and each "
                      "of its levels is decided by the first-order theory",
}


def _stratum_degenerate(eq, cond_text):
    """True if the conditions "p == v and q == u" put the equation on a locus where it loses order or degree"""
    try:
        ploc = dict((str(q), q) for q in eq.params)
        sub = {}
        for c in re.split(r"\s+and\s+|,\s+", str(cond_text)):
            if "==" not in c:
                continue
            a, b = c.split("==", 1)
            if a.strip() in ploc:
                sub[ploc[a.strip()]] = sp.sympify(b, locals=ploc)
            else:
                return False
        return bool(sub) and _degenerate(eq, eq.subs(sub))
    except Exception:
        return False


def _standard_text(report, eq=None):
    """the verdict sentence of an answer that comes from a decision module (orders one and two)"""
    v = report.get("verdict") or {}
    lo = report.get("low_order") or {}
    mod = str(lo.get("module") or "")
    lvl, scope = v.get("level"), v.get("scope")
    if not mod.startswith("mero.order") or lvl not in ("complete", "complete-W", "partial") or v.get("detail"):
        return
    sector = str(lo.get("sector") or "")
    if mod.startswith("mero.order1"):
        method = METHOD_TEXT["order1"]
    elif "order2b" in mod or sector.startswith("A(w)"):
        method = METHOD_TEXT["first_integral"]
    elif sector.startswith("C ("):
        method = METHOD_TEXT["conservative"]
    elif sector.startswith("Q(2,"):
        method = METHOD_TEXT["lienard"]
    else:
        method = None
    generic = scope == "generic parameter values"
    sd = v.get("scope_detail") or {}
    explored = [str(c) for c in sd.get("explored_strata") or []]
    if eq is not None:                              # values where the equation changes type are not "analysed"
        explored = [c for c in explored if not _stratum_degenerate(eq, c)]
    open_loci = any(it.get("kind") == "parameter-locus" or _is_special_locus(it) for it in report["not_decided"])
    if lvl == "complete":
        if scope == "this equation":
            text = "Every meromorphic solution of this equation is listed."
        elif generic:
            text = "For generic values of the parameters every meromorphic solution is listed."
        else:
            lost = bool(report.get("degenerate_loci")) or any(it.get("degenerate") for it in report["not_decided"])
            text = "Every meromorphic solution is listed, for all values of the parameters%s: the answer is " \
                   "given stratum by stratum, and each family carries the conditions under which it exists." % (
                       " at which the equation keeps its order and degree (the other values are named below; "
                       "there it is a different equation)" if lost else "")
    elif lvl == "complete-W":
        text = "%s rational, simply periodic and elliptic solutions are listed; solutions with $d = 2$ " \
               "(meromorphic, but not of these three kinds) are not decided." % (
                   "For generic values of the parameters all" if generic else "All")
    else:
        text = "The solutions listed were found and verified; the list is not known to be complete. What is not " \
               "decided is named below."
    if lvl != "partial" and explored:
        text += " Special parameter values that were analysed as well (their solutions are listed with these " \
                "conditions): %s%s." % (
                    "; ".join(", ".join(_tex_cond(c) for c in part.split(" and ")) for part in explored[:8]),
                    " and %d more" % (len(explored) - 8) if len(explored) > 8 else "")
    if lvl != "partial" and generic and open_loci:
        text += " Special parameter values that were not analysed are named under \"not decided\"."
    if v.get("supplement"):
        text += " On those values a direct search (one pole in a period) found the solutions that are listed " \
                "with their conditions."
    if "+" in mod and lvl == "complete":
        text += " Two independent procedures were run."
    if method:
        text += " Method: " + method + "."
    v["detail"] = v.get("text")
    v["text"] = text
    if method:
        v["method"] = method
    report["verdict"] = v


def _typeset_items(report):
    """`what_tex` for the not-decided items that name parameter values: the same sentence with typeset conditions;
    an item that names the same parameter values as an earlier one (the same conditions in another order) is
    dropped"""
    seen, keep = set(), []
    for it in report.get("not_decided") or []:
        conds = _item_conditions(it)
        if conds and (it.get("kind") == "parameter-locus" or _is_special_locus(it)) and \
                re.match(r"^(the stratum|the degenerate stratum|the parameter locus|parameter stratum|"
                         r"parameter values with|parameter points with)\b", str(it.get("what", ""))):
            key = frozenset(_norm_cond(c) for c in conds)
            if key in seen:
                continue
            seen.add(key)
        keep.append(it)
    report["not_decided"] = keep
    for it in report.get("not_decided") or []:
        w = str(it.get("what", ""))
        if it.get("what_tex") or "$" in w:
            continue
        m = re.match(r"^parameter values at which one of the conditions fails:\s*(.*)$", w)
        if m:
            it["what_tex"] = "parameter values at which one of the conditions fails: " + \
                ", ".join(_tex_cond(c) for c in m.group(1).split("; "))
            continue
        conds = _item_conditions(it)
        if conds and (it.get("kind") == "parameter-locus" or _is_special_locus(it)) and \
                re.match(r"^(the stratum|the degenerate stratum|the parameter locus|parameter stratum|"
                         r"parameter values with|parameter points with)\b", w):
            tail = ""
            if it.get("degenerate") or w.startswith("the degenerate stratum"):
                tail = " (the equation has lower order or degree there)"
            it["what_tex"] = "parameter values with " + ", ".join(_tex_cond(c) for c in conds) + tail


def _scope_item(report):
    """a generic verdict names the parameter values it excludes: if no not-decided item does, one is added"""
    v = report.get("verdict") or {}
    conds = [str(c) for c in v.get("conditions") or []]
    if v.get("scope") != "generic parameter values" or not conds:
        return
    if any(str(it.get("what", "")).startswith("parameter values at which one of the conditions fails")
           for it in report["not_decided"]):
        return
    _add_item(report, "not_decided", {
        "what": "parameter values at which one of the conditions fails: " + "; ".join(conds),
        "kind": "parameter-locus",
        "why": "the statement was established for generic values of the parameters only",
        "partial": "solutions found on such values are listed with their conditions; the lists there are not "
                   "claimed complete"})


def _registry_ids():
    reg = _mod("registry")
    try:
        return set(str(e.get("id")) for e in reg.load_registry())
    except Exception:
        try:
            return set(str(e.get("id")) for e in getattr(reg, "_EMBEDDED", []))
        except Exception:
            return set()


def _normalise_labels(report):
    """a ruled-out item is "published" (or "preprint") only through an entry of the registry, where the hypotheses
    of the cited statement are recorded; a citation made by a module without such an entry is agent-level"""
    ids = _registry_ids()
    if not ids:
        return
    low = bool(report.get("low_order"))
    for it in report.get("ruled_out") or []:
        b = it.get("basis")
        if low and isinstance(b, dict) and b.get("label") in ("published", "preprint") and \
                re.search(r"other than (those|the families|the ones) listed", str(it.get("what", ""))):
            b["label_cited"] = b["label"]
            b["label"] = "agent-proof"
            b["label_note"] = "the cited statement gives the class of the solutions; the list for this equation " \
                              "and its completeness are computed by the engine"
            continue
        if isinstance(b, dict) and b.get("label") in ("published", "preprint"):
            th = str(b.get("theorem") or "")
            parts = [x.strip() for x in re.split(r"\s*\+\s*|,\s*", th) if x.strip()]
            if not parts or not all(x.split(" ")[0] in ids for x in parts):
                b["label_cited"] = b["label"]
                b["label"] = "agent-proof"
                b["label_note"] = "the cited statement is not an entry of this site's registry (its hypotheses " \
                                  "are not recorded there); the item rests on the engine's own lemma"


def _finish_verdict(report, tier):
    """the label of the verdict (the weakest label among the statements it rests on) and the overall level
    (generic statement versus special parameter loci)"""
    v = report.get("verdict") or {}
    labels = {}
    used = (tier or {}).get("used_labels") or {}
    reg = _mod("registry")
    for b in v.get("basis") or []:
        b = str(b)
        lab = None
        if b in used:
            lab = (used[b] or {}).get("label")
        elif b.startswith("certificate"):
            lab = "certificate"
        elif b.startswith(("lemma:", "record:", "L-", "A-")):
            lab = "agent-proof"
        if lab is None and reg is not None and hasattr(reg, "get"):
            try:
                ent = reg.get(b)
                lab = (ent or {}).get("label")
            except Exception:
                lab = None
        if lab is None and b.startswith("T-"):
            lab = "agent-proof"
        if lab:
            labels[b] = lab
    lo = report.get("low_order") or {}
    if str(lo.get("module", "")).startswith(("mero.order2", "mero.order1")) and \
            not str(lo.get("module", "")).startswith("mero.order2b") and report["equation"].get("params") and \
            v.get("level") in ("complete", "complete-W", "partial"):
        labels["stratification by parameter values and closed forms (this engine)"] = "agent-proof"
    for it in report.get("ruled_out") or []:                # a module may give the label with its basis
        bs = it.get("basis")
        if isinstance(bs, dict) and bs.get("theorem") in (v.get("basis") or []) and bs.get("label"):
            labels[str(bs["theorem"])] = bs["label"]
    ids = _registry_ids()
    for b in list(labels):                      # a cited statement outside the registry is agent-level here
        if labels[b] in ("published", "preprint") and ids and str(b).split(" ")[0] not in ids:
            labels[b] = "agent-proof"
    if labels:
        v["labels"] = labels
        # the label of the verdict: the weakest label among the statements the verdict sentence needs.  Statements
        # that only add something (the number of solutions; a second theorem giving the same class) do not count.
        cls = (tier or {}).get("class_of_all_meromorphic_solutions")
        skip = {"T-STRUCTURE-B", "T-SERIES-PERIOD"}
        alt = {"T-PUREPOWER", "T-STRUCTURE-A", "T-STRUCTURE-E", "T-EREMENKO", "T-DEMINA2019", "T-ELN2009"}
        if not report.get("low_order"):
            if cls == "entire only":
                skip |= alt
            elif cls in W_CLASSES:
                main = (tier or {}).get("pole_bound_basis")
                n_src = None
                for b in v.get("basis") or []:
                    if str(b) in ("T-FREECOEFF", "L-ENDS"):
                        n_src = str(b)
                gives_class = {"T-EREMENKO", "T-STRUCTURE-A", "T-STRUCTURE-E", "T-DEMINA2019", "T-ELN2009"}
                if main in gives_class and n_src is None:
                    skip |= (alt - {main})
        need = dict((k, x) for k, x in labels.items() if k not in skip) or labels
        v["label"] = min(need.values(), key=lambda x: LABEL_RANK.get(x, 0))
        v["label_rests_on"] = sorted(need)
    elif v.get("level") in ("complete", "complete-W"):
        v["label"] = "agent-proof"
    if v.get("level") not in ("complete", "complete-W"):
        v.pop("label", None)                    # only a complete verdict has a label of its own
        v.pop("label_rests_on", None)
    # overall level: a statement for generic parameter values is weaker than a statement for all values
    lvl = v.get("level")
    special = [x.get("level") for x in v.get("special_loci") or []]
    open_loci = any(str(it.get("what", "")).startswith(("parameter values", "parameter stratum",
                                                         "the degenerate stratum"))
                    or it.get("kind") == "parameter-locus" for it in report.get("not_decided") or [])
    sd_ = v.get("scope_detail") or {}
    if lvl == "complete" and v.get("scope") == "generic parameter values" and not open_loci and \
            sd_.get("explored_strata") and not sd_.get("unexplored") and not v.get("conditions") and \
            not report.get("degenerate_loci"):
        v["overall"] = "complete"                   # every special value was analysed: the statement holds for all
        v["scope"] = "the parameter strata listed"
        for key_, row_ in (report.get("d_summary") or {}).items():
            if isinstance(row_, dict) and isinstance(row_.get("status"), str):
                row_["status"] = row_["status"].replace(" for generic parameter values", "")
    elif lvl == "complete" and v.get("scope") == "generic parameter values":
        v["overall"] = "complete-generic"
        rank = {"formal": 0, "partial": 1, "complete-W": 2, "complete": 3}
        if open_loci:
            v["special_min"] = "not analysed"
        elif special:
            v["special_min"] = min(special, key=lambda x: rank.get(x, 0))
        elif (v.get("scope_detail") or {}).get("explored_strata"):
            v["special_min"] = "complete"
    else:
        v["overall"] = lvl
    report["verdict"] = v


def _mark_complex(report, eq):
    """found items that exist only for non-real values of the parameters"""
    params = dict((str(q), q) for q in eq.params)
    if not params:
        return
    for it in report["found"]:
        for c in it.get("conditions") or []:
            c = str(c)
            if "==" not in c:
                continue
            a, b = [x.strip() for x in c.split("==", 1)]
            if a in params and len(b) < 200:
                try:
                    val = sp.sympify(b, locals=params)
                    if not val.free_symbols and sp.im(val) != 0:
                        it["complex_parameters"] = "exists only for a non-real value of %s" % a
                        break
                except Exception:
                    pass


def _d_summary(report):
    found = report["found"]
    d1 = [x for x in found if x.get("d") == 1 or x.get("kind") in ("rational", "simply-periodic", "elliptic",
                                                                    "polynomial")]
    d2 = [x for x in found if x.get("d") == 2]
    d3 = [x for x in found if isinstance(x.get("d"), int) and x.get("d") >= 3]
    described = (report.get("atlas") or {}).get("described") or []
    desc2 = [x for x in described if x.get("d") == 2]
    desc3 = [x for x in described if isinstance(x.get("d"), int) and x.get("d") >= 3]
    v = report.get("verdict", {})
    lvl = v.get("level")
    generic = v.get("scope") == "generic parameter values"
    tier = report.get("tier") or {}
    cls = tier.get("class_of_all_meromorphic_solutions")
    by_low = bool(report.get("low_order"))
    ruled = (cls in W_CLASSES + ("entire only",) and tier.get("d_le_1") is not False and not by_low) or \
        lvl == "complete"
    suffix = " for generic parameter values" if generic else ""

    def status(dfound, ddesc):
        if dfound:
            return "found"
        if ddesc:
            return "described in an earlier record (not derived here)"
        if cls == "listed (not all in W)":
            return "see the verdict"
        if cls == "entire (linear equation)":
            return "possible, depending on the roots (see the general solution)"
        if ruled:
            return "ruled out" + suffix
        return "not ruled out"

    if lvl in ("complete", "complete-W"):
        s1 = "complete" + suffix
    elif d1:
        s1 = "partial"
    else:
        s1 = "none found"
    s2, s3 = status(d2, desc2), status(d3, desc3)
    basis = ", ".join(str(b) for b in (v.get("basis") or []))[:200]
    report["d_summary"] = {"1": {"status": s1, "count": len(d1)},
                           "2": {"status": s2, "count": len(d2), "basis": basis if s2.startswith("ruled out") else ""},
                           "3+": {"status": s3, "count": len(d3), "basis": basis if s3.startswith("ruled out") else ""}}


def analyze_json(text, **kw):
    return json.dumps(analyze(text, **kw), default=str, ensure_ascii=False)


if __name__ == "__main__":
    import sys
    txt = sys.argv[1] if len(sys.argv) > 1 else "w''' = 12*w*w' + 1"
    print(json.dumps(analyze(txt, mode="heavy" if "--heavy" in sys.argv else "light"), indent=1, default=str,
                     ensure_ascii=False))
