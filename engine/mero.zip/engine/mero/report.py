"""mero.report -- assemble the report for one equation (project note section 3).

`analyze(text_or_eq, mode='light'|'heavy', budget_s=..., **options)` calls every available module of the
package, each one optional and time-limited, and returns a JSON-able dict.  The three lists (found, ruled out,
not decided) and the verdict are put together here and nowhere else.

Rules of this module (they are what the site promises):

* "complete" is said only when (a) a decision module for low order says so, or (b) a registry theorem gives the
  class of all meromorphic solutions and a bound on the poles in a period, and the solver has finished every form
  that this class and this bound allow, and the solutions without poles are known, or (c) an earlier record of the
  project with a completeness label contains the equation (then the label of that record is shown);
* with symbolic parameters every statement names its scope: "for generic values of the parameters" comes with the
  list of conditions, and the special loci are analysed separately when they can be reached by substituting a value
  (field `strata`), otherwise they are listed as not decided;
* nothing found is shown unless its substitution check passed.

Pure Python + SymPy: this module runs in the browser.
"""
import importlib
import json
import re
import time
import traceback

import sympy as sp

ENGINE_VERSION = "mero 0.2 (6 October 2026)"
W_CLASSES = ("W\u222arational", "W")
KINDS = ("rational", "simply-periodic", "elliptic")

z = sp.Symbol("z")


# ----------------------------------------------------------------------------------------------- optional modules
def _mod(name):
    """import mero.<name> if it exists and imports cleanly; otherwise None"""
    try:
        return importlib.import_module("mero." + name)
    except Exception:
        return None


class _Timeout(Exception):
    pass


def _hard_call(fn, args, kwargs, timeout):
    """run fn(*args, **kwargs) in a forked child with a hard wall-clock limit (heavy version only)"""
    import os
    import pickle
    import select
    import signal
    rfd, wfd = os.pipe()
    pid = os.fork()
    if pid == 0:                                                  # the child
        try:
            os.close(rfd)
            try:
                os.setpgid(0, 0)                                  # own process group: Singular / msolve die with it
            except Exception:
                pass
            try:
                data = pickle.dumps(("ok", fn(*args, **kwargs)), protocol=pickle.HIGHEST_PROTOCOL)
            except BaseException as exc:                          # noqa: reported to the parent
                data = pickle.dumps(("err", "%s: %s" % (type(exc).__name__, str(exc)[:400])))
            with os.fdopen(wfd, "wb") as fh:
                fh.write(data)
        finally:
            os._exit(0)
    os.close(wfd)
    chunks, deadline = [], time.monotonic() + timeout
    try:
        while True:
            left = deadline - time.monotonic()
            if left <= 0:
                raise _Timeout()
            ready, _, _ = select.select([rfd], [], [], min(left, 1.0))
            if ready:
                b = os.read(rfd, 1 << 20)
                if not b:
                    break
                chunks.append(b)
    except _Timeout:
        for sig_target in (os.killpg, os.kill):
            try:
                sig_target(pid, signal.SIGKILL)
            except Exception:
                pass
        try:
            os.waitpid(pid, 0)
        except Exception:
            pass
        os.close(rfd)
        raise
    os.close(rfd)
    try:
        os.waitpid(pid, 0)
    except Exception:
        pass
    try:
        try:
            os.killpg(pid, signal.SIGKILL)                        # anything the child left behind
        except Exception:
            pass
        status, out = pickle.loads(b"".join(chunks))
    except Exception as exc:
        raise RuntimeError("the result of the step could not be read (%s)" % str(exc)[:200])
    if status == "err":
        raise RuntimeError(out)
    return out


def _call(ctx, label, fn, *args, **kwargs):
    """run fn; never raise; record time and failures in the log.  In the heavy version every step runs in a
    child process with a hard time limit (`_timeout` seconds, default: what is left of the budget, at most 90)."""
    log = ctx["log"]
    cap = kwargs.pop("_timeout", None)
    soft = kwargs.pop("_soft", False)
    if ctx.get("progress"):
        try:
            ctx["progress"]("step: " + label)
        except Exception:
            pass
    t0 = time.monotonic()
    left = ctx["budget_s"] - (t0 - ctx["t0"])
    if ctx.get("hard") and left < 1.0 and label not in ("earlier records", "normal form", "readable forms",
                                                        "copies in the list",
                                                        "degenerate loci of listed solutions"):
        log.append("%s: skipped (time limit of the analysis reached)" % label)
        ctx["timeouts"].append(label)
        return None
    try:
        if ctx.get("hard") and not soft:
            limit = max(2.0, min(cap if cap else 90.0, left + 3.0))
            try:
                out = _hard_call(fn, args, kwargs, limit)
            except _Timeout:
                log.append("%s: stopped at its time limit (%.0f s)" % (label, limit))
                ctx["timeouts"].append(label)
                return None
        else:
            out = fn(*args, **kwargs)
        log.append("%s: %.2f s" % (label, time.monotonic() - t0))
        return out
    except Exception as exc:                                    # a module failure is reported, not hidden
        log.append("%s: FAILED after %.2f s: %s: %s" % (label, time.monotonic() - t0, type(exc).__name__,
                                                          str(exc)[:300]))
        tb = traceback.format_exc(limit=4).strip().splitlines()
        log.append("  " + " | ".join(t.strip() for t in tb[-4:])[:500])
        ctx["failures"].append(label)
        return None


def _left(ctx, reserve=0.0):
    return max(1.0, ctx["budget_s"] - (time.monotonic() - ctx["t0"]) - reserve)


# ----------------------------------------------------------------------------------------------- fallback parser
_PRIME = re.compile(r"\b([A-Za-z])\s*('+)")


def _fallback_parse(text, unknown=None):
    """A very small parser used only when mero.parse is not available: primes and jets, '^', one '='."""
    from mero.bootstrap import Equation
    s = text.replace("\u2212", "-").replace("^", "**").replace("\u2032", "'").replace("\u2033", "''")
    if "=" in s:
        lhs, rhs = s.split("=", 1)
        s = "(%s) - (%s)" % (lhs, rhs)
    if unknown is None:
        m = _PRIME.search(s)
        unknown = m.group(1) if m else "w"
    s = _PRIME.sub(lambda m: "%s%d" % (m.group(1), len(m.group(2))) if m.group(1) == unknown else m.group(0), s)
    s = re.sub(r"\b%s\b(?!\d)" % unknown, unknown + "0", s)
    s = re.sub(r"\b%s(\d+)\b" % unknown, r"w\1", s)
    s = re.sub(r"(\d)\s*([A-Za-z(])", r"\1*\2", s)
    order = max([int(k) for k in re.findall(r"\bw(\d+)\b", s)] or [0])
    jets = sp.symbols("w0:%d" % (order + 1))
    loc = dict((str(j), j) for j in jets)
    for name in set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", s)):          # every other name is a parameter
        if name not in loc and name not in ("sqrt", "I", "pi", "Rational"):
            loc[name] = sp.Symbol(name)
    expr = sp.expand(sp.sympify(s, locals=loc))
    params = sorted(expr.free_symbols - set(jets), key=str)
    poly = sp.Poly(expr, jets[order])
    if poly.degree() != 1 or (poly.LC().free_symbols & set(jets)):
        raise ValueError("unsupported by the fallback parser: the equation is not solved for the highest derivative")
    rhs = sp.expand(-poly.coeff_monomial(1) / poly.LC())
    eq = Equation(order, rhs, [str(q) for q in params])
    eq.unknown, eq.var = unknown, "z"
    return eq


# ----------------------------------------------------------------------------------------------- small helpers
def _s(e):
    return sp.sstr(e) if not isinstance(e, str) else e


def _E(eq):
    E = getattr(eq, "E", None)
    if E is None:
        E = eq.w[eq.K] - eq.rhs
    return E


def _fresh(eq, base="q"):
    """a symbol name that is neither a parameter nor a jet of the equation"""
    used = set(str(s) for s in _E(eq).free_symbols) | set(str(p) for p in eq.params)
    name, i = base, 0
    while name in used:
        i += 1
        name = "%s%d" % (base, i)
    return sp.Symbol(name)


def _jet_latex(eq, expr):
    name = getattr(eq, "unknown", "w")
    rep = {}
    for j, wj in enumerate(eq.w):
        if j == 0:
            rep[wj] = sp.Symbol(name)
        elif j <= 3:
            rep[wj] = sp.Symbol(name + "'" * j)
        else:
            rep[wj] = sp.Symbol("%s^{(%d)}" % (name, j))
    return sp.latex(expr.subs(rep))


def _equation_block(eq):
    E = _E(eq)
    solved = getattr(eq, "solved", True)
    ltx = None
    if hasattr(eq, "latex"):
        try:
            ltx = eq.latex()
        except Exception:
            ltx = None
    if ltx is None:
        if solved and getattr(eq, "rhs", None) is not None:
            ltx = _jet_latex(eq, eq.w[eq.K]) + " = " + _jet_latex(eq, eq.rhs)
        else:
            ltx = _jet_latex(eq, E) + " = 0"
    deg = getattr(eq, "degree", None)
    if deg is None:
        deg = max(sum(m) for m in eq.terms)
    return {"order": eq.K, "degree": int(deg), "solved": bool(solved), "sympy": _s(sp.expand(E)), "latex": ltx,
            "params": [str(q) for q in eq.params], "unknown": getattr(eq, "unknown", "w"),
            "var": getattr(eq, "var", "z")}


def _bootstrap_local(eq, budget_s=20):
    """local analysis with the reference implementation (used only if mero.laurent is missing)"""
    from mero import bootstrap as B
    out = {"balances": [], "non_integer_balances": [], "finiteness": None, "no_pole_possible": None, "strata": [],
           "note": "reference implementation"}
    if not getattr(eq, "solved", True):
        return out
    for b in B.balances(eq):
        for a0 in b["a0"]:
            kk = sp.Symbol("k")
            ind = B.indicial(eq, b["p"], a0, kk)
            roots = sp.roots(sp.Poly(sp.numer(sp.together(ind)), kk))
            pos = sorted(int(r) for r in roots if r.is_integer and r > 0)
            L = B.laurent(eq, b["p"], a0, max((max(pos) if pos else 0) + 2, b["p"] + 2))
            fail = [k for k, v in L["conditions"].items() if v != 0]
            count = "0" if fail else ("family: %d free coefficient(s)" % len(L["free"]) if L["free"] else "finite: 1")
            out["balances"].append({"p": b["p"], "a0": _s(a0), "weight": b["W"], "indicial": _s(ind),
                                    "indices": [_s(r) for r in roots], "positive_integer_indices": pos,
                                    "coeffs": [_s(c) for c in L["coeffs"]],
                                    "free": dict((str(k), str(v)) for k, v in L["free"].items()),
                                    "conditions": dict((str(k), _s(v)) for k, v in L["conditions"].items()),
                                    "series_count": count})
    return out


def _constants(eq):
    """constant solutions: the roots of E(q, 0, ..., 0)"""
    q = _fresh(eq, "q")
    e0 = sp.expand(_E(eq).subs(dict((wj, 0) for wj in eq.w[1:])).subs(eq.w[0], q))
    if e0 == 0:
        return {"all": True, "symbol": str(q)}
    if q not in e0.free_symbols:
        return {"all": False, "none": True, "poly": _s(e0), "symbol": str(q)}
    P = sp.Poly(e0, q)
    roots = []
    if P.degree() <= 2:
        try:
            roots = [sp.simplify(r) for r in sp.roots(P, multiple=True)]
        except Exception:
            roots = []
    return {"all": False, "poly": _s(P.as_expr()), "poly_latex": sp.latex(P.as_expr()), "degree": P.degree(),
            "symbol": str(q), "roots": [_s(r) for r in roots], "roots_latex": [sp.latex(r) for r in roots]}


def _const_items(consts):
    cert = {"type": "substitution", "method": "symbolic", "status": "pass"}
    if consts.get("all"):
        return [{"id": "const", "kind": "constant", "d": 0, "expr": consts["symbol"], "latex": consts["symbol"],
                 "free": [consts["symbol"]], "conditions": [], "note": "every constant is a solution",
                 "certificate": dict(cert, detail="E(q, 0, ..., 0) vanishes identically"),
                 "origin": "live:constants"}]
    if consts.get("none"):
        return []
    if consts.get("roots"):
        return [{"id": "const%d" % (i + 1), "kind": "constant", "d": 0, "expr": r, "latex": consts["roots_latex"][i],
                 "free": [], "conditions": [],
                 "certificate": dict(cert, detail="root of E(%s, 0, ..., 0) = %s" % (consts["symbol"], consts["poly"])),
                 "origin": "live:constants"} for i, r in enumerate(consts["roots"])]
    if consts.get("degree", 0) > 2:
        return [{"id": "const", "kind": "constant", "d": 0,
                 "expr": "RootOf(%s, %s)" % (consts["poly"], consts["symbol"]),
                 "latex": "%s:\\quad %s = 0" % (consts["symbol"], consts.get("poly_latex", "")),
                 "free": [], "conditions": [],
                 "note": "the constant solutions are the roots of this polynomial",
                 "certificate": dict(cert, detail="E(%s, 0, ..., 0) = %s" % (consts["symbol"], consts["poly"])),
                 "origin": "live:constants"}]
    return []


def _add_found(report, sol, origin=None):
    if not isinstance(sol, dict):
        return
    cert = sol.get("certificate") or {}
    status = cert.get("status")
    if status in ("fail", "FAIL"):
        report["rejected"].append({"expr": sol.get("expr"), "why": "substitution check failed",
                                   "origin": sol.get("origin") or origin})
        return
    if status != "pass":
        cand = dict(sol)
        cand["why"] = "the substitution check did not run (%s)" % status
        if origin and not cand.get("origin"):
            cand["origin"] = origin
        report.setdefault("candidates", []).append(cand)
        return
    sol = dict(sol)
    sol["conditions"] = _tidy_conditions(sol.get("conditions"))
    key = _sol_key(sol)
    for old in report["found"]:
        if _sol_key(old) == key:
            return
    if origin and not sol.get("origin"):
        sol["origin"] = origin
    if "id" not in sol or any(o.get("id") == sol["id"] for o in report["found"]):
        sol["id"] = "s%d" % (len(report["found"]) + 1)
    report["found"].append(sol)


def _tidy_conditions(conds):
    """the list of conditions without repetitions; a condition `monomial != 0` is written with its base"""
    out = []
    for c in conds or []:
        c = str(c).strip()
        m = re.match(r"^-?\s*([A-Za-z_][A-Za-z_0-9]*)(?:\*\*\d+)?(?:\s*/\s*\d+)?\s*!=\s*0$", c)
        if m:
            c = "%s != 0" % m.group(1)
        if c and c not in out:
            out.append(c)
    return out


def _norm_cond(c):
    c = str(c)
    if len(c) > 160:
        return c.replace(" ", "")
    try:
        for op in ("==", "!="):
            if op in c:
                a, b = c.split(op, 1)
                names = set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", c)) - {"sqrt", "I", "pi", "exp"}
                loc = dict((n, sp.Symbol(n)) for n in names)
                e = sp.factor(sp.sympify(a, locals=loc) - sp.sympify(b, locals=loc))
                num = sp.numer(sp.together(e))
                if num.could_extract_minus_sign():
                    num = -num
                co = sp.Poly(num, *sorted(num.free_symbols, key=str)).LC() if num.free_symbols else 1
                return op + sp.sstr(sp.expand(num / co))
    except Exception:
        pass
    return c.replace(" ", "")


def _combine_order2(dA, dB):
    """Two independent decision procedures for A(w) w'' + B(w) w'^2 + C(w) = 0 (mero.order2, mero.order2b).
    The answer says "complete" only if the second one does and if the first one, when it also says "complete",
    lists the same numbers of families of each kind; otherwise the union of the two lists is shown at the level
    "partial"."""
    def level(d):
        return ((d or {}).get("verdict") or {}).get("level")

    def kinds(d):
        out = {}
        for x in (d or {}).get("found") or []:
            if x.get("kind") != "constant":
                out[x.get("kind")] = out.get(x.get("kind"), 0) + 1
        return out
    warn = False
    lvA, lvB = level(dA), level(dB)
    if dA is None:
        if warn and lvB == "complete":
            dB = dict(dB, verdict=dict(dB["verdict"], level="partial", text=dB["verdict"].get("text", "") +
                                       " (The first integral has a multiple root for every level; the special "
                                       "levels were not all examined, so completeness is not claimed.)"))
        return dB
    agree = kinds(dA) == kinds(dB)
    if lvB == "complete" and not warn and (lvA != "complete" or agree):
        out = dict(dB)
        if lvA == "complete":
            out["basis"] = list(dict.fromkeys(list(dB.get("basis") or []) + list(dA.get("basis") or [])))
            out["verdict"] = dict(dB["verdict"], text=dB["verdict"].get("text", "") +
                                  " (Two independent procedures give the same list.)")
            return out
        # the second procedure states its list for generic parameter values; families that the first one found on
        # special parameter values are kept, and those values are named
        keys = set(_sol_key(x) for x in out.get("found") or [])
        extra, loci = [], []
        for x in dA.get("found") or []:
            eqs = [str(c) for c in x.get("conditions") or [] if "==" in str(c)]
            if x.get("kind") == "constant" or not eqs or _sol_key(x) in keys or \
                    (x.get("certificate") or {}).get("status") != "pass":
                continue
            extra.append(x)
            if eqs not in loci:
                loci.append(eqs)
        if extra:
            out["found"] = list(out.get("found") or []) + extra
            nd = list(out.get("not_decided") or [])
            sc0 = (dB.get("verdict") or {}).get("scope")
            named = set()                       # loci that the second procedure names itself (explored or not)
            for c in ((sc0.get("explored_strata") or []) if isinstance(sc0, dict) else []):
                for part in str(c).split(" and "):
                    named.add(_norm_cond(part))
            for it0 in nd:
                for c in _item_conditions(it0):
                    named.add(_norm_cond(c))
            for eqs in loci:
                if all(_norm_cond(c) in named for c in eqs):
                    continue
                nd.append({"what": "parameter values with %s" % " and ".join(eqs), "kind": "parameter-locus",
                           "conditions": list(eqs),
                           "why": "the list is stated for generic parameter values; on these values the first of the "
                                  "two procedures found the solutions that are listed with these conditions, and "
                                  "nothing more was established there",
                           "partial": "the solutions listed with these conditions"})
            out["not_decided"] = nd
            sc = (dB.get("verdict") or {}).get("scope")
            generic = isinstance(sc, dict) and str(sc.get("parameters", "")).startswith("generic") or \
                (isinstance(sc, str) and sc.startswith("generic"))
            if not generic:
                out["verdict"] = dict(dB["verdict"], level="partial", text=dB["verdict"].get("text", "") +
                                      " (A second procedure found further solutions on special parameter values; "
                                      "completeness is not claimed.)")
        return out
    found = list(dB.get("found") or [])
    keys = set(_sol_key(x) for x in found)
    for x in dA.get("found") or []:
        if _sol_key(x) not in keys:
            found.append(x)
    nd = list(dB.get("not_decided") or []) + [x for x in (dA.get("not_decided") or [])
                                               if x not in (dB.get("not_decided") or [])]
    nd.append({"what": "whether the list is complete",
               "why": "two independent procedures for equations of this shape (the first integral in w'^2) were run "
                      "and do not give the same complete list (%s: %s; %s: %s); the union is shown"
                      % ("first", lvA, "second", lvB + (" with a warning" if warn else "")),
               "partial": "every listed solution passed its substitution check"})
    return {"applies": True, "found": found, "ruled_out": [], "not_decided": nd,
            "verdict": {"level": "partial",
                        "text": "The solutions listed were obtained from the first integral in w'^2 by two "
                                "independent procedures, which do not agree on the complete list; the union is "
                                "shown and completeness is not claimed.",
                        "basis": list(dict.fromkeys(list(dB.get("basis") or []) + list(dA.get("basis") or [])))},
            "basis": list(dict.fromkeys(list(dB.get("basis") or []) + list(dA.get("basis") or []))),
            "first_integral": dB.get("first_integral"), "module": "mero.order2 + mero.order2b"}


def _item_conditions(it):
    """the conditions of a not-decided item, as a list of strings (from the field or from the sentence)"""
    cs = it.get("conditions")
    if cs:
        return [str(c) for c in cs]
    w = str(it.get("what", ""))
    m = re.search(r"(?:stratum|locus)\s+(.*)$", w)
    if not m:
        return []
    out = []
    for part in re.split(r"\s+and\s+|,\s+(?=[^()]*(?:==|!=))", m.group(1)):
        part = re.sub(r"\s*\(inside .*$", "", part.strip())
        if "==" in part or "!=" in part:
            out.append(part)
    return out


def _is_special_locus(it):
    """a not-decided item that concerns only a proper closed subset of the parameter space"""
    cs = it.get("conditions")
    if cs:
        return any("==" in str(c) for c in cs)
    w = str(it.get("what", ""))
    # the strata of a decision tree are enumerated generic stratum first: what an interrupted enumeration leaves
    # out are special strata
    return "==" in w or w.startswith("further special strata")


def _generic_upgrade(decided, symbolic):
    """A decision module (order one or two) answers "partial" as soon as one parameter stratum is left open.  If
    every open item is a special locus (it carries an equality between the parameters), the module's lists are
    complete for all other parameter values: the verdict is then "complete" with the scope "generic parameter
    values", and the open loci stay in the list of what is not decided."""
    v = (decided or {}).get("verdict") or {}
    if not symbolic or v.get("level") != "partial" or not decided.get("applies"):
        return decided
    if str(decided.get("module", "")).startswith("mero.order2 +"):
        return decided
    nd = decided.get("not_decided") or []
    if not nd or not all(_is_special_locus(it) for it in nd):
        return decided
    if not any(x.get("certificate", {}).get("status") == "pass" for x in decided.get("found") or []) and \
            not decided.get("ruled_out"):
        return decided
    out = dict(decided)
    out["not_decided"] = [dict(it, kind=it.get("kind") or "parameter-locus") for it in nd]
    n_open = len([it for it in nd if not it.get("degenerate")])
    text = "For generic values of the parameters every meromorphic solution is listed"
    if len(decided.get("strata") or []) > 1:
        text += " (on each of the parameter strata shown, generic stratum first)"
    text += ". Not analysed: %s." % (
        "the special parameter values listed under 'not decided'" if n_open else
        "the parameter values at which the equation loses order or degree")
    out["verdict"] = dict(v, level="complete", text=text, scope="generic parameter values", generic_upgrade=True)
    return out


def _cond_holds(c, pt, loc):
    c = str(c)
    op = "==" if "==" in c else ("!=" if "!=" in c else None)
    if op is None:
        return None
    a, b = c.split(op, 1)
    try:
        va = complex(sp.N(sp.sympify(a, locals=loc).subs(pt), 30))
        vb = complex(sp.N(sp.sympify(b, locals=loc).subs(pt), 30))
    except Exception:
        return None
    small = abs(va - vb) <= 1e-9 * (1.0 + abs(va) + abs(vb))
    return small if op == "==" else (not small)


def _match_open_strata(sols, items, params):
    """for each solution (conditions on the parameters), the indices of the open strata on which it lies; decided
    at a random numeric point of the solution's parameter locus"""
    import random
    rnd = random.Random(20261006)
    loc = dict((str(q), q) for q in params)
    out = []
    for sol in sols:
        conds = [str(c) for c in sol.get("conditions") or []]
        eqs = [c for c in conds if "==" in c]
        hits = []
        if eqs:
            for _try in range(2):
                pt = _locus_point(conds, params, rnd)
                if pt is None:
                    break
                for i, it in enumerate(items):
                    cs = _item_conditions(it)
                    if cs and all(_cond_holds(c, pt, loc) is True for c in cs) and i not in hits:
                        hits.append(i)
        out.append(hits)
    return out


def _supplement_open_strata(report, eq, local, ctx, mode, budget_s, decided):
    """direct search (one pole in a period) on the parameter strata that a decision module left open: the solutions
    found there are listed with their conditions; nothing is concluded about completeness on those strata"""
    items = [it for it in report["not_decided"] if it.get("_src") == "low_order" and _is_special_locus(it)
             and not it.get("degenerate") and _item_conditions(it)]
    wsolve = _mod("wsolve")
    if not items or wsolve is None or not hasattr(wsolve, "find_w_solutions") or not (local.get("balances") or []):
        return
    b = max(5.0, min(_left(ctx) / 3.0, 60.0 if mode == "heavy" else 10.0))
    kw = {}
    if mode == "heavy":
        kw["limits"] = {"MAX_FACTOR_TERMS": 600, "MAX_FACTOR_DEGREE": 30, "MAX_STATE_TERMS": 6000,
                        "MAX_EQ_TERMS": 1500, "MAX_SUBST_COST": 1000000, "MAX_VALUE_OPS": 800,
                        "MAX_VERIFY_CHARS": 12000}
    ws = _call(ctx, "direct search on the open parameter strata", wsolve.find_w_solutions, eq, local,
               max_poles=1, budget_s=b, _timeout=2.5 * b + 30.0, **kw)
    if not ws:
        return
    sols = [x for x in ws.get("solutions", []) or []
            if isinstance(x, dict) and x.get("kind") != "constant"
            and (x.get("certificate") or {}).get("status") == "pass"
            and any("==" in str(c) for c in x.get("conditions") or [])]
    if not sols:
        return
    hits = _call(ctx, "open parameter strata: which solutions lie on them", _match_open_strata, sols, items,
                 list(eq.params), _timeout=40.0)
    if not hits:
        return
    added = {}
    for sol, hs in zip(sols, hits):
        if not hs:
            continue
        sol = dict(sol)
        note = "found by a direct search on parameter values that the decision procedure did not analyse"
        sol["note"] = (str(sol["note"]) + "; " + note) if sol.get("note") else note
        n0 = len(report["found"])
        _add_found(report, sol, "live:wsolve")
        if len(report["found"]) > n0:
            for i in hs:
                added.setdefault(i, []).append(report["found"][-1]["id"])
    if not added:
        return
    for i, ids in added.items():
        it = items[i]
        it["partial"] = "solutions with one pole in a period found on these parameter values by a direct search: " \
            + ", ".join(ids) + " (the list there is not claimed complete)"
    v = decided.get("verdict") or {}
    v["text"] = str(v.get("text", "")).rstrip() + " On the parameter values that were not analysed, the solutions " \
        "found by a direct search (one pole in a period) are listed with their conditions."
    v["supplement"] = sum(len(x) for x in added.values())


def _sol_key(sol):
    conds = sorted(_norm_cond(c) for c in (sol.get("conditions") or []))
    consts = sol.get("constants") or {}
    return (sol.get("kind"), str(sol.get("expr")).replace(" ", ""),
            json.dumps(dict((str(k), str(v)) for k, v in consts.items()), sort_keys=True), tuple(conds))


def _add_item(report, key, item, src=None):
    if isinstance(item, str):
        item = {"what": item}
    if not isinstance(item, dict):
        return
    sig = (item.get("what"), json.dumps(item.get("conditions"), sort_keys=True, default=str))
    for old in report[key]:
        if (old.get("what"), json.dumps(old.get("conditions"), sort_keys=True, default=str)) == sig:
            return
    if src:
        item = dict(item, _src=src)
    report[key].append(item)


def _merge_lists(report, part, origin=None, src=None):
    for sol in part.get("found", []) or []:
        _add_found(report, sol, origin)
    for key in ("ruled_out", "not_decided"):
        for item in part.get(key, []) or []:
            _add_item(report, key, item, src)


# ----------------------------------------------------------------------------------------------- the report
def analyze(text_or_eq, mode="light", budget_s=30, **options):
    t_start = time.monotonic()
    log, warnings = [], []
    hard = bool(options.get("hard", mode == "heavy"))
    if hard:
        try:
            import os
            hard = hasattr(os, "fork")
        except Exception:
            hard = False
    _FAST_ONLY[0] = not hard
    ctx = {"log": log, "t0": t_start, "budget_s": float(budget_s), "failures": [], "timeouts": [], "hard": hard,
           "progress": None if hard else options.get("progress")}
    depth = int(options.get("_depth", 0))
    report = {"schema": "mero-report/1", "engine": ENGINE_VERSION, "mode": mode,
              "input": {"text": text_or_eq if isinstance(text_or_eq, str) else None, "kind": "ode"},
              "found": [], "ruled_out": [], "not_decided": [], "theorems": [], "classes": [], "rejected": [],
              "warnings": warnings, "log": log}

    # 1. the equation ----------------------------------------------------------------------------------------
    if isinstance(text_or_eq, str):
        text = text_or_eq.strip()
        pde, parse = _mod("pde"), _mod("parse")
        kind = "ode"
        if pde is not None and hasattr(pde, "detect_kind"):
            kind = _call(ctx, "detect kind", pde.detect_kind, text, _soft=True) or "ode"
        report["input"]["kind"] = kind
        try:
            if kind == "pde" and pde is not None:
                reds = pde.travelling_wave(pde.parse_pde(text))
                red = reds[min(int(options.get("reduction_index", 0)), len(reds) - 1)]
                eq = red["equation"]
                report["input"]["reduction"] = {
                    "ansatz": red.get("ansatz"), "integrated": red.get("integrated"),
                    "constants": [str(c) for c in red.get("constants", []) or []], "note": red.get("note", ""),
                    "constraints": [str(c) for c in red.get("constraints", []) or []],
                    "conditions": [str(c) for c in red.get("conditions", []) or []],
                    "chirp": red.get("chirp"), "mode": red.get("mode"),
                    "sign_convention": red.get("sign_convention"),
                    "coefficients": dict((str(k), str(v)) for k, v in (red.get("coefficients") or {}).items())
                    if isinstance(red.get("coefficients"), dict) else red.get("coefficients"),
                    "lowered": red.get("lowered"),
                    "alternatives": [{"index": i, "integrated": r.get("integrated"), "ansatz": r.get("ansatz"),
                                      "order": getattr(r.get("equation"), "K", None)} for i, r in enumerate(reds)]}
            elif parse is not None and hasattr(parse, "parse_ode"):
                eq = parse.parse_ode(text, unknown=options.get("unknown"), var=options.get("var"))
            else:
                eq = _fallback_parse(text, unknown=options.get("unknown"))
                warnings.append("fallback parser in use")
        except Exception as exc:
            report["verdict"] = {"level": "unsupported", "text": "The input could not be read: %s" % exc, "basis": []}
            report["elapsed_s"] = round(time.monotonic() - t_start, 3)
            return report
    else:
        eq = text_or_eq
    for wmsg in getattr(eq, "warnings", []) or []:
        warnings.append(str(wmsg))
    report["equation"] = _equation_block(eq)
    symbolic = len(eq.params) > 0

    # 2. local analysis ---------------------------------------------------------------------------------------
    laurent = _mod("laurent")
    local = None
    if laurent is not None and hasattr(laurent, "local_analysis"):
        local = _call(ctx, "local analysis", laurent.local_analysis, eq,
                      budget_s=max(5.0, min(40.0, 0.2 * budget_s)), _timeout=max(8.0, min(60.0, 0.3 * budget_s)))
        if local is None and ctx.get("hard"):                    # second try without the special loci
            local = _call(ctx, "local analysis (without special loci)", laurent.local_analysis, eq,
                          budget_s=max(5.0, min(30.0, 0.15 * budget_s)), depth=-1,
                          _timeout=max(8.0, min(45.0, 0.2 * budget_s)))
    if local is None:
        local = _call(ctx, "local analysis (reference implementation)", _bootstrap_local, eq) or {"balances": []}
    report["local"] = local

    # 3. constants --------------------------------------------------------------------------------------------
    consts = _call(ctx, "constant solutions", _constants, eq, _timeout=20.0) or {}
    for item in _const_items(consts):
        _add_found(report, item)

    # 4. theorems ---------------------------------------------------------------------------------------------
    classes = _mod("classes")
    tier = None
    if classes is not None:
        if hasattr(classes, "classify"):
            report["classes"] = _call(ctx, "classify", classes.classify, eq, local) or []
        if hasattr(classes, "tier"):
            tier = _call(ctx, "theorems", classes.tier, eq, local, _timeout=40.0)
    if tier:
        report["theorems"] = tier.get("theorems", []) or []
        for item in tier.get("ruled_out", []) or []:
            _add_item(report, "ruled_out", item, "tier")
        for item in tier.get("not_decided", []) or []:
            _add_item(report, "not_decided", item, "tier")
        report["tier"] = dict((k, v) for k, v in tier.items() if k not in ("theorems", "ruled_out", "not_decided"))

    # 5. decision modules for orders one and two --------------------------------------------------------------
    decided = None
    if eq.K == 1:
        m1 = _mod("order1")
        if m1 is not None and hasattr(m1, "order1_answer"):
            decided = _call(ctx, "order one", m1.order1_answer, eq)
    elif eq.K == 2:
        m2, m2b = _mod("order2"), _mod("order2b")
        if m2 is not None and hasattr(m2, "order2_answer"):
            decided = _call(ctx, "order two", m2.order2_answer, eq,
                            budget_s=min(_left(ctx), 40.0 if mode == "heavy" else 15.0),
                            _timeout=max(20.0, min(120.0, 0.4 * budget_s)))
        conservative = bool(getattr(eq, "solved", False)) and not any(m[1] for m in eq.terms)
        if not conservative and m2b is not None and hasattr(m2b, "order2b_answer"):
            d2 = _call(ctx, "order two, even in w'", m2b.order2b_answer, eq, budget_s=min(_left(ctx), 30.0),
                       _timeout=max(15.0, min(60.0, 0.25 * budget_s)))
            if d2 and d2.get("applies"):
                decided = _combine_order2(decided if (decided and decided.get("applies")) else None, d2)
    low_complete = low_applies = False
    if decided and decided.get("applies"):
        decided = _generic_upgrade(decided, symbolic)
        if any(x.get("kind") == "constant" for x in decided.get("found") or []):
            report["found"] = [x for x in report["found"] if x.get("origin") != "live:constants"]
        _merge_lists(report, decided, src="low_order")
        report["low_order"] = dict((k, v) for k, v in decided.items()
                                   if k not in ("found", "ruled_out", "not_decided", "applies"))
        low_level = (decided.get("verdict") or {}).get("level")
        low_complete = low_level == "complete"
        low_applies = low_level in ("complete", "complete-W", "partial")
        if low_applies:
            for key in ("ruled_out", "not_decided"):
                report[key] = [it for it in report[key] if it.get("_src") != "tier"]
        if low_complete:                 # the decision module supersedes the general statements of the theorems
            report["not_decided"] = [it for it in report["not_decided"] if it.get("_src") != "tier"]
        if low_applies and symbolic and depth == 0 and options.get("supplement", True):
            try:
                _supplement_open_strata(report, eq, local, ctx, mode, budget_s, decided)
            except Exception as exc:
                log.append("direct search on open strata: %s" % str(exc)[:200])

    ent = ends = bound = fc = ws = None
    linear = report["equation"]["degree"] <= 1
    if linear:
        low_applies = True                      # nothing below applies to a linear equation
        entire = _mod("entire")
        if entire is not None and hasattr(entire, "entire_solutions"):
            ent = _call(ctx, "solutions without poles", entire.entire_solutions, eq,
                        budget_s=min(_left(ctx), 30.0), _timeout=50.0)
            if ent:
                for key in ("polynomials", "exponentials"):
                    for sol in ent.get(key, []) or []:
                        _add_found(report, sol, "live:entire")
    if not low_applies:
        # 6. solutions without poles --------------------------------------------------------------------------
        entire = _mod("entire")
        if entire is not None and hasattr(entire, "entire_solutions"):
            ent = _call(ctx, "solutions without poles", entire.entire_solutions, eq,
                        budget_s=min(_left(ctx), 30.0), _timeout=50.0)
            if ent:
                for key in ("polynomials", "exponentials"):
                    for sol in ent.get(key, []) or []:
                        _add_found(report, sol, "live:entire")
                for item in ent.get("not_decided", []) or []:
                    _add_item(report, "not_decided", item)
                for item in ent.get("ruled_out", []) or []:
                    if isinstance(item, dict) and item.get("what"):
                        _add_item(report, "ruled_out", item)
                report["entire"] = {"complete": ent.get("complete"), "basis": ent.get("basis"),
                                    "complete_conditions": ent.get("complete_conditions"),
                                    "growth": ent.get("growth"), "strata": ent.get("strata"),
                                    "implicit": ent.get("implicit"), "certificate": ent.get("certificate")}

        # 7. ends, pole bound, free coefficients --------------------------------------------------------------
        ends_mod = _mod("ends")
        if ends_mod is not None:
            if hasattr(ends_mod, "end_exponents"):
                ends = _call(ctx, "ends", ends_mod.end_exponents, eq, budget_s=min(_left(ctx), 20.0),
                             _timeout=35.0)
            if hasattr(ends_mod, "pole_bound"):
                bound = _call(ctx, "pole bound", ends_mod.pole_bound, eq, local, budget_s=min(_left(ctx), 20.0),
                              _timeout=40.0)
        report["ends"] = ends
        report["pole_bound"] = bound
        fc_mod = _mod("freecoeff")
        if fc_mod is not None and hasattr(fc_mod, "free_coefficient_values") and getattr(eq, "solved", True) \
                and eq.K >= 3:
            fc = _call(ctx, "free coefficients", fc_mod.free_coefficient_values, eq, local,
                       budget_s=min(_left(ctx), 60.0 if mode == "heavy" else 15.0), _timeout=75.0)
            report["free_coefficients"] = fc

        # 8. rational / simply periodic / elliptic solutions --------------------------------------------------
        wsolve = _mod("wsolve")
        if wsolve is not None and hasattr(wsolve, "find_w_solutions") and (local.get("balances") or []):
            n_bound, _n_src = _pole_bound(tier, fc, bound)
            # two poles in a period: never when there is exactly one Laurent series; in the heavy version whenever
            # the bound is 2 or more or unknown; in the browser only for numeric equations with time to spare
            single = (tier or {}).get("laurent_series_count") == 1 or n_bound == 1
            if "max_poles" in options:
                cap = int(options["max_poles"])
            elif single:
                cap = 1
            elif mode == "heavy":
                cap = 2
            else:
                cap = 2 if (not symbolic and budget_s >= 30) else 1
            max_poles = max(1, min(cap, n_bound if n_bound else cap))
            ws_kwargs = {}
            if mode == "heavy":
                ws_kwargs["limits"] = {"MAX_FACTOR_TERMS": 600, "MAX_FACTOR_DEGREE": 30, "MAX_STATE_TERMS": 6000,
                                       "MAX_EQ_TERMS": 1500, "MAX_SUBST_COST": 1000000, "MAX_VALUE_OPS": 800,
                                       "MAX_VERIFY_CHARS": 12000}
            reserve = (15.0 if options.get("atlas", True) else 0.0) + (0.25 * budget_s if symbolic and depth == 0 else 0.0)
            solver = wsolve.find_w_solutions
            nfs = _mod("nfsolve") if (mode == "heavy" and symbolic and ctx.get("hard") and
                                      options.get("normal_form_solver", True)) else None
            if nfs is not None and hasattr(nfs, "find_w_solutions_nf") and getattr(eq, "solved", True):
                solver = nfs.find_w_solutions_nf          # returns the plain solver's result when nothing is gained
                ws_kwargs["cover_degenerate"] = True
            # the solver's budget bounds the solving only; its checks may take as long again
            if max_poles > 1 and ctx.get("hard"):
                b1 = max(5.0, min(_left(ctx, reserve) / 2.6, 0.15 * budget_s))
                ws1 = _call(ctx, "rational, simply periodic and elliptic solutions (one pole)",
                            solver, eq, local, max_poles=1, ends=ends,
                            budget_s=b1, _timeout=2.5 * b1 + 30.0, **ws_kwargs)
                ws = None
                if _left(ctx, reserve) > 20.0:
                    b2 = max(5.0, min(_left(ctx, reserve) / 2.6, 0.22 * budget_s))
                    ws = _call(ctx, "rational, simply periodic and elliptic solutions (two poles)",
                               solver, eq, local, max_poles=max_poles, ends=ends,
                               budget_s=b2, _timeout=2.5 * b2 + 30.0, **ws_kwargs)
                if ws is None:
                    ws, max_poles = ws1, 1
                elif ws1:
                    ws = _merge_searches(ws1, ws)
            else:
                ws_budget = max(5.0, min(_left(ctx, reserve) / 2.6,
                                         0.22 * budget_s if max_poles > 1 else 0.3 * budget_s))
                ws = _call(ctx, "rational, simply periodic and elliptic solutions", solver, eq,
                           local, max_poles=max_poles, ends=ends, budget_s=ws_budget,
                           _timeout=2.5 * ws_budget + 30.0, **ws_kwargs)
            if ws is None and solver is not wsolve.find_w_solutions and _left(ctx, reserve) > 20.0:
                # the normal-form route did not return: the plain solver with one pole, so that something is listed
                ws_kwargs.pop("cover_degenerate", None)
                b0 = max(5.0, min(_left(ctx, reserve) / 2.6, 0.15 * budget_s))
                ws = _call(ctx, "rational, simply periodic and elliptic solutions (one pole, plain form)",
                           wsolve.find_w_solutions, eq, local, max_poles=1, ends=ends,
                           budget_s=b0, _timeout=2.5 * b0 + 30.0, **ws_kwargs)
                max_poles = 1
            if ws:
                ws = _tidy_search(ws)
                verify_mod = _mod("verify")
                for sol in ws.get("solutions", []) or []:
                    # a second look at forms verified "modulo relations" or with several poles (found necessary)
                    if verify_mod is not None and hasattr(verify_mod, "numeric_check") and \
                            (sol.get("relations") or (sol.get("poles_per_period") or 1) > 1) and \
                            (sol.get("certificate") or {}).get("status") == "pass":
                        nc = _call(ctx, "numerical second check of a solution", _second_check, eq, sol,
                                   _timeout=25.0)
                        ok_nc = nc.get("ok", nc.get("pass", nc.get("status") in ("pass", "zero"))) \
                            if isinstance(nc, dict) else (bool(nc) if nc is not None else None)
                        if ok_nc is False:
                            report["rejected"].append({"expr": sol.get("expr"), "conditions": sol.get("conditions"),
                                                       "why": "the numerical second check failed",
                                                       "origin": "live:wsolve"})
                            continue
                    _add_found(report, sol, "live:wsolve")
                cov0 = _coverage(ws, local, ends, ent)
                ctx["one_pole_complete"] = bool(cov0.get("one_pole") and cov0.get("growth_ok") and cov0.get("poly_ok"))
                report["w_search"] = {"certificates": ws.get("certificates"), "incomplete": ws.get("incomplete"),
                                      "max_poles": max_poles}
                nf = ws.get("nf")
                if isinstance(nf, dict):
                    report["w_search"]["normal_form"] = dict(
                        (k, nf.get(k)) for k in ("reduced_equation", "symbols", "map", "conditions", "statement",
                                                 "degenerate_loci", "loci_not_covered") if nf.get(k) is not None)
                    report["w_search"]["normal_form"]["note"] = ws.get("nf_note")
                if ws.get("locus_certificates") or ws.get("locus_incomplete"):
                    loci = {}
                    for c in ws.get("locus_certificates") or []:
                        loci.setdefault(str(c.get("locus")), {"finished": [], "unfinished": []})["finished"].append(
                            "%s, poles %s" % (c.get("kind"), c.get("poles")))
                    for c in ws.get("locus_incomplete") or []:
                        loci.setdefault(str(c.get("locus")), {"finished": [], "unfinished": []})["unfinished"].append(
                            "%s, poles %s" % (c.get("kind"), c.get("poles")))
                    report["w_search"]["special_loci"] = [dict(v, conditions=k) for k, v in loci.items()]
                    ctx["nf_loci"] = [set(_norm_cond(c) for c in k.split(", ")) for k in loci]
                    for k, v in loci.items():
                        if v["unfinished"]:
                            _add_item(report, "not_decided", {
                                "what": "parameter values with %s" % k.replace(", ", " and "),
                                "kind": "parameter-locus", "conditions": k.split(", "),
                                "why": "on these values the search did not finish for: %s"
                                       % "; ".join(v["unfinished"]),
                                "partial": "the solutions found there are listed with these conditions"})
                    for cnd in (nf or {}).get("loci_not_covered") or []:
                        _add_item(report, "not_decided", {
                            "what": "parameter values with %s" % cnd, "kind": "parameter-locus",
                            "conditions": [str(cnd)],
                            "why": "the change of variables to the normal form is not defined there, and these "
                                   "values were not reached", "partial": ""})

    # 9. invariant surfaces (solutions with d < K) -------------------------------------------------------------
    darboux = _mod("darboux")
    inv_info = None
    if darboux is not None and hasattr(darboux, "darboux_polynomials") and options.get("darboux", True) \
            and eq.K >= 3 and getattr(eq, "solved", True) and not low_applies and depth == 0:
        dp = _call(ctx, "invariant surfaces", darboux.darboux_polynomials, eq,
                   budget_s=min(_left(ctx, 15.0), 45.0 if mode == "heavy" else 10.0), _timeout=60.0)
        if dp:
            report["invariants"] = dict((k, v) for k, v in dp.items()
                                        if k in ("status", "darboux_polynomials", "first_integrals", "time_functions",
                                                 "incomplete", "searched", "summary", "certificate"))
            inv_info = dp

    # 10. the earlier atlas ------------------------------------------------------------------------------------
    atlasdb = _mod("atlasdb")
    at = None
    if atlasdb is not None and hasattr(atlasdb, "lookup") and options.get("atlas", True) and depth == 0 \
            and report["equation"]["degree"] >= 2:
        at = _call(ctx, "earlier records", atlasdb.lookup, eq, mode=("exact" if mode == "heavy" else "fast"),
                   budget_s=min(30.0 if mode == "heavy" else 12.0, max(5.0, _left(ctx))), _timeout=50.0)
        if at:
            report["atlas"] = at

    # 10b. solutions of the earlier records that the engine does not derive itself (d >= 2) -------------------
    if at:
        _atlas_found(report, at)

    # 10c. changes of variables ---------------------------------------------------------------------------------
    transform = _mod("transform")
    if transform is not None and depth == 0:
        if hasattr(transform, "normal_form_block"):
            nf = _call(ctx, "normal form", transform.normal_form_block, eq, _timeout=25.0)
            if nf:
                report["normal_form"] = nf
        if options.get("twist", True) and not low_applies and hasattr(transform, "exponential_twist") \
                and getattr(eq, "solved", True):
            _twists(report, eq, transform, ctx, mode, options, depth)

    # 11. verdict ----------------------------------------------------------------------------------------------
    _verdict(report, eq, local, tier, decided, ent, ws, ends, fc, bound, at)

    if inv_info:
        info = _invariants(report, eq, inv_info, ctx, mode, options, depth)
        if info:
            _first_integral_upgrade(report, info)

    # 11b. power substitutions: w has no pole of integer order, a power of w may have ---------------------------
    if transform is not None and depth == 0 and options.get("substitutions", True) \
            and hasattr(transform, "power_substitution") and (local.get("non_integer_balances") or []):
        _power_substitutions(report, eq, transform, ctx, mode, options, depth)

    # 12. special parameter loci -------------------------------------------------------------------------------
    if symbolic and options.get("strata", True) and depth < int(options.get("max_depth", 1)) \
            and report["verdict"]["level"] != "unsupported" and not low_applies:
        _strata(report, eq, local, tier, ctx, mode, options, depth)

    try:
        _drop_degenerate(report, eq)
        _degenerate_strata_items(report, eq)
    except Exception as exc:
        log.append("degenerate loci: %s" % str(exc)[:200])
    for sf in report.get("surfaces") or []:
        if isinstance(sf, dict):
            sf.pop("_items", None)
    if depth == 0 and len(report["found"]) > 1:
        dropped = _call(ctx, "copies in the list", _copies, report["found"], [str(q) for q in eq.params],
                        20.0 if mode == "heavy" else 4.0, _timeout=40.0)
        if dropped:
            ids = set(dropped)
            report["found"] = [it for i, it in enumerate(report["found"]) if i not in ids]
    if depth == 0 and symbolic:
        try:
            _drop_degenerate_points(report, eq, ctx)
        except Exception as exc:
            log.append("degenerate loci (points): %s" % str(exc)[:200])
    _d_summary(report)
    pretty = _mod("pretty")
    if pretty is not None and hasattr(pretty, "pretty_report") and options.get("pretty", True) and depth == 0:
        b_p = min(60.0, max(5.0, 0.15 * budget_s)) if mode == "heavy" else min(8.0, max(3.0, 0.15 * budget_s))
        pr = _call(ctx, "readable forms", pretty.pretty_report, report, budget_s=b_p, _timeout=b_p + 30.0)
        if isinstance(pr, dict) and pr.get("found") is not None:
            for key in ("found", "strata", "substitutions", "surfaces"):
                if key in pr:
                    report[key] = pr[key]
    for key in ("ruled_out", "not_decided"):
        for it in report[key]:
            it.pop("_src", None)
    try:
        _finish_verdict(report, tier)
        _mark_complex(report, eq)
    except Exception as exc:
        log.append("verdict label: %s" % str(exc)[:200])
    seen_ids = set()
    for i, it in enumerate(report["found"]):                 # ids unique within the list
        if not it.get("id") or it["id"] in seen_ids:
            n = i + 1
            while "s%d" % n in seen_ids or any(o.get("id") == "s%d" % n for o in report["found"]):
                n += 1
            it["id"] = "s%d" % n
        seen_ids.add(it["id"])
    if ctx["failures"]:
        warnings.append("a part of the analysis failed and was skipped: " + "; ".join(ctx["failures"]))
    if ctx["timeouts"]:
        warnings.append("stopped at the time limit: " + "; ".join(ctx["timeouts"]))
        if report["verdict"].get("level") != "complete":
            _add_item(report, "not_decided", {
                "what": "the parts of the analysis that did not finish: " + "; ".join(ctx["timeouts"]),
                "why": "time limit", "partial": "a longer time limit may decide more"})
    if not report["rejected"]:
        report.pop("rejected")
    report["elapsed_s"] = round(time.monotonic() - t_start, 3)
    return report


# ----------------------------------------------------------------------------------------------- verdict
def _second_check(eq, sol):
    """the numerical second check of mero.verify; a form that it cannot sample is "not checked", not a failure"""
    from mero import verify
    try:
        return verify.numeric_check(eq, sol)
    except Exception as exc:
        return {"ok": None, "why": "%s: %s" % (type(exc).__name__, str(exc)[:120])}


def _tidy_search(ws):
    """(1) a certificate of the external solver with the warning "special parameter values not examined" is not a
    certificate: its form is moved to the unfinished ones; (2) certificates and unfinished forms on a special
    locus of the normal form are kept apart (`locus_certificates`, `locus_incomplete`)"""
    certs, inc, lc, li = [], [], [], []
    for c in ws.get("certificates") or []:
        hw = [w for w in ((c.get("heavy") or {}).get("warnings") or []) if "not examined" in str(w)] \
            if isinstance(c, dict) else []
        if hw:
            c = dict(c, reason="the list of this form holds for generic parameter values only: special parameter "
                               "values were not examined within the time limit")
            (li if c.get("locus") else inc).append(c)
        elif isinstance(c, dict) and c.get("locus"):
            lc.append(c)
        else:
            certs.append(c)
    for i in ws.get("incomplete") or []:
        (li if isinstance(i, dict) and i.get("locus") else inc).append(i)
    out = dict(ws)
    out["certificates"], out["incomplete"] = certs, inc
    out["locus_certificates"], out["locus_incomplete"] = lc, li
    return out


def _merge_searches(ws1, ws2):
    """results of the one-pole search (ws1) put into the results of the search with two poles (ws2): solutions and
    certificates that the second call did not reproduce are added, and a one-pole form that the first call finished
    is not listed as unfinished"""
    out = dict(ws2)
    sols = list(ws2.get("solutions") or [])
    have = set(_sol_key(x) for x in sols if isinstance(x, dict))
    for x in ws1.get("solutions") or []:
        if isinstance(x, dict) and _sol_key(x) not in have:
            sols.append(x)
    certs = list(ws2.get("certificates") or [])

    def ckey(c):
        return (c.get("kind"), tuple(sorted(c.get("poles") or [])), str(c.get("locus") or ""))

    def weak(c):
        return any("not examined" in str(w) for w in ((c.get("heavy") or {}).get("warnings") or []))
    havec = set(ckey(c) for c in certs)
    done1 = set()
    for c in ws1.get("certificates") or []:
        if weak(c):
            continue
        done1.add(ckey(c))
        if ckey(c) not in havec:
            certs.append(c)
    inc = []
    for i in ws2.get("incomplete") or []:
        if isinstance(i, dict) and len(i.get("poles") or [0]) <= 1 and ckey(i) in done1:
            continue
        inc.append(i)
    if not ws2.get("nf") and ws1.get("nf"):
        out["nf"], out["nf_note"] = ws1.get("nf"), ws1.get("nf_note")
    out["solutions"], out["certificates"], out["incomplete"] = sols, certs, inc
    return out


def _pole_bound(tier, fc, bound):
    """(N, source): the smallest proved bound on the number of poles in a period, and where it comes from"""
    cands = []
    if tier and isinstance(tier.get("pole_bound"), int):
        cands.append((tier["pole_bound"], str(tier.get("pole_bound_basis") or "theorems")))
    if fc and isinstance(fc.get("bound_poles_per_period"), int) and fc.get("status") not in ("error",):
        cands.append((fc["bound_poles_per_period"], "T-FREECOEFF"))
    if bound:
        bs = [(bound.get(k) or {}).get("bound") if isinstance(bound.get(k), dict) else None
              for k in ("simply_periodic", "elliptic", "rational")]
        if all(isinstance(b, int) for b in bs):
            cands.append((max(bs), "L-ENDS"))
    if not cands:
        return None, None
    return min(cands, key=lambda t: t[0])


def _coverage(ws, local, ends, ent):
    """what the solver finished: returns a dict used by the verdict"""
    out = {"one_pole": False, "two_pole": False, "missing": [], "growth_ok": False, "poly_ok": False,
           "assumed_nonzero": [], "multi": [], "ran": bool(ws)}
    out["growth_ok"] = bool(ends) and ends.get("growth_possible") is False
    cert = (ent or {}).get("certificate") or {}
    pdb = cert.get("polynomial_degree_bound") or {}
    out["poly_ok"] = pdb.get("bound") == 0
    if not ws:
        out["missing"].append("the search for rational, simply periodic and elliptic solutions did not run")
        return out
    certs = ws.get("certificates") or []
    incomplete = ws.get("incomplete") or []
    orders = sorted(set(int(b["p"]) for b in (local.get("balances") or []) if isinstance(b.get("p"), int)))
    have = set((c.get("kind"), tuple(sorted(c.get("poles") or []))) for c in certs)
    need1 = [(k, (p,)) for k in KINDS for p in orders]
    need2 = [(k, (p1, p2)) for k in KINDS for i, p1 in enumerate(orders) for p2 in orders[i:]]
    lack1 = [n for n in need1 if n not in have]
    lack2 = [n for n in need2 if n not in have]
    for c in certs:
        for a in c.get("assumed_nonzero") or []:
            a = re.sub(r"\s*!=\s*0\s*$", "", str(a))        # the expression that is assumed not to vanish
            if a not in out["assumed_nonzero"]:
                out["assumed_nonzero"].append(a)
    inc1 = [i for i in incomplete if not isinstance(i, dict) or len(i.get("poles") or [0]) <= 1]
    inc2 = [i for i in incomplete if isinstance(i, dict) and len(i.get("poles") or []) == 2]
    out["one_pole"] = bool(orders) and not lack1 and not inc1
    out["two_pole"] = out["one_pole"] and not lack2 and not inc2
    for k, ps in lack1:
        out["missing"].append("%s solutions with one pole of order %d in a period" % (k, ps[0]))
    for inc in incomplete:
        out["missing"].append("unfinished: %s" % (inc.get("ansatz") if isinstance(inc, dict) else str(inc))[:200])
    out["multi"] = sorted(set(len(c.get("poles") or []) for c in certs))
    return out


def _qualifier(cov):
    """the restriction under which the one-pole forms of the solver are exhaustive"""
    q = []
    if not cov.get("growth_ok"):
        q.append("simply periodic ones with finite limits at both ends of the period strip")
    if not cov.get("poly_ok"):
        q.append("rational ones with a finite limit at infinity")
    return q


def _verdict(report, eq, local, tier, decided, ent, ws, ends, fc, bound, at):
    """The only place where a level is assigned."""
    symbolic = len(eq.params) > 0
    found_nonconst = [s for s in report["found"] if s.get("kind") != "constant"]

    if decided and decided.get("applies") and decided.get("verdict") and \
            (tier or {}).get("class_of_all_meromorphic_solutions") != "entire (linear equation)":
        v = dict(decided["verdict"])
        v.setdefault("basis", decided.get("basis") or [])
        sc = v.get("scope")
        if isinstance(sc, dict):
            v["scope_detail"] = sc
            gen = str(sc.get("parameters", "")).startswith("generic")
            if gen and symbolic and not (sc.get("explored_strata") or sc.get("unexplored")) and \
                    not any(_is_special_locus(it) or it.get("kind") == "parameter-locus"
                            for it in report["not_decided"]):
                _add_item(report, "not_decided", {
                    "what": "special values of the parameters", "kind": "parameter-locus",
                    "why": "the statement is for generic values of the parameters; the values at which the analysis "
                           "changes were not enumerated",
                    "partial": "substitute numbers for the parameters to get the answer at a particular point"})
            sc = "generic parameter values" if gen else None
        if not symbolic:
            sc = "this equation"
        elif sc not in ("generic parameter values", "all parameter values", "the parameter strata listed"):
            sc = "the parameter strata listed"
        v["scope"] = sc
        if isinstance(v.get("text"), str):
            v["text"] = re.sub(r"\s*\(labels?: [^)]*\)", "", v["text"])
        report["verdict"] = v
        _record_note(report, at)
        return

    tier = tier or {}
    cls = tier.get("class_of_all_meromorphic_solutions")
    used = list(tier.get("used") or [])
    generic = bool(tier.get("generic"))
    conds = list(tier.get("conditions_factored") or tier.get("conditions") or [])
    n_bound, n_src = _pole_bound(tier, fc, bound)
    ent_complete = bool(ent) and ent.get("complete") is True
    ent_const = tier.get("entire_solutions") == "constants"
    entire_ok = ent_complete or ent_const
    cov = _coverage(ws, local, ends, ent) if cls != "entire only" else {"assumed_nonzero": [], "ran": False}
    for a in cov.get("assumed_nonzero") or []:
        c = "%s != 0" % a
        if c not in conds:
            conds.append(c)
    if ent_complete and not ent_const and cls != "entire (linear equation)":
        for c in ent.get("complete_conditions") or []:
            c = str(c)
            if c not in conds:
                conds.append(c)
    scope_generic = symbolic and (generic or bool(conds))
    if conds and not symbolic:                    # a numeric equation: the conditions are facts, not a scope
        conds_note = conds
        conds = []
    else:
        conds_note = []
    prefix = ""
    if scope_generic:
        prefix = "For generic values of the parameters (%s): " % "; ".join(conds) if conds else \
            "For generic values of the parameters: "
    basis, level, text = list(used), None, None
    head = "every meromorphic solution is rational, simply periodic or elliptic"
    if n_bound is not None:
        head += ", with at most %d pole%s in a period" % (n_bound, "" if n_bound == 1 else "s") if n_bound else \
            ", and has no pole"
        if n_src and n_src not in basis:
            basis.append(n_src)
        if tier.get("pole_bound") != n_bound and cls in W_CLASSES:
            _add_item(report, "ruled_out", {
                "what": ("rational, simply periodic or elliptic solutions with more than %d pole%s in a period"
                         % (n_bound, "" if n_bound == 1 else "s")) if n_bound else
                        "rational, simply periodic or elliptic solutions with a pole",
                "basis": {"theorem": n_src, "label": "agent-proof"}, "conditions": list(conds)})

    if cls == "listed (not all in W)" and tier.get("text"):
        level = "partial"
        text = prefix + _lower_first(tier["text"], prefix) + " The solutions with closed forms that were computed " \
            "here are listed below; the others are described in the statement cited."
        _add_item(report, "not_decided", {
            "what": "closed forms for the solutions that are not rational, simply periodic or elliptic",
            "why": "they are described by the theorem cited in the verdict, not computed here",
            "partial": tier["text"]})
    elif cls == "entire (linear equation)":
        r = _fresh(eq, "r")
        chi = sp.expand(sum(co * r ** j for j, co in enumerate(
            [eq.terms.get(tuple(1 if i == j else 0 for i in range(eq.K + 1)), 0) for j in range(eq.K + 1)])))
        report["found"].append({
            "id": "lin", "kind": "entire", "d": None, "expr": None,
            "description": "the general solution: a particular polynomial solution plus the sum of "
                           "q_i(z)*exp(r_i*z) over the roots r_i of chi(%s) = %s, with arbitrary polynomials q_i "
                           "of degree less than the multiplicity of r_i" % (r, _s(chi)),
            "latex": "w = w_{p}(z) + \\sum_i q_i(z)\\,e^{r_i z},\\qquad \\chi(%s) = %s = 0" % (r, sp.latex(chi)),
            "free": ["the coefficients of the q_i"], "conditions": [], "label": "certificate",
            "certificate": {"type": "linear equation", "status": "pass",
                            "detail": "linear equation with constant coefficients"},
            "origin": "live:linear"})
        level = "complete"
        text = prefix + _lower_first(tier.get("text") or "The equation is linear with constant coefficients: every "
                                     "solution is entire.", prefix) + " The general solution is described in the list."
        report["not_decided"] = [it for it in report["not_decided"] if it.get("_src") != "tier"]
    elif cls == "entire only" and entire_ok:
        level = "complete"
        text = prefix + _lower_first("No meromorphic solution has a pole, and the solutions without poles are the "
                                     "ones listed.", prefix)
        if ent and ent.get("basis"):
            basis += [b for b in ent["basis"] if b not in basis]
    elif cls in W_CLASSES:
        can1 = cov["one_pole"] and cov["growth_ok"] and cov["poly_ok"] and entire_ok
        if n_bound is not None and n_bound <= 1 and can1:
            level = "complete"
        elif n_bound is not None and n_bound == 2 and can1 and cov["two_pole"]:
            level = "complete"
        if level == "complete":
            text = prefix + _cap(head, prefix) + ". All of them are listed" + \
                (" (each family with the conditions on the parameters under which it exists)." if symbolic else ".")
            basis.append("certificate: the systems for %s in a period" %
                         ("one pole" if n_bound <= 1 else "one and two poles"))
            if isinstance((ws or {}).get("nf"), dict):
                basis.append("certificate: the systems were solved after the change of variables to the normal "
                             "form (w = alpha*W(z/gamma) + beta), which maps solutions to solutions for the "
                             "parameter values of the scope")
            _certificate_ruled_out(report, ws, symbolic, cov, conds)
        else:
            level = "partial"
            done, missing = [], list(cov["missing"])
            if cov["one_pole"]:
                q = _qualifier(cov)
                done.append("all such solutions with one pole in a period are listed" +
                            (" (%s)" % "; ".join(q) if q else ""))
            if n_bound is None:
                missing.append("solutions with more than one pole in a period (no bound on the number of poles is "
                               "available here)")
            elif n_bound >= 2 and not cov.get("two_pole"):
                missing.append("solutions with %s poles in a period" % ("2" if n_bound == 2 else "2 to %d" % n_bound))
            elif n_bound >= 3:
                missing.append("solutions with 3 to %d poles in a period" % n_bound)
            if not cov["growth_ok"] and cov.get("ran"):
                missing.append("simply periodic solutions that grow exponentially at an end of the period strip")
            if not cov["poly_ok"] and cov.get("ran"):
                missing.append("rational solutions that grow at infinity")
            if not entire_ok:
                missing.append("transcendental solutions without poles")
            if not missing:
                missing.append("the completeness of the list was not established")
            text = prefix + _cap(head, prefix) + ". " + ("; ".join(done).capitalize() + ". " if done else "") + \
                "Not computed: " + "; ".join(missing) + "."
            for m in missing:
                _add_item(report, "not_decided", {"what": m, "why": "not computed in this run",
                                                  "partial": head + " (" + ", ".join(basis) + ")"})
            if cov["one_pole"]:
                _certificate_ruled_out(report, ws, symbolic, cov, conds)
    else:
        cov_ok = bool(ws) and cov.get("one_pole")
        if cls == "entire only":
            level = "partial"
            text = prefix + _lower_first("No meromorphic solution has a pole. Solutions without poles: the ones "
                                         "listed; others are not decided.", prefix)
        elif found_nonconst or cov_ok:
            level = "partial"
            q = _qualifier(cov) if cov_ok else []
            text = prefix + _lower_first(
                "No theorem of the registry gives the class of all meromorphic solutions of this equation. "
                + ("All rational, simply periodic and elliptic solutions with one pole in a period are listed%s; "
                   % (" (%s)" % "; ".join(q) if q else "") if cov_ok else "The solutions listed were found; ")
                + "other meromorphic solutions are not decided.", prefix)
            if cov_ok:
                _certificate_ruled_out(report, ws, symbolic, cov, conds)
        else:
            level = "formal"
            text = prefix + _lower_first("Local analysis only: no theorem of the registry decides this equation, and "
                                         "no solution other than constants was found.", prefix)
        _add_item(report, "not_decided", {
            "what": "meromorphic solutions other than the ones listed (several poles in a period; solutions that are "
                    "not rational, simply periodic or elliptic)",
            "why": "no theorem of the registry gives the class of all meromorphic solutions of this equation",
            "partial": "the local analysis restricts every meromorphic solution: pole orders, leading coefficients, "
                       "Fuchs indices and compatibility conditions are listed below"})
    report["verdict"] = {"level": level, "text": text, "basis": basis,
                         "scope": ("generic parameter values" if scope_generic else
                                   ("all parameter values" if symbolic else "this equation")),
                         "conditions": conds if scope_generic else []}
    if conds_note:
        report["verdict"]["facts_used"] = conds_note
    _record_note(report, at)


def _cap(s, prefix):
    return s if prefix else s[:1].upper() + s[1:]


def _lower_first(s, prefix):
    return (s[:1].lower() + s[1:]) if prefix else s


def _certificate_ruled_out(report, ws, symbolic, cov, conds):
    """for every form that the solver finished: what it excludes, with the scope of the form"""
    by = {}
    for c in (ws or {}).get("certificates") or []:
        npoles = len(c.get("poles") or [])
        if npoles not in (1, 2):
            continue
        if npoles == 2 and not cov.get("two_pole"):
            continue
        by.setdefault((c.get("kind"), npoles), []).append(c)
    extra = ["%s != 0" % a for a in cov.get("assumed_nonzero") or []]
    for (kind, npoles), cs in sorted(by.items(), key=lambda t: (t[0][1], str(t[0][0]))):
        n = sum(len(c.get("solutions") or []) for c in cs)
        orders = sorted(set(tuple(sorted(c["poles"])) for c in cs))
        scope = ""
        if kind == "simply-periodic" and not cov.get("growth_ok"):
            scope = " and finite limits at both ends of the period strip"
        if kind == "rational" and not cov.get("poly_ok"):
            scope = " and a finite limit at infinity"
        poles_txt = "one pole" if npoles == 1 else "two poles"
        if n == 0:
            what = "%s solutions with %s in a period%s" % (kind, poles_txt, scope)
        else:
            what = "%s solutions with %s in a period%s other than those listed" % (kind, poles_txt, scope)
            if symbolic:
                what += " (for parameter values outside the conditions of the listed families none exist"
                what += ("; assumed: %s)" % ", ".join(extra)) if extra else ")"
        _add_item(report, "ruled_out", {
            "what": what, "basis": {"theorem": None, "label": "certificate"},
            "certificate": {"type": "system", "detail": "the general form with %s (orders %s) was substituted and the "
                            "resulting polynomial system solved completely (%s)" %
                            (poles_txt, ", ".join(str(list(o)) for o in orders),
                             "; ".join(sorted(set(str(c.get("method", ""))[:120] for c in cs)))),
                            "scope": "; ".join(sorted(set(str(c.get("scope", "")) for c in cs)))[:400]},
            "conditions": list(dict.fromkeys(list(conds) + extra))})


def _record_note(report, at):
    """an earlier record with a completeness label that contains the equation: noted, never used to raise the level"""
    if not at:
        return
    summ = at.get("summary") or {}
    if summ.get("complete") and summ.get("by"):
        rec = summ["by"]
        label = None
        for m in at.get("matches") or []:
            if m.get("id") == rec:
                label = m.get("label")
        report["verdict"]["record"] = {
            "id": rec, "label": label or "agent-proof", "complete": True,
            "text": "An earlier record of the project (%s, label %s) states the complete list of meromorphic solutions "
                    "for this equation, in the record's own variables; it is shown under 'Earlier records' and was "
                    "not used for the level above." % (rec, label or "agent-proof")}


# ----------------------------------------------------------------------------------------------- changes of variables
def _atlas_found(report, at):
    """solutions with d >= 2 described in the earlier records that contain the equation exactly"""
    seen, seen_d = set(), set()
    matches = sorted(at.get("matches") or [], key=lambda m: (("@" in str(m.get("id"))) or ("COST" in str(m.get("id"))),
                                                               len(str(m.get("id")))))
    for m in matches:
        if m.get("match") != "exact" or m.get("kind") != "wave":
            continue
        site = m.get("site")
        if isinstance(site, str):
            try:
                site = json.loads(site)
            except Exception:
                site = None
        for sol in (site or {}).get("found") or []:
            d = sol.get("d")
            if not (isinstance(d, int) and d >= 2):
                continue
            desc = sol.get("description") or sol.get("closed_form_card") or ""
            if desc in seen or d in seen_d:
                continue
            seen.add(desc)
            seen_d.add(d)
            item = {"id": "rec%d" % (len(seen)), "kind": "other", "d": d, "expr": None,
                    "description": desc, "closed_form_record": sol.get("closed_form_card"),
                    "conditions": [], "free": [], "label": m.get("label") or "agent-proof",
                    "note": "from record %s of the project's earlier atlas, in the variables of the record "
                            "(change of variables: %s)" % (m.get("id"), json.dumps(m.get("change") or {})),
                    "certificate": {"type": "record", "status": "not-run",
                                    "detail": "described in the record; not derived again here"},
                    "origin": "atlas:%s" % m.get("id")}
            at.setdefault("described", []).append(item)


def _solve_conditions(conds, params):
    """conditions of the form 'expr = 0' and 'expr != 0' -> list of substitutions {param: value} (branches)"""
    eqs, neq = [], []
    for c in conds or []:
        c = str(c)
        if "!=" in c:
            neq.append(c)
            continue
        lhs = c.split("=")[0]
        rhs = c.split("=")[-1] if "=" in c else "0"
        try:
            e = sp.sympify(lhs, locals=dict((str(q), q) for q in params)) - \
                sp.sympify(rhs, locals=dict((str(q), q) for q in params))
        except Exception:
            return None, neq
        if e != 0:
            eqs.append(e)
    if not eqs:
        return [{}], neq
    syms = sorted(set().union(*[e.free_symbols for e in eqs]), key=str)
    # prefer to solve for the symbols that occur with the lowest degree
    best = None
    import itertools
    for k in range(len(eqs), 0, -1):
        for combo in itertools.combinations(syms, min(k, len(syms))):
            if len(combo) != len(eqs):
                continue
            try:
                sol = sp.solve(eqs, list(combo), dict=True)
            except Exception:
                sol = []
            sol = [br for br in sol if all(sp.simplify(e.subs(br)) == 0 for e in eqs)]
            if sol and all(not any(v.has(sp.RootOf) for v in br.values()) for br in sol):
                size = sum(sp.count_ops(v) for br in sol for v in br.values())
                if best is None or size < best[0]:
                    best = (size, sol)
        if best:
            break
    return (best[1] if best else None), neq


def _twists(report, eq, transform, ctx, mode, options, depth):
    """w = c + (kappa s)^p Y(s), s = exp(kappa z): solutions through an autonomous equation in s"""
    tws = _call(ctx, "exponential changes of variable", transform.exponential_twist, eq, _soft=True) or []
    special = _mod("special")
    verify = _mod("verify")
    if not tws or special is None or verify is None or not hasattr(verify, "verify_expr"):
        return
    out = []
    S = sp.Symbol("S_twist")
    for tw in tws[:3]:
        target = tw.get("equation")
        ex = (tw.get("map") or {}).get("_exact") or {}
        if target is None or not ex:
            continue
        branches, neq = _branches(ctx, tw.get("conditions"), eq.params)
        entry = {"map": dict((k, v) for k, v in (tw.get("map") or {}).items() if k != "_exact"),
                 "conditions": tw.get("conditions"), "note": tw.get("note"), "solutions": 0}
        out.append(entry)
        if branches is None:
            entry["status"] = "the conditions could not be solved for a parameter; no solution was built"
            continue
        sub = _call(ctx, "equation after the exponential change of variable", analyze, target, mode=mode,
                    budget_s=min(30.0, _left(ctx, 10.0)), _depth=depth + 1, atlas=False, strata=False, twist=False,
                    substitutions=False, darboux=False)
        if not sub:
            continue
        entry["target"] = sub.get("equation")
        entry["target_verdict"] = sub.get("verdict")
        loc = {"wp": getattr(special, "wp", None), "wpp": getattr(special, "wpp", None), "z": z}
        loc = dict((k, v) for k, v in loc.items() if v is not None)
        for ysol in sub.get("found") or []:
            if ysol.get("kind") in ("constant",) or not ysol.get("expr"):
                continue
            try:
                names = set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", ysol["expr"]))
                l2 = dict(loc)
                for nme in names:
                    if nme not in l2 and nme not in ("exp", "sqrt", "I", "pi", "tanh", "coth", "sinh", "cosh"):
                        l2[nme] = sp.Symbol(nme)
                Y = sp.sympify(ysol["expr"], locals=l2)
                for cname, cval in (ysol.get("constants") or {}).items():
                    if isinstance(cval, str) and not cval.startswith("free"):
                        Y = Y.subs(sp.Symbol(cname), sp.sympify(cval, locals=l2))
                if ysol.get("conditions"):
                    continue                       # the target has no parameters; a conditional solution is skipped
                Y = Y.subs(sp.Symbol("z0"), sp.Symbol("s0")).subs(z, S)
            except Exception:
                continue
            for br in branches:
                try:
                    kap = sp.sympify(ex["kappa"]).subs(br)
                    cc = sp.sympify(ex["c"]).subs(br)
                    pp = sp.sympify(ex["p"])
                    if sp.simplify(kap) == 0:
                        continue
                    bad = False
                    for c in neq:
                        lhs = sp.sympify(str(c).split("!=")[0], locals=dict((str(q), q) for q in eq.params))
                        if sp.simplify(lhs.subs(br)) == 0:
                            bad = True
                    if bad:
                        continue                       # the branch contradicts a condition of the change of variable
                    wexpr = cc + (kap * S) ** pp * Y
                    wexpr = wexpr.subs(S, sp.exp(kap * z))
                    if z not in wexpr.free_symbols:
                        continue
                    eq_b = eq.subs(br) if br else eq
                    chk = _call(ctx, "check of a solution built by a change of variable", verify.verify_expr, eq_b,
                                sp.sstr(wexpr), _timeout=30.0)
                except Exception as exc:
                    ctx["log"].append("twist: a candidate could not be checked: %s" % str(exc)[:200])
                    continue
                if (chk or {}).get("status") != "zero":
                    report["rejected"].append({"expr": sp.sstr(wexpr), "why": "substitution check: %s" %
                                               (chk or {}).get("status"), "origin": "live:twist"})
                    continue
                rational_in_s = ysol.get("kind") == "rational"
                if rational_in_s and ctx.get("one_pole_complete"):
                    entry["note2"] = "a solution rational in s gives a simply periodic solution; the solver lists " \
                                     "those itself"
                    continue
                conds = ["%s == %s" % (k, _s(v)) for k, v in br.items()] + [c.replace(" = ", " == ") if "!=" not in c
                                                                             else c for c in neq]
                item = {"kind": "simply-periodic" if rational_in_s else "other", "d": 1 if rational_in_s else 2,
                        "expr": sp.sstr(wexpr), "latex": sp.latex(wexpr),
                        "free": ["s0"] + [f for f in (ysol.get("free") or []) if f not in ("z0",)],
                        "conditions": conds,
                        "note": "w = c + (kappa s)^p Y(s) with s = exp(kappa z); Y(s) is a %s solution of %s"
                                % (ysol.get("kind"), (sub.get("equation") or {}).get("sympy")),
                        "certificate": {"type": "substitution", "method": "symbolic", "status": "pass",
                                        "detail": (chk or {}).get("detail", "exact substitution")},
                        "origin": "live:twist"}
                _add_found(report, item)
                entry["solutions"] += 1
    if out:
        report["twists"] = out


def _power_substitutions(report, eq, transform, ctx, mode, options, depth):
    """u = w^m when w has a balance of non-integer order: analyse the equation for u"""
    subs = _call(ctx, "power substitutions", transform.power_substitution, eq, _soft=True) or []
    out = []
    for sb in subs[:2]:
        target = sb.get("equation")
        if target is None or _left(ctx) < 5.0:
            continue
        sub = _call(ctx, "equation after the substitution %s" % (sb.get("map") or {}).get("u", ""), analyze, target,
                    mode=mode, budget_s=min(40.0, _left(ctx, 2.0)), _depth=depth + 1, atlas=False, strata=False,
                    twist=False, substitutions=False, darboux=False)
        if not sub:
            continue
        out.append({"name": sb.get("name"), "map": sb.get("map"), "note": sb.get("note"),
                    "conditions": sb.get("conditions"), "equation": sub.get("equation"),
                    "verdict": sub.get("verdict"), "found": sub.get("found"), "ruled_out": sub.get("ruled_out"),
                    "not_decided": sub.get("not_decided"), "local": sub.get("local")})
    if out:
        report["substitutions"] = out
        v = report["verdict"]
        best = out[0]
        v["after_substitution"] = {"map": best.get("map"), "level": (best.get("verdict") or {}).get("level"),
                                   "text": (best.get("verdict") or {}).get("text"),
                                   "found": len([x for x in (best.get("found") or []) if x.get("kind") != "constant"])}


def _drop_degenerate(report, eq):
    """found items that live on a parameter locus where the equation loses order or degree are not listed:
    there the visitor's equation is a different equation"""
    params = dict((str(q), q) for q in eq.params)
    if not params:
        return
    cache, keep, loci = {}, [], []
    for it in report["found"]:
        subs = {}
        for c in it.get("conditions") or []:
            c = str(c)
            if "==" not in c:
                continue
            a, b = [x.strip() for x in c.split("==", 1)]
            if a in params:
                try:
                    val = sp.sympify(b, locals=params)
                except Exception:
                    continue
                if not (val.free_symbols - set(params.values())) and params[a] not in val.free_symbols:
                    subs[params[a]] = val
        key = tuple(sorted((str(k), sp.sstr(v)) for k, v in subs.items()))
        if not key:
            keep.append(it)
            continue
        if key not in cache:
            try:
                cache[key] = _degenerate(eq, eq.subs(subs))
            except Exception:
                cache[key] = False
        if cache[key]:
            txt = ", ".join("%s = %s" % kv for kv in key)
            if txt not in loci:
                loci.append(txt)
        else:
            keep.append(it)
    if loci:
        report["found"] = keep
        report["degenerate_loci"] = {
            "loci": loci,
            "note": "on these parameter loci the equation has lower order or lower degree (a coefficient of a "
                    "leading term vanishes); it is then a different equation, and its solutions are not listed here"}


_FAST_ONLY = [False]      # True in the browser: no general solving of parameter conditions without a time limit


def _locus_point(conds, params, rnd, tries=4):
    """a numeric point of the parameter space on which the equalities among `conds` hold and the inequalities too
    ({symbol: number}), or None"""
    conds = [str(c) for c in conds or []]
    eqs = [c for c in conds if "==" in c]
    loc = dict((str(q), q) for q in params)
    brs = None
    # fast path: every equality reads "parameter == expression in the other parameters"
    direct = {}
    for c in eqs:
        m = re.match(r"^\s*([A-Za-z_][A-Za-z_0-9]*)\s*==\s*(.+)$", c)
        if not m or m.group(1) not in loc or loc[m.group(1)] in direct:
            direct = None
            break
        try:
            val = sp.sympify(m.group(2), locals=loc)
        except Exception:
            direct = None
            break
        if loc[m.group(1)] in val.free_symbols or (val.free_symbols & set(direct)):
            direct = None
            break
        direct[loc[m.group(1)]] = val
    if direct is not None:
        # a value may contain a parameter that is fixed by an earlier condition only if that one is substituted
        if not any(v.free_symbols & set(direct) for v in direct.values()):
            brs = [direct]
    if brs is None and not _FAST_ONLY[0]:
        try:
            brs, _neq = _solve_conditions(eqs, params) if eqs else ([{}], [])
        except Exception:
            brs = None
    for br in (brs or [])[:2]:
        for _ in range(tries):
            vals = dict((q, sp.Rational(rnd.randint(2, 40), rnd.randint(3, 17)) * rnd.choice([1, -1]))
                        for q in params if q not in br)
            try:
                cand = dict(vals)
                for q, val in br.items():
                    cand[q] = sp.N(sp.sympify(val).subs(vals), 40)
                if all(abs(complex(x)) < 1e12 for x in cand.values()) and \
                        all(_cond_holds(c, cand, loc) is not False for c in conds):
                    return cand
            except Exception:
                continue
    return None


def _drop_degenerate_points(report, eq, ctx):
    """found items whose conditions (several equalities, not of the form parameter == value) put them on a locus
    where the equation loses order or degree: decided at a numeric point of the locus"""
    import random
    params = list(eq.params)
    items = [(i, it) for i, it in enumerate(report["found"])
             if len([c for c in it.get("conditions") or [] if "==" in str(c)]) >= 2]
    if not items or not params:
        return
    seen = {}
    todo = []
    for i, it in items:
        key = tuple(sorted(str(c) for c in it.get("conditions") or [] if "==" in str(c)))
        if key not in seen:
            seen[key] = None
            todo.append(key)
    terms = dict((m, sp.sstr(c)) for m, c in eq.terms.items())
    res = _call(ctx, "degenerate loci of listed solutions", _degenerate_points, terms, [list(k) for k in todo],
                [str(q) for q in params], eq.K, _timeout=30.0)
    if not res:
        return
    bad = set(tuple(k) for k, flag in zip(todo, res) if flag)
    if not bad:
        return
    keep = []
    dl = report.setdefault("degenerate_loci", {
        "loci": [],
        "note": "on these parameter loci the equation has lower order or lower degree (a coefficient of a "
                "leading term vanishes); it is then a different equation, and its solutions are not listed here"})
    for it in report["found"]:
        key = tuple(sorted(str(c) for c in it.get("conditions") or [] if "==" in str(c)))
        if key in bad:
            txt = ", ".join(key)
            if txt not in dl["loci"]:
                dl["loci"].append(txt)
        else:
            keep.append(it)
    report["found"] = keep


def _degenerate_points(terms, cond_lists, param_names, K):
    import random
    rnd = random.Random(7)
    params = [sp.Symbol(n) for n in param_names]
    loc = dict((n, q) for n, q in zip(param_names, params))
    coeffs = dict((m, sp.sympify(c, locals=loc)) for m, c in terms.items())
    d0 = max(sum(m) for m in coeffs)
    top_order = [c for m, c in coeffs.items() if m[K] > 0]
    top_degree = [c for m, c in coeffs.items() if sum(m) == d0]
    out = []
    for conds in cond_lists:
        pt = _locus_point(conds, params, rnd)
        if pt is None:
            out.append(False)
            continue

        def zero(cs):
            try:
                return all(abs(complex(sp.N(c.subs(pt), 30))) < 1e-12 for c in cs)
            except Exception:
                return False
        out.append(bool(zero(top_order) or zero(top_degree)))
    return out


def _copies(found, param_names, limit_s=20.0):
    """indices of found items that repeat another item: the same function (after its conditions are substituted)
    as an item with fewer conditions, or the same function with other names for the free constants.  Decided
    numerically at random points; an item is dropped only if a more general or earlier item covers it."""
    import random
    rnd = random.Random(11)
    params = [sp.Symbol(n) for n in param_names]
    loc = dict((n, q) for n, q in zip(param_names, params))
    z = sp.Symbol("z")
    funcs = {}
    special = _mod("special")

    def build(it):
        expr = it.get("expr")
        if not expr or it.get("kind") == "constant" or len(str(expr)) > 600:
            return None
        names = set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", str(expr)))
        if names & {"wp", "wpp", "zeta_w", "RootOf", "any"}:
            return None                      # elliptic forms and implicit constants are not compared here
        try:
            l2 = dict(loc)
            l2["z"] = z
            e = sp.sympify(str(expr), locals=l2)
            consts = it.get("constants") or {}
            for _ in range(3):
                sub = {}
                for k, val in consts.items():
                    ks = sp.Symbol(str(k))
                    if ks in e.free_symbols:
                        desc = str(val).strip().lower()
                        if desc.startswith(("free", "arbitrary")):
                            continue                    # a free constant: stays a symbol
                        if not re.match(r"^[-+0-9A-Za-z_*/(). ]+$", str(val)) or \
                                desc.startswith(("any", "a root", "root", "one of", "the ")):
                            return None                 # a constant given in words: the item is not compared
                        try:
                            vv = sp.sympify(str(val), locals=l2)
                        except Exception:
                            return None
                        if not isinstance(vv, sp.Expr):
                            return None
                        sub[ks] = vv
                if not sub:
                    break
                e = e.subs(sub)
            return e
        except Exception:
            return None

    t_end = time.time() + float(limit_s)
    exprs = [build(it) for it in found]
    conds = [[_norm_cond(c) for c in (it.get("conditions") or [])] for it in found]
    drop = []
    points = {}
    for i, it in enumerate(found):
        if exprs[i] is None or i in drop:
            continue
        if time.time() > t_end:
            break
        for j, other in enumerate(found):
            if j == i or exprs[j] is None or j in drop or other.get("kind") != it.get("kind"):
                continue
            ci, cj = set(conds[i]), set(conds[j])
            # j covers i if j has fewer conditions (a subset), or the same conditions and comes first
            if not (cj < ci or (cj == ci and j < i)):
                continue
            pkey = tuple(sorted(conds[i]))
            if pkey not in points:
                points[pkey] = _locus_point(it.get("conditions"), params, rnd)
            pt = points[pkey]
            if pt is None:
                continue
            fi, fj = exprs[i], exprs[j]
            free_i = sorted((fi.free_symbols - set(params)) - {z}, key=str)
            free_j = sorted((fj.free_symbols - set(params)) - {z}, key=str)
            if len(free_i) != len(free_j):
                continue
            import itertools
            # the free constants of the two items are matched by name, or else in every order (at most three)
            if set(free_i) == set(free_j):
                orders = [list(free_i)]
            elif len(free_j) <= 3:
                orders = [list(o) for o in itertools.permutations(free_j)]
            else:
                orders = [list(free_j)]
            same = False
            for order_j in orders:
                same = True
                for _ in range(3):
                    vals = dict(pt)
                    vals[z] = sp.Rational(rnd.randint(3, 50), rnd.randint(7, 23))
                    cv = [sp.Rational(rnd.randint(3, 50), rnd.randint(7, 23)) for _ in free_i]
                    vi = dict(vals)
                    vi.update(zip(free_i, cv))
                    vj = dict(vals)
                    vj.update(zip(order_j, cv))
                    try:
                        a = complex(sp.N(fi.subs(vi), 30))
                        b = complex(sp.N(fj.subs(vj), 30))
                    except Exception:
                        same = False
                        break
                    if not (abs(a - b) <= 1e-12 * (1.0 + abs(a) + abs(b))):
                        same = False
                        break
                if same:
                    break
            if same:
                drop.append(i)
                break
    return drop


def _degenerate_strata_items(report, eq):
    """not-decided items of the form 'the stratum p == 0' for a locus where the equation loses order or degree"""
    params = dict((str(q), q) for q in eq.params)
    keep = []
    for it in report["not_decided"]:
        m = re.match(r"^the stratum\s+([A-Za-z_][A-Za-z_0-9]*)\s*==\s*(\S+)\s*$", str(it.get("what", "")))
        if m and m.group(1) in params:
            try:
                val = sp.sympify(m.group(2), locals=params)
                if _degenerate(eq, eq.subs({params[m.group(1)]: val})):
                    dl = report.setdefault("degenerate_loci", {
                        "loci": [],
                        "note": "on these parameter loci the equation has lower order or lower degree (a coefficient "
                                "of a leading term vanishes); it is then a different equation, and its solutions "
                                "are not listed here"})
                    txt = "%s = %s" % (m.group(1), m.group(2))
                    if txt not in dl["loci"]:
                        dl["loci"].append(txt)
                    continue
            except Exception:
                pass
        keep.append(it)
    report["not_decided"] = keep


def _degenerate(eq, sub_eq):
    """True if the specialised equation has lower order or lower degree than the original"""
    try:
        d0 = max(sum(m) for m in eq.terms)
        d1 = max(sum(m) for m in sub_eq.terms)
        return sub_eq.K < eq.K or d1 < d0
    except Exception:
        return False


# ----------------------------------------------------------------------------------------------- invariant surfaces
def _reduced_analysis(eq, red, br, mode, budget_s, depth):
    """build the reduced equation on an invariant surface and analyse it (runs inside a time-limited step)"""
    from mero.equation import Equation
    red_eq = Equation.from_dict(red)
    if br:
        if _degenerate(eq, eq.subs(br)):
            return {"degenerate": True}
        red_eq = red_eq.subs(br)
    return analyze(red_eq, mode=mode, budget_s=budget_s, _depth=depth + 1, atlas=False, strata=True, twist=False,
                   substitutions=False, darboux=False)


def _conditions_step(conds, params):
    branches, neq = _solve_conditions(conds, params)
    if branches is None:
        return {"branches": None, "neq": neq}
    return {"branches": [dict((str(k), sp.sstr(v)) for k, v in br.items()) for br in branches], "neq": neq}


def _branches(ctx, conds, params):
    """conditions -> (list of substitutions or None, inequalities); time-limited"""
    if not conds:
        return [{}], []
    out = _call(ctx, "conditions of a special locus", _conditions_step, conds, params, _timeout=20.0)
    if not out or out.get("branches") is None:
        return None, (out or {}).get("neq") or []
    loc = dict((str(q), q) for q in params)
    brs = []
    for br in out["branches"]:
        brs.append(dict((loc.get(k, sp.Symbol(k)), sp.sympify(v, locals=loc)) for k, v in br.items()))
    return brs, out.get("neq") or []


def _invariants(report, eq, dp, ctx, mode, options, depth):
    """solutions on invariant algebraic surfaces G = 0 (and on the levels G = C of a first integral)"""
    equation_mod = _mod("equation")
    if equation_mod is None or not hasattr(equation_mod, "Equation"):
        return None
    info = {"first_integral": None}
    surfaces = list(dp.get("first_integrals") or []) + list(dp.get("darboux_polynomials") or [])
    done = 0
    seen = set()
    for g in surfaces:
        red = g.get("reduced_equation")
        if not red or done >= 3 or _left(ctx) < 8.0:
            continue
        if not red.get("solved"):
            continue
        if int(red.get("order") or 99) > 2 and (mode != "heavy" or _left(ctx) < 60.0):
            report.setdefault("surfaces", []).append({
                "G": g.get("G"), "latex": g.get("latex"), "cofactor": g.get("cofactor"),
                "first_integral": bool(g.get("first_integral")), "conditions": g.get("conditions"),
                "reduced": red, "status": "the reduced equation was not analysed here (order %s)" % red.get("order")})
            continue
        key = red.get("sympy") or red.get("E")
        if key in seen:
            continue
        seen.add(key)
        if _left(ctx) < 8.0:
            continue
        if (g.get("certificate") or {}).get("status") != "pass":
            continue
        branches, neq = _branches(ctx, g.get("conditions"), eq.params)
        if branches is None:
            continue
        neq = list(neq) + [str(a) for a in (g.get("assumptions") or [])]
        for br in branches[:2]:
            is_fi = bool(g.get("first_integral"))
            b_s = min(40.0 if mode == "heavy" else 12.0, _left(ctx, 5.0))
            sub = _call(ctx, "equation on the %s %s" % ("levels of the first integral" if is_fi else "invariant surface",
                                                         str(g.get("G"))[:60]), _reduced_analysis, eq, red, br, mode,
                        b_s, depth, _timeout=b_s + 10.0)
            if sub and sub.get("degenerate"):
                continue                     # the equation itself changes type on this locus
            done += 1
            if not sub:
                continue
            conds = ["%s == %s" % (k, _s(v)) for k, v in br.items()] + list(neq)
            entry = {"G": g.get("G"), "latex": g.get("latex"), "cofactor": g.get("cofactor"),
                     "first_integral": is_fi, "conditions": conds, "reduced": sub.get("equation"),
                     "verdict": sub.get("verdict"), "found": sub.get("found"), "ruled_out": sub.get("ruled_out"),
                     "not_decided": sub.get("not_decided")}
            report.setdefault("surfaces", []).append(entry)
            for sol in sub.get("found") or []:
                if sol.get("kind") == "constant" and not is_fi:
                    continue
                item = dict(sol)
                item.pop("id", None)
                item["conditions"] = conds + list(sol.get("conditions") or [])
                item["note"] = ((sol.get("note") or "") + " Solution of the reduced equation %s = %s (%s)." % (
                    g.get("G"), "C_I" if is_fi else "0",
                    "a first integral" if is_fi else "an invariant surface with cofactor %s" % g.get("cofactor"))).strip()
                item["origin"] = "live:invariant-surface"
                d_sol = sol.get("d")
                covered = report.get("verdict", {}).get("level") == "complete" or \
                    (ctx.get("one_pole_complete") and sol.get("poles_per_period") == 1)
                if any("C_I" in str(c) for c in item["conditions"]):
                    item["constants"] = dict(item.get("constants") or {}, C_I="free; the value of the first integral")
                if sol.get("origin") == "live:linear" or sol.get("id") == "lin":
                    # the general solution of a reduced linear equation: explicit items of the same analysis say it
                    if any(o.get("kind") != "constant" and o is not sol and o.get("expr")
                           for o in sub.get("found") or []):
                        continue
                    if item.get("description"):
                        item["description"] = "on %s = %s the equation reduces to a linear equation; there: %s" % (
                            g.get("G"), "C_I" if is_fi else "0", item["description"])
                if sol.get("kind") != "constant":
                    entry.setdefault("_items", []).append(item)
                    if not covered or (isinstance(d_sol, int) and d_sol >= 2):
                        _add_found(report, item)
            if is_fi and not br and info["first_integral"] is None and not (g.get("conditions") or []):
                try:
                    jets = sp.symbols("w0:%d" % eq.K)
                    Gx = sp.sympify(str(g.get("G")), locals=dict([(str(j), j) for j in jets] +
                                                                  [(str(q), q) for q in eq.params]))
                    lead = sp.Poly(Gx, jets[eq.K - 1])
                    if lead.degree() == 1 and not lead.LC().free_symbols and lead.LC() != 0:
                        info["first_integral"] = entry
                except Exception:
                    pass
    return info


def _first_integral_upgrade(report, info):
    fi = info.get("first_integral")
    if not fi:
        return
    v = report["verdict"]
    sv = fi.get("verdict") or {}
    if v.get("level") == "complete" or sv.get("level") != "complete":
        return
    if str(sv.get("scope") or "").startswith("generic") or sv.get("generic_upgrade"):
        return
    for item in fi.get("_items") or []:         # the list must contain what the statement speaks about
        _add_found(report, item)
    report["verdict"] = {
        "level": "complete",
        "text": "The equation has the polynomial first integral %s = C_I, so every solution satisfies the equation of "
                "lower order obtained from it, for some value of the constant C_I. For that family: %s"
                % (fi.get("G"), sv.get("text")),
        "basis": ["certificate: first integral"] + list(sv.get("basis") or []),
        "scope": "all parameter values, by strata" if report["equation"]["params"] else "this equation",
        "conditions": [], "level_before": v.get("level"), "text_before": v.get("text")}
    report["not_decided"] = [it for it in report["not_decided"]
                             if not str(it.get("what", "")).startswith("meromorphic solutions other than")
                             and it.get("_src") != "tier"]


# ----------------------------------------------------------------------------------------------- strata
def _strata(report, eq, local, tier, ctx, mode, options, depth):
    """special parameter loci that can be reached by substituting a value: analyse the equation there"""
    strata = [s for s in (local.get("strata") or []) if isinstance(s, dict) and s.get("substitution")]
    seen, todo = set(), []
    for s in strata:
        key = json.dumps(s.get("substitution"), sort_keys=True)
        if key in seen:
            continue
        seen.add(key)
        todo.append(s)
    if not todo:
        return
    out = []
    max_n = int(options.get("max_strata", 6))
    share = max(5.0, 0.25 * ctx["budget_s"] / max(1, min(len(todo), max_n)))
    for s in todo[:max_n]:
        if _left(ctx) < 3.0:
            out.append({"conditions": s.get("conditions"), "status": "not analysed (time limit)"})
            continue
        try:
            subs = dict((sp.Symbol(k), sp.sympify(v)) for k, v in s["substitution"].items())
            sub_eq = eq.subs(subs) if hasattr(eq, "subs") else None
        except Exception as exc:
            out.append({"conditions": s.get("conditions"), "status": "not analysed (%s)" % exc})
            continue
        if sub_eq is None:
            continue
        if _degenerate(eq, sub_eq):
            out.append({"conditions": s.get("conditions"), "substitution": s.get("substitution"),
                        "status": "degenerate: on this locus the equation has lower order or degree; "
                                  "it is a different equation and is not analysed here",
                        "equation": _equation_block(sub_eq)})
            continue
        sub = _call(ctx, "special locus %s" % ", ".join(s.get("conditions") or []), analyze, sub_eq, mode=mode,
                    budget_s=min(share, _left(ctx)), _depth=depth + 1, atlas=False,
                    max_poles=options.get("max_poles", 1), strata=False)
        if not sub:
            out.append({"conditions": s.get("conditions"), "status": "not analysed (failed)"})
            continue
        out.append({"conditions": s.get("conditions"), "substitution": s.get("substitution"),
                    "status": "analysed", "equation": sub.get("equation"), "verdict": sub.get("verdict"),
                    "found": sub.get("found"), "ruled_out": sub.get("ruled_out"),
                    "not_decided": sub.get("not_decided"),
                    "tier_text": (sub.get("tier") or {}).get("text")})
        if set(_norm_cond(c) for c in (s.get("conditions") or [])) in (ctx.get("nf_loci") or []):
            continue                    # this locus was solved with the normal form: its solutions are in the list
        for sol in sub.get("found") or []:
            if sol.get("kind") == "constant":
                continue
            sol = dict(sol)
            sol["conditions"] = list(s.get("conditions") or []) + list(sol.get("conditions") or [])
            sol["origin"] = (sol.get("origin") or "live") + " (special locus)"
            sol.pop("id", None)
            _add_found(report, sol)
    if len(todo) > max_n:
        out.append({"conditions": ["%d further loci" % (len(todo) - max_n)], "status": "not analysed (limit)"})
    report["strata"] = out
    v = report["verdict"]
    done = [o for o in out if o.get("status") == "analysed"]
    if done:
        v["special_loci"] = [{"conditions": o["conditions"], "level": (o.get("verdict") or {}).get("level"),
                              "text": (o.get("verdict") or {}).get("text")} for o in done]
    rest = [o for o in out if o.get("status") != "analysed" and not str(o.get("status")).startswith("degenerate")]
    for o in rest:
        _add_item(report, "not_decided", {"what": "parameter values with " + ", ".join(o.get("conditions") or []),
                                          "why": o.get("status"), "partial": ""})
    # the generic statement of the theorems left the special loci open: say what was done there
    for item in report["not_decided"]:
        w = item.get("what", "")
        if w.startswith("parameter values at which one of the conditions fails") and done:
            item["partial"] = (item.get("partial") or "") + " Analysed here: " + "; ".join(
                "%s: %s" % (", ".join(o["conditions"]), (o.get("verdict") or {}).get("level")) for o in done) + \
                " (see the field 'strata')."


LABEL_RANK = {"agent-proof": 0, "preprint": 1, "published": 2, "certificate": 3}


def _finish_verdict(report, tier):
    """the label of the verdict (the weakest label among the statements it rests on) and the overall level
    (generic statement versus special parameter loci)"""
    v = report.get("verdict") or {}
    labels = {}
    used = (tier or {}).get("used_labels") or {}
    reg = _mod("registry")
    for b in v.get("basis") or []:
        b = str(b)
        lab = None
        if b in used:
            lab = (used[b] or {}).get("label")
        elif b.startswith("certificate"):
            lab = "certificate"
        elif b.startswith(("lemma:", "record:", "L-", "A-")):
            lab = "agent-proof"
        if lab is None and reg is not None and hasattr(reg, "get"):
            try:
                ent = reg.get(b)
                lab = (ent or {}).get("label")
            except Exception:
                lab = None
        if lab is None and b.startswith("T-"):
            lab = "agent-proof"
        if lab:
            labels[b] = lab
    lo = report.get("low_order") or {}
    if str(lo.get("module", "")).startswith(("mero.order2", "mero.order1")) and \
            not str(lo.get("module", "")).startswith("mero.order2b") and report["equation"].get("params") and \
            v.get("level") in ("complete", "complete-W", "partial"):
        labels["stratification by parameter values and closed forms (this engine)"] = "agent-proof"
    for it in report.get("ruled_out") or []:                # a module may give the label with its basis
        bs = it.get("basis")
        if isinstance(bs, dict) and bs.get("theorem") in (v.get("basis") or []) and bs.get("label"):
            labels[str(bs["theorem"])] = bs["label"]
    if labels:
        v["labels"] = labels
        # the label of the verdict: the weakest label among the statements the verdict sentence needs.  Statements
        # that only add something (the number of solutions; a second theorem giving the same class) do not count.
        cls = (tier or {}).get("class_of_all_meromorphic_solutions")
        skip = {"T-STRUCTURE-B", "T-SERIES-PERIOD"}
        alt = {"T-PUREPOWER", "T-STRUCTURE-A", "T-STRUCTURE-E", "T-EREMENKO", "T-DEMINA2019", "T-ELN2009"}
        if not report.get("low_order"):
            if cls == "entire only":
                skip |= alt
            elif cls in W_CLASSES:
                main = (tier or {}).get("pole_bound_basis")
                n_src = None
                for b in v.get("basis") or []:
                    if str(b) in ("T-FREECOEFF", "L-ENDS"):
                        n_src = str(b)
                gives_class = {"T-EREMENKO", "T-STRUCTURE-A", "T-STRUCTURE-E", "T-DEMINA2019", "T-ELN2009"}
                if main in gives_class and n_src is None:
                    skip |= (alt - {main})
        need = dict((k, x) for k, x in labels.items() if k not in skip) or labels
        v["label"] = min(need.values(), key=lambda x: LABEL_RANK.get(x, 0))
        v["label_rests_on"] = sorted(need)
    elif v.get("level") in ("complete", "complete-W"):
        v["label"] = "agent-proof"
    # overall level: a statement for generic parameter values is weaker than a statement for all values
    lvl = v.get("level")
    special = [x.get("level") for x in v.get("special_loci") or []]
    open_loci = any(str(it.get("what", "")).startswith(("parameter values", "parameter stratum",
                                                         "the degenerate stratum"))
                    or it.get("kind") == "parameter-locus" for it in report.get("not_decided") or [])
    if lvl == "complete" and v.get("scope") == "generic parameter values":
        v["overall"] = "complete-generic"
        rank = {"formal": 0, "partial": 1, "complete-W": 2, "complete": 3}
        if open_loci:
            v["special_min"] = "not analysed"
        elif special:
            v["special_min"] = min(special, key=lambda x: rank.get(x, 0))
        elif (v.get("scope_detail") or {}).get("explored_strata"):
            v["special_min"] = "complete"
    else:
        v["overall"] = lvl
    report["verdict"] = v


def _mark_complex(report, eq):
    """found items that exist only for non-real values of the parameters"""
    params = dict((str(q), q) for q in eq.params)
    if not params:
        return
    for it in report["found"]:
        for c in it.get("conditions") or []:
            c = str(c)
            if "==" not in c:
                continue
            a, b = [x.strip() for x in c.split("==", 1)]
            if a in params and len(b) < 200:
                try:
                    val = sp.sympify(b, locals=params)
                    if not val.free_symbols and sp.im(val) != 0:
                        it["complex_parameters"] = "exists only for a non-real value of %s" % a
                        break
                except Exception:
                    pass


def _d_summary(report):
    found = report["found"]
    d1 = [x for x in found if x.get("d") == 1 or x.get("kind") in ("rational", "simply-periodic", "elliptic",
                                                                    "polynomial")]
    d2 = [x for x in found if x.get("d") == 2]
    d3 = [x for x in found if isinstance(x.get("d"), int) and x.get("d") >= 3]
    described = (report.get("atlas") or {}).get("described") or []
    desc2 = [x for x in described if x.get("d") == 2]
    desc3 = [x for x in described if isinstance(x.get("d"), int) and x.get("d") >= 3]
    v = report.get("verdict", {})
    lvl = v.get("level")
    generic = v.get("scope") == "generic parameter values"
    tier = report.get("tier") or {}
    cls = tier.get("class_of_all_meromorphic_solutions")
    by_low = bool(report.get("low_order"))
    ruled = (cls in W_CLASSES + ("entire only",) and tier.get("d_le_1") is not False and not by_low) or \
        (lvl == "complete" and by_low)
    suffix = " for generic parameter values" if generic else ""

    def status(dfound, ddesc):
        if dfound:
            return "found"
        if ddesc:
            return "described in an earlier record (not derived here)"
        if cls == "listed (not all in W)":
            return "see the verdict"
        if cls == "entire (linear equation)":
            return "possible, depending on the roots (see the general solution)"
        if ruled:
            return "ruled out" + suffix
        return "not ruled out"

    if lvl == "complete":
        s1 = "complete" + suffix
    elif d1:
        s1 = "partial"
    else:
        s1 = "none found"
    s2, s3 = status(d2, desc2), status(d3, desc3)
    basis = ", ".join(str(b) for b in (v.get("basis") or []))[:200]
    report["d_summary"] = {"1": {"status": s1, "count": len(d1)},
                           "2": {"status": s2, "count": len(d2), "basis": basis if s2.startswith("ruled out") else ""},
                           "3+": {"status": s3, "count": len(d3), "basis": basis if s3.startswith("ruled out") else ""}}


def analyze_json(text, **kw):
    return json.dumps(analyze(text, **kw), default=str, ensure_ascii=False)


if __name__ == "__main__":
    import sys
    txt = sys.argv[1] if len(sys.argv) > 1 else "w''' = 12*w*w' + 1"
    print(json.dumps(analyze(txt, mode="heavy" if "--heavy" in sys.argv else "light"), indent=1, default=str,
                     ensure_ascii=False))
