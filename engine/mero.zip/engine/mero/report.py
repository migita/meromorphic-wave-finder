"""mero.report -- assemble the report for one equation (project note section 3).

`analyze(text_or_eq, mode='light'|'heavy', budget_s=..., **options)` calls every available module of the
package, each one optional and time-limited, and returns a JSON-able dict.  The three lists (found, ruled out,
not decided) and the verdict are put together here and nowhere else.

Rules of this module (they are what the site promises):

* "complete" is said only when (a) a decision module for low order says so, or (b) a registry theorem gives the
  class of all meromorphic solutions and a bound on the poles in a period, and the solver has finished every form
  that this class and this bound allow, and the solutions without poles are known, or (c) an earlier record of the
  project with a completeness label contains the equation (then the label of that record is shown);
* with symbolic parameters every statement names its scope: "for generic values of the parameters" comes with the
  list of conditions, and the special loci are analysed separately when they can be reached by substituting a value
  (field `strata`), otherwise they are listed as not decided;
* nothing found is shown unless its substitution check passed.

Pure Python + SymPy: this module runs in the browser.
"""
import importlib
import json
import re
import time
import traceback

import sympy as sp

ENGINE_VERSION = "mero 0.2 (6 October 2026)"
W_CLASSES = ("W\u222arational", "W")
KINDS = ("rational", "simply-periodic", "elliptic")

z = sp.Symbol("z")


# ----------------------------------------------------------------------------------------------- optional modules
def _mod(name):
    """import mero.<name> if it exists and imports cleanly; otherwise None"""
    try:
        return importlib.import_module("mero." + name)
    except Exception:
        return None


class _Timeout(Exception):
    pass


def _hard_call(fn, args, kwargs, timeout):
    """run fn(*args, **kwargs) in a forked child with a hard wall-clock limit (heavy version only)"""
    import os
    import pickle
    import select
    import signal
    rfd, wfd = os.pipe()
    pid = os.fork()
    if pid == 0:                                                  # the child
        try:
            os.close(rfd)
            try:
                os.setpgid(0, 0)                                  # own process group: Singular / msolve die with it
            except Exception:
                pass
            try:
                data = pickle.dumps(("ok", fn(*args, **kwargs)), protocol=pickle.HIGHEST_PROTOCOL)
            except BaseException as exc:                          # noqa: reported to the parent
                data = pickle.dumps(("err", "%s: %s" % (type(exc).__name__, str(exc)[:400])))
            with os.fdopen(wfd, "wb") as fh:
                fh.write(data)
        finally:
            os._exit(0)
    os.close(wfd)
    chunks, deadline = [], time.monotonic() + timeout
    try:
        while True:
            left = deadline - time.monotonic()
            if left <= 0:
                raise _Timeout()
            ready, _, _ = select.select([rfd], [], [], min(left, 1.0))
            if ready:
                b = os.read(rfd, 1 << 20)
                if not b:
                    break
                chunks.append(b)
    except _Timeout:
        for sig_target in (os.killpg, os.kill):
            try:
                sig_target(pid, signal.SIGKILL)
            except Exception:
                pass
        try:
            os.waitpid(pid, 0)
        except Exception:
            pass
        os.close(rfd)
        raise
    os.close(rfd)
    try:
        os.waitpid(pid, 0)
    except Exception:
        pass
    try:
        try:
            os.killpg(pid, signal.SIGKILL)                        # anything the child left behind
        except Exception:
            pass
        status, out = pickle.loads(b"".join(chunks))
    except Exception as exc:
        raise RuntimeError("the result of the step could not be read (%s)" % str(exc)[:200])
    if status == "err":
        raise RuntimeError(out)
    return out


def _call(ctx, label, fn, *args, **kwargs):
    """run fn; never raise; record time and failures in the log.  In the heavy version every step runs in a
    child process with a hard time limit (`_timeout` seconds, default: what is left of the budget, at most 90)."""
    log = ctx["log"]
    cap = kwargs.pop("_timeout", None)
    soft = kwargs.pop("_soft", False)
    if ctx.get("progress"):
        try:
            ctx["progress"]("step: " + label)
        except Exception:
            pass
    t0 = time.monotonic()
    left = ctx["budget_s"] - (t0 - ctx["t0"])
    if ctx.get("hard") and left < 1.0 and label not in ("earlier records", "normal form"):
        log.append("%s: skipped (time limit of the analysis reached)" % label)
        ctx["timeouts"].append(label)
        return None
    try:
        if ctx.get("hard") and not soft:
            limit = max(2.0, min(cap if cap else 90.0, left + 3.0))
            try:
                out = _hard_call(fn, args, kwargs, limit)
            except _Timeout:
                log.append("%s: stopped at its time limit (%.0f s)" % (label, limit))
                ctx["timeouts"].append(label)
                return None
        else:
            out = fn(*args, **kwargs)
        log.append("%s: %.2f s" % (label, time.monotonic() - t0))
        return out
    except Exception as exc:                                    # a module failure is reported, not hidden
        log.append("%s: FAILED after %.2f s: %s: %s" % (label, time.monotonic() - t0, type(exc).__name__,
                                                          str(exc)[:300]))
        tb = traceback.format_exc(limit=4).strip().splitlines()
        log.append("  " + " | ".join(t.strip() for t in tb[-4:])[:500])
        ctx["failures"].append(label)
        return None


def _left(ctx, reserve=0.0):
    return max(1.0, ctx["budget_s"] - (time.monotonic() - ctx["t0"]) - reserve)


# ----------------------------------------------------------------------------------------------- fallback parser
_PRIME = re.compile(r"\b([A-Za-z])\s*('+)")


def _fallback_parse(text, unknown=None):
    """A very small parser used only when mero.parse is not available: primes and jets, '^', one '='."""
    from mero.bootstrap import Equation
    s = text.replace("\u2212", "-").replace("^", "**").replace("\u2032", "'").replace("\u2033", "''")
    if "=" in s:
        lhs, rhs = s.split("=", 1)
        s = "(%s) - (%s)" % (lhs, rhs)
    if unknown is None:
        m = _PRIME.search(s)
        unknown = m.group(1) if m else "w"
    s = _PRIME.sub(lambda m: "%s%d" % (m.group(1), len(m.group(2))) if m.group(1) == unknown else m.group(0), s)
    s = re.sub(r"\b%s\b(?!\d)" % unknown, unknown + "0", s)
    s = re.sub(r"\b%s(\d+)\b" % unknown, r"w\1", s)
    s = re.sub(r"(\d)\s*([A-Za-z(])", r"\1*\2", s)
    order = max([int(k) for k in re.findall(r"\bw(\d+)\b", s)] or [0])
    jets = sp.symbols("w0:%d" % (order + 1))
    loc = dict((str(j), j) for j in jets)
    for name in set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", s)):          # every other name is a parameter
        if name not in loc and name not in ("sqrt", "I", "pi", "Rational"):
            loc[name] = sp.Symbol(name)
    expr = sp.expand(sp.sympify(s, locals=loc))
    params = sorted(expr.free_symbols - set(jets), key=str)
    poly = sp.Poly(expr, jets[order])
    if poly.degree() != 1 or (poly.LC().free_symbols & set(jets)):
        raise ValueError("unsupported by the fallback parser: the equation is not solved for the highest derivative")
    rhs = sp.expand(-poly.coeff_monomial(1) / poly.LC())
    eq = Equation(order, rhs, [str(q) for q in params])
    eq.unknown, eq.var = unknown, "z"
    return eq


# ----------------------------------------------------------------------------------------------- small helpers
def _s(e):
    return sp.sstr(e) if not isinstance(e, str) else e


def _E(eq):
    E = getattr(eq, "E", None)
    if E is None:
        E = eq.w[eq.K] - eq.rhs
    return E


def _fresh(eq, base="q"):
    """a symbol name that is neither a parameter nor a jet of the equation"""
    used = set(str(s) for s in _E(eq).free_symbols) | set(str(p) for p in eq.params)
    name, i = base, 0
    while name in used:
        i += 1
        name = "%s%d" % (base, i)
    return sp.Symbol(name)


def _jet_latex(eq, expr):
    name = getattr(eq, "unknown", "w")
    rep = {}
    for j, wj in enumerate(eq.w):
        if j == 0:
            rep[wj] = sp.Symbol(name)
        elif j <= 3:
            rep[wj] = sp.Symbol(name + "'" * j)
        else:
            rep[wj] = sp.Symbol("%s^{(%d)}" % (name, j))
    return sp.latex(expr.subs(rep))


def _equation_block(eq):
    E = _E(eq)
    solved = getattr(eq, "solved", True)
    ltx = None
    if hasattr(eq, "latex"):
        try:
            ltx = eq.latex()
        except Exception:
            ltx = None
    if ltx is None:
        if solved and getattr(eq, "rhs", None) is not None:
            ltx = _jet_latex(eq, eq.w[eq.K]) + " = " + _jet_latex(eq, eq.rhs)
        else:
            ltx = _jet_latex(eq, E) + " = 0"
    deg = getattr(eq, "degree", None)
    if deg is None:
        deg = max(sum(m) for m in eq.terms)
    return {"order": eq.K, "degree": int(deg), "solved": bool(solved), "sympy": _s(sp.expand(E)), "latex": ltx,
            "params": [str(q) for q in eq.params], "unknown": getattr(eq, "unknown", "w"),
            "var": getattr(eq, "var", "z")}


def _bootstrap_local(eq, budget_s=20):
    """local analysis with the reference implementation (used only if mero.laurent is missing)"""
    from mero import bootstrap as B
    out = {"balances": [], "non_integer_balances": [], "finiteness": None, "no_pole_possible": None, "strata": [],
           "note": "reference implementation"}
    if not getattr(eq, "solved", True):
        return out
    for b in B.balances(eq):
        for a0 in b["a0"]:
            kk = sp.Symbol("k")
            ind = B.indicial(eq, b["p"], a0, kk)
            roots = sp.roots(sp.Poly(sp.numer(sp.together(ind)), kk))
            pos = sorted(int(r) for r in roots if r.is_integer and r > 0)
            L = B.laurent(eq, b["p"], a0, max((max(pos) if pos else 0) + 2, b["p"] + 2))
            fail = [k for k, v in L["conditions"].items() if v != 0]
            count = "0" if fail else ("family: %d free coefficient(s)" % len(L["free"]) if L["free"] else "finite: 1")
            out["balances"].append({"p": b["p"], "a0": _s(a0), "weight": b["W"], "indicial": _s(ind),
                                    "indices": [_s(r) for r in roots], "positive_integer_indices": pos,
                                    "coeffs": [_s(c) for c in L["coeffs"]],
                                    "free": dict((str(k), str(v)) for k, v in L["free"].items()),
                                    "conditions": dict((str(k), _s(v)) for k, v in L["conditions"].items()),
                                    "series_count": count})
    return out


def _constants(eq):
    """constant solutions: the roots of E(q, 0, ..., 0)"""
    q = _fresh(eq, "q")
    e0 = sp.expand(_E(eq).subs(dict((wj, 0) for wj in eq.w[1:])).subs(eq.w[0], q))
    if e0 == 0:
        return {"all": True, "symbol": str(q)}
    if q not in e0.free_symbols:
        return {"all": False, "none": True, "poly": _s(e0), "symbol": str(q)}
    P = sp.Poly(e0, q)
    roots = []
    if P.degree() <= 2:
        try:
            roots = [sp.simplify(r) for r in sp.roots(P, multiple=True)]
        except Exception:
            roots = []
    return {"all": False, "poly": _s(P.as_expr()), "poly_latex": sp.latex(P.as_expr()), "degree": P.degree(),
            "symbol": str(q), "roots": [_s(r) for r in roots], "roots_latex": [sp.latex(r) for r in roots]}


def _const_items(consts):
    cert = {"type": "substitution", "method": "symbolic", "status": "pass"}
    if consts.get("all"):
        return [{"id": "const", "kind": "constant", "d": 0, "expr": consts["symbol"], "latex": consts["symbol"],
                 "free": [consts["symbol"]], "conditions": [], "note": "every constant is a solution",
                 "certificate": dict(cert, detail="E(q, 0, ..., 0) vanishes identically"),
                 "origin": "live:constants"}]
    if consts.get("none"):
        return []
    if consts.get("roots"):
        return [{"id": "const%d" % (i + 1), "kind": "constant", "d": 0, "expr": r, "latex": consts["roots_latex"][i],
                 "free": [], "conditions": [],
                 "certificate": dict(cert, detail="root of E(%s, 0, ..., 0) = %s" % (consts["symbol"], consts["poly"])),
                 "origin": "live:constants"} for i, r in enumerate(consts["roots"])]
    if consts.get("degree", 0) > 2:
        return [{"id": "const", "kind": "constant", "d": 0,
                 "expr": "RootOf(%s, %s)" % (consts["poly"], consts["symbol"]),
                 "latex": "%s:\\quad %s = 0" % (consts["symbol"], consts.get("poly_latex", "")),
                 "free": [], "conditions": [],
                 "note": "the constant solutions are the roots of this polynomial",
                 "certificate": dict(cert, detail="E(%s, 0, ..., 0) = %s" % (consts["symbol"], consts["poly"])),
                 "origin": "live:constants"}]
    return []


def _add_found(report, sol, origin=None):
    if not isinstance(sol, dict):
        return
    cert = sol.get("certificate") or {}
    status = cert.get("status")
    if status in ("fail", "FAIL"):
        report["rejected"].append({"expr": sol.get("expr"), "why": "substitution check failed",
                                   "origin": sol.get("origin") or origin})
        return
    key = _sol_key(sol)
    for old in report["found"]:
        if _sol_key(old) == key:
            return
    sol = dict(sol)
    if origin and not sol.get("origin"):
        sol["origin"] = origin
    if "id" not in sol or any(o.get("id") == sol["id"] for o in report["found"]):
        sol["id"] = "s%d" % (len(report["found"]) + 1)
    report["found"].append(sol)


def _sol_key(sol):
    conds = sorted(str(c).replace(" ", "") for c in (sol.get("conditions") or []))
    consts = sol.get("constants") or {}
    return (sol.get("kind"), str(sol.get("expr")).replace(" ", ""),
            json.dumps(dict((str(k), str(v)) for k, v in consts.items()), sort_keys=True), tuple(conds))


def _add_item(report, key, item, src=None):
    if isinstance(item, str):
        item = {"what": item}
    if not isinstance(item, dict):
        return
    sig = (item.get("what"), json.dumps(item.get("conditions"), sort_keys=True, default=str))
    for old in report[key]:
        if (old.get("what"), json.dumps(old.get("conditions"), sort_keys=True, default=str)) == sig:
            return
    if src:
        item = dict(item, _src=src)
    report[key].append(item)


def _merge_lists(report, part, origin=None, src=None):
    for sol in part.get("found", []) or []:
        _add_found(report, sol, origin)
    for key in ("ruled_out", "not_decided"):
        for item in part.get(key, []) or []:
            _add_item(report, key, item, src)


# ----------------------------------------------------------------------------------------------- the report
def analyze(text_or_eq, mode="light", budget_s=30, **options):
    t_start = time.monotonic()
    log, warnings = [], []
    hard = bool(options.get("hard", mode == "heavy"))
    if hard:
        try:
            import os
            hard = hasattr(os, "fork")
        except Exception:
            hard = False
    ctx = {"log": log, "t0": t_start, "budget_s": float(budget_s), "failures": [], "timeouts": [], "hard": hard,
           "progress": None if hard else options.get("progress")}
    depth = int(options.get("_depth", 0))
    report = {"schema": "mero-report/1", "engine": ENGINE_VERSION, "mode": mode,
              "input": {"text": text_or_eq if isinstance(text_or_eq, str) else None, "kind": "ode"},
              "found": [], "ruled_out": [], "not_decided": [], "theorems": [], "classes": [], "rejected": [],
              "warnings": warnings, "log": log}

    # 1. the equation ----------------------------------------------------------------------------------------
    if isinstance(text_or_eq, str):
        text = text_or_eq.strip()
        pde, parse = _mod("pde"), _mod("parse")
        kind = "ode"
        if pde is not None and hasattr(pde, "detect_kind"):
            kind = _call(ctx, "detect kind", pde.detect_kind, text, _soft=True) or "ode"
        report["input"]["kind"] = kind
        try:
            if kind == "pde" and pde is not None:
                reds = pde.travelling_wave(pde.parse_pde(text))
                red = reds[min(int(options.get("reduction_index", 0)), len(reds) - 1)]
                eq = red["equation"]
                report["input"]["reduction"] = {
                    "ansatz": red.get("ansatz"), "integrated": red.get("integrated"),
                    "constants": [str(c) for c in red.get("constants", []) or []], "note": red.get("note", ""),
                    "alternatives": [{"index": i, "integrated": r.get("integrated"), "ansatz": r.get("ansatz"),
                                      "order": getattr(r.get("equation"), "K", None)} for i, r in enumerate(reds)]}
            elif parse is not None and hasattr(parse, "parse_ode"):
                eq = parse.parse_ode(text, unknown=options.get("unknown"), var=options.get("var"))
            else:
                eq = _fallback_parse(text, unknown=options.get("unknown"))
                warnings.append("fallback parser in use")
        except Exception as exc:
            report["verdict"] = {"level": "unsupported", "text": "The input could not be read: %s" % exc, "basis": []}
            report["elapsed_s"] = round(time.monotonic() - t_start, 3)
            return report
    else:
        eq = text_or_eq
    for wmsg in getattr(eq, "warnings", []) or []:
        warnings.append(str(wmsg))
    report["equation"] = _equation_block(eq)
    symbolic = len(eq.params) > 0

    # 2. local analysis ---------------------------------------------------------------------------------------
    laurent = _mod("laurent")
    local = None
    if laurent is not None and hasattr(laurent, "local_analysis"):
        local = _call(ctx, "local analysis", laurent.local_analysis, eq,
                      budget_s=max(5.0, min(40.0, 0.2 * budget_s)), _timeout=max(8.0, min(60.0, 0.3 * budget_s)))
        if local is None and ctx.get("hard"):                    # second try without the special loci
            local = _call(ctx, "local analysis (without special loci)", laurent.local_analysis, eq,
                          budget_s=max(5.0, min(30.0, 0.15 * budget_s)), depth=-1,
                          _timeout=max(8.0, min(45.0, 0.2 * budget_s)))
    if local is None:
        local = _call(ctx, "local analysis (reference implementation)", _bootstrap_local, eq) or {"balances": []}
    report["local"] = local

    # 3. constants --------------------------------------------------------------------------------------------
    consts = _call(ctx, "constant solutions", _constants, eq, _timeout=20.0) or {}
    for item in _const_items(consts):
        _add_found(report, item)

    # 4. theorems ---------------------------------------------------------------------------------------------
    classes = _mod("classes")
    tier = None
    if classes is not None:
        if hasattr(classes, "classify"):
            report["classes"] = _call(ctx, "classify", classes.classify, eq, local) or []
        if hasattr(classes, "tier"):
            tier = _call(ctx, "theorems", classes.tier, eq, local, _timeout=40.0)
    if tier:
        report["theorems"] = tier.get("theorems", []) or []
        for item in tier.get("ruled_out", []) or []:
            _add_item(report, "ruled_out", item, "tier")
        for item in tier.get("not_decided", []) or []:
            _add_item(report, "not_decided", item, "tier")
        report["tier"] = dict((k, v) for k, v in tier.items() if k not in ("theorems", "ruled_out", "not_decided"))

    # 5. decision modules for orders one and two --------------------------------------------------------------
    decided = None
    if eq.K == 1:
        m1 = _mod("order1")
        if m1 is not None and hasattr(m1, "order1_answer"):
            decided = _call(ctx, "order one", m1.order1_answer, eq)
    elif eq.K == 2:
        m2, m2b = _mod("order2"), _mod("order2b")
        if m2 is not None and hasattr(m2, "order2_answer"):
            decided = _call(ctx, "order two", m2.order2_answer, eq,
                            budget_s=min(_left(ctx), 40.0 if mode == "heavy" else 15.0),
                            _timeout=max(20.0, min(120.0, 0.4 * budget_s)))
        if not (decided and decided.get("applies")) and m2b is not None and hasattr(m2b, "order2b_answer"):
            d2 = _call(ctx, "order two, even in w'", m2b.order2b_answer, eq, budget_s=min(_left(ctx), 30.0),
                       _timeout=max(15.0, min(60.0, 0.25 * budget_s)))
            if d2 and d2.get("applies"):
                decided = d2
    low_complete = low_applies = False
    if decided and decided.get("applies"):
        if any(x.get("kind") == "constant" for x in decided.get("found") or []):
            report["found"] = [x for x in report["found"] if x.get("origin") != "live:constants"]
        _merge_lists(report, decided, src="low_order")
        report["low_order"] = dict((k, v) for k, v in decided.items()
                                   if k not in ("found", "ruled_out", "not_decided", "applies"))
        low_level = (decided.get("verdict") or {}).get("level")
        low_complete = low_level == "complete"
        low_applies = low_level in ("complete", "complete-W", "partial")
        if low_complete:                 # the decision module supersedes the general statements of the theorems
            report["not_decided"] = [it for it in report["not_decided"] if it.get("_src") != "tier"]

    ent = ends = bound = fc = ws = None
    if not low_applies:
        # 6. solutions without poles --------------------------------------------------------------------------
        entire = _mod("entire")
        if entire is not None and hasattr(entire, "entire_solutions"):
            ent = _call(ctx, "solutions without poles", entire.entire_solutions, eq,
                        budget_s=min(_left(ctx), 30.0), _timeout=50.0)
            if ent:
                for key in ("polynomials", "exponentials"):
                    for sol in ent.get(key, []) or []:
                        _add_found(report, sol, "live:entire")
                for item in ent.get("not_decided", []) or []:
                    _add_item(report, "not_decided", item)
                for item in ent.get("ruled_out", []) or []:
                    if isinstance(item, dict) and item.get("what"):
                        _add_item(report, "ruled_out", item)
                report["entire"] = {"complete": ent.get("complete"), "basis": ent.get("basis"),
                                    "complete_conditions": ent.get("complete_conditions"),
                                    "growth": ent.get("growth"), "strata": ent.get("strata"),
                                    "implicit": ent.get("implicit"), "certificate": ent.get("certificate")}

        # 7. ends, pole bound, free coefficients --------------------------------------------------------------
        ends_mod = _mod("ends")
        if ends_mod is not None:
            if hasattr(ends_mod, "end_exponents"):
                ends = _call(ctx, "ends", ends_mod.end_exponents, eq, budget_s=min(_left(ctx), 20.0),
                             _timeout=35.0)
            if hasattr(ends_mod, "pole_bound"):
                bound = _call(ctx, "pole bound", ends_mod.pole_bound, eq, local, budget_s=min(_left(ctx), 20.0),
                              _timeout=40.0)
        report["ends"] = ends
        report["pole_bound"] = bound
        fc_mod = _mod("freecoeff")
        if fc_mod is not None and hasattr(fc_mod, "free_coefficient_values") and getattr(eq, "solved", True) \
                and eq.K >= 3:
            fc = _call(ctx, "free coefficients", fc_mod.free_coefficient_values, eq, local,
                       budget_s=min(_left(ctx), 60.0 if mode == "heavy" else 15.0), _timeout=75.0)
            report["free_coefficients"] = fc

        # 8. rational / simply periodic / elliptic solutions --------------------------------------------------
        wsolve = _mod("wsolve")
        if wsolve is not None and hasattr(wsolve, "find_w_solutions") and (local.get("balances") or []):
            n_bound = _pole_bound(tier, fc, bound)
            cap = int(options.get("max_poles", 2 if mode == "heavy" else 1))
            max_poles = max(1, min(cap, n_bound if n_bound else cap))
            reserve = (15.0 if options.get("atlas", True) else 0.0) + (0.25 * budget_s if symbolic and depth == 0 else 0.0)
            ws_budget = max(5.0, min(_left(ctx, reserve), 0.45 * budget_s))
            ws = _call(ctx, "rational, simply periodic and elliptic solutions", wsolve.find_w_solutions, eq, local,
                       max_poles=max_poles, ends=ends, budget_s=ws_budget, _timeout=ws_budget + 15.0)
            if ws is None and ctx.get("hard") and max_poles > 1 and _left(ctx) > 20.0:
                ws = _call(ctx, "rational, simply periodic and elliptic solutions (one pole)",
                           wsolve.find_w_solutions, eq, local, max_poles=1, ends=ends,
                           budget_s=min(_left(ctx, reserve), 0.25 * budget_s),
                           _timeout=min(_left(ctx), 0.25 * budget_s + 15.0))
                max_poles = 1
            if ws:
                for sol in ws.get("solutions", []) or []:
                    _add_found(report, sol, "live:wsolve")
                report["w_search"] = {"certificates": ws.get("certificates"), "incomplete": ws.get("incomplete"),
                                      "max_poles": max_poles}

    # 9. invariant surfaces (solutions with d < K) -------------------------------------------------------------
    darboux = _mod("darboux")
    inv_info = None
    if darboux is not None and hasattr(darboux, "darboux_polynomials") and options.get("darboux", True) \
            and eq.K >= 3 and getattr(eq, "solved", True) and not low_applies and depth == 0:
        dp = _call(ctx, "invariant surfaces", darboux.darboux_polynomials, eq,
                   budget_s=min(_left(ctx, 15.0), 45.0 if mode == "heavy" else 10.0), _timeout=60.0)
        if dp:
            report["invariants"] = dict((k, v) for k, v in dp.items()
                                        if k in ("status", "darboux_polynomials", "first_integrals", "time_functions",
                                                 "incomplete", "searched", "summary", "certificate"))
            inv_info = dp

    # 10. the earlier atlas ------------------------------------------------------------------------------------
    atlasdb = _mod("atlasdb")
    at = None
    if atlasdb is not None and hasattr(atlasdb, "lookup") and options.get("atlas", True) and depth == 0 \
            and report["equation"]["degree"] >= 2:
        at = _call(ctx, "earlier records", atlasdb.lookup, eq, mode=("exact" if mode == "heavy" else "fast"),
                   budget_s=min(30.0 if mode == "heavy" else 12.0, max(5.0, _left(ctx))), _timeout=50.0)
        if at:
            report["atlas"] = at

    # 10b. solutions of the earlier records that the engine does not derive itself (d >= 2) -------------------
    if at:
        _atlas_found(report, at)

    # 10c. changes of variables ---------------------------------------------------------------------------------
    transform = _mod("transform")
    if transform is not None and depth == 0:
        if hasattr(transform, "normal_form_block"):
            nf = _call(ctx, "normal form", transform.normal_form_block, eq, _timeout=25.0)
            if nf:
                report["normal_form"] = nf
        if options.get("twist", True) and not low_applies and hasattr(transform, "exponential_twist") \
                and getattr(eq, "solved", True):
            _twists(report, eq, transform, ctx, mode, options, depth)

    # 11. verdict ----------------------------------------------------------------------------------------------
    _verdict(report, eq, local, tier, decided, ent, ws, ends, fc, bound, at)

    if inv_info:
        info = _invariants(report, eq, inv_info, ctx, mode, options, depth)
        if info:
            _first_integral_upgrade(report, info)

    # 11b. power substitutions: w has no pole of integer order, a power of w may have ---------------------------
    if transform is not None and depth == 0 and options.get("substitutions", True) \
            and hasattr(transform, "power_substitution") and (local.get("non_integer_balances") or []):
        _power_substitutions(report, eq, transform, ctx, mode, options, depth)

    # 12. special parameter loci -------------------------------------------------------------------------------
    if symbolic and options.get("strata", True) and depth < int(options.get("max_depth", 1)) \
            and report["verdict"]["level"] != "unsupported" and not low_applies:
        _strata(report, eq, local, tier, ctx, mode, options, depth)

    try:
        _drop_degenerate(report, eq)
    except Exception as exc:
        log.append("degenerate loci: %s" % str(exc)[:200])
    _d_summary(report)
    for key in ("ruled_out", "not_decided"):
        for it in report[key]:
            it.pop("_src", None)
    if ctx["failures"]:
        warnings.append("a part of the analysis failed and was skipped: " + "; ".join(ctx["failures"]))
    if ctx["timeouts"]:
        warnings.append("stopped at the time limit: " + "; ".join(ctx["timeouts"]))
        if report["verdict"].get("level") != "complete":
            _add_item(report, "not_decided", {
                "what": "the parts of the analysis that did not finish: " + "; ".join(ctx["timeouts"]),
                "why": "time limit", "partial": "a longer time limit may decide more"})
    if not report["rejected"]:
        report.pop("rejected")
    report["elapsed_s"] = round(time.monotonic() - t_start, 3)
    return report


# ----------------------------------------------------------------------------------------------- verdict
def _pole_bound(tier, fc, bound):
    """the smallest proved bound on the number of poles in a period (None if none)"""
    cands = []
    if tier and isinstance(tier.get("pole_bound"), int):
        cands.append(tier["pole_bound"])
    if fc and isinstance(fc.get("bound_poles_per_period"), int):
        cands.append(fc["bound_poles_per_period"])
    if bound:
        for k in ("simply_periodic", "elliptic"):
            b = (bound.get(k) or {}).get("bound") if isinstance(bound.get(k), dict) else None
            if isinstance(b, int):
                cands.append(b)
    return min(cands) if cands else None


def _coverage(ws, local, ends, ent):
    """what the solver finished: returns a dict used by the verdict"""
    out = {"one_pole": False, "missing": [], "growth_ok": False, "poly_ok": False, "assumed_nonzero": []}
    if not ws:
        out["missing"].append("the search for rational, simply periodic and elliptic solutions did not run")
        return out
    certs = ws.get("certificates") or []
    incomplete = ws.get("incomplete") or []
    orders = sorted(set(int(b["p"]) for b in (local.get("balances") or []) if isinstance(b.get("p"), int)))
    have = set((c.get("kind"), tuple(c.get("poles") or [])) for c in certs)
    need = [(k, (p,)) for k in KINDS for p in orders]
    lacking = [n for n in need if n not in have]
    for c in certs:
        for a in c.get("assumed_nonzero") or []:
            if a not in out["assumed_nonzero"]:
                out["assumed_nonzero"].append(a)
    out["one_pole"] = bool(orders) and not lacking and not incomplete
    for k, ps in lacking:
        out["missing"].append("%s solutions with one pole of order %d in a period" % (k, ps[0]))
    for inc in incomplete:
        out["missing"].append("unfinished: %s" % (inc.get("ansatz") if isinstance(inc, dict) else str(inc))[:200])
    out["growth_ok"] = bool(ends) and ends.get("growth_possible") is False
    cert = (ent or {}).get("certificate") or {}
    pdb = cert.get("polynomial_degree_bound") or {}
    out["poly_ok"] = pdb.get("bound") == 0
    out["multi"] = sorted(set(len(c.get("poles") or []) for c in certs))
    return out


def _verdict(report, eq, local, tier, decided, ent, ws, ends, fc, bound, at):
    """The only place where a level is assigned."""
    symbolic = len(eq.params) > 0
    found_nonconst = [s for s in report["found"] if s.get("kind") != "constant"]

    if decided and decided.get("applies") and decided.get("verdict"):
        v = dict(decided["verdict"])
        v.setdefault("basis", decided.get("basis") or [])
        v.setdefault("scope", "all parameter values, by strata" if symbolic else "this equation")
        report["verdict"] = v
        _atlas_upgrade(report, at)
        return

    tier = tier or {}
    cls = tier.get("class_of_all_meromorphic_solutions")
    used = list(tier.get("used") or [])
    generic = bool(tier.get("generic"))
    conds = list(tier.get("conditions_factored") or tier.get("conditions") or [])
    n_bound = _pole_bound(tier, fc, bound)
    ent_complete = bool(ent) and ent.get("complete") is True
    ent_const = tier.get("entire_solutions") == "constants"
    cov = _coverage(ws, local, ends, ent) if cls != "entire only" else {"assumed_nonzero": []}
    for a in cov.get("assumed_nonzero") or []:
        c = "%s != 0" % a
        if c not in conds:
            conds.append(c)
    scope_generic = symbolic and (generic or bool(conds))
    prefix = ""
    if scope_generic:
        prefix = "For generic values of the parameters (%s): " % "; ".join(conds) if conds else \
            "For generic values of the parameters: "
    basis, level, text = list(used), None, None

    if cls == "listed (not all in W)" and tier.get("text"):
        level = "complete"
        text = prefix + _lower_first(tier["text"], prefix)
    elif cls == "entire (linear equation)":
        if not [x for x in report["found"] if x.get("kind") in ("entire", "polynomial")]:
            r = _fresh(eq, "r")
            chi = sp.expand(sum(co * r ** j for j, co in enumerate(
                [eq.terms.get(tuple(1 if i == j else 0 for i in range(eq.K + 1)), 0) for j in range(eq.K + 1)])))
            report["found"].append({
                "id": "lin", "kind": "entire", "d": None, "expr": None,
                "description": "the general solution: a particular polynomial solution plus the sum of "
                               "q_i(z)*exp(r_i*z) over the roots r_i of chi(%s) = %s, with arbitrary polynomials q_i "
                               "of degree less than the multiplicity of r_i" % (r, _s(chi)),
                "latex": "w = w_{p}(z) + \\sum_i q_i(z)\\,e^{r_i z},\\qquad \\chi(%s) = %s = 0" % (r, sp.latex(chi)),
                "free": ["the coefficients of the q_i"], "conditions": [],
                "certificate": {"type": "linear equation", "status": "pass",
                                "detail": "linear equation with constant coefficients"},
                "origin": "live:linear"})
        level = "complete"
        text = prefix + _lower_first(tier.get("text") or "The equation is linear with constant coefficients: every "
                                     "solution is entire.", prefix) + " The general solution is listed."
        report["not_decided"] = [it for it in report["not_decided"] if it.get("_src") != "tier"]
    elif cls == "entire only" and (ent_complete or ent_const):
        level = "complete"
        text = prefix + _lower_first("No meromorphic solution has a pole, and the solutions without poles are the "
                                     "ones listed.", prefix)
        if ent and ent.get("basis"):
            basis += [b for b in ent["basis"] if b not in basis]
    elif cls in W_CLASSES:
        head = "every meromorphic solution is rational, simply periodic or elliptic"
        if n_bound is not None:
            head += ", with at most %d pole%s in a period" % (n_bound, "" if n_bound == 1 else "s")
        entire_ok = ent_complete or ent_const
        if n_bound is not None and n_bound <= 1 and cov["one_pole"] and cov["growth_ok"] and cov["poly_ok"] \
                and entire_ok:
            level = "complete"
            text = prefix + _cap(head, prefix) + ". All of them are listed" + \
                (" (each family with the conditions on the parameters under which it exists)." if symbolic else ".")
            basis.append("certificate: the systems for one pole in a period")
            _certificate_ruled_out(report, ws, symbolic)
        else:
            level = "partial"
            done = []
            if cov["one_pole"]:
                done.append("all such solutions with one pole in a period are listed")
            missing = list(cov["missing"])
            if n_bound is None:
                missing.append("solutions with more than one pole in a period (no bound on the number of poles is "
                               "available here)")
            elif n_bound >= 2 and max(cov.get("multi") or [1]) < n_bound:
                missing.append("solutions with %s poles in a period" %
                               ("2" if n_bound == 2 else "2 to %d" % n_bound))
            if not cov["growth_ok"] and ws:
                missing.append("simply periodic solutions that grow exponentially at an end of the period strip")
            if not cov["poly_ok"] and ws:
                missing.append("rational solutions that grow at infinity")
            if not entire_ok:
                missing.append("transcendental solutions without poles")
            text = prefix + _cap(head, prefix) + ". " + ("; ".join(done).capitalize() + ". " if done else "") + \
                "Not computed: " + "; ".join(missing) + "."
            for m in missing:
                _add_item(report, "not_decided", {"what": m, "why": "not computed in this run",
                                                  "partial": head + " (" + ", ".join(used) + ")"})
            if cov["one_pole"]:
                _certificate_ruled_out(report, ws, symbolic)
    else:
        cov_ok = bool(ws) and cov["one_pole"]
        if cls == "entire only":
            level = "partial"
            text = prefix + _lower_first("No meromorphic solution has a pole. Solutions without poles: the ones "
                                         "listed; others are not decided.", prefix)
        elif found_nonconst or cov_ok:
            level = "partial"
            text = prefix + _lower_first(
                "No theorem of the registry gives the class of all meromorphic solutions of this equation. "
                + ("All rational, simply periodic and elliptic solutions with one pole in a period%s are listed; "
                   % ("" if cov.get("growth_ok") else " and finite limits at the ends") if cov_ok else
                   "The solutions listed were found; ")
                + "other meromorphic solutions are not decided.", prefix)
            if cov_ok:
                _certificate_ruled_out(report, ws, symbolic)
        else:
            level = "formal"
            text = prefix + _lower_first("Local analysis only: no theorem of the registry decides this equation, and "
                                         "no solution other than constants was found.", prefix)
        _add_item(report, "not_decided", {
            "what": "meromorphic solutions other than the ones listed (several poles in a period; solutions that are "
                    "not rational, simply periodic or elliptic)",
            "why": "no theorem of the registry gives the class of all meromorphic solutions of this equation",
            "partial": "the local analysis restricts every meromorphic solution: pole orders, leading coefficients, "
                       "Fuchs indices and compatibility conditions are listed below"})
    report["verdict"] = {"level": level, "text": text, "basis": basis,
                         "scope": ("generic parameter values" if scope_generic else
                                   ("all parameter values" if symbolic else "this equation")),
                         "conditions": conds if scope_generic else []}
    _atlas_upgrade(report, at)


def _cap(s, prefix):
    return s if prefix else s[:1].upper() + s[1:]


def _lower_first(s, prefix):
    return (s[:1].lower() + s[1:]) if prefix else s


def _certificate_ruled_out(report, ws, symbolic):
    """for every form that the solver finished: what it excludes"""
    by_kind = {}
    for c in (ws or {}).get("certificates") or []:
        if len(c.get("poles") or []) != 1:
            continue
        by_kind.setdefault(c.get("kind"), []).append(c)
    for kind, cs in by_kind.items():
        n = sum(len(c.get("solutions") or []) for c in cs)
        orders = sorted(set(c["poles"][0] for c in cs))
        if n == 0:
            what = "%s solutions with one pole in a period" % kind
        else:
            what = "%s solutions with one pole in a period other than the %d listed%s" % (
                kind, n, " (for other parameter values none exist)" if symbolic else "")
        _add_item(report, "ruled_out", {
            "what": what, "basis": {"theorem": None, "label": "certificate"},
            "certificate": {"type": "system", "detail": "the general form with one pole of order %s was substituted "
                            "and the resulting polynomial system solved completely (%s)" %
                            (", ".join(str(o) for o in orders), "; ".join(sorted(set(str(c.get("method", ""))[:120] for c in cs)))),
                            "scope": "; ".join(sorted(set(str(c.get("scope", "")) for c in cs)))[:400]},
            "conditions": []})


def _atlas_upgrade(report, at):
    """an earlier record with a completeness label that contains the equation"""
    if not at:
        return
    summ = at.get("summary") or {}
    v = report["verdict"]
    if summ.get("complete") and summ.get("by"):
        rec = summ["by"]
        label = None
        for m in at.get("matches") or []:
            if m.get("id") == rec:
                label = m.get("label")
        v["record"] = {"id": rec, "label": label or "agent-proof", "complete": True}
        if v.get("level") != "complete":
            v["level_without_record"] = v.get("level")
            v["level"] = "complete"
            v["text"] = ("According to record %s of the project's earlier atlas (label: %s), all meromorphic "
                         "solutions of this equation are known; the record is shown below. Computed here: %s"
                         % (rec, label or "agent-proof", v.get("text", "")))
            v["basis"] = ["record:" + rec] + list(v.get("basis") or [])


# ----------------------------------------------------------------------------------------------- changes of variables
def _atlas_found(report, at):
    """solutions with d >= 2 described in the earlier records that contain the equation exactly"""
    seen, seen_d = set(), set()
    matches = sorted(at.get("matches") or [], key=lambda m: (("@" in str(m.get("id"))) or ("COST" in str(m.get("id"))),
                                                               len(str(m.get("id")))))
    for m in matches:
        if m.get("match") != "exact" or m.get("kind") != "wave":
            continue
        site = m.get("site")
        if isinstance(site, str):
            try:
                site = json.loads(site)
            except Exception:
                site = None
        for sol in (site or {}).get("found") or []:
            d = sol.get("d")
            if not (isinstance(d, int) and d >= 2):
                continue
            desc = sol.get("description") or sol.get("closed_form_card") or ""
            if desc in seen or d in seen_d:
                continue
            seen.add(desc)
            seen_d.add(d)
            item = {"id": "rec%d" % (len(seen)), "kind": "other", "d": d, "expr": None,
                    "description": desc, "closed_form_record": sol.get("closed_form_card"),
                    "conditions": [], "free": [], "label": m.get("label") or "agent-proof",
                    "note": "from record %s of the project's earlier atlas, in the variables of the record "
                            "(change of variables: %s)" % (m.get("id"), json.dumps(m.get("change") or {})),
                    "certificate": {"type": "record", "status": "not-run",
                                    "detail": "described in the record; not derived again here"},
                    "origin": "atlas:%s" % m.get("id")}
            report["found"].append(item)


def _solve_conditions(conds, params):
    """conditions of the form 'expr = 0' and 'expr != 0' -> list of substitutions {param: value} (branches)"""
    eqs, neq = [], []
    for c in conds or []:
        c = str(c)
        if "!=" in c:
            neq.append(c)
            continue
        lhs = c.split("=")[0]
        rhs = c.split("=")[-1] if "=" in c else "0"
        try:
            e = sp.sympify(lhs, locals=dict((str(q), q) for q in params)) - \
                sp.sympify(rhs, locals=dict((str(q), q) for q in params))
        except Exception:
            return None, neq
        if e != 0:
            eqs.append(e)
    if not eqs:
        return [{}], neq
    syms = sorted(set().union(*[e.free_symbols for e in eqs]), key=str)
    # prefer to solve for the symbols that occur with the lowest degree
    best = None
    import itertools
    for k in range(len(eqs), 0, -1):
        for combo in itertools.combinations(syms, min(k, len(syms))):
            if len(combo) != len(eqs):
                continue
            try:
                sol = sp.solve(eqs, list(combo), dict=True)
            except Exception:
                sol = []
            sol = [br for br in sol if all(sp.simplify(e.subs(br)) == 0 for e in eqs)]
            if sol and all(not any(v.has(sp.RootOf) for v in br.values()) for br in sol):
                size = sum(sp.count_ops(v) for br in sol for v in br.values())
                if best is None or size < best[0]:
                    best = (size, sol)
        if best:
            break
    return (best[1] if best else None), neq


def _twists(report, eq, transform, ctx, mode, options, depth):
    """w = c + (kappa s)^p Y(s), s = exp(kappa z): solutions through an autonomous equation in s"""
    tws = _call(ctx, "exponential changes of variable", transform.exponential_twist, eq, _soft=True) or []
    special = _mod("special")
    verify = _mod("verify")
    if not tws or special is None or verify is None or not hasattr(verify, "verify_expr"):
        return
    out = []
    S = sp.Symbol("S_twist")
    for tw in tws[:3]:
        target = tw.get("equation")
        ex = (tw.get("map") or {}).get("_exact") or {}
        if target is None or not ex:
            continue
        branches, neq = _branches(ctx, tw.get("conditions"), eq.params)
        entry = {"map": dict((k, v) for k, v in (tw.get("map") or {}).items() if k != "_exact"),
                 "conditions": tw.get("conditions"), "note": tw.get("note"), "solutions": 0}
        out.append(entry)
        if branches is None:
            entry["status"] = "the conditions could not be solved for a parameter; no solution was built"
            continue
        sub = _call(ctx, "equation after the exponential change of variable", analyze, target, mode=mode,
                    budget_s=min(30.0, _left(ctx, 10.0)), _depth=depth + 1, atlas=False, strata=False, twist=False,
                    substitutions=False, darboux=False)
        if not sub:
            continue
        entry["target"] = sub.get("equation")
        entry["target_verdict"] = sub.get("verdict")
        loc = {"wp": getattr(special, "wp", None), "wpp": getattr(special, "wpp", None), "z": z}
        loc = dict((k, v) for k, v in loc.items() if v is not None)
        for ysol in sub.get("found") or []:
            if ysol.get("kind") in ("constant",) or not ysol.get("expr"):
                continue
            try:
                names = set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", ysol["expr"]))
                l2 = dict(loc)
                for nme in names:
                    if nme not in l2 and nme not in ("exp", "sqrt", "I", "pi", "tanh", "coth", "sinh", "cosh"):
                        l2[nme] = sp.Symbol(nme)
                Y = sp.sympify(ysol["expr"], locals=l2)
                for cname, cval in (ysol.get("constants") or {}).items():
                    if isinstance(cval, str) and not cval.startswith("free"):
                        Y = Y.subs(sp.Symbol(cname), sp.sympify(cval, locals=l2))
                if ysol.get("conditions"):
                    continue                       # the target has no parameters; a conditional solution is skipped
                Y = Y.subs(sp.Symbol("z0"), sp.Symbol("s0")).subs(z, S)
            except Exception:
                continue
            for br in branches:
                try:
                    kap = sp.sympify(ex["kappa"]).subs(br)
                    cc = sp.sympify(ex["c"]).subs(br)
                    pp = sp.sympify(ex["p"])
                    wexpr = cc + (kap * S) ** pp * Y
                    wexpr = wexpr.subs(S, sp.exp(kap * z))
                    eq_b = eq.subs(br) if br else eq
                    chk = _call(ctx, "check of a solution built by a change of variable", verify.verify_expr, eq_b,
                                sp.sstr(wexpr), _timeout=30.0)
                except Exception as exc:
                    ctx["log"].append("twist: a candidate could not be checked: %s" % str(exc)[:200])
                    continue
                if (chk or {}).get("status") != "zero":
                    report["rejected"].append({"expr": sp.sstr(wexpr), "why": "substitution check: %s" %
                                               (chk or {}).get("status"), "origin": "live:twist"})
                    continue
                rational_in_s = ysol.get("kind") == "rational"
                if rational_in_s and not br and any(x.get("kind") == "simply-periodic" and
                                                    x.get("origin") == "live:wsolve" for x in report["found"]):
                    entry["note2"] = "a solution rational in s gives a simply periodic solution; the solver lists " \
                                     "those itself"
                    continue
                conds = ["%s == %s" % (k, _s(v)) for k, v in br.items()] + [c.replace(" = ", " == ") if "!=" not in c
                                                                             else c for c in neq]
                item = {"kind": "simply-periodic" if rational_in_s else "other", "d": 1 if rational_in_s else 2,
                        "expr": sp.sstr(wexpr), "latex": sp.latex(wexpr),
                        "free": ["s0"] + [f for f in (ysol.get("free") or []) if f not in ("z0",)],
                        "conditions": conds,
                        "note": "w = c + (kappa s)^p Y(s) with s = exp(kappa z); Y(s) is a %s solution of %s"
                                % (ysol.get("kind"), (sub.get("equation") or {}).get("sympy")),
                        "certificate": {"type": "substitution", "method": "symbolic", "status": "pass",
                                        "detail": (chk or {}).get("detail", "exact substitution")},
                        "origin": "live:twist"}
                _add_found(report, item)
                entry["solutions"] += 1
    if out:
        report["twists"] = out


def _power_substitutions(report, eq, transform, ctx, mode, options, depth):
    """u = w^m when w has a balance of non-integer order: analyse the equation for u"""
    subs = _call(ctx, "power substitutions", transform.power_substitution, eq, _soft=True) or []
    out = []
    for sb in subs[:2]:
        target = sb.get("equation")
        if target is None or _left(ctx) < 5.0:
            continue
        sub = _call(ctx, "equation after the substitution %s" % (sb.get("map") or {}).get("u", ""), analyze, target,
                    mode=mode, budget_s=min(40.0, _left(ctx, 2.0)), _depth=depth + 1, atlas=False, strata=False,
                    twist=False, substitutions=False, darboux=False)
        if not sub:
            continue
        out.append({"name": sb.get("name"), "map": sb.get("map"), "note": sb.get("note"),
                    "conditions": sb.get("conditions"), "equation": sub.get("equation"),
                    "verdict": sub.get("verdict"), "found": sub.get("found"), "ruled_out": sub.get("ruled_out"),
                    "not_decided": sub.get("not_decided"), "local": sub.get("local")})
    if out:
        report["substitutions"] = out
        v = report["verdict"]
        best = out[0]
        v["after_substitution"] = {"map": best.get("map"), "level": (best.get("verdict") or {}).get("level"),
                                   "text": (best.get("verdict") or {}).get("text"),
                                   "found": len([x for x in (best.get("found") or []) if x.get("kind") != "constant"])}


def _drop_degenerate(report, eq):
    """found items that live on a parameter locus where the equation loses order or degree are not listed:
    there the visitor's equation is a different equation"""
    params = dict((str(q), q) for q in eq.params)
    if not params:
        return
    cache, keep, loci = {}, [], []
    for it in report["found"]:
        subs = {}
        for c in it.get("conditions") or []:
            c = str(c)
            if "==" not in c:
                continue
            a, b = [x.strip() for x in c.split("==", 1)]
            if a in params:
                try:
                    val = sp.sympify(b, locals=params)
                except Exception:
                    continue
                if not (val.free_symbols - set(params.values())) and params[a] not in val.free_symbols:
                    subs[params[a]] = val
        key = tuple(sorted((str(k), sp.sstr(v)) for k, v in subs.items()))
        if not key:
            keep.append(it)
            continue
        if key not in cache:
            try:
                cache[key] = _degenerate(eq, eq.subs(subs))
            except Exception:
                cache[key] = False
        if cache[key]:
            txt = ", ".join("%s = %s" % kv for kv in key)
            if txt not in loci:
                loci.append(txt)
        else:
            keep.append(it)
    if loci:
        report["found"] = keep
        report["degenerate_loci"] = {
            "loci": loci,
            "note": "on these parameter loci the equation has lower order or lower degree (a coefficient of a "
                    "leading term vanishes); it is then a different equation, and its solutions are not listed here"}


def _degenerate(eq, sub_eq):
    """True if the specialised equation has lower order or lower degree than the original"""
    try:
        d0 = max(sum(m) for m in eq.terms)
        d1 = max(sum(m) for m in sub_eq.terms)
        return sub_eq.K < eq.K or d1 < d0
    except Exception:
        return False


# ----------------------------------------------------------------------------------------------- invariant surfaces
def _reduced_analysis(eq, red, br, mode, budget_s, depth):
    """build the reduced equation on an invariant surface and analyse it (runs inside a time-limited step)"""
    from mero.equation import Equation
    red_eq = Equation.from_dict(red)
    if br:
        if _degenerate(eq, eq.subs(br)):
            return {"degenerate": True}
        red_eq = red_eq.subs(br)
    return analyze(red_eq, mode=mode, budget_s=budget_s, _depth=depth + 1, atlas=False, strata=True, twist=False,
                   substitutions=False, darboux=False)


def _conditions_step(conds, params):
    branches, neq = _solve_conditions(conds, params)
    if branches is None:
        return {"branches": None, "neq": neq}
    return {"branches": [dict((str(k), sp.sstr(v)) for k, v in br.items()) for br in branches], "neq": neq}


def _branches(ctx, conds, params):
    """conditions -> (list of substitutions or None, inequalities); time-limited"""
    if not conds:
        return [{}], []
    out = _call(ctx, "conditions of a special locus", _conditions_step, conds, params, _timeout=20.0)
    if not out or out.get("branches") is None:
        return None, (out or {}).get("neq") or []
    loc = dict((str(q), q) for q in params)
    brs = []
    for br in out["branches"]:
        brs.append(dict((loc.get(k, sp.Symbol(k)), sp.sympify(v, locals=loc)) for k, v in br.items()))
    return brs, out.get("neq") or []


def _invariants(report, eq, dp, ctx, mode, options, depth):
    """solutions on invariant algebraic surfaces G = 0 (and on the levels G = C of a first integral)"""
    equation_mod = _mod("equation")
    if equation_mod is None or not hasattr(equation_mod, "Equation"):
        return None
    info = {"first_integral": None}
    surfaces = list(dp.get("first_integrals") or []) + list(dp.get("darboux_polynomials") or [])
    done = 0
    seen = set()
    for g in surfaces:
        red = g.get("reduced_equation")
        if not red or done >= 3 or _left(ctx) < 8.0:
            continue
        if not red.get("solved"):
            continue
        if int(red.get("order") or 99) > 2 and (mode != "heavy" or _left(ctx) < 60.0):
            report.setdefault("surfaces", []).append({
                "G": g.get("G"), "latex": g.get("latex"), "cofactor": g.get("cofactor"),
                "first_integral": bool(g.get("first_integral")), "conditions": g.get("conditions"),
                "reduced": red, "status": "the reduced equation was not analysed here (order %s)" % red.get("order")})
            continue
        key = red.get("sympy") or red.get("E")
        if key in seen:
            continue
        seen.add(key)
        if _left(ctx) < 8.0:
            continue
        branches, neq = _branches(ctx, g.get("conditions"), eq.params)
        if branches is None:
            continue
        for br in branches[:2]:
            is_fi = bool(g.get("first_integral"))
            b_s = min(40.0 if mode == "heavy" else 12.0, _left(ctx, 5.0))
            sub = _call(ctx, "equation on the %s %s" % ("levels of the first integral" if is_fi else "invariant surface",
                                                         str(g.get("G"))[:60]), _reduced_analysis, eq, red, br, mode,
                        b_s, depth, _timeout=b_s + 10.0)
            if sub and sub.get("degenerate"):
                continue                     # the equation itself changes type on this locus
            done += 1
            if not sub:
                continue
            conds = ["%s == %s" % (k, _s(v)) for k, v in br.items()] + list(neq)
            entry = {"G": g.get("G"), "latex": g.get("latex"), "cofactor": g.get("cofactor"),
                     "first_integral": is_fi, "conditions": conds, "reduced": sub.get("equation"),
                     "verdict": sub.get("verdict"), "found": sub.get("found"), "ruled_out": sub.get("ruled_out"),
                     "not_decided": sub.get("not_decided")}
            report.setdefault("surfaces", []).append(entry)
            for sol in sub.get("found") or []:
                if sol.get("kind") == "constant" and not is_fi:
                    continue
                item = dict(sol)
                item.pop("id", None)
                item["conditions"] = conds + list(sol.get("conditions") or [])
                item["note"] = ((sol.get("note") or "") + " Solution of the reduced equation %s = %s (%s)." % (
                    g.get("G"), "C_I" if is_fi else "0",
                    "a first integral" if is_fi else "an invariant surface with cofactor %s" % g.get("cofactor"))).strip()
                item["origin"] = "live:invariant-surface"
                complete_now = report.get("verdict", {}).get("level") == "complete"
                d_sol = sol.get("d")
                if sol.get("kind") != "constant" and (not complete_now or (isinstance(d_sol, int) and d_sol >= 2)):
                    _add_found(report, item)
            if is_fi and not br and info["first_integral"] is None:
                info["first_integral"] = entry
    return info


def _first_integral_upgrade(report, info):
    fi = info.get("first_integral")
    if not fi:
        return
    v = report["verdict"]
    sv = fi.get("verdict") or {}
    if v.get("level") == "complete" or sv.get("level") != "complete":
        return
    if (sv.get("scope") or "").startswith("generic"):
        return
    report["verdict"] = {
        "level": "complete",
        "text": "The equation has the polynomial first integral %s = C_I, so every solution satisfies the equation of "
                "lower order obtained from it, for some value of the constant C_I. For that family: %s"
                % (fi.get("G"), sv.get("text")),
        "basis": ["certificate: first integral"] + list(sv.get("basis") or []),
        "scope": "all parameter values, by strata" if report["equation"]["params"] else "this equation",
        "conditions": [], "level_before": v.get("level"), "text_before": v.get("text")}
    report["not_decided"] = [it for it in report["not_decided"]
                             if not str(it.get("what", "")).startswith("meromorphic solutions other than")]


# ----------------------------------------------------------------------------------------------- strata
def _strata(report, eq, local, tier, ctx, mode, options, depth):
    """special parameter loci that can be reached by substituting a value: analyse the equation there"""
    strata = [s for s in (local.get("strata") or []) if isinstance(s, dict) and s.get("substitution")]
    seen, todo = set(), []
    for s in strata:
        key = json.dumps(s.get("substitution"), sort_keys=True)
        if key in seen:
            continue
        seen.add(key)
        todo.append(s)
    if not todo:
        return
    out = []
    max_n = int(options.get("max_strata", 6))
    share = max(5.0, 0.25 * ctx["budget_s"] / max(1, min(len(todo), max_n)))
    for s in todo[:max_n]:
        if _left(ctx) < 3.0:
            out.append({"conditions": s.get("conditions"), "status": "not analysed (time limit)"})
            continue
        try:
            subs = dict((sp.Symbol(k), sp.sympify(v)) for k, v in s["substitution"].items())
            sub_eq = eq.subs(subs) if hasattr(eq, "subs") else None
        except Exception as exc:
            out.append({"conditions": s.get("conditions"), "status": "not analysed (%s)" % exc})
            continue
        if sub_eq is None:
            continue
        if _degenerate(eq, sub_eq):
            out.append({"conditions": s.get("conditions"), "substitution": s.get("substitution"),
                        "status": "degenerate: on this locus the equation has lower order or degree; "
                                  "it is a different equation and is not analysed here",
                        "equation": _equation_block(sub_eq)})
            continue
        sub = _call(ctx, "special locus %s" % ", ".join(s.get("conditions") or []), analyze, sub_eq, mode=mode,
                    budget_s=min(share, _left(ctx)), _depth=depth + 1, atlas=False,
                    max_poles=options.get("max_poles", 1), strata=False)
        if not sub:
            out.append({"conditions": s.get("conditions"), "status": "not analysed (failed)"})
            continue
        out.append({"conditions": s.get("conditions"), "substitution": s.get("substitution"),
                    "status": "analysed", "equation": sub.get("equation"), "verdict": sub.get("verdict"),
                    "found": sub.get("found"), "ruled_out": sub.get("ruled_out"),
                    "not_decided": sub.get("not_decided"),
                    "tier_text": (sub.get("tier") or {}).get("text")})
        for sol in sub.get("found") or []:
            if sol.get("kind") == "constant":
                continue
            sol = dict(sol)
            sol["conditions"] = list(s.get("conditions") or []) + list(sol.get("conditions") or [])
            sol["origin"] = (sol.get("origin") or "live") + " (special locus)"
            sol.pop("id", None)
            _add_found(report, sol)
    if len(todo) > max_n:
        out.append({"conditions": ["%d further loci" % (len(todo) - max_n)], "status": "not analysed (limit)"})
    report["strata"] = out
    v = report["verdict"]
    done = [o for o in out if o.get("status") == "analysed"]
    if done:
        v["special_loci"] = [{"conditions": o["conditions"], "level": (o.get("verdict") or {}).get("level"),
                              "text": (o.get("verdict") or {}).get("text")} for o in done]
    rest = [o for o in out if o.get("status") != "analysed" and not str(o.get("status")).startswith("degenerate")]
    for o in rest:
        _add_item(report, "not_decided", {"what": "parameter values with " + ", ".join(o.get("conditions") or []),
                                          "why": o.get("status"), "partial": ""})
    # the generic statement of the theorems left the special loci open: say what was done there
    for item in report["not_decided"]:
        w = item.get("what", "")
        if w.startswith("parameter values at which one of the conditions fails") and done:
            item["partial"] = (item.get("partial") or "") + " Analysed here: " + "; ".join(
                "%s: %s" % (", ".join(o["conditions"]), (o.get("verdict") or {}).get("level")) for o in done) + \
                " (see the field 'strata')."


def _d_summary(report):
    found = report["found"]
    d1 = [s for s in found if s.get("d") == 1 or s.get("kind") in ("rational", "simply-periodic", "elliptic",
                                                                    "polynomial")]
    d2 = [s for s in found if s.get("d") == 2]
    d3 = [s for s in found if isinstance(s.get("d"), int) and s.get("d") >= 3]
    lvl = report.get("verdict", {}).get("level")
    tier = report.get("tier") or {}
    all_w = tier.get("class_of_all_meromorphic_solutions") in W_CLASSES + ("entire only",) and \
        (tier.get("d_le_1") is not False)
    dge2 = (tier.get("d_ge_2") or {}).get("status")
    generic = bool(tier.get("generic")) or report.get("verdict", {}).get("scope") == "generic parameter values"
    if lvl == "complete" and report.get("verdict", {}).get("level_without_record"):
        s1 = "partial" if d1 else "none found"
        s2 = s3 = "see the record"
    elif lvl == "complete":
        s1 = "complete"
        s2 = "found" if d2 else "ruled out"
        s3 = "found" if d3 else "ruled out"
    else:
        s1 = "partial" if d1 else "none found"
        s2 = "ruled out" if all_w else ("found" if d2 else "not ruled out")
        s3 = "ruled out" if all_w else ("found" if d3 else "not ruled out")
    if lvl == "complete" and not all_w and dge2 == "not ruled out":
        s2 = s3 = "possible (see the list)"
    if tier.get("class_of_all_meromorphic_solutions") == "listed (not all in W)" and not d2 and not d3:
        s1 = "see the verdict"
        s2 = s3 = "occurs (see the verdict)"
    if d2:
        s2 = "found"
    elif dge2 == "occurs" and not d3:
        s2 = "occurs (see the verdict)"
    if d3:
        s3 = "found"
    elif dge2 == "not ruled out" and s3 == "ruled out" and lvl != "complete":
        s3 = "not ruled out"
    if generic:
        if s2 == "ruled out":
            s2 = "ruled out for generic parameter values"
        if s3 == "ruled out":
            s3 = "ruled out for generic parameter values"
    basis = ", ".join(report.get("verdict", {}).get("basis") or [])[:200]
    report["d_summary"] = {"1": {"status": s1, "count": len(d1)},
                           "2": {"status": s2, "count": len(d2), "basis": basis if s2.startswith("ruled out") else ""},
                           "3+": {"status": s3, "count": len(d3), "basis": basis if s3.startswith("ruled out") else ""}}


def analyze_json(text, **kw):
    return json.dumps(analyze(text, **kw), default=str, ensure_ascii=False)


if __name__ == "__main__":
    import sys
    txt = sys.argv[1] if len(sys.argv) > 1 else "w''' = 12*w*w' + 1"
    print(json.dumps(analyze(txt, mode="heavy" if "--heavy" in sys.argv else "light"), indent=1, default=str,
                     ensure_ascii=False))
