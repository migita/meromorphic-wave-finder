"""mero.special -- the special functions used in closed-form solutions.

SymPy function classes

    wp(z, g2, g3)       Weierstrass function,          wp'  = wpp
    wpp(z, g2, g3)      its derivative in z,           wpp' = 6*wp**2 - g2/2,   wpp**2 = 4*wp**3 - g2*wp - g3
    zeta_w(z, g2, g3)   Weierstrass zeta function,     zeta_w' = -wp

with LaTeX printing and numerical evaluation (mpmath) that is valid for complex arguments and complex
invariants, including the degenerate case g2**3 = 27*g3**2.  The numerical evaluation uses the Laurent series
at 0,

    wp(u) = u**-2 + sum_{k>=2} c_k u**(2k-2),   c_2 = g2/20, c_3 = g3/28,
    c_k = 3/((2k+1)(k-3)) * sum_{m=2}^{k-2} c_m c_{k-m},

at the point u = z/2**n and n applications of the duplication formulas

    wp(2u)   = -2 wp(u) + (wp''(u)/(2 wp'(u)))**2,
    wp'(2u)  = -( (wp''(u)/wp'(u)) (wp(2u) - wp(u)) + wp'(u) ),
    zeta(2u) = 2 zeta(u) + wp''(u)/(2 wp'(u)).

If rho = max(|g2|**(1/4), |g3|**(1/6)), then |c_k| <= 3 (rho**2/4)**k (induction on the recursion), so the series
converges for |u| rho < 2; n is chosen with |u| rho <= 1/4, where the terms decrease like 64**-k.

Helpers for simply periodic solutions:  T(z, nu) = nu/(exp(nu z) - 1)  (T' = -T**2 - nu T)  and
tau(z, nu) = (nu/2) coth(nu z/2) = T + nu/2  (tau' = nu**2/4 - tau**2; an even function of nu).

Only SymPy and mpmath are used.
"""
import mpmath as mp
import sympy as sp
from sympy.core.function import ArgumentIndexError, Function

__all__ = ["wp", "wpp", "zeta_w", "T", "tau", "weierstrass_num", "wp_num", "wpp_num", "zeta_num",
           "NAMESPACE", "MP_FUNCTIONS"]


# ----------------------------------------------------------------------------------------------- numerics
def _weierstrass_at(zv, g2, g3, work):
    """(wp, wp', zeta) computed with `work` digits of working precision (no accuracy guarantee by itself)"""
    with mp.workdps(work):
        zv = mp.mpmathify(zv)
        g2 = mp.mpmathify(g2)
        g3 = mp.mpmathify(g3)
        rho = max(abs(g2) ** mp.mpf("0.25"), abs(g3) ** (mp.mpf(1) / 6))
        if rho == 0:
            return (1 / zv ** 2, -2 / zv ** 3, 1 / zv)
        n = max(0, int(mp.ceil(mp.log(4 * abs(zv) * rho, 2))))
        u = zv / mp.mpf(2) ** n
        nterms = int(work / 1.8) + 4
        c = [mp.mpf(0)] * (nterms + 1)
        c[2] = g2 / 20
        c[3] = g3 / 28
        for k in range(4, nterms + 1):
            acc = mp.mpf(0)
            for m in range(2, k - 1):
                acc += c[m] * c[k - m]
            c[k] = 3 * acc / ((2 * k + 1) * (k - 3))
        u2 = u * u
        P = 1 / u2
        Pd = -2 / (u2 * u)
        Z = 1 / u
        pw = u2            # u**(2k-2) for k = 2
        for k in range(2, nterms + 1):
            P += c[k] * pw
            Pd += (2 * k - 2) * c[k] * pw / u
            Z -= c[k] * pw * u / (2 * k - 1)
            pw *= u2
        for _ in range(n):
            half = (6 * P * P - g2 / 2) / (2 * Pd)        # wp''/(2 wp')
            Pn = half * half - 2 * P
            Pdn = -(2 * half * (Pn - P) + Pd)
            Zn = 2 * Z + half
            P, Pd, Z = Pn, Pdn, Zn
        return (P, Pd, Z)


def weierstrass_num(zv, g2, g3, dps=30):
    """(wp, wp', zeta) at the complex point zv for the invariants g2, g3; mpmath numbers, `dps` digits.

    The duplication steps lose digits where wp' is small (near half-periods of the intermediate points and,
    for a degenerate curve, far from the poles), so the working precision is doubled until two successive
    results agree to `dps` digits."""
    if mp.mpmathify(zv) == 0:
        raise ZeroDivisionError("pole of the Weierstrass function")
    work = dps + 25
    prev = _weierstrass_at(zv, g2, g3, work)
    for _ in range(7):
        work *= 2
        cur = _weierstrass_at(zv, g2, g3, work)
        with mp.workdps(work):
            ok = all(abs(a - b) <= mp.mpf(10) ** (-dps - 2) * max(abs(b), mp.mpf(10) ** (-dps))
                     for a, b in zip(prev, cur))
        prev = cur
        if ok:
            break
    with mp.workdps(dps + 5):
        return tuple(+x for x in prev)


def wp_num(zv, g2, g3, dps=None):
    return weierstrass_num(zv, g2, g3, dps or mp.mp.dps)[0]


def wpp_num(zv, g2, g3, dps=None):
    return weierstrass_num(zv, g2, g3, dps or mp.mp.dps)[1]


def zeta_num(zv, g2, g3, dps=None):
    return weierstrass_num(zv, g2, g3, dps or mp.mp.dps)[2]


def _evalf_args(args, prec):
    vals = []
    for a in args:
        v = a._eval_evalf(prec) if not a.is_number else a.evalf(n=sp.core.evalf.prec_to_dps(prec) + 5)
        if v is None or not v.is_number:
            return None
        vals.append(mp.mpc(*[mp.mpf(str(t)) for t in v.as_real_imag()]))
    return vals


class _WeierstrassBase(Function):
    nargs = 3
    _index = 0
    _latex_name = r"\wp"

    def _eval_evalf(self, prec):
        dps = sp.core.evalf.prec_to_dps(prec)
        with mp.workdps(dps + 10):
            vals = _evalf_args(self.args, prec)
            if vals is None:
                return None
            v = weierstrass_num(vals[0], vals[1], vals[2], dps + 5)[self._index]
            re, im = sp.Float(str(mp.re(v)), dps), sp.Float(str(mp.im(v)), dps)
        return re if im == 0 else re + im * sp.I

    def _latex(self, printer, exp=None):
        u, g2, g3 = [printer._print(a) for a in self.args]
        name = self._latex_name
        if exp is not None:
            name = "%s^{%s}" % (name, exp) if "'" not in name else None
        if name is None:
            return r"\left(%s\left(%s; %s, %s\right)\right)^{%s}" % (self._latex_name, u, g2, g3, exp)
        return r"%s\left(%s; %s, %s\right)" % (name, u, g2, g3)


class wp(_WeierstrassBase):
    """Weierstrass function wp(z; g2, g3)."""
    _index = 0
    _latex_name = r"\wp"

    def fdiff(self, argindex=1):
        if argindex == 1:
            return wpp(*self.args)
        raise ArgumentIndexError(self, argindex)


class wpp(_WeierstrassBase):
    """Derivative in z of the Weierstrass function."""
    _index = 1
    _latex_name = r"\wp'"

    def fdiff(self, argindex=1):
        if argindex == 1:
            u, g2, g3 = self.args
            return 6 * wp(u, g2, g3) ** 2 - g2 / 2
        raise ArgumentIndexError(self, argindex)


class zeta_w(_WeierstrassBase):
    """Weierstrass zeta function, zeta_w' = -wp."""
    _index = 2
    _latex_name = r"\zeta"

    def fdiff(self, argindex=1):
        if argindex == 1:
            return -wp(*self.args)
        raise ArgumentIndexError(self, argindex)


def T(zexpr, nu):
    """nu/(exp(nu z) - 1):  simple pole at 0 with residue 1,  T' = -T**2 - nu*T."""
    return nu / (sp.exp(nu * zexpr) - 1)


def tau(zexpr, nu):
    """(nu/2) coth(nu z/2) written with exponentials:  tau' = nu**2/4 - tau**2,  tau = 1/z + O(z)."""
    return nu / 2 * (sp.exp(nu * zexpr) + 1) / (sp.exp(nu * zexpr) - 1)


#: names understood in solution strings (SCHEMA section 2) in addition to the SymPy elementary functions
NAMESPACE = {"wp": wp, "wpp": wpp, "zeta_w": zeta_w}

#: the same names for sympy.lambdify(..., modules=[MP_FUNCTIONS, "mpmath"])
MP_FUNCTIONS = {"wp": wp_num, "wpp": wpp_num, "zeta_w": zeta_num}
