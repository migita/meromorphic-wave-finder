"""mero.wsolve -- rational, simply periodic and elliptic solutions with a prescribed set of poles.

    find_w_solutions(eq, local=None, max_poles=1, kinds=(...), ends=None, budget_s=60, numeric_only=False)
        -> {'solutions': [Solution (SCHEMA section 2)], 'certificates': [...], 'incomplete': [...], 'log': [...]}

For every pole order p at which the equation E(w0..wK) = 0 admits a pole (the integer balances) and for every
kind, the module writes the complete form of a function of that kind with the prescribed poles, substitutes it
into the equation, and solves the resulting polynomial system for the constants of the form:

  rational          w = b_p z**-p + ... + b_1 z**-1 + b_0 (+ q_1 z + ... + q_m z**m if `ends` allows a polynomial part)
  simply periodic   w = b_0 + b_1 tau + ... + b_p tau**p,   tau = (nu/2) coth(nu z/2),  tau' = kappa - tau**2,
                    kappa = nu**2/4 != 0;  this is every function rational in s = exp(nu z) with one pole of
                    order <= p in a period strip and finite limits at both ends (tau is even in nu, so every
                    function occurs once).  With `ends` (see _growth_options: the output of
                    mero.ends.ansatz_terms or end_exponents, or {'exponents': [{'lambda': ...}]}), the forms
                    w = sum_j b_j T**j + sum_m q_m s**m,  T = nu/(s - 1),  with the listed exponents m and nu
                    given (nu = lambda/m) or unknown.
  elliptic          w = q0 + b_2 wp + b_3 wp' + ... + b_p wp^(p-2)   (no residue),  g2**3 != 27 g3**2.

Two poles in a period (`max_poles=2`): the same with a second pole at tau = t (simply periodic), at z = a
(rational), at a point with wp = A, wp' = B (elliptic; residues r and -r at the two poles; g3 is eliminated by
B**2 = 4A**3 - g2 A - g3).  Cases that differ by the exchange of two poles of the same order (a translation) are
listed once, and cases with the same Laurent series at both poles (then the distance of the poles is a period)
are left to the one-pole forms; the certificate keeps all cases.

The pole is put at z = 0; the equation is autonomous, so z - z0 may be written for z.  The principal parts are
unknowns of the system (b_p != 0), so every Laurent series of the equation with a pole of order p - whatever
its leading coefficient and its free coefficients - is covered by one system, and the answer does not depend
on the Laurent module; only the pole orders are read from `local` (SCHEMA section 1) or computed here
(`pole_orders`).  The coefficients of the dominant part and of the highest derivative are assumed not to
vanish (recorded in `assumed_nonzero`).

The system is solved by elimination with case distinctions (`tri_solve`): products are split, an unknown that
occurs linearly is solved for (with the two cases coefficient != 0 / coefficient = 0), two equations in one
unknown are reduced by pseudo-division, an unknown left in one equation is "any root of" that equation.  Every
step is an equivalence; the certificate records the system, the steps (`trace`) and the cases that came out
(`solution_set`).  Parameters of the equation are kept as symbols; equations that contain only parameters
become the `conditions` of a family.  For numeric parameters a second, independent argument is attached to
the one-pole certificates: the number of distinct solutions from Groebner bases (`groebner_count`).  If the
elimination does not finish and mero.heavy.algsys is available with an external tool, that module is tried
(`_heavy_leaves`); otherwise the form is listed in `incomplete` with its system and the unfinished cases.

Every solution is verified by exact substitution (mero.verify.verify_solution) before it is returned; its
certificate says 'pass', 'fail' or 'not-run' (expressions too large, or no time left).

Only SymPy is used; time limits are checked with time.monotonic() between steps (a single SymPy call cannot be
interrupted: MAX_* below bound the size of what is factored, simplified or verified).
"""
import itertools
import time

import sympy as sp

from .special import wp, wpp, zeta_w

__all__ = ["find_w_solutions", "tri_solve", "pole_orders", "system_for", "groebner_count"]

z = sp.Symbol("z")
z0 = sp.Symbol("z0")
ENGINE_TAG = "live:wsolve"
MAX_FACTOR_TERMS = 400       # multivariate polynomials with more terms, or of total degree above
MAX_FACTOR_DEGREE = 24       # MAX_FACTOR_DEGREE, are not factored (kept as one factor)
MAX_STATE_TERMS = 3000       # a case whose equations have more terms in all (or one equation with more than
MAX_EQ_TERMS = 700           # MAX_EQ_TERMS terms) is not continued: it is returned unfinished
MAX_SUBST_COST = 300000      # bound on (terms of an equation) * (terms of the value)**degree in a substitution
MAX_VALUE_OPS = 400          # larger values of constants are not simplified / substituted into each other
MAX_VERIFY_CHARS = 2500      # solutions whose constants are longer in all are not verified inside the solver


# =============================================================================================== helpers
def _eq_terms(eq):
    """{exponent tuple: coefficient} of E, from eq.terms (CORE / bootstrap) or from eq.E"""
    terms = getattr(eq, "terms", None)
    if terms:
        return dict((tuple(int(e) for e in m), sp.sympify(c)) for m, c in terms.items())
    E = getattr(eq, "E", None)
    if E is None:
        E = eq.w[eq.K] - eq.rhs
    poly = sp.Poly(sp.expand(E), *eq.w)
    return dict((tuple(int(e) for e in m), c) for m, c in poly.terms())


def _weight(mon, p):
    return sum(e * (p + j) for j, e in enumerate(mon))


def pole_orders(eq, local=None):
    """the positive integers p at which at least two monomials of E have the largest weight (the pole orders
    that a balance can have).  If `local` (SCHEMA: local_analysis) is given, its balances are used."""
    if local:
        try:
            ps = sorted(set(int(sp.sympify(b["p"])) for b in local.get("balances", [])
                            if sp.sympify(b["p"]).is_integer))
            return ps
        except Exception:
            pass
    terms = _eq_terms(eq)
    mons = list(terms)
    cand = set()
    for m1, m2 in itertools.combinations(mons, 2):
        d1, d2 = sum(m1), sum(m2)
        if d1 == d2:
            continue
        j1 = sum(j * e for j, e in enumerate(m1))
        j2 = sum(j * e for j, e in enumerate(m2))
        p = sp.Rational(j2 - j1, d1 - d2)
        if p.is_integer and p > 0:
            cand.add(int(p))
    out = []
    for p in sorted(cand):
        W = max(_weight(m, p) for m in mons)
        if sum(1 for m in mons if _weight(m, p) == W) >= 2:
            out.append(p)
    return out


def _has_algebraic(exprs):
    for e in exprs:
        e = sp.sympify(e)
        for a in e.atoms(sp.Pow):
            if a.exp.is_Rational and not a.exp.is_Integer and a.base.is_number:
                return True
        if e.has(sp.I) or e.atoms(sp.AlgebraicNumber) or e.has(sp.CRootOf):
            return True
    return False


def _numer(expr):
    expr = sp.sympify(expr)
    if expr.is_polynomial():
        return sp.expand(expr)
    return sp.expand(sp.fraction(sp.together(expr))[0])


_FACTOR_CACHE = {}


def _total_degree(expr):
    try:
        return sp.Poly(expr).total_degree()
    except Exception:
        return 10 ** 6


def _factors(expr, ext=False):
    """the distinct irreducible non-constant factors of the numerator of expr;  None if expr = 0."""
    key = (expr, ext)
    if key in _FACTOR_CACHE:
        got = _FACTOR_CACHE[key]
        return None if got is None else list(got)
    res = _factors_uncached(expr, ext)
    if len(_FACTOR_CACHE) > 20000:
        _FACTOR_CACHE.clear()
    _FACTOR_CACHE[key] = None if res is None else tuple(res)
    return res


def _factors_uncached(expr, ext=False):
    expr = _numer(expr)
    if expr == 0:
        return None
    if expr.is_number:
        return []
    nterms, nsym = len(sp.Add.make_args(expr)), len(expr.free_symbols)
    if nsym >= 2 and (nterms > MAX_FACTOR_TERMS or (nterms > 40 and _total_degree(expr) > MAX_FACTOR_DEGREE)):
        # too large to factor within a time budget (SymPy calls cannot be interrupted): kept as one factor
        return [expr]
    try:
        _, fl = sp.factor_list(expr, extension=True) if ext else sp.factor_list(expr)
    except Exception:
        return [expr]
    out = []
    for f, _m in fl:
        f = sp.expand(f)
        if f.is_number:
            continue
        out.append(f)
    return out


def _in(f, lst):
    return any(f == g or sp.expand(f + g) == 0 for g in lst)


# =============================================================================================== solver
class _State(object):
    __slots__ = ("eqs", "assign", "rels", "nz", "notes", "hold")

    def __init__(self, eqs, assign=(), rels=(), nz=(), notes=(), hold=()):
        self.eqs = list(eqs)
        self.assign = list(assign)
        self.rels = list(rels)
        self.nz = list(nz)
        self.notes = list(notes)
        self.hold = set(hold)


def _known_nonzero(A, nz, ext):
    if A.is_number:
        return A != 0
    fs = _factors(A, ext)
    return fs is not None and all(_in(f, nz) for f in fs)


def _subst(e, u, A, B):
    """numerator of e with u = -B/A  (times a power of A)"""
    if u not in e.free_symbols:
        return e
    pe = sp.Poly(e, u)
    cs = pe.all_coeffs()
    d = len(cs) - 1
    return sp.expand(sum(c * (-B) ** (d - i) * A ** i for i, c in enumerate(cs)))


class _TooLarge(Exception):
    """a substitution would produce polynomials beyond the size limits: the case is returned unfinished"""


def _apply_subst(st, eqs, u, A, B, ext):
    big = max(len(sp.Add.make_args(A)), len(sp.Add.make_args(B)))
    if big > 3:
        for e in list(eqs) + list(st.nz) + [f for _, f in st.rels]:
            if u in e.free_symbols and len(sp.Add.make_args(e)) * big ** int(sp.degree(e, u)) > MAX_SUBST_COST:
                raise _TooLarge()
    new_nz = []
    for n in st.nz:
        fs = _factors(_subst(n, u, A, B), ext)
        if fs is None:
            return None
        for f in fs:
            if not _in(f, new_nz):
                new_nz.append(f)
    rels = []
    for v, f in st.rels:
        g = _subst(f, u, A, B)
        if g == 0 or v not in g.free_symbols:
            return None
        rels.append((v, g))
    return _State([_subst(e, u, A, B) for e in eqs], st.assign + [(u, sp.cancel(-B / A))], rels, new_nz,
                  st.notes, st.hold)


def _short(e, n=160):
    t = str(e)
    return t if len(t) <= n else t[:n] + " ...[%d characters]" % len(t)


def _step(st, unknowns, params, ext, tr=None):
    """one step of the elimination: ('leaf', st) or ('branch', [states]);  tr: list that receives one line
    describing the step"""
    if tr is None:
        tr = []
    U, P = set(unknowns), set(params)
    # cheap pass: only the smallest equations are factored; a product is split, an unknown that occurs
    # linearly with a non-vanishing coefficient is solved for.  (The other equations are not touched.)
    raw = []
    for e in st.eqs:
        e = _numer(e)
        if e == 0:
            continue
        if e.is_number:
            tr.append("contradiction: %s = 0" % e)
            return "branch", []
        if not any(e == x for x in raw):
            raw.append(e)
    if not raw:
        st.eqs = []
        tr.append("case finished: no equation left")
        return "leaf", st
    raw.sort(key=lambda e: len(sp.Add.make_args(e)))
    for e in raw[:3]:
        fs = _factors(e, ext)
        fs = [f for f in fs if not _in(f, st.nz)]
        if not fs:
            tr.append("contradiction: %s = 0, a product of non-vanishing factors" % _short(sp.factor(e)))
            return "branch", []
        rest = [x for x in raw if x is not e]
        if len(fs) > 1:
            tr.append("product: one case for each factor of " + " * ".join("(%s)" % _short(f, 80) for f in fs))
            return "branch", [_State(rest + [f], st.assign, st.rels,
                                     st.nz + [g for g in fs[:i] if not _in(g, st.nz)], st.notes, st.hold)
                              for i, f in enumerate(fs)]
        g = fs[0]
        syms = g.free_symbols
        ponly = not (syms & U)
        best = None
        for u in sorted((syms & P) if ponly else (syms & U), key=lambda sy: sy.name):
            if sp.degree(g, u) != 1:
                continue
            A = g.coeff(u, 1)
            if A.is_number or _known_nonzero(A, st.nz, ext):
                B = sp.expand(g - A * u)
                score = (0 if A.is_number else 1, sp.count_ops(A), sp.count_ops(B))
                if best is None or score < best[0]:
                    best = (score, u, A, B)
        if best is not None:
            _, u, A, B = best
            new = _apply_subst(st, rest, u, A, B, ext)
            tr.append("solve %s = 0 for %s (coefficient %s != 0): %s = %s%s" % (
                _short(g), u, _short(A, 60), u, _short(sp.cancel(-B / A)),
                "" if new is not None else "; this makes a non-vanishing expression zero: no solution"))
            return "branch", ([new] if new is not None else [])
    eqs, seen = [], set()
    for e in st.eqs:
        fs = _factors(e, ext)
        if fs is None:
            continue
        fs = [f for f in fs if not _in(f, st.nz)]
        if not fs:
            tr.append("contradiction: %s = 0, a product of non-vanishing factors" % _short(sp.factor(e)))
            return "branch", []
        key = frozenset(fs)
        if key in seen:
            continue
        seen.add(key)
        eqs.append(fs)
    if not eqs:
        st.eqs = []
        tr.append("case finished: no equation left")
        return "leaf", st
    # a product: one case per factor (made disjoint)
    multi = [fs for fs in eqs if len(fs) > 1]
    if multi:
        fs = min(multi, key=len)
        others = [sp.Mul(*g) for g in eqs if g is not fs]
        tr.append("product: one case for each factor of " + " * ".join("(%s)" % _short(f, 80) for f in fs))
        out = []
        for i, f in enumerate(fs):
            out.append(_State(others + [f], st.assign, st.rels, st.nz + [g for g in fs[:i] if not _in(g, st.nz)],
                              st.notes, st.hold))
        return "branch", out
    E = [fs[0] for fs in eqs]
    # an unknown (or, in an equation without unknowns, a parameter) that occurs linearly
    best = None
    for e in E:
        syms = e.free_symbols
        ponly = not (syms & U)
        cand = (syms & P) if ponly else (syms & U)
        for u in sorted(cand, key=lambda s: s.name):
            if sp.degree(e, u) != 1:
                continue
            A = e.coeff(u, 1)
            B = sp.expand(e - A * u)
            if A.is_number:
                cls = 0
            elif _known_nonzero(A, st.nz, ext):
                cls = 1
            elif not (A.free_symbols & U):
                cls = 2
            else:
                cls = 3
            score = (cls, 0 if ponly else 1, sp.count_ops(A), sp.count_ops(B))
            if best is None or score < best[0]:
                best = (score, e, u, A, B)
    if best is not None:
        (cls, _, _, _), e, u, A, B = best
        rest = [x for x in E if x is not e]
        if cls <= 1:
            new = _apply_subst(st, rest, u, A, B, ext)
            tr.append("solve %s = 0 for %s (coefficient %s != 0): %s = %s%s" % (
                _short(e), u, _short(A, 60), u, _short(sp.cancel(-B / A)),
                "" if new is not None else "; this makes a non-vanishing expression zero: no solution"))
            return "branch", ([new] if new is not None else [])
        tr.append("two cases for the equation %s, linear in %s: coefficient %s != 0, or the coefficient and %s "
                  "both zero" % (_short(e), u, _short(A, 80), _short(B, 80)))
        fa = [f for f in _factors(A, ext) if not _in(f, st.nz)]
        s1 = _State(E, st.assign, st.rels, st.nz + fa, st.notes, st.hold)
        s2 = _State(rest + [A, B], st.assign, st.rels, st.nz, st.notes, st.hold)
        return "branch", [s1, s2]
    # no linear occurrence: pseudo-division in the variable of smallest degree
    present = set()
    for e in E:
        present |= e.free_symbols
    cand = ((present & U) - st.hold) or ((present & P) - st.hold) or (present & U) or (present & P)
    choice = None
    for u in sorted(cand, key=lambda s: s.name):
        degs = sorted(sp.degree(e, u) for e in E if u in e.free_symbols)
        key = (degs[0], len(degs))
        if choice is None or key < choice[0]:
            choice = (key, u)
    u = choice[1]
    F = sorted((e for e in E if u in e.free_symbols), key=lambda e: (sp.degree(e, u), sp.count_ops(e)))
    f = F[0]
    d = sp.degree(f, u)
    lc = sp.Poly(f, u).LC()
    rest = [x for x in E if x is not f]
    if not _known_nonzero(lc, st.nz, ext):
        tr.append("two cases for %s as a polynomial in %s: leading coefficient %s != 0, or = 0" % (
            _short(f), u, _short(lc, 80)))
        fa = [g for g in _factors(lc, ext) if not _in(g, st.nz)]
        s1 = _State(E, st.assign, st.rels, st.nz + fa, st.notes, st.hold)
        s2 = _State(rest + [lc, sp.expand(f - lc * u ** d)], st.assign, st.rels, st.nz, st.notes, st.hold)
        return "branch", [s1, s2]
    if len(F) == 1:
        # u is any root of f (leading coefficient not zero) at which the non-vanishing conditions hold; these
        # conditions stay in the case as constraints on the root
        notes = list(st.notes)
        for n in st.nz:
            if u in n.free_symbols and len(sp.Add.make_args(f)) * len(sp.Add.make_args(n)) <= 400 \
                    and sp.degree(f, u) * sp.degree(n, u) <= 24:
                R = sp.resultant(f, n, u)
                fr = _factors(R, ext)
                if fr is None:
                    tr.append("contradiction: every root of %s = 0 in %s makes %s zero" % (_short(f), u, n))
                    return "branch", []
                fr = [g for g in fr if not _in(g, st.nz)]
                if fr:
                    notes.append("where %s = 0, a root of %s = 0 (in %s) is excluded by %s != 0" % (
                        sp.Mul(*fr), f, u, n))
        tr.append("%s occurs in one equation only: %s is any root of %s = 0" % (u, u, _short(f)))
        return "branch", [_State(rest, st.assign, st.rels + [(u, f)], st.nz, notes, st.hold)]
    g = F[1]
    r = sp.expand(sp.prem(g, f, u))
    tr.append("pseudo-division in %s: %s is replaced by its pseudo-remainder modulo %s, which is %s" % (
        u, _short(g, 80), _short(f, 80), _short(sp.factor(r))))
    return "branch", [_State([f] + [x for x in rest if x is not g] + [r], st.assign, st.rels, st.nz, st.notes,
                             st.hold)]


def _reduce_mod_relations(expr, rels):
    """Pseudo-remainder of expr modulo the relations.  The relations form a triangular set in the order in which
    they were recorded: the polynomial of an earlier relation may contain the symbols of the later ones, never
    the other way round.  So one pass in that order gives a remainder of degree < deg f_i in every v_i; it is
    zero if and only if expr is in the ideal of the relations saturated by their leading coefficients."""
    r = sp.expand(expr)
    for v, f in rels:
        if r == 0:
            break
        if v in r.free_symbols and v in f.free_symbols and sp.degree(r, v) >= sp.degree(f, v):
            if len(sp.Add.make_args(r)) * len(sp.Add.make_args(f)) > 60000:
                return None                                  # too large: not decided
            r = sp.expand(sp.prem(r, f, v))
    return r


def _excluded_everywhere(nonzero, rels):
    """True if the product N of the non-vanishing conditions is zero at every root of the relations: then the
    case is empty.  Exact test: the relations are a triangular set, zero-dimensional over the field of the
    other symbols, with D = product of their degrees solutions counted with multiplicity; N vanishes at all of
    them if and only if N**D is in the (saturated) ideal, i.e. the remainder of N**k is zero for some k <= D
    (the roots may be multiple: the remainder of N itself need not vanish)."""
    rv = set(v for v, _ in rels)
    tests = [n for n in nonzero if n.free_symbols & rv]
    if not tests:
        return False
    try:
        N = sp.expand(sp.Mul(*tests))
        if len(sp.Add.make_args(N)) > 3000:
            return False
        D = 1
        for v, f in rels:
            D *= max(1, int(sp.degree(f, v)))
        r = _reduce_mod_relations(N, rels)
        if r is None:
            return False
        if r == 0:
            return True
        pw = r
        for _k in range(2, min(D, 12) + 1):
            if len(sp.Add.make_args(pw)) * len(sp.Add.make_args(r)) > 40000:
                return False
            pw = _reduce_mod_relations(sp.expand(pw * r), rels)
            if pw is None:
                return False
            if pw == 0:
                return True
    except Exception:
        return False
    return False


def _finalize(st, unknowns, params):
    if st.rels and _excluded_everywhere(st.nz, st.rels):
        return None
    vals, direct = {}, {}
    for u, ex in reversed(st.assign):
        v = ex.xreplace(vals) if vals else ex
        if sp.count_ops(v) <= MAX_VALUE_OPS:
            v = sp.cancel(v)
            vals[u] = sp.factor(v) if sp.count_ops(v) < 1500 else v
        else:
            # too large to simplify: the value stays as it was found, in terms of the other constants
            direct[u] = ex
    relsyms = [v for v, _ in st.rels]
    rels = []
    for v, f in st.rels:
        g = f.xreplace(vals)
        if sp.count_ops(g) <= MAX_VALUE_OPS:
            f = _numer(g)
        # factors free of v divide the leading coefficient, which is not zero in this case: dropped
        fs = [g for g in (_factors(f) or [f]) if v in g.free_symbols]
        rels.append((v, sp.Mul(*fs) if fs else f))
    allv = dict(vals)
    allv.update(direct)
    notes = list(st.notes)
    if direct:
        notes.append("the values of %s are given in terms of other constants (too large to substitute)"
                     % ", ".join(str(u) for u in direct))
    return {"values": dict((u, allv[u]) for u in unknowns if u in allv),
            "param_values": dict((q, allv[q]) for q in params if q in allv),
            "relations": rels,
            "free": [u for u in unknowns if u not in allv and u not in relsyms],
            "nonzero": [n for n in st.nz],
            "notes": notes, "nested": bool(direct)}


def tri_solve(eqs, unknowns, params=(), nonzero=(), budget_s=30.0, ext=None):
    """All solutions of  eqs = 0, nonzero != 0  in the unknowns, with case distinctions on the parameters.

    Returns (leaves, pending, stats).  A leaf is a dict
        values        {unknown: rational expression in the free unknowns, relation unknowns and parameters}
        param_values  {parameter: expression in the other parameters}      (conditions of the case)
        relations     [(symbol, polynomial)]: the symbol is any root of the polynomial (its leading
                      coefficient is among `nonzero`)
        free          unknowns that remain arbitrary
        nonzero       polynomials that do not vanish in this case
        notes         what was not analysed inside this case (empty if nothing)
    The union of the leaves is the solution set, provided `pending` (states not processed within the budget:
    dicts with the remaining equations) is empty.
    """
    t_end = time.monotonic() + budget_s
    _FACTOR_CACHE.clear()
    eqs = [_numer(e) for e in eqs]
    if ext is None:
        ext = _has_algebraic(eqs)
    nz0 = []
    for n in nonzero:
        for f in (_factors(n, ext) or []):
            if not _in(f, nz0):
                nz0.append(f)
    stack = [(_State(eqs, nz=nz0), "1")]
    leaves, pending, steps, trace, too_large = [], [], 0, [], []
    while stack:
        if time.monotonic() > t_end:
            pending = [st for st, _ in stack]
            break
        st, label = stack.pop()
        sizes = [len(sp.Add.make_args(e)) for e in st.eqs] or [0]
        size = sum(sizes)
        if size > MAX_STATE_TERMS or max(sizes) > MAX_EQ_TERMS:
            too_large.append(st)
            trace.append("[%s] not continued: the equations of this case have %d terms (largest: %d)"
                         % (label, size, max(sizes)))
            continue
        steps += 1
        tr = []
        try:
            kind, res = _step(st, unknowns, params, ext, tr)
        except _TooLarge:
            too_large.append(st)
            trace.append("[%s] not continued: the next substitution would exceed the size limit" % label)
            continue
        if kind == "leaf":
            lf = _finalize(res, unknowns, params)
            if lf is None:
                trace.append("[%s] %s; but a non-vanishing condition is zero at every root of the relations: "
                             "no solution in this case" % (label, "; ".join(tr)))
                continue
            leaves.append(lf)
            leaves[-1]["case"] = label
            trace.append("[%s] %s -> case %d of the solution set" % (label, "; ".join(tr), len(leaves)))
        else:
            if len(res) == 1:
                labels = [label]
            else:
                labels = ["%s.%d" % (label, i + 1) for i in range(len(res))]
            trace.append("[%s] %s%s" % (label, "; ".join(tr), "" if len(res) <= 1 else
                                        " -> cases " + ", ".join(labels)))
            stack.extend(reversed(list(zip(res, labels))))
    pend = []
    for st in pending + too_large:
        pend.append({"equations": [str(e) for e in st.eqs if e != 0],
                     "solved_so_far": dict((str(u), str(v)) for u, v in st.assign),
                     "relations": [str(f) for _, f in st.rels],
                     "nonzero": [str(n) for n in st.nz]})
    return leaves, pend, {"steps": steps, "ext": ext, "trace": trace}


def _standard_monomials(exprs, gens):
    """number of monomials outside the leading-term ideal of a grevlex Groebner basis; None if infinite"""
    lms = [sp.Poly(g, *gens).monoms(order="grevlex")[0] for g in exprs]
    bound = []
    for i in range(len(gens)):
        pure = [m[i] for m in lms if all(m[j] == 0 for j in range(len(gens)) if j != i)]
        if not pure:
            return None
        bound.append(min(pure))
    count = 0
    for mono in itertools.product(*[range(b) for b in bound]):
        if not any(all(mono[i] >= m[i] for i in range(len(gens))) for m in lms):
            count += 1
    return count


def groebner_count(equations, unknowns, nonzero=()):
    """An independent count for a system without parameters, from Groebner bases computed by SymPy.

    I = ideal of the equations and of y*prod(nonzero) - 1.  Returns
      {'dimension': -1 (no solution) | 0 | 'positive', 'count': D, 'distinct': N, 'basis_size': n}
    D = dimension of the quotient ring = number of solutions with multiplicity; N = number of distinct
    solutions = the same for I + (squarefree parts of the univariate polynomials of I in each variable),
    which is the radical of I (Seidenberg).  No time limit can be imposed on these computations: use for
    small systems."""
    y = sp.Dummy("y")
    eqs = [_numer(e) for e in equations]
    gens = list(unknowns)
    if nonzero:
        eqs.append(sp.expand(y * sp.Mul(*[sp.sympify(n) for n in nonzero]) - 1))
        gens = gens + [y]
    kw = {"extension": True} if _has_algebraic(eqs) else {}
    G = sp.groebner(eqs, *gens, order="grevlex", **kw)
    exprs = list(G.exprs)
    if len(exprs) == 1 and exprs[0].is_number:
        return {"dimension": -1, "count": 0, "distinct": 0, "basis_size": 1}
    D = _standard_monomials(exprs, gens)
    if D is None:
        return {"dimension": "positive", "count": None, "distinct": None, "basis_size": len(exprs)}
    extra = []
    for v in gens:
        order = [g for g in gens if g != v] + [v]
        L = sp.groebner(exprs, *order, order="lex", **kw)
        uni = [g for g in L.exprs if g.free_symbols <= {v}]
        if not uni:                                     # cannot happen for a zero-dimensional ideal
            return {"dimension": 0, "count": D, "distinct": None, "basis_size": len(exprs)}
        pv = sp.Poly(uni[0], v, **kw)
        extra.append(sp.quo(pv, sp.gcd(pv, pv.diff(v))).as_expr())
    R = sp.groebner(exprs + extra, *gens, order="grevlex", **kw)
    return {"dimension": 0, "count": D, "distinct": _standard_monomials(list(R.exprs), gens),
            "basis_size": len(exprs)}


# =============================================================================================== systems
def _poly(expr, x):
    return sp.Poly(expr, x)


def _system_rational_in(terms, K, x, delta, N, poles):
    """Coefficients (in x) of the numerator of E[w] for  w = N(x)/prod (x - x_i)**p_i  and d/dz = delta(x) d/dx."""
    Ls = [x - xi for xi, _ in poles]
    Lprod = sp.Mul(*Ls) if Ls else sp.Integer(1)
    jets = [_poly(N, x)]
    dl = _poly(delta, x)
    Lp = _poly(Lprod, x)
    for j in range(K):
        if poles:
            S = sp.Integer(0)
            for i, (xi, pi) in enumerate(poles):
                S += (pi + j) * sp.Mul(*[L for l, L in enumerate(Ls) if l != i])
            new = dl * (jets[j].diff(x) * Lp - jets[j] * _poly(S, x))
        else:
            new = dl * jets[j].diff(x)
        jets.append(new)
    wmax = [max(_weight(m, pi) for m in terms) for _, pi in poles]
    total = _poly(0, x)
    for m, co in terms.items():
        t = _poly(co, x)
        for j, e in enumerate(m):
            if e:
                t = t * jets[j] ** e
        for i, (xi, pi) in enumerate(poles):
            k = wmax[i] - _weight(m, pi)
            if k:
                t = t * _poly(Ls[i], x) ** k
        total = total + t
    return [c for c in total.all_coeffs() if c != 0]


class _Ell(object):
    """a + b*Y with a, b rational in X with denominator (X - A)**k;  Y**2 = 4X**3 - g2 X - g3."""

    def __init__(self, X, g2, g3, A=None):
        self.X, self.g2, self.g3, self.A = X, g2, g3, A
        self.C = sp.Poly(4 * X ** 3 - g2 * X - g3, X)
        self.dY = sp.Poly(6 * X ** 2 - g2 / 2, X)
        self.L = sp.Poly(X - A, X) if A is not None else None

    def el(self, a, b=0, k=0):
        return (sp.Poly(a, self.X), sp.Poly(b, self.X), k)

    def mul(self, u, v):
        a1, b1, k1 = u
        a2, b2, k2 = v
        return (a1 * a2 + b1 * b2 * self.C, a1 * b2 + a2 * b1, k1 + k2)

    def add(self, u, v):
        a1, b1, k1 = u
        a2, b2, k2 = v
        if k1 < k2:
            f = self.L ** (k2 - k1)
            return (a1 * f + a2, b1 * f + b2, k2)
        if k2 < k1:
            f = self.L ** (k1 - k2)
            return (a1 + a2 * f, b1 + b2 * f, k1)
        return (a1 + a2, b1 + b2, k1)

    def scale(self, c, u):
        c = sp.Poly(c, self.X)
        return (u[0] * c, u[1] * c, u[2])

    def D(self, u):
        a, b, k = u
        # (a + bY)' = a' Y + b' Y**2 + b Y'  (primes = d/dX), then the denominator
        na = b.diff(self.X) * self.C + b * self.dY
        nb = a.diff(self.X)
        if k == 0:
            return (na, nb, 0)
        # d/dz [n/L**k] = (n' L - k n X')/L**(k+1),  X' = Y:   -k (a + bY) Y = -k b C - k a Y
        return (na * self.L - k * b * self.C, nb * self.L - k * a, k + 1)

    def power(self, u, e):
        r = self.el(1)
        for _ in range(e):
            r = self.mul(r, u)
        return r

    def substitute(self, terms, K, w):
        jets = [w]
        for _ in range(K):
            jets.append(self.D(jets[-1]))
        total = self.el(0)
        for m, co in terms.items():
            t = self.el(co)
            for j, e in enumerate(m):
                if e:
                    t = self.mul(t, self.power(jets[j], e))
            total = self.add(total, t)
        return [c for c in total[0].all_coeffs() + total[1].all_coeffs() if c != 0]


def _names(eq, wanted):
    """symbols for the constants of a form, renamed if they clash with a parameter of the equation"""
    used = set(str(s) for s in getattr(eq, "params", []))
    out = []
    for n in wanted:
        while n in used:
            n = n + "_"
        used.add(n)
        out.append(sp.Symbol(n))
    return out


def _growth_options(ends, loc):
    """Read the `ends` argument.  Returns (options, polynomial degree, text).

    An option is (nu, exps, label): the simply periodic form gets the terms q_m s**m, m in exps (nonzero
    integers; m > 0 grows at s -> oo, m < 0 at s -> 0), with nu given (an expression) or None (unknown).
    Accepted forms of `ends`:
      * the output of mero.ends.ansatz_terms(eq): key 'options' (each: 'nu' = expression or 'free',
        'exponents' = list of m);
      * the output of mero.ends.end_exponents(eq), or a dict {'exponents': [{'lambda': expr, ...}], ...}:
        a growth term C exp(lambda z), so nu = lambda/m with m in 'm_values' of the entry (or 1..max_multiple,
        default 2) and exps = 1..m;  'rational' (ENDS) or 'rational_degree' / 'm_max' give the degree of the
        polynomial part of a rational solution;
      * a list of exponents lambda.
    """
    if ends is None:
        return [], 0, "no `ends` data"
    opts, deg, seen = [], 0, set()

    def S(x):
        return sp.sympify(x, locals=loc) if isinstance(x, str) else sp.sympify(x)

    def add(nu, exps, label):
        exps = tuple(sorted(int(m) for m in exps if int(m) != 0))
        if not exps:
            return
        if nu is not None:
            nu = sp.factor(S(nu))
            if all(m < 0 for m in exps):            # s -> 1/s: the same functions with -nu
                nu, exps = -nu, tuple(sorted(-m for m in exps))
        key = (str(nu), exps)
        if key not in seen:
            seen.add(key)
            opts.append((nu, exps, label or "search"))

    if isinstance(ends, dict) and "options" in ends:
        for o in ends["options"]:
            ex = [int(m) for m in (o.get("exponents") or [])]
            if not ex:
                continue
            nu = o.get("nu")
            if nu in (None, "free"):
                hi = max([abs(m) for m in ex])
                for mp in range(1, hi + 1):
                    for mm in range(0, mp + 1):
                        add(None, list(range(-mm, 0)) + list(range(1, mp + 1)), "search")
            else:
                add(nu, ex, o.get("label"))
    else:
        items = ends.get("exponents", []) if isinstance(ends, dict) else list(ends)
        mm = int((ends.get("max_multiple") if isinstance(ends, dict) else None) or 2)
        if isinstance(ends, dict) and ends.get("growth_possible") is False:
            items = []
        for item in items or []:
            if isinstance(item, dict):
                if item.get("kind", "growth") != "growth" or item.get("lambda") is None:
                    continue
                lam, mv = item["lambda"], item.get("m_values")
            else:
                lam, mv = item, None
            for m in (mv or range(1, mm + 1)):
                add(S(lam) / int(m), range(1, int(m) + 1), "agent-proof" if mv else "search")
    if isinstance(ends, dict):
        for key in ("rational_degree", "polynomial_degree", "poly_degree", "m_max"):
            if ends.get(key) is not None:
                deg = int(ends[key])
                break
        else:
            try:
                adm = ends["rational"]["growth"]["admissible"]
                deg = max([int(e["m"]) for e in adm if int(e["m"]) >= 1] + [0])
            except Exception:
                deg = 0
    text = "growth forms from `ends`: %s; polynomial part of degree <= %d" % (
        ["nu = %s, s**m for m in %s" % ("unknown" if nu is None else nu, list(ex)) for nu, ex, _ in opts], deg)
    return opts, deg, text


def _system_s(terms, K, nu, N, p, r):
    """Coefficients (ascending powers of x = s - 1) of the numerator of E[w] for
    w = N(x)/(x**p (x + 1)**r),  d/dz = nu (x + 1) d/dx."""
    x = N.gen
    X1 = sp.Poly(x + 1, x)
    Xp = sp.Poly(x, x)
    nuP = sp.Poly(nu, x)
    jets = [N]
    for j in range(K):
        Nj = jets[j]
        jets.append(nuP * (Nj.diff(x) * Xp * X1 - (p + j) * Nj * X1 - r * Nj * Xp))
    W = max(_weight(m, p) for m in terms)
    dmax = max(sum(m) for m in terms)
    total = sp.Poly(0, x)
    for m, co in terms.items():
        t = sp.Poly(co, x)
        for j, e in enumerate(m):
            if e:
                t = t * jets[j] ** e
        k = W - _weight(m, p)
        if k:
            t = t * Xp ** k
        k = r * (dmax - sum(m))
        if k:
            t = t * X1 ** k
        total = total + t
    return [c for c in total.all_coeffs()[::-1] if c != 0]


def system_for(eq, kind, poles, growth=None, poly_degree=0):
    """The polynomial system of one form.

    kind: 'rational' | 'simply-periodic' | 'elliptic';  poles: tuple of pole orders (one or two);
    growth: None or (nu, m): simply periodic form with nu given and the terms q_1 s + ... + q_m s**m.
    Returns a dict: equations, unknowns, nonzero, form (text), build (a function leaf-values -> expression
    data), or {'empty': reason}.
    """
    d = _system_for(eq, kind, poles, growth, poly_degree)
    if "empty" in d:
        return d
    # the form belongs to the balance at these pole orders: the coefficients of the dominant part and of the
    # highest derivative are not zero (otherwise the equation is a different one)
    terms = _eq_terms(eq)
    K = max(len(m) for m in terms) - 1
    assume = []
    for p in set(poles):
        W = max(_weight(m, p) for m in terms)
        for m, co in terms.items():
            if (_weight(m, p) == W or m[K] > 0) and sp.sympify(co).free_symbols:
                for f in (_factors(co) or []):
                    if not _in(f, assume):
                        assume.append(f)
    d["assumed_nonzero"] = assume
    d["nonzero"] = list(d["nonzero"]) + assume
    return d


def _system_for(eq, kind, poles, growth=None, poly_degree=0):
    terms = _eq_terms(eq)
    K = max(len(m) for m in terms) - 1
    par = list(getattr(eq, "params", []))
    npoles = len(poles)
    if kind == "rational":
        p = poles[0]
        if npoles == 1:
            b = _names(eq, ["b%d" % j for j in range(p + 1)])
            q = _names(eq, ["q%d" % i for i in range(1, poly_degree + 1)])
            x = sp.Dummy("x")
            N = sum(b[j] * x ** (p - j) for j in range(p + 1)) + sum(q[i - 1] * x ** (p + i) for i in
                                                                    range(1, poly_degree + 1))
            eqs = _system_rational_in(terms, K, x, sp.Integer(1), N, [(sp.Integer(0), p)])
            expr = sum(b[j] * (z - z0) ** (-j) for j in range(p + 1)) + sum(q[i - 1] * (z - z0) ** i for i in
                                                                           range(1, poly_degree + 1))
            form = "w = " + " + ".join(["%s/z**%d" % (b[j], j) for j in range(p, 0, -1)] + [str(b[0])] +
                                       ["%s*z**%d" % (q[i - 1], i) for i in range(1, poly_degree + 1)])
            return {"equations": eqs, "unknowns": b[::-1] + q[::-1], "nonzero": [b[p]], "expr": expr,
                    "form": form, "poles": [p], "free": [z0], "defs": {}}
        p2 = poles[1]
        b = _names(eq, ["b%d" % j for j in range(p + 1)])
        c = _names(eq, ["c%d" % j for j in range(1, p2 + 1)])
        a, = _names(eq, ["a"])
        x = sp.Dummy("x")
        N = sum(b[j] * x ** (p - j) for j in range(p + 1)) * (x - a) ** p2 + \
            sum(c[j - 1] * (x - a) ** (p2 - j) for j in range(1, p2 + 1)) * x ** p
        eqs = _system_rational_in(terms, K, x, sp.Integer(1), sp.expand(N), [(sp.Integer(0), p), (a, p2)])
        expr = sum(b[j] * (z - z0) ** (-j) for j in range(p + 1)) + sum(c[j - 1] * (z - z0 - a) ** (-j)
                                                                        for j in range(1, p2 + 1))
        form = "w = b0 + sum_j b_j/z**j + sum_j c_j/(z - a)**j  (pole orders %d, %d; no polynomial part)" % (p, p2)
        return {"equations": eqs, "unknowns": b[::-1] + c[::-1] + [a], "nonzero": [b[p], c[p2 - 1], a],
                "expr": expr, "form": form, "poles": [p, p2], "free": [z0], "defs": {},
                "swap": (dict(zip(b[1:], c)), [a]) if p == p2 else None}
    if kind == "simply-periodic":
        p = poles[0]
        nu, = _names(eq, ["nu"])
        s = sp.exp(nu * (z - z0))
        if growth is not None:
            nuval, exps = growth[0], tuple(growth[1])
            b = _names(eq, ["b%d" % j for j in range(p + 1)])
            q = _names(eq, [("q%d" % m) if m > 0 else ("qm%d" % (-m)) for m in exps])
            nuv = nu if nuval is None else sp.sympify(nuval)
            r = max(0, -min(exps))
            x = sp.Dummy("x")           # x = s - 1: the coefficients of low powers of x are the conditions
            N = sum(b[j] * nuv ** j * x ** (p - j) for j in range(p + 1)) * (x + 1) ** r + \
                sum(qm * (x + 1) ** (m + r) for qm, m in zip(q, exps)) * x ** p          # at the pole
            eqs = _system_s(terms, K, nuv, sp.Poly(sp.expand(N), x), p, r)
            Tz = nu / (s - 1)
            expr = sum(b[j] * Tz ** j for j in range(p + 1)) + sum(qm * s ** m for qm, m in zip(q, exps))
            form = ("w = sum_{j<=%d} b_j T**j + sum_{m in %s} q_m s**m,  T = nu/(s - 1),  s = exp(nu z),  "
                    "nu %s" % (p, list(exps), "unknown, != 0" if nuval is None else "= %s" % nuv))
            nzl = [b[p], nuv]
            if max(exps) > 0:
                nzl.append(q[len(exps) - 1])
            if min(exps) < 0:
                nzl.append(q[0])
            return {"equations": eqs, "unknowns": b[::-1] + q[::-1] + ([nu] if nuval is None else []),
                    "nonzero": nzl, "expr": expr, "form": form, "poles": [p], "free": [z0],
                    "defs": {} if nuval is None else {nu: nuv}}
        kap, = _names(eq, ["kappa"])
        tau = sp.Dummy("tau")
        tz = nu / 2 * (s + 1) / (s - 1)
        if npoles == 1:
            b = _names(eq, ["b%d" % j for j in range(p + 1)])
            N = sum(b[j] * tau ** j for j in range(p + 1))
            eqs = _system_rational_in(terms, K, tau, kap - tau ** 2, N, [])
            expr = sum(b[j] * tz ** j for j in range(p + 1))
            form = ("w = " + " + ".join(["%s*tau**%d" % (b[j], j) for j in range(p, 0, -1)] + [str(b[0])]) +
                    ",  tau = (nu/2)*coth(nu*z/2),  tau' = kappa - tau**2,  kappa = nu**2/4")
            return {"equations": eqs, "unknowns": b[::-1] + [kap], "nonzero": [b[p], kap], "expr": expr,
                    "form": form, "poles": [p], "free": [z0], "defs": {nu: 2 * sp.sqrt(kap)}, "kappa": kap}
        p2 = poles[1]
        b = _names(eq, ["b%d" % j for j in range(p + 1)])
        c = _names(eq, ["c%d" % j for j in range(1, p2 + 1)])
        t, = _names(eq, ["t"])
        # tau2 = tau(z - a) = (t tau - kappa)/(t - tau),  t = tau(a):  a pole of order one at tau = t
        N = sum(b[j] * tau ** j for j in range(p + 1)) * (tau - t) ** p2 + \
            sum(c[j - 1] * (kap - t * tau) ** j * (tau - t) ** (p2 - j) for j in range(1, p2 + 1))
        eqs = _system_rational_in(terms, K, tau, kap - tau ** 2, sp.expand(N), [(t, p2)])
        t2 = (t * tz - kap) / (t - tz)
        expr = sum(b[j] * tz ** j for j in range(p + 1)) + sum(c[j - 1] * t2 ** j for j in range(1, p2 + 1))
        form = ("w = sum_{j<=%d} b_j tau**j + sum_{1<=j<=%d} c_j tau2**j,  tau = (nu/2)*coth(nu*z/2),  "
                "tau2 = (t*tau - kappa)/(t - tau) = tau(z - a) with t = tau(a),  kappa = nu**2/4" % (p, p2))
        return {"equations": eqs, "unknowns": b[::-1] + c[::-1] + [kap, t],
                "nonzero": [b[p], c[p2 - 1], kap, t ** 2 - kap], "expr": expr, "form": form, "poles": [p, p2],
                "free": [z0], "defs": {nu: 2 * sp.sqrt(kap)}, "kappa": kap,
                "swap": (dict(zip(b[1:], c)), [t]) if p == p2 else None}
    if kind == "elliptic":
        p = poles[0]
        g2, g3, q0 = _names(eq, ["g2", "g3", "q0"])
        X = sp.Dummy("X")
        if npoles == 1:
            if p < 2:
                return {"empty": "an elliptic function cannot have a single simple pole in a period parallelogram"}
            b = _names(eq, ["b%d" % j for j in range(2, p + 1)])
            R = _Ell(X, g2, g3)
            w = R.el(q0)
            d = R.el(X)
            for j in range(2, p + 1):
                w = R.add(w, R.scale(b[j - 2], d))
                d = R.D(d)
            eqs = R.substitute(terms, K, w)
            P = wp(z - z0, g2, g3)
            expr = q0 + sum(b[j - 2] * sp.diff(P, z, j - 2) for j in range(2, p + 1))
            form = ("w = q0 + " + " + ".join("%s*wp^(%d)" % (b[j - 2], j - 2) for j in range(2, p + 1)) +
                    "  (wp^(k): k-th derivative of wp(z; g2, g3)),  g2**3 - 27*g3**2 != 0")
            return {"equations": eqs, "unknowns": b[::-1] + [q0, g2, g3],
                    "nonzero": [b[-1], g2 ** 3 - 27 * g3 ** 2], "expr": expr, "form": form, "poles": [p],
                    "free": [z0], "defs": {}}
        p2 = poles[1]
        b = _names(eq, ["b%d" % j for j in range(2, p + 1)])
        c = _names(eq, ["c%d" % j for j in range(2, p2 + 1)])
        r, A, B = _names(eq, ["r", "A", "B"])
        g3v = 4 * A ** 3 - g2 * A - B ** 2
        R = _Ell(X, g2, g3v, A)
        w = R.el(q0)
        d = R.el(X)
        for j in range(2, p + 1):
            w = R.add(w, R.scale(b[j - 2], d))
            d = R.D(d)
        # Z = zeta(z - a) - zeta(z) + zeta(a) = (Y + B)/(2 (X - A)):  residue +1 at z = a, -1 at z = 0
        Zf = (sp.Poly(B / 2, X), sp.Poly(sp.Rational(1, 2), X), 1)
        w = R.add(w, R.scale(r, Zf))
        # wp(z - a) = -X - A + Z**2
        d = R.add(R.el(-X - A), R.mul(Zf, Zf))
        for j in range(2, p2 + 1):
            w = R.add(w, R.scale(c[j - 2], d))
            d = R.D(d)
        eqs = R.substitute(terms, K, w)
        P, Pd = wp(z - z0, g2, g3), wpp(z - z0, g2, g3)
        Zx = (Pd + B) / (2 * (P - A))
        P2 = -P - A + Zx ** 2
        expr = q0 + sum(b[j - 2] * sp.diff(P, z, j - 2) for j in range(2, p + 1)) + r * Zx + \
            sum(c[j - 2] * sp.diff(P2, z, j - 2) for j in range(2, p2 + 1))
        form = ("w = q0 + sum_j b_j wp^(j-2)(z) + r*Zeta + sum_j c_j wp^(j-2)(z - a),  "
                "Zeta = zeta(z - a) - zeta(z) + zeta(a) = (wp'(z) + B)/(2 (wp(z) - A)),  A = wp(a), B = wp'(a),  "
                "g3 = 4*A**3 - g2*A - B**2  (pole orders %d at 0, %d at a)" % (p, p2))
        nzl = [g2 ** 3 - 27 * g3v ** 2]
        nzl.append(b[-1] if p >= 2 else r)
        nzl.append(c[-1] if p2 >= 2 else r)
        return {"equations": eqs, "unknowns": b[::-1] + c[::-1] + [r, q0, g2, A, B], "nonzero": nzl,
                "expr": expr, "form": form, "poles": [p, p2], "free": [z0], "defs": {g3: g3v},
                "swap": (dict(zip(b, c)), [r, B]) if p == p2 else None}
    raise ValueError("unknown kind %r" % (kind,))


# =============================================================================================== solutions
def _tidy(e):
    """simplification with a size limit (SymPy's simplify can take minutes on large expressions)"""
    n = sp.count_ops(e)
    try:
        if n <= 150:
            return sp.simplify(e)
        if n <= MAX_VALUE_OPS:
            return sp.cancel(e)
    except Exception:
        pass
    return e


def _explicit_roots(leaf, ext, params=()):
    """Refine the relations of a case: one case per irreducible factor; a factor of degree one in its symbol
    gives the value; a quadratic with numeric coefficients gives its two roots."""
    out, work = [], [leaf]
    guard = 0
    while work:
        guard += 1
        lf = work.pop()
        done = False
        if guard < 200 and not lf.get("nested"):
            for i, (v, f) in enumerate(lf["relations"]):
                fs = [g for g in (_factors(f, ext) or [f]) if v in g.free_symbols]
                roots = None
                if len(fs) > 1:
                    for g in fs:
                        new = dict(lf)
                        new["relations"] = [(a, (g if j == i else h)) for j, (a, h) in enumerate(lf["relations"])]
                        work.append(new)
                    done = True
                    break
                g = fs[0] if fs else f
                d = sp.degree(g, v)
                if d == 1:
                    A = g.coeff(v, 1)
                    roots = [sp.cancel(-(g - A * v) / A)]
                elif d == 2 and g.free_symbols == {v}:
                    roots = list(sp.roots(sp.Poly(g, v)).keys())
                    if len(roots) != 2:
                        roots = None
                if roots is None:
                    continue
                for rt in roots:
                    sub = {v: rt}
                    new = dict(lf)
                    new["values"] = dict((k, _tidy(val.xreplace(sub))) for k, val in lf["values"].items())
                    new["param_values"] = dict((k, _tidy(val.xreplace(sub)))
                                               for k, val in lf["param_values"].items())
                    if v in params:
                        new["param_values"][v] = rt
                    else:
                        new["values"][v] = rt
                    new["relations"] = [(a, _numer(h.xreplace(sub))) for j, (a, h) in
                                        enumerate(lf["relations"]) if j != i]
                    new["nonzero"] = [n.xreplace(sub) for n in lf["nonzero"]]
                    if any(_tidy(n) == 0 for n in new["nonzero"]):
                        continue
                    work.append(new)
                done = True
                break
        if not done:
            if lf["relations"] and _excluded_everywhere(lf["nonzero"], lf["relations"]):
                continue                    # every root of this factor violates a non-vanishing condition
            out.append(_normalise_values(lf))
    return out[::-1]


def _normalise_values(lf):
    """values that are rational functions of one root symbol v (relation f(v) = 0 with rational coefficients)
    are written as polynomials in v of degree < deg f"""
    if lf.get("nested"):
        return lf
    for v, f in lf["relations"]:
        if f.free_symbols != {v}:
            continue
        try:
            pf = sp.Poly(f, v, domain="QQ")
        except Exception:
            continue
        for key in ("values", "param_values"):
            new = dict(lf[key])
            for u, val in lf[key].items():
                if sp.sympify(val).free_symbols != {v}:
                    continue
                try:
                    num, den = sp.fraction(sp.together(val))
                    pn, pd = sp.Poly(num, v, domain="QQ"), sp.Poly(den, v, domain="QQ")
                    if pd.degree() > 0:
                        pn = pn * sp.invert(pd, pf)
                    else:
                        pn = pn * sp.Poly(1 / pd.as_expr(), v, domain="QQ")
                    new[u] = pn.rem(pf).as_expr()
                except Exception:
                    pass
            lf = dict(lf)
            lf[key] = new
    return lf


def _swap_leaf(leaf, swap):
    """the same solutions after the translation that exchanges the two poles: (pairs b_j <-> c_j, sign changes)"""
    pairs, signs = swap
    perm = dict(pairs)
    perm.update(dict((v, k) for k, v in pairs.items()))
    sub = dict(perm)
    for sg in signs:
        sub[sg] = -sg
    vals = {}
    for u, v in leaf["values"].items():
        nv = v.xreplace(sub)
        vals[perm.get(u, u)] = -nv if u in signs else nv
    return {"values": vals,
            "param_values": dict((k, v.xreplace(sub)) for k, v in leaf["param_values"].items()),
            "relations": [(perm.get(v, v), f.xreplace(sub)) for v, f in leaf["relations"]],
            "free": [perm.get(u, u) for u in leaf["free"]], "nonzero": [], "notes": []}


def _is_special_case(L, M):
    """True if the values of the case L are those of the case M at particular values of M's free unknowns"""
    if L["relations"] or M["relations"]:
        if len(L["relations"]) != len(M["relations"]):
            return False
        for (v1, f1), (v2, f2) in zip(L["relations"], M["relations"]):
            if v1 != v2 or (sp.expand(f1 - f2) != 0 and sp.expand(f1 + f2) != 0):
                return False
    if set(L["free"]) - set(M["free"]):
        return False
    sigma = {}
    for f in M["free"]:
        if f not in L["free"]:
            if f not in L["values"]:
                return False
            sigma[f] = L["values"][f]
    keys = set(L["values"]) | set(M["values"])
    for u in keys:
        if u in sigma:
            continue
        if u not in L["values"] or u not in M["values"]:
            return False
        if sp.simplify(M["values"][u].xreplace(sigma) - L["values"][u]) != 0:
            return False
    if set(L["param_values"]) != set(M["param_values"]):
        return False
    for q in L["param_values"]:
        if sp.simplify(M["param_values"][q].xreplace(sigma) - L["param_values"][q]) != 0:
            return False
    return True


def _exchange_dedupe(leaves, swap):
    """Remove the cases that are translations of earlier ones (exchange of two poles of the same order) and
    the cases in which both poles carry the same Laurent series (then the distance of the poles is a period,
    and the function belongs to the one-pole forms).  Returns (kept, exchanged, same_series)."""
    pairs, signs = swap
    kept, dup, same = [], [], []

    def zero_mod(e, L):
        """e = 0 on the case L (modulo its relations)"""
        try:
            n = _numer(e)
            if n == 0:
                return True
            if not L["relations"]:
                return _tidy(e) == 0
            r_ = _reduce_mod_relations(n, L["relations"])
            return r_ is not None and r_ == 0
        except Exception:
            return False

    # of two cases that differ by the exchange of the poles, the one whose leading coefficient at the first
    # pole does not start with a minus sign is kept (a fixed choice of the representative)
    lead = list(pairs)[-1] if pairs else None

    def rank(L):
        v = L["values"].get(lead) if lead is not None else None
        try:
            return 1 if (v is not None and sp.sympify(v).could_extract_minus_sign()) else 0
        except Exception:
            return 0

    leaves = sorted(leaves, key=rank)
    for L in leaves:
        # the same Laurent series at both poles  <=>  the case is fixed by the exchange of the poles:
        # equal principal parts (b_j = c_j) and the sign-changing constants zero (second pole at a half period)
        fixed = all(sg in L["values"] and zero_mod(L["values"][sg], L) for sg in signs) and \
            all(k in L["values"] and v in L["values"] and zero_mod(L["values"][k] - L["values"][v], L)
                for k, v in pairs.items())
        if fixed:
            same.append(L)
            continue
        SL = _swap_leaf(L, swap)
        if any(_is_special_case(SL, M) for M in kept):
            dup.append(L)
        else:
            kept.append(L)
    return kept, dup, same


def _leaf_json(leaf, params=()):
    return {"values": dict((str(k), str(v)) for k, v in leaf["values"].items()),
            "conditions": ["%s == %s" % (k, v) for k, v in leaf["param_values"].items()] +
                          ["%s == 0" % f for v, f in leaf["relations"] if v in params],
            "relations": ["%s == 0" % f for v, f in leaf["relations"] if v not in params],
            "free": [str(u) for u in leaf["free"]],
            "nonzero": [str(n) for n in leaf["nonzero"]],
            "notes": list(leaf["notes"]), "case": leaf.get("case")}


def _solution_from_leaf(eq, kind, sysd, leaf, sid):
    par = set(getattr(eq, "params", []))
    vals = dict(leaf["values"])
    defs = dict(sysd.get("defs", {}))
    consts, relations = {}, []
    for u in sysd["unknowns"]:
        if u in vals:
            consts[str(u)] = str(vals[u])
        elif u in leaf["free"]:
            consts[str(u)] = "free"
    count = 1
    for v, f in leaf["relations"]:
        if v in par:
            continue
        consts[str(v)] = "any root of %s = 0" % f
        relations.append(str(f))
        count *= int(sp.degree(f, v))
    big = bool(leaf.get("nested"))
    for sym, ex in defs.items():
        val = ex.xreplace(vals)
        if "kappa" in sysd and sysd["kappa"] in ex.free_symbols:
            # tau is an even function of nu: either square root of 4*kappa may be taken
            kv = vals.get(sysd["kappa"], sysd["kappa"])
            if big or sp.count_ops(kv) > 600:
                rel = sym ** 2 - 4 * sysd["kappa"]
                consts[str(sym)] = "any root of %s = 0" % rel
                relations.append(str(rel))
                continue
            val = sp.sqrt(sp.factor(4 * kv))
            try:
                val = sp.powdenest(val, force=True)
                val = val.replace(sp.Abs, lambda x_: x_)       # either square root: the sign does not matter
                if not val.free_symbols:
                    val = sp.sqrtdenest(sp.radsimp(val))
            except Exception:
                pass
            rads = [a for a in val.atoms(sp.Pow) if a.exp.is_Rational and not a.exp.is_Integer
                    and a.base.free_symbols]
            if val.atoms(sp.Function) or (rads and (len(rads) > 1 or leaf["relations"])):
                # kept as a polynomial relation (the radical would hide relations between the constants)
                num, den = sp.fraction(sp.together(4 * kv))
                rel = sp.expand(sym ** 2 * den - num)
                consts[str(sym)] = "any root of %s = 0" % rel
                relations.append(str(rel))
                continue
        consts[str(sym)] = str(val)
    conditions = ["%s == %s" % (k, v) for k, v in leaf["param_values"].items()]
    for v, f in leaf["relations"]:
        if v in par:
            conditions.append("%s == 0" % f)
    constraints = []
    for n in leaf["nonzero"]:
        if big:
            nn = n
        else:
            nn = n.xreplace(vals)
            nn = sp.factor(_numer(nn)) if sp.count_ops(nn) <= MAX_VALUE_OPS else nn
        if nn.is_number:
            continue
        if nn.free_symbols <= par:
            conditions.append("%s != 0" % nn)
        else:
            constraints.append("%s != 0" % nn)
    free = [str(s) for s in sysd.get("free", [])] + [str(u) for u in leaf["free"]]
    expr = sysd["expr"]
    sol = {"id": sid, "kind": kind, "d": 1, "expr": str(expr), "latex": "",
           "constants": consts, "free": free, "conditions": conditions, "constraints": constraints,
           "relations": relations, "count": count,
           "poles_per_period": len(sysd["poles"]), "pole_orders": list(sysd["poles"]),
           "certificate": {"type": "substitution", "method": "symbolic", "status": "not-run", "detail": ""},
           "origin": ENGINE_TAG, "citations": []}
    if leaf["notes"]:
        sol["notes"] = list(leaf["notes"])
    size = sum(len(str(v)) for v in consts.values()) + sum(len(c) for c in conditions)
    sol["size"] = size
    if big or size > 3000:
        sol["latex"] = sp.latex(expr)
        return sol
    try:
        sol["latex"] = _solution_latex(sol, expr, vals, defs, sysd)
    except Exception:
        sol["latex"] = sp.latex(expr)
    if kind == "simply-periodic":
        try:
            _periodic_extras(sol, expr, sysd)
        except Exception:               # pragma: no cover  (display only)
            pass
    return sol


def _periodic_extras(sol, expr, sysd):
    """Display data of a simply periodic solution: `form_s` (w as a rational function of s = exp(nu (z - z0)))
    and `real` (SCHEMA: behaviour on the real axis, with an expression that is bounded there if one exists)."""
    loc = _locals_for(sol, sysd)
    sub = {}
    for name, val in sol["constants"].items():
        if val != "free" and not val.startswith("any root"):
            sub[loc.get(name, sp.Symbol(name))] = sp.sympify(val, locals=loc)
    nu = [k for k in sysd.get("defs", {}) if k.name.startswith("nu")] or [sp.Symbol("nu")]
    nu = nu[0]
    S = sp.Symbol("s")
    ws = expr.xreplace({sp.exp(nu * (z - z0)): S})
    if ws.has(sp.exp):
        return
    for _ in range(3):
        ws = ws.xreplace(sub)
    ws = sp.factor(sp.together(ws))
    nuv = sub.get(nu, nu)
    for _ in range(3):
        nuv = sp.sympify(nuv).xreplace(sub)
    sol["form_s"] = {"s": str(sp.exp(sp.sympify(nuv) * (z - z0))), "w": str(ws), "latex": sp.latex(ws)}
    if ws.free_symbols - {S} or sp.sympify(nuv).free_symbols:
        sol["real"] = {"bounded_on_real_axis": "depends", "note": "depends on the parameters and on z0"}
        return
    num, den = sp.fraction(ws)
    grows = sp.degree(num, S) > sp.degree(den, S) or sp.Poly(den, S).eval(0) == 0 if den.has(S) else \
        sp.degree(num, S) > 0
    if nuv.is_real:
        wr = sp.factor(ws.xreplace({S: -S}))                     # z0 -> z0 + I*pi/nu
        nr, dr = sp.fraction(wr)
        coeffs_real = all(c.is_real for c in sp.Poly(nr, S).all_coeffs() + (sp.Poly(dr, S).all_coeffs()
                                                                            if dr.has(S) else [dr]))
        pos = sp.Poly(dr, S).count_roots(0, None) if dr.has(S) else 0       # real roots s >= 0
        if coeffs_real and not grows and pos == 0:
            e2 = wr.xreplace({S: sp.exp(nuv * (z - z0))})
            sol["real"] = {"bounded_on_real_axis": "depends",
                           "note": "for real z0 the pole z = z0 is on the real axis; after the shift "
                                   "z0 -> z0 + I*pi/nu the solution is real and bounded on the real axis",
                           "bounded_expr": str(e2), "bounded_latex": sp.latex(e2)}
        else:
            sol["real"] = {"bounded_on_real_axis": "no" if grows else "depends",
                           "note": "grows at an end" if grows else "complex coefficients or poles on the real axis"}
    elif (sp.I * nuv).is_real:
        sol["real"] = {"bounded_on_real_axis": "depends",
                       "note": "real period 2*pi/|nu|: for real z0 the poles z0 + 2*pi*k/|nu| are on the real "
                               "axis; for non-real z0 the solution is bounded there and, in general, complex"}
    else:
        sol["real"] = {"bounded_on_real_axis": "depends", "note": "complex period"}


def _solution_latex(sol, expr, vals, defs, sysd):
    sub = {}
    for u in sysd["unknowns"]:
        if u in vals:
            sub[u] = vals[u]
    for sym in defs:
        v = sol["constants"].get(str(sym))
        if v is not None:
            try:
                sub[sym] = sp.sympify(v, locals=_locals_for(sol, sysd))
            except Exception:
                pass
    e = expr.xreplace(sub)
    if sp.count_ops(e) > 400:
        return sp.latex(expr)
    return sp.latex(e)


def _locals_for(sol, sysd):
    loc = {"wp": wp, "wpp": wpp, "zeta_w": zeta_w}
    for u in list(sysd["unknowns"]) + list(sysd.get("defs", {})) + [z, z0]:
        loc[str(u)] = u
    return loc


# =============================================================================================== accelerator
def _heavy_leaves(sysd, par, budget_s):
    """Optional accelerator: mero.heavy.algsys.solve_system (worker HEAVY; Singular / msolve), used only when
    the elimination above did not finish.  Returns (leaves or None, info).  The components are converted to
    cases only if all their formulas are explicit; every solution built from them is verified by substitution
    like the others, and the completeness of the list is the statement of that module."""
    try:
        from .heavy import algsys
        tools = algsys.available_tools()
    except Exception as err:
        return None, {"available": False, "why": repr(err)}
    if not any(t in tools for t in ("msolve", "singular")):
        return None, {"available": False, "why": "no external tool (%s)" % (tools,)}
    try:
        r = algsys.solve_system([_numer(e) for e in sysd["equations"]], list(sysd["unknowns"]), list(par),
                                budget_s=budget_s, nonvanishing=list(sysd["nonzero"]))
    except Exception as err:
        return None, {"available": True, "status": "error", "why": repr(err)}
    info = {"available": True, "tool": r.get("tool"), "status": r.get("status"),
            "components": len(r.get("components") or []), "warnings": r.get("warnings"),
            "certificate": r.get("certificate"), "elapsed_s": r.get("elapsed_s")}
    if r.get("status") != "ok":
        return None, info
    loc = dict((str(u), u) for u in list(sysd["unknowns"]) + list(par))
    parset = set(par)
    leaves = []

    def conv(c):
        vals, pvals, rels = {}, {}, []
        loc2 = dict(loc)
        root = c.get("root") or {}
        rsym = root.get("symbol")
        if rsym and rsym not in loc2:                    # an auxiliary root (a linear form of the unknowns)
            loc2[rsym] = sp.Symbol(rsym)
            rels.append((loc2[rsym], _numer(sp.sympify(root["minpoly"], locals=loc2))))
        for name, val in (c.get("unknowns") or {}).items():
            val = str(val)
            if val.startswith("RootOf("):                # RootOf(f, x): x is any root of f
                body = val[len("RootOf("):-1]
                pol, sym = body.rsplit(",", 1)
                sym = sym.strip()
                if sym not in loc2:
                    raise ValueError("RootOf in an unknown symbol")
                rels.append((loc2[sym], _numer(sp.sympify(pol, locals=loc2))))
                if sym != name:
                    raise ValueError("RootOf of another symbol")
                continue
            if "RootOf" in val:
                raise ValueError("implicit component")
            (pvals if loc2.get(name) in parset else vals)[loc2[name]] = sp.sympify(val, locals=loc2)
        for pc in c.get("param_conditions") or []:
            f = sp.sympify(pc, locals=loc2)
            fs = sorted(f.free_symbols & parset, key=str)
            if not fs:
                raise ValueError("condition without parameters")
            if not any(sp.expand(f - g) == 0 for _, g in rels):
                rels.append((fs[0], f))
        # triangular order: a relation whose polynomial contains the symbol of another one comes first
        rels.sort(key=lambda vf: -len(vf[1].free_symbols & set(v for v, _ in rels)))
        relsyms = set(v for v, _ in rels)
        # a parameter that is the root symbol of the component: its relation is the condition
        for q in list(pvals):
            if q in relsyms:
                del pvals[q]
        free = [loc2[n] for n in (c.get("free") or []) if n in loc2 and loc2[n] not in parset]
        for u in sysd["unknowns"]:
            if u not in vals and u not in free and u not in relsyms:
                raise ValueError("unknown %s without a formula" % u)
        leaves.append({"values": vals, "param_values": pvals, "relations": rels, "free": free,
                       "nonzero": [sp.sympify(n, locals=loc2) for n in (c.get("param_nonvanishing") or [])] +
                       list(sysd["nonzero"]),
                       "notes": [], "case": "heavy"})
        for sub in c.get("special") or []:
            conv(sub)

    try:
        for c in r.get("components") or []:
            conv(c)
    except Exception as err:
        info["not_converted"] = repr(err)
        info["raw_components"] = r.get("components")
        return None, info
    return leaves, info


def _second_checks(eq, sol, poles, _verify, time_limit):
    """After the symbolic check:
    (1) if it did not run (size or time), the exact check at rational points of the parameters
        (certificate method 'exact-points');
    (2) the floating-point check at random admissible values, mandatory for every solution whose check is
        modulo relations, that has two poles, or whose symbolic check did not pass: a solution that fails
        it - or for which no admissible values exist - gets the status 'fail' (and is rejected)."""
    cert = sol["certificate"]
    if cert["status"] == "not-run" and sol.get("size", 0) <= 40000:
        try:
            c2 = _verify.verify_solution_at_points(eq, sol, points=2, time_limit=time_limit)
        except Exception as err:            # pragma: no cover
            c2 = {"status": "not-run", "detail": repr(err)}
        if c2["status"] in ("pass", "fail"):
            c2["detail"] += " [symbolic check: %s]" % cert["detail"][:200]
            sol["certificate"] = cert = c2
    relational = bool(sol.get("relations")) or any("== 0" in c for c in sol.get("conditions") or []) \
        or "modulo" in cert.get("detail", "")
    if cert["status"] == "fail" or not (relational or len(poles) == 2 or cert["status"] != "pass"
                                         or cert.get("method") == "exact-points"):
        return
    if sol.get("size", 0) > 40000:
        return
    try:
        nc = _verify.numeric_check(eq, sol, digits=20, points=2)
        sol["numeric_check"] = {"ok": nc["ok"], "max_relative_residual": nc["max_relative_residual"],
                                "points": nc["points"]}
        if not nc["ok"]:
            sol["certificate"] = {"type": "substitution", "method": cert.get("method", "symbolic"),
                                  "status": "fail",
                                  "detail": "the floating-point check at random admissible values fails "
                                            "(relative residual %.3g); symbolic check said: %s"
                                            % (nc["max_relative_residual"], cert["detail"][:300])}
    except _verify.NoAdmissibleValues as err:       # an empty family
        sol["numeric_check"] = {"ok": False, "error": str(err)}
        sol["certificate"] = {"type": "substitution", "method": cert.get("method", "symbolic"), "status": "fail",
                              "detail": "%s; symbolic check said: %s" % (err, cert["detail"][:300])}
    except Exception as err:                # the check itself could not be carried out: recorded, not decisive
        sol["numeric_check"] = {"ok": None, "error": repr(err)[:300]}


def _heavy_count(sysd, budget_s):
    """the number of distinct solutions of a system without parameters from mero.heavy.algsys (components of
    the saturated ideal; time-limited); None if the accelerator is not available or did not finish"""
    try:
        from .heavy import algsys
        if not any(t in algsys.available_tools() for t in ("msolve", "singular")):
            return None
        r = algsys.solve_system([_numer(e) for e in sysd["equations"]], list(sysd["unknowns"]), [],
                                budget_s=budget_s, nonvanishing=list(sysd["nonzero"]))
    except Exception:
        return None
    if r.get("status") != "ok":
        return None
    comps = r.get("components") or []
    how = "mero.heavy.algsys.solve_system (%s): prime components of the saturated ideal" % r.get("tool")
    if not comps:
        return {"dimension": -1, "count": 0, "distinct": 0, "how": how}
    if any(c.get("dimension") not in (0, None) for c in comps):
        return {"dimension": "positive", "count": None, "distinct": None, "how": how}
    try:
        n = sum(int(c.get("degree")) for c in comps)
    except Exception:
        return None
    return {"dimension": 0, "count": n, "distinct": n, "how": how}


# =============================================================================================== driver
def _system_string(e):
    e = _numer(e)
    if len(sp.Add.make_args(e)) <= 120:
        try:
            return str(sp.factor(e))
        except Exception:
            pass
    return str(e)


def _two_pole_lists(orders):
    out = []
    for i, p1 in enumerate(orders):
        for p2 in orders[i:]:
            out.append((p2, p1) if p2 > p1 else (p1, p2))
    return out


def find_w_solutions(eq, local=None, max_poles=1, kinds=("rational", "simply-periodic", "elliptic"),
                     ends=None, budget_s=60, numeric_only=False, verify=True, cross_check="auto",
                     accelerate=True, limits=None):
    """Rational, simply periodic and elliptic solutions of E = 0 with at most `max_poles` poles per period.

    Returns {'solutions': [Solution], 'certificates': [...], 'incomplete': [...], 'log': [...]}.

    limits: optional dict {'MAX_EQ_TERMS': ..., ...} that replaces the size limits of the module (the constants
    MAX_* above) during this call; the defaults are chosen for the browser.

    budget_s bounds the time of the solving (shared among the forms; checked between elimination steps); the
    exact checks of the solutions found may take up to the same time again.  A form that is not finished, or
    not started, is listed in `incomplete`; a solution that is not checked has certificate status 'not-run'.

    A certificate (one per form that was solved completely) has the keys
        ansatz, kind, poles, form, unknowns, parameters, nonzero, system, method, solution_set, scope, time_s
    and means: the functions of the stated form that satisfy the equation are exactly those given by
    `solution_set` (each case: values of the unknowns, conditions on the parameters, free unknowns, polynomial
    relations, non-vanishing conditions); `system` is the list of coefficients of E[w] in the basis of the
    form, which must all vanish.  `scope` says what the form does not cover.
    """
    if limits:
        # size limits for this call (the module constants MAX_*; larger values for a server with long budgets)
        saved = dict((k, globals()[k]) for k in limits if k.startswith("MAX_") and k in globals())
        globals().update(dict((k, limits[k]) for k in saved))
        try:
            return find_w_solutions(eq, local, max_poles, kinds, ends, budget_s, numeric_only, verify,
                                    cross_check, accelerate, None)
        finally:
            globals().update(saved)
    from . import verify as _verify
    t0 = time.monotonic()
    t_end = t0 + float(budget_s)
    verify_spent, verify_cap = 0.0, max(float(budget_s), 5.0)   # the checks may take as long again as the solving
    log, sols, certs, incomplete = [], [], [], []
    par = list(getattr(eq, "params", []))
    orders = pole_orders(eq, local)
    log.append("pole orders: %s" % orders)
    loc = dict((str(q), q) for q in par)
    gopts, deg, ends_text = _growth_options(ends, loc)
    log.append(ends_text)
    tasks = []
    for p in orders:
        if "rational" in kinds:
            tasks.append(("rational", (p,), None, deg))
        if "simply-periodic" in kinds:
            tasks.append(("simply-periodic", (p,), None, 0))
        if "elliptic" in kinds:
            tasks.append(("elliptic", (p,), None, 0))
    if "simply-periodic" in kinds:
        for p in orders:
            for nuv, exps, _lab in gopts:
                tasks.append(("simply-periodic", (p,), (nuv, exps), 0))
    if max_poles >= 2:
        for pp in _two_pole_lists(orders):
            for kind in ("rational", "simply-periodic", "elliptic"):
                if kind in kinds:
                    tasks.append((kind, pp, None, 0))
    if ends is None:
        scope_sp = "only solutions with finite limits at both ends of the period strip were sought (no `ends` data)"
        scope_r = "only rational solutions with a finite limit at infinity were sought (no `ends` data)"
    else:
        scope_sp = "finite limits at both ends of the period strip; growth is treated in separate forms (%s)" % ends_text
        scope_r = "polynomial part of degree <= %d (from `ends`)" % deg
    if not orders:
        log.append("no integer pole order is possible: no solution with poles")
    for idx, (kind, poles, growth, pdeg) in enumerate(tasks):
        now = time.monotonic()
        left = t_end - now
        name = "%s, %s" % (kind, "one pole of order %d" % poles[0] if len(poles) == 1 else
                           "two poles of orders %d and %d" % poles) + \
               (", terms s**m for m in %s, nu %s" % (list(growth[1]), "unknown" if growth[0] is None
                                                       else "= %s" % growth[0]) if growth else "") + \
               (" per period" if kind != "rational" else "")
        if left <= 0:
            # no time left for this form: its system is still returned, in a usable form
            item = {"ansatz": name, "kind": kind, "poles": list(poles), "reason": "time budget", "system": None}
            try:
                sysd = system_for(eq, kind, poles, growth, pdeg)
                if "empty" not in sysd:
                    item.update({"form": sysd["form"], "unknowns": [str(u) for u in sysd["unknowns"]],
                                 "parameters": [str(q) for q in par],
                                 "nonzero": [str(n) for n in sysd["nonzero"]],
                                 "system": [str(_numer(e)) for e in sysd["equations"]]})
            except Exception:           # pragma: no cover
                pass
            incomplete.append(item)
            continue
        share = max(left / (len(tasks) - idx), min(left, 5.0))
        ts = time.monotonic()
        try:
            sysd = system_for(eq, kind, poles, growth, pdeg)
        except Exception as err:            # pragma: no cover
            incomplete.append({"ansatz": name, "kind": kind, "poles": list(poles),
                               "reason": "error while building the system: %r" % (err,), "system": None})
            continue
        if "empty" in sysd:
            certs.append({"ansatz": name, "kind": kind, "poles": list(poles), "form": None, "unknowns": [],
                          "parameters": [str(q) for q in par], "nonzero": [], "system": [],
                          "method": "none needed", "solution_set": [], "scope": sysd["empty"], "time_s": 0.0})
            continue
        base = {"ansatz": name, "kind": kind, "poles": list(poles), "form": sysd["form"],
                "unknowns": [str(u) for u in sysd["unknowns"]], "parameters": [str(q) for q in par],
                "nonzero": [str(n) for n in sysd["nonzero"]],
                "assumed_nonzero": [str(n) for n in sysd.get("assumed_nonzero", [])],
                "system": [_system_string(e) for e in sysd["equations"]]}
        if numeric_only and par:
            d = dict(base)
            d["reason"] = "symbolic parameters and numeric_only=True: the system is returned unsolved"
            incomplete.append(d)
            continue
        heavy, leaves, pending, stats = None, None, [], None
        if accelerate and len(poles) == 2:
            # two-pole systems: the external solver first, when it is there (Singular / msolve)
            hl, heavy = _heavy_leaves(sysd, par, max(share, 10.0))
            if hl is not None:
                leaves = hl
                stats = {"steps": 0, "ext": _has_algebraic(sysd["equations"]),
                         "trace": ["solved by mero.heavy.algsys (%s): minimal primes of the saturated ideal; "
                                   "see the field `heavy`" % heavy.get("tool")]}
            elif not heavy.get("available"):
                heavy = None
        if leaves is None:
            leaves, pending, stats = tri_solve(sysd["equations"], sysd["unknowns"], par, sysd["nonzero"],
                                               budget_s=share)
        ext = stats["ext"]
        if pending and accelerate and heavy is None:
            hl, heavy = _heavy_leaves(sysd, par, max(share, 10.0))
            if hl is not None:
                leaves, pending = hl, []
                stats["trace"] = ["solved by mero.heavy.algsys (%s): minimal primes of the saturated ideal; see "
                                  "the field `heavy`" % heavy.get("tool")]
        leaves2 = []
        for lf in leaves:
            leaves2.extend(_explicit_roots(lf, ext, par))
        scope = {"rational": scope_r, "simply-periodic": scope_sp,
                 "elliptic": "cases with g2**3 = 27*g3**2 are simply periodic or rational functions and belong "
                             "to those forms"}[kind]
        if growth:
            scope = ("the coefficients of the extreme powers of s are not zero (the other cases belong to forms "
                     "with fewer terms)" + ("; nu and -nu with the exponents reversed give the same functions"
                                            if growth[0] is None else ""))
        if len(poles) == 2:
            no_growth = isinstance(ends, dict) and ends.get("growth_possible") is False
            p1_, p2_ = poles
            if kind == "rational":
                scope = ("exactly two poles: at 0 of order exactly %d and at a != 0 of order exactly %d (leading "
                         "coefficients not zero, any residues); finite limit at infinity, no polynomial part"
                         % (p1_, p2_))
            elif kind == "simply-periodic":
                scope = ("exactly two poles in a period strip: at 0 of order exactly %d and at a of order "
                         "exactly %d, a not congruent to 0 modulo the period (t = tau(a) finite, t**2 != kappa; "
                         "a half period, t = 0, is included); any residues; finite limits at both ends; %s"
                         % (p1_, p2_, "growth terms are not needed: `ends` says that growth at the ends is "
                            "impossible" if no_growth else
                            "forms with growth at an end were not built for two poles"))
            else:
                scope = ("exactly two poles in a period parallelogram: at 0 of order exactly %d and at a of "
                         "order exactly %d, a not a period (A = wp(a) finite; a half period, B = wp'(a) = 0, is "
                         "included); residues -r at 0 and r at a through the term r*(zeta(z - a) - zeta(z) + "
                         "zeta(a)) (r != 0 is required where the pole is simple, r = 0 is allowed otherwise); "
                         "g2**3 != 27*g3**2 (the degenerate curves give simply periodic or rational functions, "
                         "which belong to those forms)" % (p1_, p2_))
        if sysd.get("assumed_nonzero"):
            scope += ("; parameter values at which a coefficient of the dominant part or of the highest "
                      "derivative vanishes (%s) are not covered: the equation is then a different one"
                      % ", ".join(str(n) for n in sysd["assumed_nonzero"]))
        all_leaves, exchanged, same_series = leaves2, [], []
        if sysd.get("swap"):
            leaves2, exchanged, same_series = _exchange_dedupe(leaves2, sysd["swap"])
        found = []
        for lf in leaves2:
            sol = _solution_from_leaf(eq, kind, sysd, lf, "s%d" % (len(sols) + len(found) + 1))
            if verify and sol.get("size", 0) > MAX_VERIFY_CHARS:
                sol["certificate"]["detail"] = ("not verified inside the solver: the constants are too large "
                                                "(%d characters); run mero.verify.verify_solution(eq, sol)"
                                                % sol["size"])
            elif verify and verify_spent >= verify_cap and sol.get("size", 0) > 600:
                sol["certificate"]["detail"] = ("not verified inside the solver: time budget; run "
                                                "mero.verify.verify_solution(eq, sol)")
            elif verify:
                tv = time.monotonic()
                try:
                    sol["certificate"] = _verify.verify_solution(
                        eq, sol, time_limit=max(3.0, min(max(5.0, 0.25 * float(budget_s)),
                                                         verify_cap - verify_spent)))
                except Exception as err:        # pragma: no cover
                    sol["certificate"] = {"type": "substitution", "method": "symbolic", "status": "not-run",
                                          "detail": "verification raised %r" % (err,)}
                tv = time.monotonic() - tv
                verify_spent += tv
                t_end += tv                 # the time of the checks is not taken from the solving budget
            if verify:
                tv = time.monotonic()
                _second_checks(eq, sol, poles, _verify, max(10.0, 0.25 * float(budget_s)))
                tv = time.monotonic() - tv
                t_end += tv
            found.append(sol)
        # a case that fails the exact check is not a solution: it is not returned, and the form is not certified
        rejected = [s_ for s_ in found if s_["certificate"]["status"] == "fail"]
        found = [s_ for s_ in found if s_["certificate"]["status"] != "fail"]
        sols.extend(found)
        notes = [n for lf in leaves2 for n in lf["notes"]]
        rec = dict(base)
        if heavy is not None:
            rec["heavy"] = heavy
        rec.update({"method": ("mero.heavy.algsys.solve_system (%s); completeness as stated by that module"
                               % heavy.get("tool")) if heavy is not None and not pending and
                    heavy.get("status") == "ok" and "not_converted" not in heavy else
                    "elimination with case distinctions (mero.wsolve.tri_solve): products split, "
                    "linear unknowns solved for with the cases coefficient != 0 / = 0, "
                    "pseudo-division; %d steps" % stats["steps"],
                    "solution_set": [_leaf_json(lf, par) for lf in all_leaves],
                    "trace": stats["trace"] if len(stats["trace"]) <= 400 else
                    stats["trace"][:400] + ["... %d more steps" % (len(stats["trace"]) - 400)],
                    "solutions": [s["id"] for s in found], "scope": scope,
                    "time_s": round(time.monotonic() - ts, 3)})
        if cross_check and not par and not pending and heavy is None:
            # second, independent argument (numeric parameters): the number of distinct solutions of the
            # system.  cross_check=True: Groebner bases by SymPy (no time limit can be imposed on them: SymPy's
            # Buchberger algorithm may not return on small systems, so this is not done by default);
            # 'auto': the external solver of mero.heavy.algsys, which has a time limit, when it is there.
            try:
                if cross_check is True:
                    g = groebner_count(sysd["equations"], sysd["unknowns"], sysd["nonzero"])
                    g["how"] = ("Groebner bases (SymPy) of the ideal of the system and y*prod(nonzero) - 1, and "
                                "of its radical; mero.wsolve.groebner_count")
                else:
                    g = _heavy_count(sysd, 8.0)
                if g is None:
                    raise _TooLarge()
                anyfree = any(lf["free"] for lf in all_leaves)
                nfound = 0
                for lf in all_leaves:
                    k = 1
                    for v, f in lf["relations"]:
                        k *= int(sp.degree(f, v))
                    nfound += k
                if g["dimension"] == -1:
                    ok, text = (nfound == 0), "the Groebner basis is {1}: the system has no solution"
                elif g["dimension"] == 0:
                    ok = (not anyfree) and g["distinct"] == nfound
                    text = ("the system has %s distinct solutions (%d with multiplicity); the elimination found "
                            "%d" % (g["distinct"], g["count"], nfound))
                else:
                    ok, text = anyfree, "the solution set is not finite (a variable without a pure power " \
                                        "among the leading monomials)"
                rec["groebner_check"] = {"agrees": bool(ok), "statement": text, "count": g["count"],
                                         "distinct": g["distinct"], "found": nfound, "how": g.get("how")}
                if not ok:
                    log.append("WARNING %s: the independent count and the elimination do not agree (%s)"
                               % (name, text))
            except _TooLarge:
                pass                            # no independent count available here
            except Exception as err:            # pragma: no cover
                rec["groebner_check"] = {"agrees": None, "statement": "not run: %r" % (err,)}
        if exchanged or same_series:
            rec["exchange_duplicates"] = [_leaf_json(lf, par) for lf in exchanged]
            rec["same_series_at_both_poles"] = [_leaf_json(lf, par) for lf in same_series]
            rec["scope"] += ("; of the %d cases of solution_set, %d are translations of others (exchange of the "
                             "two poles) and %d have the same Laurent series at both poles (equal principal "
                             "parts and a at a half period: then a is a period and the function is a one-pole "
                             "solution of the one-pole forms); these are not repeated in `solutions`"
                             % (len(all_leaves), len(exchanged), len(same_series)))
        if notes:
            rec["notes"] = notes
        if rejected:
            rec["rejected"] = rejected
            log.append("WARNING %s: %d cases of the elimination failed the exact check and are not returned"
                       % (name, len(rejected)))
        if pending or rejected:
            why = []
            if pending:
                why.append("time budget or size limit: %d cases not finished" % len(pending))
            if rejected:
                why.append("%d cases failed the exact check (see `rejected`): the list of this form is not "
                           "certified" % len(rejected))
            rec["reason"] = "; ".join(why)
            rec["pending"] = pending
            incomplete.append(rec)
        else:
            certs.append(rec)
        log.append("%s: %d equations, %d unknowns, %d cases, %d solutions, %.2f s%s" % (
            name, len(sysd["equations"]), len(sysd["unknowns"]), len(all_leaves), len(found),
            time.monotonic() - ts, " (INCOMPLETE)" if pending or rejected else ""))
    log.append("total %.2f s" % (time.monotonic() - t0))
    return {"solutions": sols, "certificates": certs, "incomplete": incomplete, "log": log}
