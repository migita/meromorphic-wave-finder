"""mero.verify -- exact verification of closed-form solutions by substitution.

    verify_solution(eq, sol)          certificate (SCHEMA section 2) of a Solution object
    verify_expr(eq, text)             'zero' / 'not zero' / 'undecided' for an expression typed by a visitor
    numeric_check(eq, sol, digits)    an independent floating-point check (tests only; never a certificate)
    exact_zero_test(eq, expr, ...)    the common exact test

The exact test.  The expression is written as a rational function of generators with known derivatives:

    z                               z' = 1
    S = exp(g z) (one per class of commensurable exponents; exp(a z + c) = exp(c) S**n)       S' = g S
    X = wp(u), Y = wpp(u), Zt = zeta_w(u)  for each argument u = a z + c and each pair (g2, g3):
                                    X' = a Y,  Y' = a (6 X**2 - g2/2),  Zt' = -a X,  Y**2 = 4X**3 - g2 X - g3.

w = N/Q, w^(j) = N_j/Q**(j+1) with N_{j+1} = N_j' Q - (j+1) N_j Q'.  The numerator of E[w] is reduced with
Y**2 = 4X**3 - g2 X - g3, and every coefficient of the resulting polynomial in the generators (an expression
in the constants) must vanish: identically, or modulo the polynomial relations that the constants satisfy
(radicals are replaced by symbols r with r**q = base; conditions and `relations` of the Solution are added).
If all coefficients vanish, the function is a solution for all values of the free constants: status 'zero'.
If some coefficient does not vanish and there are no relations, the function is not a solution for generic
values of the constants, provided the generators are algebraically independent (exponents incommensurable,
non-degenerate curves); the answer 'not zero' is given only after a numerical confirmation, otherwise
'undecided'.
"""
import keyword
import random
import re
import time

import mpmath as mp
import sympy as sp

from .special import MP_FUNCTIONS, wp, wpp, zeta_w

__all__ = ["verify_solution", "verify_solution_at_points", "verify_expr", "numeric_check", "exact_zero_test",
           "parse_expression", "solution_expression", "NoAdmissibleValues"]

z = sp.Symbol("z")

_FUNCS = {"exp": sp.exp, "cosh": sp.cosh, "sinh": sp.sinh, "tanh": sp.tanh, "coth": sp.coth, "sech": sp.sech,
          "csch": sp.csch, "cosech": sp.csch, "sin": sp.sin, "cos": sp.cos, "tan": sp.tan, "cot": sp.cot,
          "sec": sp.sec, "csc": sp.csc, "sqrt": sp.sqrt, "wp": wp, "wpp": wpp, "zeta_w": zeta_w,
          "pi": sp.pi, "I": sp.I, "E": sp.E, "log": sp.log, "ln": sp.log, "Abs": sp.Abs}
_BAD = re.compile(r"[^0-9A-Za-z_\s\+\-\*/\^\(\)\.,=!]")


def parse_expression(text, symbols=()):
    """SymPy expression from a string: the functions of _FUNCS, every other identifier is a symbol.
    Decimal numbers are read as exact rationals.  Raises ValueError on anything else."""
    if not isinstance(text, str):
        return sp.sympify(text)
    if _BAD.search(text) or "__" in text or re.search(r"[A-Za-z_]\s*\.|\.\s*[A-Za-z_]", text):
        raise ValueError("unsupported characters in the expression")
    text = text.replace("^", "**")
    loc = dict(_FUNCS)
    for s in symbols:
        loc[str(s)] = s
    for name in set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", text)):
        if keyword.iskeyword(name):             # a symbol called lambda, in, is, ...: read under an alias
            alias = name + "_kw_"
            text = re.sub(r"(?<![A-Za-z_0-9])%s(?![A-Za-z_0-9])" % name, alias, text)
            loc[alias] = loc.get(name, sp.Symbol(name))
        elif name not in loc:
            loc[name] = sp.Symbol(name)
    try:
        expr = sp.sympify(text, locals=loc, rational=True)
    except Exception as err:
        raise ValueError("cannot read the expression: %s" % (err,))
    return expr


def _eq_terms(eq):
    terms = getattr(eq, "terms", None)
    if terms:
        return dict((tuple(int(e) for e in m), sp.sympify(c)) for m, c in terms.items())
    E = getattr(eq, "E", None)
    if E is None:
        E = eq.w[eq.K] - eq.rhs
    poly = sp.Poly(sp.expand(E), *eq.w)
    return dict((tuple(int(e) for e in m), c) for m, c in poly.terms())


class _Undecided(Exception):
    pass


class NoAdmissibleValues(ValueError):
    """numeric_check: at every root of the relations some non-vanishing constraint fails (an empty family)"""


def _to_exp(expr):
    """hyperbolic and trigonometric functions written with exponentials (nothing else is touched)"""
    from sympy.functions.elementary.hyperbolic import HyperbolicFunction
    from sympy.functions.elementary.trigonometric import TrigonometricFunction
    sub = {}
    for f in expr.atoms(HyperbolicFunction, TrigonometricFunction):
        sub[f] = f.rewrite(sp.exp)
    for _ in range(3):
        if not sub:
            break
        expr = expr.xreplace(sub)
        sub = dict((f, f.rewrite(sp.exp)) for f in expr.atoms(HyperbolicFunction, TrigonometricFunction))
    return expr


def _generators(expr, var):
    """replace exp / wp / wpp / zeta_w by symbols; returns (expr, gens, D, curves, constants_note)"""
    D, curves, gens = {var: sp.Integer(1)}, [], [var]
    sub = {}
    # exponentials
    classes = []          # [reference rate, [(atom, ratio, const)]]
    for a in sorted(expr.atoms(sp.exp), key=str):
        arg = a.args[0]
        if var not in arg.free_symbols:
            continue
        try:
            pa = sp.Poly(arg, var)
        except Exception:
            raise _Undecided("exponent not polynomial in %s" % var)
        if pa.degree() != 1:
            raise _Undecided("exponent of degree %d in %s" % (pa.degree(), var))
        lam, c = pa.all_coeffs()
        for cl in classes:
            r = sp.cancel(lam / cl[0])
            if r.is_Rational:
                cl[1].append((a, r, c))
                break
        else:
            classes.append([lam, [(a, sp.Integer(1), c)]])
    consts = {}
    for i, (lam, members) in enumerate(classes):
        Lc = sp.ilcm(1, *[r.q for _, r, _ in members])
        g = lam / Lc
        S = sp.Symbol("S%d_" % i)          # S = exp(g z + c_ref/Lc): the shift of the first member is absorbed
        gens.append(S)
        D[S] = g * S
        cref = members[0][2]
        for a, r, c in members:
            dc = sp.expand(c - r * cref)
            if dc == 0:
                sub[a] = S ** int(r * Lc)
            else:                           # a constant factor exp(dc): an opaque constant
                key = sp.exp(dc)
                if key not in consts:
                    consts[key] = sp.Symbol("K%d_" % len(consts))
                sub[a] = consts[key] * S ** int(r * Lc)
    # Weierstrass functions
    groups = {}
    for a in sorted(expr.atoms(wp, wpp, zeta_w), key=str):
        u, g2, g3 = a.args
        if var not in u.free_symbols:
            continue
        if var in g2.free_symbols or var in g3.free_symbols:
            raise _Undecided("invariants depend on %s" % var)
        try:
            pu = sp.Poly(u, var)
        except Exception:
            raise _Undecided("argument of wp not polynomial in %s" % var)
        if pu.degree() != 1:
            raise _Undecided("argument of wp of degree %d in %s" % (pu.degree(), var))
        key = (tuple(pu.all_coeffs()), g2, g3)
        if key not in groups:
            i = len(groups)
            X, Y, Zt = sp.Symbol("X%d_" % i), sp.Symbol("Y%d_" % i), sp.Symbol("Zt%d_" % i)
            aa = pu.all_coeffs()[0]
            groups[key] = (X, Y, Zt)
            gens += [X, Y]
            D[X] = aa * Y
            D[Y] = aa * (6 * X ** 2 - g2 / 2)
            D[Zt] = -aa * X
            curves.append((Y, sp.expand(Y ** 2 - (4 * X ** 3 - g2 * X - g3))))
        X, Y, Zt = groups[key]
        sub[a] = {wp: X, wpp: Y, zeta_w: Zt}[a.func]
        if a.func is zeta_w and Zt not in gens:
            gens.append(Zt)
    out = expr.xreplace(sub)
    # exponentials of constants are opaque constants
    csub = {}
    for a in sorted(out.atoms(sp.exp), key=str):
        if var not in a.free_symbols:
            if a not in consts:
                consts[a] = sp.Symbol("K%d_" % len(consts))
            csub[a] = consts[a]
    if csub:
        out = out.xreplace(csub)
    # anything else that depends on var must be the symbol var itself
    for f in out.atoms(sp.Function):
        if var in f.free_symbols:
            raise _Undecided("function %s is not supported in the exact test" % f.func)
    for pw in out.atoms(sp.Pow):
        if var in pw.exp.free_symbols or (var in pw.base.free_symbols and not pw.exp.is_Integer):
            raise _Undecided("power %s is not supported in the exact test" % pw)
    return out, gens, D, curves, len(groups) > 1 or len(classes) > 1


def _radicals(exprs, gens):
    """replace radicals of constants and I by symbols; returns (exprs, relations, symbols, back-substitution).

    A positive rational base is split into primes, one symbol r_p = p**(1/Q) per prime (so that sqrt(30),
    sqrt(15), sqrt(2) are expressed through the same symbols).  Any other base gets one symbol
    r = base**(1/Q), Q the l.c.m. of the denominators that occur; bases are compared in the canonical form of
    sympy.cancel (the same radical may be written in several ways)."""
    gset = set(gens)

    def is_rad(e):
        return e.is_Pow and e.exp.is_Rational and not e.exp.is_Integer and not (e.base.free_symbols & gset)

    def is_num(base):
        return base.is_Rational and base.is_positive

    canon_cache = {}

    def canon(base):
        if base not in canon_cache:
            try:
                canon_cache[base] = sp.cancel(sp.together(base)) if base.free_symbols else base
            except Exception:
                canon_cache[base] = base
        return canon_cache[base]

    def primes(base):
        d = dict(sp.factorint(base.p))
        for q_, e_ in sp.factorint(base.q).items():
            d[q_] = d.get(q_, 0) - e_
        return d

    exprs = [sp.sympify(e) for e in exprs]
    rels, syms, back = [], [], {}
    ptable = {}                                   # prime -> [symbol, Q]
    # numeric radicals: the exponents needed for each prime
    need = {}
    for e in exprs:
        for pw in e.atoms(sp.Pow):
            if is_rad(pw) and is_num(pw.base):
                for pr, ex in primes(pw.base).items():
                    need[pr] = sp.ilcm(need.get(pr, 1), (ex * pw.exp).q)
    for pr in sorted(need):
        if need[pr] > 1:
            r = sp.Symbol("r%d_" % len(syms))
            syms.append(r)
            ptable[pr] = (r, need[pr])
            rels.append(r ** need[pr] - pr)
            back[r] = sp.Pow(sp.Integer(pr), sp.Rational(1, need[pr]))

    def rep_num(e):
        out = sp.Integer(1)
        for pr, ex in primes(e.base).items():
            t = ex * e.exp
            if pr in ptable:
                r, Q = ptable[pr]
                out *= r ** int(t * Q)
            else:
                out *= sp.Integer(pr) ** int(t)
        return out

    if ptable or need:
        exprs = [e.replace(lambda x: is_rad(x) and is_num(x.base), rep_num) for e in exprs]
    for _round in range(6):
        qs = {}
        for e in exprs:
            for pw in e.atoms(sp.Pow):
                if is_rad(pw) and not any(is_rad(x) for x in pw.base.atoms(sp.Pow)):
                    cb = canon(pw.base)
                    qs[cb] = sp.ilcm(qs.get(cb, 1), pw.exp.q)
        if not qs:
            break
        table = {}
        for base in sorted(qs, key=str):
            r = sp.Symbol("r%d_" % len(syms))
            syms.append(r)
            table[base] = (r, qs[base])
            num, den = sp.fraction(sp.together(base))
            rels.append(sp.expand(r ** qs[base] * den - num))
            back[r] = sp.Pow(base.xreplace(back), sp.Rational(1, qs[base]))

        def rep(e):
            r, Q = table[canon(e.base)]
            return r ** (e.exp.p * (Q // e.exp.q))

        exprs = [e.replace(lambda x: is_rad(x) and canon(x.base) in table, rep) for e in exprs]
    if any(e.has(sp.I) for e in exprs) or any(r.has(sp.I) for r in rels):
        ii = sp.Symbol("i_")
        syms.append(ii)
        exprs = [e.xreplace({sp.I: ii}) for e in exprs]
        rels = [sp.expand(r.xreplace({sp.I: ii})) for r in rels]       # a radical of a complex number
        rels.append(ii ** 2 + 1)
        back[ii] = sp.I
    return exprs, rels, syms, back


class _CallLimit(BaseException):
    """private: the time limit of one bounded SymPy call has passed (a BaseException so that the `except
    Exception` clauses inside SymPy do not swallow it; it never leaves _bounded)"""


class _Empty(Exception):
    """private: the relations of a family have no common zero"""


GROEBNER_LIMIT_S = 10.0         # time limit of one Groebner basis computation / one reduction in this module


def _bounded(fn, args=(), kwargs=None, limit=None):
    """fn(*args, **kwargs) with a cooperative time limit (no threads, signals or processes; works in the
    browser): a trace function, called by the interpreter at each new Python frame (no line tracing), raises
    once the limit has passed; _Undecided is raised to the caller.  A trace function installed by the caller
    (the time limit of a step of mero.report) stays in force: it is called first, and restored afterwards."""
    import os
    import sys
    if os.environ.get("MERO_IN_STEP") == "1":       # heavy version: the step has a hard time limit of its own
        return fn(*args, **(kwargs or {}))
    limit = GROEBNER_LIMIT_S if limit is None else max(0.2, float(limit))
    prev = sys.gettrace()
    deadline = time.monotonic() + limit

    def tracer(frame, event, arg):
        if prev is not None:
            prev(frame, event, arg)                 # may raise the caller's own timeout
        c = frame.f_code                # not in generator frames and collector callbacks: an exception raised
        if state["on"] and time.monotonic() > deadline and not (c.co_flags & 0x20) and not (     # there is ignored
                c.co_argcount == 2 and c.co_varnames[:2] == ("phase", "info")):
            raise _CallLimit()
        return None

    state = {"on": True}
    sys.settrace(tracer)
    try:
        return fn(*args, **(kwargs or {}))
    except _CallLimit:
        state["on"] = False
        raise _Undecided("a Groebner basis computation reached its time limit (%.0f s)" % limit)
    finally:
        state["on"] = False
        sys.settrace(prev)


def _left(t_stop, cap=None):
    """seconds for one bounded call: what is left until t_stop, at most GROEBNER_LIMIT_S (or cap)"""
    cap = GROEBNER_LIMIT_S if cap is None else cap
    if t_stop is None:
        return cap
    return max(0.2, min(cap, t_stop - time.monotonic()))


def _is_unit(G):
    return len(G.exprs) == 1 and G.exprs[0].is_number and G.exprs[0] != 0


def _main_variables(rels, rsyms, params, with_flag=False):
    """one main variable per relation (radical symbols first, then constants, then parameters): the relations
    are used as a triangular set over the field of rational functions of the other symbols.
    with_flag: also return whether the relations ARE triangular for this choice (every relation has its own
    main variable, and the dependence of a relation on the main variables of the others has no cycle).  Only
    then do the other symbols stay free on the set of the relations."""
    rset, pset = set(rsyms), set(params)
    order = sorted(rels, key=lambda r: (len(r.free_symbols), str(r)))
    chosen = []
    ok = True
    for r in order:
        cand = sorted((sy for sy in r.free_symbols if sy not in chosen),
                      key=lambda sy: (0 if sy in rset else (2 if sy in pset else 1), str(sy)))
        if cand:
            chosen.append(cand[0])
        else:
            ok = False
    if not with_flag:
        return chosen
    if ok and len(chosen) == len(order):
        deps = dict((i, set(j for j in range(len(order)) if j != i and chosen[j] in order[i].free_symbols))
                    for i in range(len(order)))
        state = {}

        def cyclic(i):
            if state.get(i) == 1:
                return True
            if state.get(i) == 2:
                return False
            state[i] = 1
            if any(cyclic(j) for j in deps[i]):
                return True
            state[i] = 2
            return False

        ok = not any(cyclic(i) for i in range(len(order)))
    return chosen, ok


def _family_is_empty(rels, rsyms, params, nonzero, limit=None):
    """Is the set {relations = 0, nonzero != 0} empty?  All symbols are variables (Rabinowitsch): the set is
    empty over the complex numbers if and only if the ideal of the relations and y*N - 1 (N = product of the
    non-vanishing conditions) contains 1.
        True   the reduced Groebner basis is {1}: empty (a proof)
        False  it is not {1}: the set has points
        None   not decided (too large for a Groebner basis here, or the time limit of the computation)."""
    rels = [sp.expand(r) for r in rels]
    rels = [r for r in rels if r != 0]
    if any(r.is_number for r in rels):
        return True
    if not rels:
        return False
    N = sp.Integer(1)
    for n in nonzero:
        n = sp.sympify(n)
        if n.is_number:
            if n == 0:
                return True
            continue
        N *= n
    N = sp.expand(N)
    syms = set(N.free_symbols)
    for r in rels:
        syms |= r.free_symbols
    syms = sorted(syms, key=str)
    size = sum(len(sp.Add.make_args(r)) for r in rels) + len(sp.Add.make_args(N))
    if size > 600 or len(syms) > 9:
        return None
    y = sp.Symbol("y_")
    polys = list(rels) + ([sp.expand(y * N - 1)] if N != 1 else [])
    gens = syms + ([y] if N != 1 else [])
    try:
        G = _bounded(sp.groebner, (polys,) + tuple(gens), {"order": "grevlex"}, limit)
    except _Undecided:
        return None
    except Exception:
        return None
    return bool(_is_unit(G))


def _check_time(t_stop):
    if t_stop is not None and time.monotonic() > t_stop:
        raise _Undecided("time limit of the exact check reached; call verify_solution with a larger time_limit")


def _vanishing_test(coeffs, rels, rsyms, params, nonzero=(), t_stop=None):
    """Which of the coefficients do not vanish on the set {relations = 0, nonzero != 0}?

    First test: remainder modulo a Groebner basis of the relations.  If the relations are triangular in their
    main variables (see _main_variables) the basis is taken in these variables, with coefficients in the field
    of the other symbols, which stay free; if they are not triangular, or if that basis is {1} (the relations
    then restrict the other symbols too), the basis is taken with ALL symbols as variables.  A zero remainder
    proves that the coefficient vanishes on the set (in the first case: for generic values of the free symbols).
    Second test, for what is left: P vanishes on the set if and only if the ideal generated by the relations,
    y*N - 1 and t*P - 1, all symbols being variables, is the unit ideal (N = product of the non-vanishing
    conditions).  Returns the list of the coefficients for which neither test gives zero; raises _Undecided
    when a computation is too large or reaches its time limit, _Empty when the relations have no common zero."""
    rels = [sp.expand(r) for r in rels]
    rels = [r for r in rels if r != 0]
    allsyms = sorted(set().union(*[r.free_symbols for r in rels]), key=str)
    main, triangular = _main_variables(rels, rsyms, params, with_flag=True)
    G = None
    if triangular:
        G = _bounded(sp.groebner, (rels,) + tuple(main), {"order": "grevlex"}, _left(t_stop))
        if _is_unit(G):
            G = None
    if G is None:
        size = sum(len(sp.Add.make_args(r)) for r in rels)
        if size > 600 or len(allsyms) > 9:
            raise _Undecided("the relations are not triangular and too large for a Groebner basis in all symbols")
        main = allsyms
        G = _bounded(sp.groebner, (rels,) + tuple(main), {"order": "grevlex"}, _left(t_stop))
        if _is_unit(G):
            raise _Empty()
    gex = list(G.exprs)
    left = []
    for c in coeffs:
        _check_time(t_stop)
        c = sp.expand(c)
        if c == 0:
            continue
        rem = _bounded(sp.reduced, (c, gex) + tuple(main), {"order": "grevlex"}, _left(t_stop, 30.0))[1]
        if sp.expand(sp.fraction(sp.together(rem))[0]) != 0:
            left.append(c)
    if not left:
        return []
    N = sp.Integer(1)
    for n in nonzero:
        N *= n
    if triangular and main is not allsyms:  # "v any root of f": the leading coefficient of f in v is not zero
        for r, v in zip(sorted(rels, key=lambda r: (len(r.free_symbols), str(r))), main):
            if v in r.free_symbols:
                N *= sp.Poly(r, v).LC()
    N = sp.expand(N)
    y, t = sp.Symbol("y_"), sp.Symbol("t_")
    bad = []
    size = sum(len(sp.Add.make_args(r)) for r in rels) + len(sp.Add.make_args(N))
    if size > 300 or len(allsyms) > 7:      # the second test would take too long: not decided here
        raise _Undecided("the remainders modulo the relations are not zero and the relations are too large "
                         "for the unit-ideal test")
    for c in left[:8]:                      # each test is a Groebner basis computation
        _check_time(t_stop)
        syms = sorted(set().union(c.free_symbols, N.free_symbols if hasattr(N, "free_symbols") else set(),
                                  *[r.free_symbols for r in rels]), key=str)
        if len(sp.Add.make_args(c)) > 400:
            raise _Undecided("a coefficient is too large for the unit-ideal test")
        polys = list(rels) + ([sp.expand(y * N - 1)] if N != 1 else []) + [sp.expand(t * c - 1)]
        gens = syms + ([y] if N != 1 else []) + [t]
        try:
            G2 = _bounded(sp.groebner, (polys,) + tuple(gens), {"order": "grevlex"}, _left(t_stop))
        except _Undecided:
            raise
        except Exception as err:
            raise _Undecided("the unit-ideal test could not be run (%s)" % (str(err) or repr(err),))
        if not _is_unit(G2):
            bad.append(c)                   # a point with relations = 0, N != 0 and c != 0 exists
    if not bad and len(left) > 8:
        raise _Undecided("more than 8 coefficients would need the unit-ideal test")
    return bad


def exact_zero_test(eq, expr, var=z, relations=(), param_subs=None, nonzero=(), time_limit=None):
    """Exact test of E[expr] = 0.  Returns {'status': 'zero' | 'nonzero' | 'undecided', 'detail': ..., ...}.

    relations: polynomial expressions in the constants that vanish; nonzero: expressions that do not vanish;
    param_subs: {parameter: value}; time_limit: seconds (checked between the steps; 'undecided' when reached)."""
    t_stop = None if time_limit is None else time.monotonic() + float(time_limit)
    try:
        return _exact_zero_test(eq, expr, var, relations, param_subs, nonzero, t_stop)
    except _Undecided as err:
        return {"status": "undecided", "detail": str(err)}


def _exact_zero_test(eq, expr, var, relations, param_subs, nonzero, t_stop):
    terms = _eq_terms(eq)
    K = max(len(m) for m in terms) - 1
    if param_subs:
        terms = dict((m, sp.sympify(c).xreplace(param_subs)) for m, c in terms.items())
    expr = sp.sympify(expr)
    try:
        e2 = _to_exp(expr)
        e2, gens, D, curves, several = _generators(e2, var)
    except _Undecided as err:
        return {"status": "undecided", "detail": str(err)}
    cos = [terms[m] for m in terms]
    nc, ng, ncv = len(cos), len(gens), len(curves)
    pack = [e2] + cos + [D[g] for g in gens] + [c for _, c in curves] + list(relations)
    full, rrels, rsyms, back = _radicals(pack, gens)
    e2 = full[0]
    cos = full[1:1 + nc]
    Dr = dict(zip(gens, full[1 + nc:1 + nc + ng]))
    curves = [(Y, c) for (Y, _), c in zip(curves, full[1 + nc + ng:1 + nc + ng + ncv])]
    rels = [sp.expand(sp.fraction(sp.together(r))[0]) for r in full[1 + nc + ng + ncv:]]
    rels = [r for r in rels if r != 0] + rrels
    N, Q = sp.fraction(sp.together(e2))
    try:
        Np = sp.Poly(N, *gens)
        Qp = sp.Poly(Q, *gens)
    except Exception as err:
        return {"status": "undecided", "detail": "not a rational function of the generators: %s" % (err,)}
    Dp = dict((g, sp.Poly(sp.together(Dr[g]), *gens)) if sp.together(Dr[g]).is_polynomial(*gens) else (g, None)
              for g in gens)
    if any(v is None for v in Dp.values()):
        return {"status": "undecided", "detail": "derivation not polynomial"}
    basis = [sp.Poly(c, *gens) for _, c in curves]

    def red(P):
        if not basis or P.is_zero:
            return P
        for (Y, _), b in zip(curves, basis):
            if P.degree(Y) >= 2:
                order = [Y] + [g for g in gens if g != Y]
                P = sp.Poly(P.as_expr(), *order).rem(sp.Poly(b.as_expr(), *order))
                P = sp.Poly(P.as_expr(), *gens)
        return P

    def Dop(P):
        r = sp.Poly(0, *gens)
        for g in gens:
            dg = P.diff(g)
            if not dg.is_zero:
                r = r + dg * Dp[g]
        return r

    DQ = Dop(Qp)
    Ns = [red(Np)]
    for j in range(K):
        _check_time(t_stop)
        Ns.append(red(Dop(Ns[j]) * Qp - (j + 1) * Ns[j] * DQ))
    M = max(sum(e * (j + 1) for j, e in enumerate(m)) for m in terms)
    total = sp.Poly(0, *gens)
    for m, co in zip(terms, cos):
        _check_time(t_stop)
        t = sp.Poly(co, *gens)
        for j, e in enumerate(m):
            for _ in range(e):
                t = red(t * Ns[j])
        k = M - sum(e * (j + 1) for j, e in enumerate(m))
        if k:
            t = red(t * Qp ** k)
        total = total + t
    total = red(total)
    coeffs = [sp.fraction(sp.together(c))[0] for c in total.coeffs()]
    shown = [r for r in rels if not (r.free_symbols & set(rsyms))] + \
        ["%s = %s" % (r, back[r]) for r in rsyms if r in back and back[r] != sp.I]
    info = {"generators": [str(g) for g in gens], "coefficients": len(coeffs),
            "relations": [str(r) for r in shown]}
    if Qp.is_zero:
        return dict(info, status="undecided", detail="denominator vanishes identically")
    bad = []
    if rels:
        try:
            nzl = []
            for n in nonzero:
                (n2,), _, _, _ = _radicals([n], gens)
                if not (n2.atoms(sp.Pow) and any(a.exp.is_Rational and not a.exp.is_Integer
                                                 for a in n2.atoms(sp.Pow))) and not n2.has(sp.I):
                    nzl.append(sp.fraction(sp.together(n2))[0])
            empty_text = ("the family is empty: the non-vanishing conditions fail at every point at which the "
                          "relations hold (the ideal of the relations and y*N - 1, all symbols as variables, "
                          "is the unit ideal)")
            if _family_is_empty(rels, rsyms, getattr(eq, "params", []), nzl, _left(t_stop)) is True:
                return dict(info, status="nonzero", empty=True, detail=empty_text)
            try:
                cand = _vanishing_test(coeffs, rels, rsyms, getattr(eq, "params", []), nzl, t_stop)
            except _Empty:
                return dict(info, status="nonzero", empty=True, detail=empty_text)
            for c in cand:
                try:                        # relations between different radicals that the table does not know
                    if sp.count_ops(c) <= 300 and sp.simplify(sp.expand(c.xreplace(back))) == 0:
                        continue
                except Exception:
                    pass
                bad.append(c)
        except _Undecided:
            raise
        except Exception as err:
            return dict(info, status="undecided",
                        detail="reduction modulo the relations failed: %s" % (str(err) or repr(err),))
    else:
        bad = [c for c in (sp.expand(c) for c in coeffs) if c != 0]
    if not bad:
        how = "the numerator of E[w], a polynomial in %s" % ", ".join(str(g) for g in gens)
        if curves:
            how += ", reduced with wpp**2 = 4*wp**3 - g2*wp - g3,"
        how += " has %d coefficients; all vanish" % len(coeffs)
        given = [r for r in rels if not (r.free_symbols & set(rsyms))]
        if given:
            how += " modulo " + ", ".join("%s = 0" % r for r in given)
        if rsyms:
            how += " (radicals and I treated as algebraic numbers: %d symbols with their defining equations)" \
                % len(rsyms)
        return dict(info, status="zero", detail=how.replace(", 0 = 0", "").replace(" 0 = 0,", ""))
    return dict(info, status="nonzero", several_generators=several,
                detail="%d of %d coefficients of the numerator of E[w] do not vanish%s; one of them: %s" % (
                    len(bad), len(coeffs), " modulo the relations" if rels else "",
                    sp.factor(bad[0]).xreplace(back)))


# ----------------------------------------------------------------------------------------------- Solution
def _split_condition(text):
    for op in ("==", "!=", "="):
        if op in text:
            a, b = text.split(op, 1)
            return a.strip(), ("!=" if op == "!=" else "=="), b.strip().lstrip("=")
    return text, None, None


def solution_expression(eq, sol):
    """(expr, param_subs, relations, symbols, nonzero) of a Solution dict: constants substituted, conditions
    read (equalities: parameter values or relations; inequalities: the list `nonzero`)."""
    par = list(getattr(eq, "params", []))
    syms = dict((str(q), q) for q in par)
    syms["z"] = z
    expr = parse_expression(sol["expr"], syms.values())
    consts = {}
    for name, val in (sol.get("constants") or {}).items():
        if not isinstance(val, str) or val == "free" or val.startswith("any root"):
            continue
        consts[sp.Symbol(name)] = parse_expression(val, syms.values())
    for _ in range(len(consts) + 1):
        new = expr.xreplace(consts)
        if new == expr:
            break
        expr = new
    relations, psub = [], {}
    for text in sol.get("conditions") or []:
        a, op, b = _split_condition(text)
        if op != "==":
            continue
        lhs, rhs = parse_expression(a, syms.values()), parse_expression(b, syms.values())
        if lhs.is_Symbol and lhs in par and lhs not in rhs.free_symbols and lhs not in psub:
            psub[lhs] = rhs
        else:
            relations.append(lhs - rhs)
    for _ in range(len(psub) + 1):          # a parameter value may contain another determined parameter
        psub = dict((k, v.xreplace(psub)) for k, v in psub.items())
    for text in sol.get("relations") or []:
        a, op, b = _split_condition(text)
        r = parse_expression(a, syms.values()) - (parse_expression(b, syms.values()) if b else 0)
        relations.append(r)
    nonzero = []
    for text in list(sol.get("conditions") or []) + list(sol.get("constraints") or []):
        a, op, b = _split_condition(text)
        if op == "!=":
            nonzero.append(parse_expression(a, syms.values()) - parse_expression(b, syms.values()))
    for _ in range(len(consts) + 1):
        relations = [r.xreplace(consts) for r in relations]
        nonzero = [r.xreplace(consts) for r in nonzero]
    relations = [r.xreplace(psub) for r in relations]
    relations = [r for r in relations if r != 0 and (sp.count_ops(r) > 300 or sp.simplify(r) != 0)]
    nonzero = [r.xreplace(psub) for r in nonzero]
    expr = expr.xreplace(psub)
    return expr, psub, relations, syms, nonzero


def verify_solution(eq, sol, time_limit=None):
    """Exact substitution check of a Solution object; returns its certificate (SCHEMA section 2).
    time_limit (seconds, optional): the check stops with status 'not-run' when it is reached."""
    cert = {"type": "substitution", "method": "symbolic", "status": "not-run", "detail": ""}
    try:
        expr, psub, relations, _, nonzero = solution_expression(eq, sol)
    except Exception as err:
        cert["detail"] = "could not read the solution: %s" % (err,)
        return cert
    res = exact_zero_test(eq, expr, z, relations, psub, nonzero, time_limit)
    if res["status"] == "zero":
        cert["status"] = "pass"
        cert["detail"] = res["detail"]
        if psub:
            cert["detail"] += "; parameters substituted: " + ", ".join("%s = %s" % kv for kv in psub.items())
    elif res["status"] == "nonzero":
        cert["status"] = "fail"
        cert["detail"] = res["detail"]
    else:
        cert["detail"] = "exact test not applicable: " + res["detail"]
    return cert


def verify_solution_at_points(eq, sol, points=2, seed=7, time_limit=None):
    """The exact substitution check of a Solution at points with rational coordinates: parameters of the
    equation and free constants are replaced by random rational numbers as far as the relations of the family
    allow it, and the exact test is run there.  Certificate with method 'exact-points': 'pass' means an exact
    zero at these points only - it is not a proof for all values (used when the symbolic check does not
    finish).  Every point is first shown to lie on the family (the relations and non-vanishing conditions,
    specialised at the point, have a common solution: Groebner basis in all remaining symbols); if no such
    point is found, or the test at a point is not completed, the status is 'not-run' - never 'pass'."""
    cert = {"type": "substitution", "method": "exact-points", "status": "not-run", "detail": ""}
    try:
        expr, psub, relations, _syms, nonzero = solution_expression(eq, sol)
    except Exception as err:
        cert["detail"] = "could not read the solution: %s" % (err,)
        return cert
    par = list(getattr(eq, "params", []))
    try:
        (rel_num, nz_num), _rr, _rs, _bk = [None, None], None, None, None
        rel_num = [sp.expand(sp.fraction(sp.together(r))[0]) for r in relations]
        nz_num = [sp.expand(sp.fraction(sp.together(n))[0]) for n in nonzero]
    except Exception as err:
        cert["detail"] = "could not read the relations: %s" % (err,)
        return cert
    used = set(expr.free_symbols) | set(par)
    for v in list(psub.values()) + list(relations) + list(nonzero):
        used |= sp.sympify(v).free_symbols
    main = set(_main_variables(rel_num, [], par)) if rel_num else set()
    cand = sorted((s_ for s_ in used - {z} - set(psub) if s_.name != "z0"), key=lambda s_: (s_ in main, str(s_)))
    rng = random.Random(seed)
    t0 = time.monotonic()

    def left():
        return None if time_limit is None else max(1.0, time_limit - (time.monotonic() - t0))

    def radical_free(e):
        return not any(a.exp.is_Rational and not a.exp.is_Integer for a in sp.sympify(e).atoms(sp.Pow)) \
            and not sp.sympify(e).has(sp.I)

    plain = all(radical_free(e) for e in rel_num + nz_num)

    def on_family(vals):
        """True if the point is shown to lie on the family, False if not, None if not decided"""
        rr = [sp.expand(r.xreplace(vals)) for r in rel_num]
        nn = [sp.expand(n.xreplace(vals)) for n in nz_num]
        if any(n == 0 for n in nn) or any(r.is_number and r != 0 for r in rr):
            return False
        rr = [r for r in rr if r != 0]
        if not rr:
            return True if all(n.is_number for n in nn) else None if not plain else True
        if not plain:
            return None
        e_ = _family_is_empty(rr, [], par, nn, GROEBNER_LIMIT_S if time_limit is None else min(GROEBNER_LIMIT_S,
                                                                                                 left()))
        return None if e_ is None else (not e_)

    def rnd():
        return rng.choice([-1, 1]) * sp.Rational(rng.choice([3, 5, 7, 11, 13]), rng.choice([2, 4, 8]))

    def sample():
        """rational values for as many symbols as the relations allow; None if no point could be confirmed"""
        free_ = [s_ for s_ in cand if s_ not in main]
        for _try in range(6):               # all symbols outside the main variables at once (the usual case)
            vals = dict((s_, rnd()) for s_ in free_)
            if on_family(vals) is True:
                return vals
        vals = {}                           # one symbol at a time: a symbol that the relations fix stays
        for s_ in cand:
            if time_limit is not None and time.monotonic() - t0 > time_limit:
                break
            for _try in range(3):
                trial = dict(vals)
                trial[s_] = rnd()
                if on_family(trial) is True:
                    vals = trial
                    break
        return vals if vals and on_family(vals) is True else None

    shown = []
    for i in range(points):
        vals = sample()
        if vals is None:
            cert["detail"] = ("no point with rational coordinates could be shown to lie on the family (%d points "
                              "checked before): the check at points was not carried out" % len(shown))
            return cert
        psub2 = dict((k, sp.sympify(v).xreplace(vals)) for k, v in psub.items())
        psub2.update(dict((q, vals[q]) for q in par if q in vals))
        res = exact_zero_test(eq, expr.xreplace(vals), z, [r.xreplace(vals) for r in relations], psub2,
                              [n.xreplace(vals) for n in nonzero], left())
        if res["status"] == "nonzero" and not res.get("empty"):
            cert["status"] = "fail"
            cert["detail"] = "at the rational point %s: %s" % (dict((str(k), str(v)) for k, v in vals.items()),
                                                                res["detail"])
            return cert
        if res["status"] != "zero":
            cert["detail"] = "the exact check at a rational point was not completed: %s" % res["detail"]
            return cert
        shown.append(", ".join("%s = %s" % (k, v) for k, v in vals.items()))
    if len(shown) < max(1, points):
        cert["detail"] = "no point was checked"
        return cert
    cert["status"] = "pass"
    cert["detail"] = ("exact substitution at %d points of the family with rational values of %s (%s); each point "
                      "was first shown to lie on the family; this is not a proof for all values: the symbolic "
                      "check did not finish" % (len(shown), "the parameters and free constants", "; ".join(shown)))
    return cert


# ----------------------------------------------------------------------------------------------- numerics
def _mp_number(x, dps):
    """mpmath number of a numeric SymPy expression with dps digits (through decimal strings: independent of
    how the SymPy version converts its numbers)"""
    v = sp.sympify(x).evalf(dps + 10)
    re, im = v.as_real_imag()
    with mp.workdps(dps + 10):
        re, im = mp.mpf(str(sp.Float(re, dps + 10))), mp.mpf(str(sp.Float(im, dps + 10)))
        return mp.mpc(re, im) if im != 0 else re


def _num_roots(expr, sym, dps):
    """the roots of a polynomial in `sym` with numeric coefficients, to about dps digits.  The coefficients are
    read with the expression domain: a Poly with floating-point coefficients would be converted to a real or
    complex field whose precision depends on the SymPy version (53 bits in SymPy 1.13: the roots then have 16
    digits, and a residual computed from them looks like a failure)."""
    pr = sp.Poly(sp.expand(expr), sym, domain="EX")
    if pr.degree() < 1:
        return []
    coeffs = [_mp_number(c, dps) for c in pr.all_coeffs()]
    with mp.workdps(dps + 10):
        for extra, steps in ((4 * dps, 200), (10 * dps, 2000)):
            try:
                return list(mp.polyroots(coeffs, maxsteps=steps, extraprec=extra))
            except mp.libmp.libhyper.NoConvergence:
                continue
    raise ValueError("cannot sample: the roots of a relation were not found numerically")


def _rand_c(rng, scale=1):
    return sp.Rational(rng.randint(-40, 40), 37) * scale + sp.I * sp.Rational(rng.randint(-40, 40), 41) * scale \
        + sp.Rational(1, 3)


def _sample(eq, sol, rng, dps):
    """exact / high-precision values for parameters and constants that satisfy conditions and relations"""
    par = list(getattr(eq, "params", []))
    syms = dict((str(q), q) for q in par)
    syms["z"] = z
    expr = parse_expression(sol["expr"], syms.values())
    consts, roots = {}, {}
    for name, val in (sol.get("constants") or {}).items():
        if isinstance(val, str) and val.startswith("any root of"):
            roots[sp.Symbol(name)] = parse_expression(val[len("any root of"):].split("=")[0], syms.values())
        elif isinstance(val, str) and val != "free":
            consts[sp.Symbol(name)] = parse_expression(val, syms.values())
    eqs, psub = [], {}
    for text in sol.get("conditions") or []:
        a, op, b = _split_condition(text)
        if op != "==":
            continue
        lhs, rhs = parse_expression(a, syms.values()), parse_expression(b, syms.values())
        if lhs.is_Symbol and lhs in par and lhs not in rhs.free_symbols and lhs not in psub:
            psub[lhs] = rhs
        else:
            eqs.append(lhs - rhs)
    vals = {}
    # parameters: free ones random, then relations among parameters solved for one of them
    for r in eqs:
        r = r.xreplace(psub)
        free = sorted(r.free_symbols, key=str)
        if not free:
            continue
        target = free[-1]
        for s in free[:-1]:
            vals.setdefault(s, _rand_c(rng))
        rts = _num_roots(sp.fraction(sp.together(r.xreplace(vals)))[0], target, dps)
        if not rts:
            raise ValueError("cannot sample: the condition %s does not determine %s" % (r, target))
        rt = rts[rng.randrange(len(rts))]
        vals[target] = sp.Float(str(mp.re(rt)), dps) + sp.I * sp.Float(str(mp.im(rt)), dps)
    for q in par:
        if q not in psub and q not in vals:
            vals[q] = _rand_c(rng)
    for _ in range(len(psub) + 1):
        psub = dict((k, v.xreplace(psub)) for k, v in psub.items())
    for q, v in psub.items():
        vals[q] = v.xreplace(vals)
    # free constants and roots
    others = set(expr.free_symbols) | set().union(*[v.free_symbols for v in consts.values()]) if consts else \
        set(expr.free_symbols)
    for v in roots.values():
        others |= v.free_symbols
    for s in sorted(others, key=str):
        if s == z or s in vals or s in consts or s in roots:
            continue
        vals[s] = _rand_c(rng)
    cons = []
    for text in list(sol.get("constraints") or []) + list(sol.get("conditions") or []):
        a, op, b = _split_condition(text)
        if op == "!=":
            cons.append(parse_expression(a, syms.values()) - parse_expression(b, syms.values()))
    # roots: a joint choice at which all non-vanishing constraints hold (depth-first over the roots)
    order, left = [], dict(roots)
    known = set(vals)
    for _ in range(len(left) + 1):
        for s_, pol in list(left.items()):
            if not (pol.free_symbols - known - {s_}):
                order.append(s_)
                known.add(s_)
                del left[s_]
    order += list(left)                       # circular definitions: tried as they are

    def admissible(v):
        full = dict(v)
        cc = dict(consts)
        for _i in range(len(cc) + 1):
            cc = dict((k, x.xreplace(cc)) for k, x in cc.items())
        for k, x in cc.items():
            full[k] = x.xreplace(full)
        for cexpr in cons:
            cv = cexpr.xreplace(full)
            if cv.free_symbols:
                continue
            if abs(sp.N(cv, 20)) < sp.Float(10) ** (-12) * max(1, max([abs(sp.N(t_, 20)) for t_ in
                                                                    sp.Add.make_args(sp.expand(cv))] or [1])):
                return False
        return True

    def choose(i, v):
        if i == len(order):
            return v if admissible(v) else None
        s_ = order[i]
        pol2 = roots[s_].xreplace(v)
        if pol2.free_symbols - {s_}:
            raise ValueError("cannot sample: %s depends on undetermined constants" % s_)
        rts = _num_roots(sp.fraction(sp.together(pol2))[0], s_, dps)
        if not rts:
            return None
        rng.shuffle(rts)
        for rt in rts:
            v2 = dict(v)
            v2[s_] = sp.Float(str(mp.re(rt)), dps) + sp.I * sp.Float(str(mp.im(rt)), dps)
            got = choose(i + 1, v2)
            if got is not None:
                return got
        return None

    if order or cons:
        got = choose(0, vals)
        if got is None:
            raise NoAdmissibleValues("no admissible values: at every root of the relations a non-vanishing "
                                     "constraint fails (the family is empty)")
        vals = got
    for _ in range(len(consts) + 1):
        consts = dict((k, v.xreplace(consts)) for k, v in consts.items())
    for k, v in consts.items():
        vals[k] = v.xreplace(vals)
    return expr, vals


def _numeric_residual(eq, sol, dps, points, seed):
    """(largest relative residual of E, values used) at random complex points and random admissible values"""
    rng = random.Random(seed)
    terms = _eq_terms(eq)
    K = max(len(m) for m in terms) - 1
    worst = mp.mpf(0)
    with mp.workdps(dps):
        expr, vals = _sample(eq, sol, rng, dps)
        ders = [expr]
        for _ in range(K):
            ders.append(sp.diff(ders[-1], z))
        ders = [d.xreplace(vals) for d in ders]
        fs = [sp.lambdify(z, d, modules=[MP_FUNCTIONS, "mpmath"]) for d in ders]
        cof = dict((m, _mp_number(sp.sympify(c).xreplace(vals), dps)) for m, c in terms.items())
        for _ in range(points):
            zv = mp.mpc(rng.uniform(-2, 2), rng.uniform(-2, 2)) + mp.mpf("0.123")
            jv = [mp.mpmathify(f(zv)) for f in fs]
            tot, scale = mp.mpf(0), mp.mpf(0)
            for m, c in cof.items():
                t = c
                for j, e in enumerate(m):
                    if e:
                        t *= jv[j] ** e
                tot += t
                scale += abs(t)
            rel = abs(tot) / scale if scale != 0 else abs(tot)
            if not mp.isfinite(rel):
                raise ArithmeticError("the residual is not a finite number at a sampled point")
            worst = max(worst, rel)
        worst = +worst
    return worst, vals


def numeric_check(eq, sol, digits=30, points=3, seed=20261006):
    """Floating-point check of a Solution: the residual of E at random complex points for random admissible
    values of the parameters and constants, relative to the sum of the moduli of the terms of E.

    Returns {'ok': True | False | None, 'max_relative_residual': float or None, 'points': n, ...}:
      True   the residual is below 10**-(digits - 8);
      False  the residual is not small, and stays where it is when the working precision is doubled (the same
             points and values): the function is not a solution there;
      None   not run or not decided: an evaluation problem (key 'error'), or a residual that shrinks with the
             precision without reaching the tolerance (an ill-conditioned point).
    Raises NoAdmissibleValues when no values of the constants satisfy the relations and constraints (an empty
    family).  Not a certificate."""
    tol = mp.mpf(10) ** (-(digits - 8))
    dps = digits + 20
    try:
        worst, vals = _numeric_residual(eq, sol, dps, points, seed)
    except NoAdmissibleValues:
        raise
    except Exception as err:
        return {"ok": None, "max_relative_residual": None, "points": points,
                "error": "%s: %s" % (type(err).__name__, str(err)[:200])}
    out = {"ok": True, "max_relative_residual": float(worst), "points": points, "digits": dps,
           "values": dict((str(k), str(sp.N(v, 8))) for k, v in vals.items())}
    if worst < tol:
        return out
    # not small: the same computation with twice (and four times) the precision decides
    last = worst
    for factor in (2, 4):
        try:
            again, _ = _numeric_residual(eq, sol, factor * dps, points, seed)
        except NoAdmissibleValues:
            raise
        except Exception as err:
            out.update({"ok": None, "error": "%s: %s" % (type(err).__name__, str(err)[:200])})
            return out
        out["max_relative_residual"], out["digits"] = float(again), factor * dps
        if again < tol:
            out["note"] = "the residual at %d digits was %.3g (loss of precision at the sampled values)" % (
                dps, float(worst))
            return out
        if again > last * mp.mpf(10) ** (-5) and again > mp.mpf(10) ** (-(digits // 2)):
            out["ok"] = False               # the residual does not move with the precision: a real one
            out["note"] = "residual %.3g at %d digits and %.3g at %d digits" % (float(last), dps, float(again),
                                                                              factor * dps)
            return out
        last = again
    out["ok"] = None
    out["note"] = ("the residual decreases with the working precision but does not reach the tolerance: "
                   "ill-conditioned values, not decided")
    return out


def verify_expr(eq, text, var=None):
    """For the "check my solution" page: is the typed expression a solution of E = 0?

    Returns {'status': 'zero' | 'not zero' | 'undecided', 'detail': ..., 'numeric': ...}.  'zero' is exact
    (for all values of the symbols in the expression other than the variable and for the equation's
    parameters as symbols); 'not zero' is the exact test confirmed numerically at random values."""
    vname = var or getattr(eq, "var", "z") or "z"
    v = sp.Symbol(str(vname))
    par = list(getattr(eq, "params", []))
    try:
        expr = parse_expression(text, par + [v])
    except ValueError as err:
        return {"status": "undecided", "detail": str(err)}
    res = exact_zero_test(eq, expr, v)
    out = {"status": res["status"], "detail": res["detail"], "expr": str(expr)}
    if res["status"] == "zero":
        return out
    # numerical look at the residual
    num = None
    try:
        rng = random.Random(7)
        terms = _eq_terms(eq)
        K = max(len(m) for m in terms) - 1
        with mp.workdps(40):
            vals = dict((s, _rand_c(rng)) for s in sorted(expr.free_symbols | set(par), key=str) if s != v)
            ders = [expr]
            for _ in range(K):
                ders.append(sp.diff(ders[-1], v))
            fs = [sp.lambdify(v, d.xreplace(vals), modules=[MP_FUNCTIONS, "mpmath"]) for d in ders]
            worst = mp.mpf(0)
            for _ in range(3):
                zv = mp.mpc(rng.uniform(-2, 2), rng.uniform(-2, 2)) + mp.mpf("0.123")
                jv = [mp.mpmathify(f(zv)) for f in fs]
                tot, scale = mp.mpf(0), mp.mpf(0)
                for m, c in terms.items():
                    t = mp.mpmathify(sp.N(sp.sympify(c).xreplace(vals), 40))
                    for j, e in enumerate(m):
                        if e:
                            t *= jv[j] ** e
                    tot += t
                    scale += abs(t)
                worst = max(worst, abs(tot) / scale if scale != 0 else abs(tot))
            num = float(worst)
    except Exception as err:
        out["numeric_error"] = str(err)
    out["numeric"] = num
    if res["status"] == "nonzero":
        if num is not None and num > 1e-12:
            out["status"] = "not zero"
        else:
            out["status"] = "undecided"
            out["detail"] += "; the numerical residual is %s, so the exact test could not decide" % num
    else:
        if num is not None:
            out["detail"] += "; numerical relative residual at random points: %.3g (not a proof)" % num
    return out
