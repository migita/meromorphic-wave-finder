"""mero.order1 -- autonomous first-order equations F(w, w') = 0 (worker ORDER2, run of 6 October 2026).

Pure SymPy.  Public functions

    order1_answer(eq)               -> dict in the format of SCHEMA section 3 (applies/found/ruled_out/...)
    riccati_solutions(A, B, C)      -> Solution dicts for w' = A w^2 + B w + C   (all solutions)
    binomial2_solutions(P)          -> Solution dicts for w'^2 = P(w), deg P <= 4 (all nonconstant solutions)
    binomial_criterion(m, R)        -> the exact existence test for w'^m = R(w), R rational in w
    verify_carrier(E, jets, sol)    -> substitution certificate (exact) for a solution given on a carrier

Statements, proofs and sources: lemmas/order2/project note (items O1-O4).  Every closed form returned here is
checked by exact substitution (verify_carrier) before it is reported.

A solution is built on a *carrier*: polynomial variables (t = z - z0, S = exp(lam z), P = wp, Q = wp'), their
derivatives, and the relation Q^2 = 4 P^3 - g2 P - g3.  The derivative of any rational function of the carrier
variables is computed by the chain rule, and the residual is reduced modulo the relation: an exact, fast check.
"""
import sympy as sp

z = sp.Symbol('z')
w0, w1, w2 = sp.symbols('w0 w1 w2')
wp = sp.Function('wp')
wpp = sp.Function('wpp')

LIGHT_LIMIT_DEG = 12        # factorisation / root finding beyond this degree is skipped in the light engine

_CTX = {"reserved": {"z"}}  # names that auxiliary constants must avoid (parameters, jets, z); set by the entry points


def set_reserved(names):
    _CTX["reserved"] = set(str(n) for n in names) | {"z"} | set("w%d" % k for k in range(9))


def aux(name):
    """an auxiliary constant named `name`, renamed (name_1, name_2, ...) if the name is taken by a parameter,
    a jet or z"""
    res = _CTX["reserved"]
    cand, i = name, 0
    while cand in res:
        i += 1
        cand = "%s_%d" % (name, i)
    return sp.Symbol(cand)


# ----------------------------------------------------------------------------------------------- exact zero tests
def is_zero(x):
    """exact zero test: rationals, algebraic numbers, expressions in symbols"""
    x = sp.sympify(x)
    if x == 0:
        return True
    if x.is_Rational:
        return False
    x2 = sp.expand(x)
    if x2 == 0:
        return True
    if x2.free_symbols:
        x3 = sp.cancel(sp.together(x2))
        if x3 == 0:
            return True
        radical = any(isinstance(a_, sp.Pow) and not a_.exp.is_Integer for a_ in x3.atoms(sp.Pow)) or \
            x3.has(sp.exp, sp.log, sp.sin, sp.cos)
        if not radical:
            return False          # a rational function of the symbols with exact coefficients: cancel decides
        return sp.simplify(x3) == 0
    try:
        X = sp.Dummy('X')
        mp = sp.minimal_polynomial(x2, X)
        return sp.expand(mp - X) == 0
    except Exception:
        return sp.simplify(x2) == 0


def zero_status(x):
    """'zero' | 'nonzero' | 'unknown' (the last only when x depends on parameters)"""
    x = sp.sympify(x)
    if is_zero(x):
        return 'zero'
    if not sp.expand(x).free_symbols:
        return 'nonzero'
    num = sp.numer(sp.together(x))
    if sp.expand(num).free_symbols:
        return 'unknown'
    return 'nonzero'


def cond_str(x, rel):
    """'X == 0' / 'X != 0' with X the radical of the numerator (distinct irreducible factors, no numerical content)"""
    num = sp.numer(sp.together(sp.sympify(x)))
    try:
        exts = sorted(set(a for a in num.atoms(sp.Pow)
                          if a.exp.is_Rational and not a.exp.is_Integer and a.base.is_Rational), key=str)
        fl = sp.factor_list(num, extension=exts)[1] if exts else sp.factor_list(num)[1]
        facs = [f for f, _ in fl if f.free_symbols]
        if facs:
            rest = sp.Mul(*facs)
            return "%s %s 0" % (rest, rel)
    except Exception:
        pass
    x = sp.factor(num)
    c, rest = x.as_coeff_Mul()
    if rest == 1 or rest.is_number:
        rest = x
    return "%s %s 0" % (rest, rel)


def nice(x):
    """a compact exact form"""
    x = sp.sympify(x)
    try:
        if x.free_symbols:
            if sp.count_ops(x) > 40 or len(x.free_symbols) > 3:
                return sp.cancel(sp.together(x))          # factoring large symbolic expressions is too slow
            return sp.factor(sp.cancel(sp.together(x)))
        y = sp.nsimplify(sp.radsimp(x)) if x.is_number and not x.is_Rational else x
        y = sp.radsimp(sp.expand(y))
        return y if sp.count_ops(y) <= sp.count_ops(x) else x
    except Exception:
        return x


def sqrt_exact(x):
    x = nice(x)
    r = sp.sqrt(x)
    try:
        r2 = sp.sqrtdenest(r)
        return r2
    except Exception:
        return r


# ----------------------------------------------------------------------------------------------- carriers
class Carrier(object):
    """variables, derivation D (var -> expression), relations Q -> Q^2 value, display map var -> f(z)"""

    def __init__(self, D, rels=None, display=None, alg=None):
        self.D = dict(D)
        self.rels = dict(rels or {})          # {Qsym: expression for Qsym**2}
        self.display = dict(display or {})
        self.alg = dict(alg or {})            # {r: m(r)}: algebraic constants, m(r) = 0 (reduction by remainder)

    def deriv(self, expr):
        expr = sp.sympify(expr)
        return sum((sp.diff(expr, v) * dv for v, dv in self.D.items()), sp.Integer(0))

    def reduce(self, num):
        """polynomial numerator reduced modulo the relations"""
        num = sp.expand(num)
        for Qs, val in self.rels.items():
            if num.has(Qs):
                p = sp.Poly(num, Qs)
                out = sp.Integer(0)
                for (k,), co in p.terms():
                    out += co * (val ** (k // 2)) * (Qs ** (k % 2))
                num = sp.expand(out)
        for r, m in self.alg.items():
            if num.has(r):
                num = sp.expand(sp.rem(sp.Poly(num, r), sp.Poly(m, r)).as_expr())
        return num


def carrier_t():
    t = sp.Dummy('t')
    return t, Carrier({t: 1}, display={t: z - aux('z0')})


def carrier_exp(lam):
    S = sp.Dummy('S')
    return S, Carrier({S: lam * S}, display={S: sp.exp(lam * z)})


def carrier_wp(g2, g3, arg_kind='t', lam=None, zeta0=None):
    """P = wp(arg), Q = wp'(arg); arg = z - z0 ('t') or exp(lam z) - zeta0 ('exp')."""
    P, Q = sp.Dummy('P'), sp.Dummy('Q')
    rel = {Q: 4 * P ** 3 - g2 * P - g3}
    if arg_kind == 't':
        t = sp.Dummy('t')
        D = {t: 1, P: Q, Q: 6 * P ** 2 - g2 / 2}
        arg = z - aux('z0')
        disp = {t: arg, P: wp(arg, g2, g3), Q: wpp(arg, g2, g3)}
        return (t, P, Q), Carrier(D, rel, disp)
    S = sp.Dummy('S')
    zeta0 = aux('zeta0') if zeta0 is None else zeta0
    D = {S: lam * S, P: lam * S * Q, Q: lam * S * (6 * P ** 2 - g2 / 2)}
    arg = sp.exp(lam * z) - zeta0
    disp = {S: sp.exp(lam * z), P: wp(arg, g2, g3), Q: wpp(arg, g2, g3)}
    return (S, P, Q), Carrier(D, rel, disp)


def verify_carrier(E, jets, w_expr, car, extra_subs=None):
    """Substitute w = w_expr (a rational function of the carrier variables) into E(jets) = 0.
    Returns a certificate dict; status 'pass' iff the reduced numerator is identically 0."""
    try:
        ws = [sp.sympify(w_expr)]
        for _ in range(len(jets) - 1):
            ws.append(sp.together(car.deriv(ws[-1])))
        res = sp.sympify(E)
        if extra_subs:
            res = res.subs(extra_subs)
        res = res.subs(dict(zip(jets, ws)), simultaneous=True)
        num = sp.numer(sp.together(res))
        num = car.reduce(num)
        gens = [v for v in list(car.D.keys()) if num.has(v)]
        ok = True
        if num != 0:
            if gens:
                p = sp.Poly(num, *gens)
                for co in p.coeffs():
                    if not is_zero(co):
                        ok = False
                        break
            else:
                ok = is_zero(num)
        detail = "E evaluated on the carrier (derivation %s%s); reduced numerator is 0" % (
            ", ".join("%s' = %s" % (k, v) for k, v in car.D.items()),
            "; modulo " + ", ".join("%s**2 = %s" % (k, v) for k, v in car.rels.items()) if car.rels else "")
        return {"type": "substitution", "method": "symbolic", "status": "pass" if ok else "fail",
                "detail": detail if ok else "nonzero residual after reduction"}
    except Exception as exc:   # never crash the caller
        return {"type": "substitution", "method": "symbolic", "status": "not-run", "detail": "error: %s" % exc}


def verify_exact_points(E, jets, w_expr, car, extra_subs=None, npts=2, seed=20261006):
    """The substitution check at exact rational values of the remaining symbolic parameters and free constants
    (used when the symbolic check would be too heavy).  Every evaluation is exact; the points are reported."""
    import random
    rng = random.Random(seed)
    E0 = sp.sympify(E).subs(extra_subs or {})
    carvars = set(car.D.keys()) | set(car.alg.keys())
    syms = set(E0.free_symbols) | set(sp.sympify(w_expr).free_symbols)
    for v in list(car.D.values()) + list(car.rels.values()) + list(car.alg.values()):
        syms |= set(sp.sympify(v).free_symbols)
    syms = sorted(syms - set(jets) - carvars - {z}, key=str)
    pts, ok = [], True
    for _ in range(npts):
        for _try in range(20):
            vals = dict((x, sp.Rational(rng.choice([1, 2, 3, 5, 7, 11]) * rng.choice([1, -1]), rng.choice([1, 2, 3, 4, 5])))
                        for x in syms)
            S_ = lambda e: sp.sympify(e).subs(vals)
            try:
                w1 = S_(w_expr)
                car1 = Carrier(dict((k, S_(v)) for k, v in car.D.items()), dict((k, S_(v)) for k, v in car.rels.items()),
                               car.display, dict((k, S_(v)) for k, v in car.alg.items()))
                if any(sp.sympify(x).has(sp.zoo, sp.nan, sp.oo) for x in [w1] + list(car1.D.values()) + list(car1.rels.values())):
                    continue
                cert = verify_carrier(S_(E0), jets, w1, car1)
            except Exception:
                continue
            if cert["status"] == "not-run":
                continue
            pts.append(dict((str(k), str(v)) for k, v in vals.items()))
            if cert["status"] != "pass":
                ok = False
            break
        if not ok:
            break
    if not pts:
        return {"type": "substitution", "method": "exact-points", "status": "not-run", "detail": "no admissible point"}
    return {"type": "substitution", "method": "exact-points", "status": "pass" if ok else "fail",
            "detail": "E reduced to 0 exactly at the parameter points %s (carrier derivation and relations as in the "
                      "symbolic check)" % pts}


# ----------------------------------------------------------------------------------------------- Solution objects
def _latex(expr):
    s = sp.latex(expr)
    return s.replace(r'\operatorname{wpp}', r"\wp'").replace(r'\operatorname{wp}', r'\wp')


def make_solution(kind, d, w_expr, car, *, constants=None, free=None, conditions=None, ppp=None,
                  pole_orders=None, origin='live:order1', citations=None, note=None, real=None):
    expr = sp.sympify(w_expr).subs(car.display) if car is not None else sp.sympify(w_expr)
    sol = {"id": None, "kind": kind, "d": d, "expr": str(expr), "latex": _latex(expr),
           "constants": dict((str(k), str(v)) for k, v in (constants or {}).items()),
           "free": [str(f) for f in (free or [])],
           "conditions": [str(c) for c in (conditions or [])],
           "poles_per_period": ppp, "pole_orders": pole_orders or [],
           "certificate": {"type": "substitution", "method": "symbolic", "status": "not-run", "detail": ""},
           "origin": origin, "citations": citations or []}
    if note:
        sol["note"] = note
    if real:
        sol["real"] = real
    sol["_carrier"] = (w_expr, car)
    return sol


def finalize(solutions, E, jets, prefix='s', extra_subs=None, deadline=None):
    """verify every solution on its carrier, number them, drop internal fields; after `deadline` (a time.time()
    value) the checks are not run (status not-run: the caller moves such items to not_decided)"""
    import time as _time
    out = []
    for i, s in enumerate(solutions):
        s = dict(s)
        wc = s.pop("_carrier", None)
        subs = dict(extra_subs or {})
        subs.update(s.pop("_subs", None) or {})
        if _CTX.get("keep_carrier") and wc is not None:
            s["_carrier_obj"] = wc            # test device only (not JSON): the closed form on its carrier
        if wc is not None and wc[1] is not None and subs:
            car0 = wc[1]
            S_ = lambda x: sp.sympify(x).subs(subs)
            car1 = Carrier(dict((k, S_(v)) for k, v in car0.D.items()), dict((k, S_(v)) for k, v in car0.rels.items()),
                           dict((k, S_(v)) for k, v in car0.display.items()), dict((k, S_(v)) for k, v in car0.alg.items()))
            wc = (S_(wc[0]), car1)
            if _CTX.get("keep_carrier"):
                s["_carrier_obj"] = wc
            ex = sp.sympify(wc[0]).subs(car1.display)
            s["expr"], s["latex"] = str(ex), _latex(ex)
        if wc is not None and wc[1] is not None and s["certificate"]["status"] == "not-run" and \
                deadline is not None and _time.time() > deadline:
            s["certificate"] = {"type": "substitution", "method": "symbolic", "status": "not-run",
                                "detail": "time limit of this call"}
        elif wc is not None and wc[1] is not None and s["certificate"]["status"] == "not-run":
            Eparams = set(sp.sympify(E).subs(subs).free_symbols) - set(jets) if subs else set(sp.sympify(E).free_symbols) - set(jets)
            heavy = bool(Eparams) and (bool(wc[1].rels) or bool(wc[1].alg) or sp.count_ops(wc[0]) > 80)
            if heavy:
                s["certificate"] = verify_exact_points(E, jets, wc[0], wc[1], extra_subs=subs or None)
            else:
                s["certificate"] = verify_carrier(E, jets, wc[0], wc[1], extra_subs=subs or None)
            if subs and s["certificate"]["status"] == "pass" and "stratum" not in s["certificate"]["detail"]:
                s["certificate"]["detail"] += " (on the stratum %s)" % ", ".join("%s = %s" % kv for kv in subs.items())
        elif wc is not None and wc[1] is None and s["kind"] == "constant":
            val = sp.sympify(wc[0])
            res = sp.sympify(E).subs(subs).subs(dict((j, (val if k == 0 else 0)) for k, j in enumerate(jets)))
            s["certificate"] = {"type": "substitution", "method": "symbolic",
                                "status": "pass" if is_zero(res) else "fail",
                                "detail": "constant: E(c, 0, ..., 0) = 0"}
        s["id"] = "%s%d" % (prefix, i + 1)
        normalize_constants(s)
        out.append(s)
    return out


def normalize_constants(s):
    """every auxiliary symbol of `expr` (a symbol that is not a parameter, a jet or z) is listed in `constants`:
    "free" (a remark may follow after a semicolon) or "any root of <polynomial in the name> = 0"; `free` lists the
    free ones.  Entries for symbols that do not occur in `expr` are dropped."""
    try:
        ex = sp.sympify(s["expr"], locals={"wp": wp, "wpp": wpp, "z": z})
    except Exception:
        return s
    res = _CTX["reserved"]
    names = sorted(set(str(x) for x in ex.free_symbols) - res)
    old = dict(s.get("constants", {}))
    new = {}
    for n in names:
        v = str(old.get(n, "free"))
        if v.startswith("any root of"):
            new[n] = v
            continue
        rem = v
        for pre in ("free", ",", ";", " "):
            if rem.startswith(pre):
                rem = rem[len(pre):]
        rem = rem.strip().lstrip(",;").strip()
        new[n] = "free" + ("; " + rem if rem else "")
    s["constants"] = new
    s["free"] = [n for n in names if new[n].startswith("free")]
    return s


def constant_solutions(poly_in_w0, origin='live:order1', conditions=None):
    """constant solutions w = c, c a root of poly_in_w0 (a polynomial in w0).  Linear and quadratic factors give
    explicit roots; an irreducible factor of degree >= 3 gives one item 'r = any root of q(r)'."""
    poly_in_w0 = sp.expand(poly_in_w0)
    if poly_in_w0 == 0:
        c_ = aux('c')
        s = make_solution("constant", 0, c_, None, constants={str(c_): 'free'}, free=[str(c_)],
                          conditions=conditions, origin=origin, note="every constant is a solution")
        s["certificate"] = {"type": "substitution", "method": "symbolic", "status": "pass",
                            "detail": "E(c, 0, ..., 0) = 0 identically"}
        return [s]
    if not poly_in_w0.has(w0):
        return []
    out = []
    try:
        facs = sp.factor_list(poly_in_w0, w0)[1]
    except Exception:
        facs = [(poly_in_w0, 1)]
    for fac, _m in facs:
        fp = sp.Poly(fac, w0)
        if fp.degree() <= 0:
            continue
        if fp.degree() <= 2:
            for r in sp.roots(fp, multiple=False):
                r = nice(r)
                s = make_solution("constant", 0, r, None, conditions=conditions, origin=origin)
                s["_carrier"] = (r, None)
                out.append(s)
            continue
        r = aux('r')
        s = make_solution("constant", 0, r, None, constants={str(r): 'any root of %s = 0' % fac.subs(w0, r)},
                          conditions=conditions, origin=origin,
                          note="constant solutions: the roots of the displayed polynomial")
        s["certificate"] = {"type": "substitution", "method": "symbolic", "status": "pass",
                            "detail": "w = r with E(r, 0, ...) a multiple of q(r) = 0"}
        s.pop("_carrier", None)
        out.append(s)
    return out


def _drop_known_nonzero(num, nonzero):
    """irreducible factors of num that do not occur among the factors of the expressions known to be nonzero"""
    banned = set()
    for x in nonzero or []:
        try:
            for fac, _ in sp.factor_list(sp.numer(sp.together(sp.sympify(x))))[1]:
                banned.add(sp.expand(fac))
                banned.add(sp.expand(-fac))
        except Exception:
            pass
    keep = []
    try:
        exts = sorted(set(a for a in sp.sympify(num).atoms(sp.Pow)
                          if a.exp.is_Rational and not a.exp.is_Integer and a.base.is_Rational), key=str)
        fl = sp.factor_list(num, extension=exts)[1] if exts else sp.factor_list(num)[1]
        for fac, _ in fl:
            if not fac.free_symbols:
                continue
            if sp.expand(fac) in banned:
                continue
            keep.append(fac)
    except Exception:
        keep = [num]
    return keep


def solve_for_param(expr, params=None, nonzero=None):
    """Solutions of expr = 0 for one parameter, as a list of substitution dicts.  The numerator is split into
    irreducible factors; factors known to be nonzero (from `nonzero`) are dropped; for every remaining factor a
    parameter in which it is linear is preferred, otherwise one of degree <= 4 with explicit roots.
    None if some factor cannot be solved this way."""
    num = sp.numer(sp.together(sp.sympify(expr)))
    facs = _drop_known_nonzero(num, nonzero)
    if not facs:
        return []
    out = []
    for fac in facs:
        syms = sorted(fac.free_symbols if params is None else (fac.free_symbols & set(params)), key=str)
        best = None
        for s in syms:
            try:
                pol = sp.Poly(fac, s)
            except Exception:
                continue
            dg = pol.degree()
            if dg == 1:
                lc_ok = zero_status(pol.LC()) == 'nonzero'
                score = 0 if lc_ok else 1
                if best is None or score < best[1]:
                    best = (s, score)
            elif dg == 2 and (best is None or best[1] > 1 + dg):
                best = (s, 1 + dg)
        if best is None:
            return None
        try:
            sols = sp.solve(fac, best[0], dict=True)
        except Exception:
            return None
        if not sols:
            return None
        for d in sols:
            for v in d.values():
                if any(isinstance(a_, sp.Pow) and not a_.exp.is_Integer and a_.base.free_symbols
                       for a_ in sp.sympify(v).atoms(sp.Pow)):
                    return None       # a radical of the parameters: such strata are left to numeric input
        out += [dict((k, nice(v)) for k, v in d.items()) for d in sols if d]
    return out or None


# ----------------------------------------------------------------------------------------------- Riccati
REF_RICCATI = "classical (separation of variables); e.g. Hille, Ordinary Differential Equations in the Complex Domain (1976), ch. 4"
REF_WW = "Whittaker and Watson, A Course of Modern Analysis, sec. 20.6 (Weierstrass's formula for the quartic)"


def riccati_solutions(A, B, C, origin='live:order1', conditions=None):
    """All nonconstant solutions of w' = A w^2 + B w + C (constant coefficients, numbers or expressions that
    are nonzero/zero as decided by zero_status; 'unknown' is treated as generic and recorded as a condition).
    Returns (solutions, special_strata)."""
    A, B, C = [sp.sympify(x) for x in (A, B, C)]
    conds = list(conditions or [])
    special = []
    sols = []
    K, z0 = aux('K'), aux('z0')
    sA = zero_status(A)
    if sA == 'zero':
        sB = zero_status(B)
        if sB == 'zero':
            if zero_status(C) == 'zero':
                return sols, special
            t, car = carrier_t()
            sols.append(make_solution("polynomial", 1, C * t, car, free=['z0'],
                                      conditions=conds, ppp=None, pole_orders=[], origin=origin,
                                      citations=[REF_RICCATI]))
            return sols, special
        if sB == 'unknown':
            special.append({"conditions": [cond_str(B, "==")], "note": "linear coefficient vanishes"})
            conds = conds + [cond_str(B, "!=")]
        S, car = carrier_exp(B)
        sols.append(make_solution("simply-periodic", 1, -C / B + K * S, car, constants={'K': 'free'}, free=['K'],
                                  conditions=conds, ppp=0, pole_orders=[], origin=origin, citations=[REF_RICCATI],
                                  note="entire (an exponential); K = 0 gives the constant"))
        return sols, special
    if sA == 'unknown':
        special.append({"conditions": [cond_str(A, "==")], "note": "the equation becomes linear"})
        conds = conds + [cond_str(A, "!=")]
    Delta = nice(B ** 2 - 4 * A * C)
    sD = zero_status(Delta)
    if sD != 'zero':
        if sD == 'unknown':
            special.append({"conditions": [cond_str(Delta, "==")], "note": "double root: rational solutions"})
        sq = sqrt_exact(Delta)
        r1 = nice((-B + sq) / (2 * A))
        r2 = nice((-B - sq) / (2 * A))
        lam = nice(A * (r1 - r2))            # = sqrt(Delta)
        S, car = carrier_exp(lam)
        sols.append(make_solution("simply-periodic", 1, (r1 - r2 * K * S) / (1 - K * S), car,
                                  constants={'K': 'free'}, free=['K'],
                                  conditions=conds + ([cond_str(Delta, "!=")] if sD == 'unknown' else []),
                                  ppp=1, pole_orders=[1], origin=origin, citations=[REF_RICCATI],
                                  note="rational in exp(%s z); K = 0 and K = oo give the constants %s, %s" % (lam, r1, r2)))
    if sD in ('zero', 'unknown'):
        r = nice(-B / (2 * A))
        t, car = carrier_t()
        s_rat = make_solution("rational", 1, r - 1 / (A * t), car, free=[],
                              conditions=conds + ([cond_str(Delta, "==")] if sD == 'unknown' else []),
                              ppp=None, pole_orders=[1], origin=origin, citations=[REF_RICCATI])
        if sD == 'unknown':
            subl = solve_for_param(Delta, nonzero=[A])
            if subl == []:
                s_rat = None          # the double-root condition contradicts A != 0: no such stratum
            elif subl:
                sub0 = subl[0]
                if any(sp.sympify(v).has(sp.zoo, sp.nan, sp.oo) for v in sub0.values()):
                    s_rat = None
                else:
                    s_rat["_subs"] = sub0
                    s_rat["expr"] = str(sp.sympify(s_rat["expr"]).subs(sub0))
                    s_rat["latex"] = _latex(sp.sympify(s_rat["expr"]))
                    s_rat["conditions"] = list(conds) + ["%s == %s" % kv for kv in sub0.items()]
            else:
                s_rat["certificate"] = {"type": "substitution", "method": "symbolic", "status": "not-run",
                                        "detail": "on the stratum %s = 0 (not solved for a parameter)" % Delta}
                s_rat.pop("_carrier", None)
        if s_rat is not None:
            sols.append(s_rat)
    return sols, special


# ----------------------------------------------------------------------------------------------- w'^2 = P(w)
def _wp_invariants_cubic(P, X=None):
    """P cubic in w0: w = alpha X + beta with alpha = 4/A, beta = -B/(3A) gives P = alpha^2 (4X^3 - g2 X - g3)"""
    Pp = sp.Poly(P, w0)
    A = Pp.coeff_monomial(w0 ** 3)
    Bc = Pp.coeff_monomial(w0 ** 2)
    alpha = 4 / A
    beta = -Bc / (3 * A)
    Xs = sp.Dummy('X')
    q = sp.Poly(sp.expand(P.subs(w0, alpha * Xs + beta) / alpha ** 2), Xs)
    g2 = nice(-q.coeff_monomial(Xs))
    g3 = nice(-q.coeff_monomial(1))
    return alpha, beta, g2, g3


def weierstrass_quartic(P, x0, sqrtPx0):
    """Weierstrass's formula (Whittaker-Watson 20.6): a solution of w'^2 = P(w), P quartic, with w(0) = x0.
    Returns (w as a rational function of (P, Q), g2, g3, carrier)."""
    Pp = sp.Poly(P, w0)
    a0 = Pp.coeff_monomial(w0 ** 4)
    a1 = Pp.coeff_monomial(w0 ** 3) / 4
    a2 = Pp.coeff_monomial(w0 ** 2) / 6
    a3 = Pp.coeff_monomial(w0) / 4
    a4 = Pp.coeff_monomial(1)
    g2 = nice(a0 * a4 - 4 * a1 * a3 + 3 * a2 ** 2)
    g3 = nice(a0 * a2 * a4 + 2 * a1 * a2 * a3 - a2 ** 3 - a0 * a3 ** 2 - a1 ** 2 * a4)
    (t, Ps, Qs), car = carrier_wp(g2, g3, 't')
    f = [sp.expand(sp.diff(P, w0, k).subs(w0, x0)) for k in range(5)]
    num = sqrtPx0 * Qs + sp.Rational(1, 2) * f[1] * (Ps - f[2] / 24) + f[0] * f[3] / 24
    den = 2 * (Ps - f[2] / 24) ** 2 - f[0] * f[4] / 48
    return x0 + num / den, g2, g3, car


def _field_roots(P):
    """roots of P (polynomial in w0) that lie in the coefficient field: from linear factors of factor_list"""
    out = []
    try:
        for fac, mult in sp.factor_list(P, w0)[1]:
            fp = sp.Poly(fac, w0)
            if fp.degree() == 1:
                out.append((nice(-fp.coeff_monomial(1) / fp.coeff_monomial(w0)), mult))
    except Exception:
        pass
    return out


def binomial2_solutions(P, origin='live:order1', conditions=None, label='w'):
    """All nonconstant solutions of w'^2 = P(w0), P a polynomial (numbers or symbols) of degree <= 4.
    Returns (solutions, notes).  For deg P >= 5 returns ([], [reason])."""
    P = sp.expand(sp.sympify(P))
    conds = list(conditions or [])
    if P == 0:
        return [], ["w' = 0: constants only"]
    Pp = sp.Poly(P, w0)
    N = Pp.degree()
    if N >= 5:
        return [], ["deg P = %d >= 5: a pole would have order 2/(deg P - 2), not an integer, and every nonconstant "
                    "solution has a pole (statement O2): only constants" % N]
    A = Pp.LC()
    sols = []
    K, z0 = aux('K'), aux('z0')
    cit = [REF_RICCATI, REF_WW]
    # square case: P = A Q(w)^2  ->  w' = +- sqrt(A) Q(w)
    try:
        sq = sp.sqf_list(P, w0)
        mults = [m for _, m in sq[1]]
    except Exception:
        sq, mults = None, [1]
    if sq is not None and all(m % 2 == 0 for m in mults):
        Qw = sp.Integer(1)
        for fac, m in sq[1]:
            Qw *= fac ** (m // 2)
        cQ = sq[0]
        sA = sqrt_exact(cQ)
        out = []
        for sign in (1, -1):
            q = sp.Poly(sp.expand(sign * sA * Qw), w0)
            Aq = q.coeff_monomial(w0 ** 2) if q.degree() >= 2 else 0
            Bq = q.coeff_monomial(w0) if q.degree() >= 1 else 0
            Cq = q.coeff_monomial(1)
            ss, _ = riccati_solutions(Aq, Bq, Cq, origin=origin, conditions=conds)
            for s in ss:
                s["note"] = (s.get("note", "") + "; branch w' = %s" % sp.expand(sign * sA * Qw)).strip("; ")
            out += ss
        return out, ["P is a constant times a square: the equation splits into w' = +-sqrt(A) Q(w)"]
    if N == 1:
        a = nice(-Pp.coeff_monomial(1) / A)
        t, car = carrier_t()
        sols.append(make_solution("polynomial", 1, a + A * t ** 2 / 4, car, free=['z0'], conditions=conds,
                                  origin=origin, citations=cit))
        return sols, []
    if N == 2:
        Bc = Pp.coeff_monomial(w0)
        Cc = Pp.coeff_monomial(1)
        Delta = nice(Bc ** 2 - 4 * A * Cc)
        lam = sqrt_exact(A)
        S, car = carrier_exp(lam)
        sols.append(make_solution("simply-periodic", 1, -Bc / (2 * A) + K * S + Delta / (16 * A ** 2 * K * S), car,
                                  constants={'K': 'free, nonzero'}, free=['K'], conditions=conds, ppp=0,
                                  pole_orders=[], origin=origin, citations=cit,
                                  note="entire; a cosh: w = -B/(2A) + sqrt(Delta)/(2A) cosh(sqrt(A)(z - z0)), Delta = B^2 - 4AC"))
        return sols, []
    multi = [(f, m) for f, m in (sq[1] if sq else []) if m >= 2]
    if N == 3:
        if not multi:
            alpha, beta, g2, g3 = _wp_invariants_cubic(P)
            (t, Ps, Qs), car = carrier_wp(g2, g3, 't')
            sols.append(make_solution("elliptic", 1, alpha * Ps + beta, car, free=['z0'], conditions=conds, ppp=1,
                                      pole_orders=[2], origin=origin, citations=cit,
                                      note="g2^3 - 27 g3^2 = %s" % nice(g2 ** 3 - 27 * g3 ** 2)))
            return sols, []
        fac, m = multi[0]
        a = nice(sp.solve(fac, w0)[0])
        if m == 3:
            t, car = carrier_t()
            sols.append(make_solution("rational", 1, a + 4 / (A * t ** 2), car, free=['z0'], conditions=conds,
                                      pole_orders=[2], origin=origin, citations=cit))
            return sols, []
        b = nice(-Pp.coeff_monomial(w0 ** 2) / A - 2 * a)      # P = A (w - a)^2 (w - b)
        lam = sqrt_exact(A * (a - b))                           # S = exp(2 mu z), mu^2 = A (a - b)/4
        S, car = carrier_exp(lam)
        sols.append(make_solution("simply-periodic", 1, a + 4 * (b - a) * K * S / (1 + K * S) ** 2, car,
                                  constants={'K': 'free, nonzero'}, free=['K'], conditions=conds, ppp=1,
                                  pole_orders=[2], origin=origin, citations=cit,
                                  note="a sech^2: w = a + (b - a) sech^2(sqrt(A (a - b)) (z - z0)/2)"))
        return sols, []
    # N == 4
    if multi:
        fac, m = multi[0]
        if sp.Poly(fac, w0).degree() == 1:
            a = nice(sp.solve(fac, w0)[0])
            u = sp.Dummy('u')
            H = sp.expand(sp.cancel(u ** 4 * P.subs(w0, a + 1 / u)))
            Hw = H.subs(u, w0)
            inner, _ = binomial2_solutions(Hw, origin=origin, conditions=conds)
            for s in inner:
                wexpr, car = s["_carrier"]
                new = make_solution(s["kind"] if s["kind"] != "polynomial" else "rational", 1, a + 1 / wexpr, car,
                                    constants=dict((k, v) for k, v in s["constants"].items()), free=s["free"],
                                    conditions=conds, ppp=s["poles_per_period"], pole_orders=[1], origin=origin,
                                    citations=cit, note="w = %s + 1/u with u'^2 = %s" % (a, sp.factor(H)))
                if new["kind"] == "simply-periodic":
                    new["poles_per_period"] = 2 if sp.Poly(H, u).degree() == 2 else 1
                sols.append(new)
            return sols, ["double root %s: w = %s + 1/u reduces the degree" % (a, a)]
    roots = _field_roots(P)
    if roots:
        e = roots[0][0]
        u = sp.Dummy('u')
        H = sp.expand(sp.cancel(u ** 4 * P.subs(w0, e + 1 / u)))
        alpha, beta, g2, g3 = _wp_invariants_cubic(H.subs(u, w0))
        (t, Ps, Qs), car = carrier_wp(g2, g3, 't')
        sols.append(make_solution("elliptic", 1, e + 1 / (alpha * Ps + beta), car, free=['z0'], conditions=conds,
                                  ppp=2, pole_orders=[1], origin=origin, citations=cit,
                                  note="w = %s + 1/u, u'^2 = %s (cubic)" % (e, sp.factor(H))))
        return sols, []
    x0 = sp.Integer(0)
    sq0 = sqrt_exact(P.subs(w0, 0))
    wexpr, g2, g3, car = weierstrass_quartic(P, x0, sq0)
    sols.append(make_solution("elliptic", 1, wexpr, car, free=['z0'], conditions=conds, ppp=2, pole_orders=[1],
                              origin=origin, citations=cit, note="Weierstrass's formula with w(z0) = 0"))
    return sols, []


# ----------------------------------------------------------------------------------------------- criterion
def binomial_criterion(m, R):
    """w'^m = R(w0), R a nonzero rational function of w0.  Statement O3 (lemmas/order2/project note):
    a nonconstant meromorphic solution exists iff every root of multiplicity k < m (poles of R count with
    k < 0) has (m - k) | m, and, with N = deg num - deg den, either N <= m or (N - m) | m."""
    R = sp.cancel(sp.together(sp.sympify(R)))
    num, den = sp.fraction(R)
    data = {"m": m, "roots": [], "N": None}
    ok = True
    cone, ends = [], []
    for poly, sign in ((num, 1), (den, -1)):
        if not sp.sympify(poly).has(w0):
            continue
        for fac, mult in sp.sqf_list(poly, w0)[1]:
            k = sign * mult
            dg = sp.Poly(fac, w0).degree()
            entry = {"factor": str(fac), "multiplicity": k, "number_of_roots": dg}
            if k < m:
                if m % (m - k) == 0:
                    s = m // (m - k)
                    entry["ramification"] = s
                    if s > 1:
                        cone += [s] * dg
                else:
                    entry["ramification"] = "not an integer (%d/%d)" % (m, m - k)
                    ok = False
            else:
                entry["ramification"] = "omitted value (end of angle %s*2*pi)" % sp.Rational(m - k, m)
                ends += [sp.Rational(m - k, m)] * dg
            data["roots"].append(entry)
    N = (sp.Poly(num, w0).degree() if num.has(w0) else 0) - (sp.Poly(den, w0).degree() if den.has(w0) else 0)
    data["N"] = N
    if N > m:
        if m % (N - m) == 0:
            s = m // (N - m)
            data["infinity"] = {"pole_order": s}
            if s > 1:
                cone.append(s)
        else:
            data["infinity"] = {"pole_order": "not an integer (%d/%d)" % (m, N - m)}
            ok = False
    else:
        data["infinity"] = {"pole_order": None, "note": "no poles (end of angle %s*2*pi)" % sp.Rational(N - m, m)}
        ends.append(sp.Rational(N - m, m))
    data["holds"] = ok
    if ok:
        cone.sort()
        if not ends:
            data["type"] = "elliptic, orbifold signature %s" % (tuple(cone),)
            data["kind"] = "elliptic"
        elif any(e == 0 for e in ends):
            data["type"] = "simply periodic (cylinder%s)" % (" with two cone points of order 2" if cone else "")
            data["kind"] = "simply-periodic"
        else:
            data["type"] = "rational (plane%s)" % ((" mod Z_%d" % cone[0]) if cone else "")
            data["kind"] = "rational"
    return data


# ----------------------------------------------------------------------------------------------- equation adapter
def jets_and_E(eq):
    """(K, E, params) with E a SymPy polynomial in the module's symbols w0, w1, ... ; accepts mero Equation
    objects (CORE or bootstrap), strings in jets 'w0, w1, ...' (or 'E = 0' / 'lhs = rhs'), and dicts."""
    if isinstance(eq, dict):
        try:
            from mero.equation import Equation as _Eq            # noqa
            eq = _Eq.from_dict(eq)
        except Exception:
            eq = eq.get("sympy") or eq.get("E") or eq.get("ode")
    if isinstance(eq, str):
        txt = eq
        E = None
        try:
            from mero.parse import parse_ode                       # CORE's parser, if present
            eq = parse_ode(txt)
        except Exception:
            loc = dict(("w%d" % k, sp.Symbol("w%d" % k)) for k in range(9))
            loc.update({"wp": wp, "wpp": wpp})
            if "=" in txt and "==" not in txt:
                l, r = txt.split("=", 1)
                E = sp.sympify(l, locals=loc) - sp.sympify(r, locals=loc)
            else:
                E = sp.sympify(txt.replace("==", "-(") + (")" if "==" in txt else ""), locals=loc)
            E = sp.expand(E)
            if E.atoms(sp.Float):
                E = sp.expand(sp.nsimplify(E, rational=True))
            jets = sorted([s for s in E.free_symbols if s.name.startswith('w') and s.name[1:].isdigit()],
                          key=lambda s: int(s.name[1:]))
            K = max([int(s.name[1:]) for s in jets] + [0])
            params = sorted([s for s in E.free_symbols if s not in jets], key=str)
            return K, E, params
    K = int(getattr(eq, 'K'))
    jets = list(getattr(eq, 'w'))
    E = getattr(eq, 'E', None)
    if E is None:
        E = jets[K] - eq.rhs
    mine = sp.symbols('w0:%d' % (K + 1))
    E = sp.expand(sp.sympify(E).subs(dict(zip(jets, mine)), simultaneous=True))
    if E.atoms(sp.Float):
        E = sp.expand(sp.nsimplify(E, rational=True))
    params = [sp.Symbol(str(p)) for p in getattr(eq, 'params', [])]
    params = sorted(set(params) | (E.free_symbols - set(mine)), key=str)
    return K, E, params


# ----------------------------------------------------------------------------------------------- order 1 answer
def _first_order_factor(G, origin):
    """decide one irreducible factor G(w0, w1); returns dict with found / ruled_out / not_decided / complete"""
    out = {"found": [], "ruled_out": [], "not_decided": [], "complete": True, "notes": [], "basis": []}
    Gp = sp.Poly(G, w1)
    degs = [mon[0] for mon in Gp.monoms()]
    out["found"] += constant_solutions(sp.expand(G.subs(w1, 0)), origin=origin)
    if Gp.degree() == 0:
        return out
    nz = [k for k in degs if k > 0]
    if len(degs) == 1 and degs[0] > 0:            # G = g(w0) w1^m, irreducible => G = c*w1
        out["notes"].append("w' = 0: every constant")
        return out
    if len(degs) == 2 and 0 in degs:
        m = max(degs)
        R = sp.cancel(-Gp.coeff_monomial(1) / Gp.coeff_monomial(w1 ** m))
        crit = binomial_criterion(m, R)
        out["criterion"] = crit
        out["basis"].append("lemma:order2/O3")
        if not crit["holds"]:
            lab = ("published" if m <= 2 else "agent-proof")
            src = ("Malmquist (1913, m = 1) / Yosida (1933, m = 2): a transcendental solution forces R to be a "
                   "polynomial of degree <= 2m; rational solutions: pole order and value count (statement O3)"
                   if m <= 2 else "statement O3 (Lemma L), read by a second agent (project file)")
            out["ruled_out"].append({"what": "nonconstant meromorphic solutions of %s = %s" % ("w'" if m == 1 else "w'^%d" % m, R),
                                     "basis": {"theorem": "lemma:order2/O3", "label": lab, "source": src},
                                     "certificate": {"type": "binomial-criterion", "data": crit}, "conditions": []})
            return out
        num, den = sp.fraction(R)
        gm = Gp.coeff_monomial(w1 ** m)
        lc = sp.Poly(gm, w0).LC() if gm.has(w0) else gm
        sconds = [cond_str(lc, "!=")] if zero_status(lc) == 'unknown' else []
        if sconds:
            out["notes"].append("the coefficient %s of w'^%d is assumed nonzero" % (lc, m))
        if m == 1 and not den.has(w0):
            Pp = sp.Poly(num / den, w0)
            co = [Pp.coeff_monomial(w0 ** k) for k in (2, 1, 0)]
            ss, special = riccati_solutions(co[0], co[1], co[2], origin=origin, conditions=sconds)
            out["found"] += ss
            out["basis"].append("lemma:order2/O1")
            return out
        if m == 2 and not den.has(w0):
            ss, notes = binomial2_solutions(sp.expand(num / den), origin=origin, conditions=sconds)
            out["found"] += ss
            out["notes"] += notes
            out["basis"].append("lemma:order2/O2")
            return out
        out["complete"] = False
        out["exists"] = True
        out["not_decided"].append({"what": "nonconstant meromorphic solutions of w'^%d = %s" % (m, R),
                                   "why": "the necessary condition of statement O3 holds; closed forms and the "
                                          "existence statement are not produced for m >= 3",
                                   "partial": "if they exist they are %s (orbifold signature from the local data; "
                                              "classical Briot-Bouquet theory)" % crit.get("type")})
        return out
    out["complete"] = False
    out["not_decided"].append({"what": "nonconstant meromorphic solutions of %s = 0" % G,
                               "why": "not a binomial equation; the genus computation of the curve F(w, w') = 0 is "
                                      "not implemented in the light engine",
                               "partial": "every meromorphic solution is rational, simply periodic or elliptic "
                                          "(T-FIRSTORDER); the constant solutions are listed"})
    return out


def order1_answer(eq, origin='live:order1'):
    """complete answer for first-order equations where O1-O3 decide; never raises"""
    try:
        return _order1_answer(eq, origin)
    except Exception as exc:
        return {"applies": False, "found": [], "ruled_out": [], "not_decided": [], "basis": [],
                "verdict": {"level": "unsupported", "text": "mero.order1 failed on this input", "basis": []},
                "warnings": ["mero.order1 error: %s" % str(exc)[:300]], "module": "mero.order1"}


def _order1_answer(eq, origin='live:order1'):
    K, E, params = jets_and_E(eq)
    set_reserved([str(p_) for p_ in params])
    res = {"applies": False, "found": [], "ruled_out": [], "not_decided": [], "verdict": {}, "basis": [],
           "module": "mero.order1"}
    if K != 1 or not E.has(w1):
        res["verdict"] = {"level": "unsupported", "text": "not a first-order equation", "basis": []}
        return res
    res["applies"] = True
    try:
        c0, facs = sp.factor_list(E, w0, w1)
    except Exception:
        facs = [(E, 1)]
    complete = True
    exists = False
    found, notes = [], []
    for G, _mult in facs:
        G = sp.expand(G)
        if not G.has(w1):
            found += constant_solutions(G, origin=origin)
            continue
        part = _first_order_factor(G, origin)
        found += part["found"]
        res["ruled_out"] += part["ruled_out"]
        res["not_decided"] += part["not_decided"]
        res["basis"] += [b for b in part["basis"] if b not in res["basis"]]
        notes += part["notes"]
        if "criterion" in part:
            res.setdefault("criteria", []).append(part["criterion"])
        complete = complete and part["complete"]
        exists = exists or part.get("exists", False)
    res["found"] = finalize(found, E, list(sp.symbols('w0:2')))
    # dedupe constants
    seen, ded = set(), []
    for s in res["found"]:
        key = (s["kind"], s["expr"])
        if key in seen:
            continue
        seen.add(key)
        ded.append(s)
    for i, s in enumerate(ded):
        s["id"] = "s%d" % (i + 1)
    res["found"] = ded
    if any(s["certificate"]["status"] == "fail" for s in ded):
        res.setdefault("warnings", []).append("a substitution check failed: see the certificates")
    res["notes"] = notes
    if "T-FIRSTORDER" not in res["basis"]:
        res["basis"].insert(0, "T-FIRSTORDER")
    if complete:
        res["verdict"] = {"level": "complete",
                          "text": "every meromorphic solution is listed (first-order equation: all factors decided)",
                          "basis": list(res["basis"]) + ["certificate:substitution"]}
        res["ruled_out"].append({"what": "meromorphic solutions other than those listed",
                                 "basis": {"theorem": "lemma:order2/O0-O3", "label": "published",
                                           "source": "O1, O2 (classical integration), O3 for m <= 2 (Malmquist, Yosida)"},
                                 "certificate": {"type": "factorisation", "factors": [str(f) for f, _ in facs]},
                                 "conditions": []})
    else:
        res["verdict"] = {"level": "partial" if (any(s["kind"] != "constant" for s in ded) or exists) else "formal",
                          "text": "some factors of the equation are not decided by this module",
                          "basis": list(res["basis"])}
    res["d_summary"] = {"1": {"status": "complete" if complete else "partial",
                              "count": len([s for s in ded if s["d"] == 1])},
                        "2": {"status": "ruled out", "basis": "T-FIRSTORDER: first-order autonomous => d <= 1"},
                        "3+": {"status": "ruled out", "basis": "T-FIRSTORDER"}}
    return res
