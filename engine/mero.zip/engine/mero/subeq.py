"""mero.subeq -- Briot-Bouquet subequations: the subequation method of Musette and Conte.

A function w of class W (elliptic, rational in s = exp(nu z), rational in z) satisfies an autonomous algebraic
equation of the first order F(w, w') = 0, F = prod_i (w' - phi_i(w)) over the m preimages of a value of w
(m = the degree of w on its compact model: torus, sphere of s, sphere of z).  The degrees of the coefficients
of F are bounded by the growth of the branches phi_i as w -> oo (lemmas/subeq/project note, Lemma 1):

    pole of order p (p branches)              phi ~ w^((p+1)/p)
    end s -> 0 or s -> oo, growth order g     phi ~ w           (g branches; simply periodic solutions)
    end z -> oo, polynomial growth degree g   phi ~ w^((g-1)/g) (g branches; rational solutions)

With E_k = sum of the k largest exponents, the coefficient of w'^(m-k) has degree <= floor(E_k) in w.  For one
pole of order p and bounded ends this is the classical form

    F = sum_{k=0..p} sum_{j p + k (p+1) <= p (p+1)} a_jk w^j w'^k,     a_{0,p} = 1.

Substituting the Laurent series of the differential equation at each pole of the configuration gives a LINEAR
system for the a_jk whose coefficients are polynomials in the parameters and in the free Laurent coefficients
h_k; its solvability gives polynomial conditions.  Every F found is then turned into a closed form (one pole:
q0 + sum b_j wp^(j-2), or gamma + sum b_j T^j with T = nu/(exp(nu z) - 1) (+ end terms), or a rational
function) which is verified by exact substitution into the differential equation.

Public functions
    find_subequations(eq, config=None, local=None, budget_s=120, extra=None, closed_forms=True, depth=3) -> dict
    count_solutions(eq, config=None, budget_s=120) -> dict           (number of distinct F = solutions up to
                                                                       translation; see the docstring)
    cross_check(eq, solutions, config=None, budget_s=120, growth=(0,)) -> dict
                                                                     (claimed closed forms <-> subequations)
    exponents(config), support(config)                               the degree formulas
    subequation_of_solution(expr, config, constants=None)            F of an explicit function (exact)
    solution_config(expr, constants=None)                            configuration of an explicit W-function
Statements, proofs and the status of each output: lemmas/subeq/project note; algorithm: lemmas/subeq/project note.

config (a dict; the default is one configuration per Laurent series of the equation, bounded ends):
    {"poles": [ {"p": 2, "a0": "1", "multiplicity": 1}, ... ]   # poles in a period; an int p means "order p,
                                                                #  every leading coefficient of that order"
     "g0": 0, "ginf": 0,       # growth orders of a simply periodic solution at the ends s -> 0, s -> oo
     "g": 0}                   # degree of polynomial growth of a rational solution at z -> oo
Exact arithmetic only (SymPy polynomial rings over QQ, number fields and their fraction fields); no threads,
signals or processes; the time budget is watched with time.monotonic().
"""
import itertools
import math
import sys
import time
from fractions import Fraction

import sympy as sp
from sympy.polys.rings import ring
from sympy.polys.domains import QQ

from .equation import Equation, algebraic_atoms, algebraic_domain, exact_zero, exact_canonical
from . import laurent as _lt

__all__ = ["find_subequations", "count_solutions", "cross_check", "exponents", "support", "solution_config",
           "SolutionCount",
           "subequation_of_solution", "WSYM", "YSYM"]

WSYM = sp.Symbol("w")          # w in F(w, w')
YSYM = sp.Symbol("wp1")        # w' in F(w, w')
ZSYM = sp.Symbol("z")
Z0 = sp.Symbol("z0")
NU = sp.Symbol("nu")
TSYM = sp.Symbol("T")
G2, G3, Q0 = sp.symbols("g2 g3 q0")
PSYM, QSYM = sp.symbols("P_wp Q_wpp")      # wp, wp' in the verification ring

VERSION = "subeq/1 (2026-10-06)"
GB_SIZE_LIMIT = 60000          # characters of the input of one Groebner basis (a guard: groebner has no time limit)
GB_PARAM_LIMIT = 1500          # the same over a field of rational functions in the parameters (3 or more unknowns)


class _Budget(object):
    def __init__(self, budget_s):
        self.t0 = time.monotonic()
        self.deadline = None if budget_s is None else self.t0 + float(budget_s)

    def left(self):
        return None if self.deadline is None else max(0.0, self.deadline - time.monotonic())

    def expired(self):
        return self.deadline is not None and time.monotonic() > self.deadline

    def elapsed(self):
        return round(time.monotonic() - self.t0, 3)


class _Timeout(Exception):
    pass


class _BigInts(object):
    """lift the int <-> str digit limit of Python >= 3.11 during a computation (SymPy converts large integers
    through strings in places); the previous limit is restored on exit"""
    def __enter__(self):
        self.old = sys.get_int_max_str_digits() if hasattr(sys, "get_int_max_str_digits") else None
        if self.old is not None:
            sys.set_int_max_str_digits(0)
        return self

    def __exit__(self, *exc):
        if self.old is not None:
            sys.set_int_max_str_digits(self.old)
        return False


# ============================================================================== degree formulas
def _ends(config):
    g0 = int(config.get("g0", 0) or 0)
    ginf = int(config.get("ginf", 0) or 0)
    g = int(config.get("g", 0) or 0)
    if (g0 or ginf) and g:
        raise ValueError("config: growth at the ends s -> 0, oo (simply periodic) and polynomial growth "
                         "(rational) cannot be combined")
    return g0, ginf, g


def _pole_list(config):
    """the poles of a period one by one (multiplicities expanded): list of dicts with p, a0, ..."""
    out = []
    for P in config.get("poles", []):
        if isinstance(P, int):
            P = {"p": P}
        for _ in range(int(P.get("multiplicity", 1) or 1)):
            out.append(P)
    return out


def exponents(config):
    """the growth exponents e_i of the m branches phi_i(w) ~ w^(e_i) of F as w -> oo, sorted decreasingly
    (Fractions).  m = len(exponents) is the degree of F in w'."""
    g0, ginf, g = _ends(config)
    ex = []
    for P in _pole_list(config):
        p = int(P["p"])
        if p < 1:
            raise ValueError("config: pole orders are positive integers")
        ex += [Fraction(p + 1, p)] * p
    ex += [Fraction(1)] * (g0 + ginf)
    if g:
        ex += [Fraction(g - 1, g)] * g
    ex.sort(reverse=True)
    return ex


def support(config):
    """(m, S, bounds): m = degree of F in w', S = list of the exponent pairs (j, k) of w^j w'^k allowed in F
    (including the normalised (0, m)), bounds[k] = the largest j allowed with w'^k (= floor(E_{m-k}))."""
    ex = exponents(config)
    m = len(ex)
    E = [Fraction(0)]
    for e in ex:
        E.append(E[-1] + e)
    bounds = {}
    S = []
    for k in range(m + 1):
        jmax = int(math.floor(E[m - k]))
        bounds[k] = jmax
        for j in range(jmax + 1):
            S.append((j, k))
    return m, S, bounds


def _weight(jk, p):
    j, k = jk
    return j * p + k * (p + 1)


# ============================================================================== helpers
def _s(x):
    return str(sp.sympify(x))


def _latex(x):
    try:
        return sp.latex(sp.sympify(x))
    except Exception:
        return str(x)


def _ff(x, j):
    r = 1
    for i in range(j):
        r *= (x - i)
    return r


def _domain(atoms, syms):
    K = algebraic_domain(atoms)
    syms = sorted(set(syms), key=lambda s_: s_.name)
    return K.frac_field(*syms) if syms else K


CANON_SIZE_LIMIT = 30000       # characters: larger expressions with 4 or more parameters are not normalised


def _canon(expr, atoms=()):
    """exact normal form of a rational expression (numbers in a number field).  Normalisation only (decisions are
    made by exact ring arithmetic in _is_zero): very large expressions in many parameters are returned as they are,
    because multivariate gcds can take very long."""
    expr = sp.sympify(expr)
    if expr == 0:
        return sp.Integer(0)
    if len(expr.free_symbols) >= 4:
        try:
            if len(str(expr)) > CANON_SIZE_LIMIT:
                return expr
        except ValueError:
            return expr
    try:
        if algebraic_atoms(expr) or atoms:
            return exact_canonical(expr, atoms)
        return sp.cancel(expr)
    except Exception:
        return sp.cancel(sp.together(expr))


def _nice(expr, atoms=()):
    """display form: canonical and factorised when the expression is small (no work on huge expressions)"""
    expr = sp.sympify(expr)
    try:
        if len(str(expr)) > 4000:
            return expr
    except ValueError:
        return expr
    expr = _canon(expr, atoms)
    try:
        # factorisation for display only, and only when cheap (multivariate factorisation can be slow)
        if not algebraic_atoms(expr) and len(expr.free_symbols) <= 3 and sp.count_ops(expr) < 200:
            return sp.factor(expr)
    except Exception:
        pass
    return expr


def _short(expr, limit=4000):
    """str(expr), or a placeholder when it is too long to be shown"""
    try:
        s = str(expr)
    except ValueError:
        return "(expression with more than 4300 digits)"
    return s if len(s) <= limit else s[:limit] + " ... (%d characters)" % len(s)


_RKEY = {}


def _rkey_split(b):
    """(key, ratio) with b = ratio * key, ratio a positive rational number and key a canonical radicand
    (expanded primitive numerator / expanded primitive denominator after cancellation; no factorisation), so that
    sqrt(8*a*(c-1)*(c+1)) and sqrt(a*c**2 - a) are recognised as 2*sqrt(2) times the same radical"""
    b = sp.sympify(b)
    r = _RKEY.get(b)
    if r is None:
        try:
            num, den = sp.fraction(sp.cancel(b))

            def prim(x):
                x = sp.expand(x)
                if not x.free_symbols:
                    return x, sp.Integer(1)
                return sp.primitive(x)
            cn, pn = prim(num)
            cd, pd = prim(den)
            ratio = sp.Rational(cn) / sp.Rational(cd)
            key = pn / pd
            if ratio < 0:
                ratio, key = -ratio, -key
            r = (key, ratio)
        except Exception:
            r = (b, sp.Integer(1))
        if len(_RKEY) > 5000:
            _RKEY.clear()
        _RKEY[b] = r
    return r


def _rkey(b):
    if not sp.sympify(b).free_symbols:
        return sp.sympify(b)
    return _rkey_split(b)[0]


def _replace_radicals(expr, rep):
    """replace b**(k/2) by ratio**(k/2) * s**k where rep maps canonical radicands to symbols"""
    def repl(n):
        if n.base.free_symbols:
            key, ratio = _rkey_split(n.base)
        else:
            key, ratio = n.base, sp.Integer(1)
        return rep[key] ** n.exp.p * ratio ** sp.Rational(n.exp.p, 2)
    return sp.sympify(expr).replace(
        lambda n: n.is_Pow and n.exp.is_Rational and n.exp.q == 2 and _rkey(n.base) in rep, repl)


def _sym_sqrt_bases(expr):
    """bases b (containing symbols) of the square roots b**(k/2) in expr"""
    out = []
    for n in sp.preorder_traversal(expr):
        if n.is_Pow and n.exp.is_Rational and n.exp.q == 2 and n.base.free_symbols:
            if n.base not in out:
                out.append(n.base)
    return out


def _sqrt_to_symbols(expr, numeric=False):
    """(expr', rep) with the square roots of expressions in symbols (with numeric=True: of all non-square
    bases) replaced by Dummy symbols; rep: base -> s"""
    expr = sp.sympify(expr)
    bases = _sym_sqrt_bases(expr) if expr.has(sp.Pow) else []
    if numeric and expr.has(sp.Pow):
        for n in sp.preorder_traversal(expr):
            if n.is_Pow and n.exp.is_Rational and n.exp.q == 2 and n.base.is_Rational and n.base not in bases:
                bases.append(n.base)
    if not bases:
        return expr, {}
    keys = []
    for b in bases:
        k = _rkey(b)
        if k not in keys:
            keys.append(k)
    rep = dict((k, sp.Dummy("sq%d" % i)) for i, k in enumerate(keys))
    return _replace_radicals(expr, rep), rep


def _reduce_symbols(expr, rep):
    """reduce a rational expression in the Dummy symbols of rep modulo s^2 = base and put sqrt(base) back"""
    if not rep:
        return expr
    num, den = sp.fraction(sp.together(sp.sympify(expr)))
    def red(x):
        x = sp.expand(x)
        for b, s in rep.items():
            if x.has(s):
                P = sp.Poly(x, s)
                x = sp.expand(sum(co * b ** (e // 2) * s ** (e % 2) for (e,), co in P.terms()))
        return x
    num, den = red(num), red(den)
    back = dict((s, sp.sqrt(b)) for b, s in rep.items())
    # rationalise a denominator A + B s:  (A + B s)(A - B s) = A^2 - B^2 b
    for b, s in rep.items():
        if den.has(s):
            P = sp.Poly(den, s)
            A = P.coeff_monomial(1)
            B = P.coeff_monomial(s)
            conj = A - B * s
            num, den = red(num * conj), red(den * conj)
    return sp.cancel(num.subs(back) / den.subs(back)) if not (num.subs(back).has(sp.Pow) or den.subs(back).has(sp.Pow)) \
        else num.subs(back) / den.subs(back)


def _is_zero(expr, atoms=()):
    """exact zero test; square roots of expressions in the parameters (sqrt(D), D in Q(params) not a square) are
    handled by reduction modulo s^2 = D (sound: True only if the expression vanishes)"""
    expr = sp.sympify(expr)
    bases = _sym_sqrt_bases(expr) if expr.has(sp.Pow) else []
    if not bases:
        return exact_zero(expr, atoms)
    keys = []
    for b in bases:
        k = _rkey(b)
        if k not in keys:
            keys.append(k)
    rep = dict((k, sp.Dummy("sq%d" % i)) for i, k in enumerate(keys))
    e2 = _replace_radicals(expr, rep)
    num = sp.expand(sp.numer(sp.together(e2)))
    for b, s in rep.items():
        if not num.has(s):
            continue
        P = sp.Poly(num, s)
        red = 0
        for (e,), co in P.terms():
            red += co * b ** (e // 2) * s ** (e % 2)
        num = sp.expand(sp.numer(sp.together(red)))
    if num == 0:
        return True
    syms = list(rep.values())
    try:
        P = sp.Poly(num, *syms)
    except Exception:
        return False
    for co in P.coeffs():
        if any(co.has(s) for s in syms) or not exact_zero(co, atoms):
            return False
    return True


def _numer(expr):
    return sp.numer(sp.together(sp.sympify(expr)))


# ============================================================================== configurations
def _default_configs(eq, budget):
    """one configuration per class of Laurent series (pole order, leading coefficient), bounded ends"""
    ab = _lt.all_balances(eq)
    cfgs, notes = [], []
    for rec in ab["poles"]:
        for cls in rec["classes"]:
            cfgs.extend(_class_poles(eq, rec["p"], cls, notes))
    for rec in ab.get("special", []):
        if rec.get("p") is not None:
            notes.append({"what": "special balance of order %s" % rec["p"],
                          "why": "on the parameter condition %s == 0 a further balance appears; it is not "
                                 "treated by the default configuration" % rec.get("condition")})
    return [{"poles": [P], "g0": 0, "ginf": 0, "g": 0} for P in cfgs], notes


def _class_poles(eq, p, cls, notes):
    """pole descriptions (p, a0 explicit) for one class of leading coefficients"""
    if cls.get("free"):
        notes.append({"what": "pole of order %s with a free leading coefficient" % p,
                      "why": "the dominant terms do not fix a0; this case is not treated by subeq"})
        return []
    if cls["minpoly"] is None:
        return [{"p": int(p), "a0": cls["a0"]}]
    vals = cls.get("values")
    if vals and all(not (sp.sympify(v).free_symbols) for v in vals):
        return [{"p": int(p), "a0": v} for v in vals]
    if vals:
        try:
            ok = []
            for v in vals:
                from .equation import check_algebraic
                check_algebraic(v)
                ok.append({"p": int(p), "a0": v})
            return ok
        except ValueError:
            pass
    rp = _a0_reparametrisation(eq, cls["minpoly"])
    if rp is not None:
        A0, x, val = rp
        return [{"p": int(p), "a0": A0, "reparam": (x, val)}]
    notes.append({"what": "pole of order %s with a0 a root of %s" % (p, cls["minpoly"]),
                  "why": "the leading coefficient is algebraic over the field of the parameters; substitute "
                         "numerical values of the parameters"})
    return []


def _a0_reparametrisation(eq, minpoly):
    """a0 algebraic over Q(parameters), minpoly(a0) = 0 linear in some parameter x (e.g. a a0^2 - 2 b): then the
    leading coefficient itself is taken as a new parameter A0 and x is expressed through it (x = value).  Every
    parameter point with the coefficient of x nonzero is covered (each root a0 corresponds to one value of A0).
    Returns (A0, x, value) or None."""
    a0s = _lt.lead_symbol(eq)
    taken = set(s_.name for s_ in eq.params) | {"w", "wp1", "z", "z0", "nu", "T", "g2", "g3", "q0"}
    name = "a0"
    while name in taken:
        name += "_"
    A0 = sp.Symbol(name)
    mp = sp.expand(sp.sympify(minpoly).subs(a0s, A0))
    for x in eq.params:
        try:
            P = sp.Poly(mp, x)
        except Exception:
            continue
        if P.degree() != 1:
            continue
        c1, c0 = P.all_coeffs()
        if c1.free_symbols & {x}:
            continue
        if c1.free_symbols - {A0}:
            continue                     # prefer a coefficient that depends on a0 only (nonzero for a0 != 0)
        return A0, x, sp.cancel(-c0 / c1)
    return None


def _normalise_config(eq, config):
    """explicit configurations (list) from a user config: every pole gets an explicit a0"""
    if config is None:
        return None
    g0, ginf, g = _ends(config)
    ab = None
    notes = []
    choices = []
    for P in config.get("poles", []):
        if isinstance(P, int):
            P = {"p": P}
        mult = int(P.get("multiplicity", 1) or 1)
        if P.get("a0") is None:
            ab = ab or _lt.all_balances(eq)
            opts = []
            for rec in ab["poles"]:
                if rec["p"] == int(P["p"]):
                    for cls in rec["classes"]:
                        opts.extend(_class_poles(eq, rec["p"], cls, notes))
            if not opts:
                raise ValueError("config: the equation has no Laurent series with a pole of order %s" % P["p"])
        else:
            a0 = P["a0"]
            if isinstance(a0, str):
                from .parse import parse_jet_expression
                a0 = parse_jet_expression(a0)
            opts = [{"p": int(P["p"]), "a0": sp.sympify(a0)}]
        choices.append((opts, mult))
    # all combinations of leading coefficients (unordered within one entry)
    per_entry = []
    for opts, mult in choices:
        per_entry.append(list(itertools.combinations_with_replacement(range(len(opts)), mult)))
    out = []
    for combo in itertools.product(*per_entry):
        poles = []
        for (opts, mult), idxs in zip(choices, combo):
            for i in idxs:
                poles.append(dict(opts[i]))
        out.append({"poles": poles, "g0": g0, "ginf": ginf, "g": g})
    return out, notes


def _config_json(cfg):
    return {"poles": [{"p": P["p"], "a0": _s(P["a0"])} for P in cfg["poles"]],
            "g0": cfg.get("g0", 0), "ginf": cfg.get("ginf", 0), "g": cfg.get("g", 0)}


# ============================================================================== the linear system
def _series_products(C, Dd, S, N, R, budget=None):
    """truncated products C^j Dd^k (lists of ring elements) for (j, k) in S, length N + 1"""
    jmax = max(j for j, _ in S)
    kmax = max(k for _, k in S)

    def mul(a, b, n):
        out = [R.zero] * (n + 1)
        for i, x in enumerate(a[:n + 1]):
            if budget is not None and budget.expired():
                raise _Timeout("series products")
            if not x:
                continue
            for l in range(0, n + 1 - i):
                y = b[l] if l < len(b) else None
                if y:
                    out[i + l] += x * y
        return out
    one = [R.one] + [R.zero] * N
    Cp = [one]
    for _ in range(jmax):
        Cp.append(mul(Cp[-1], C, N))
    Dp = [one]
    for _ in range(kmax):
        Dp.append(mul(Dp[-1], Dd, N))
    prods = {}
    for (j, k) in S:
        prods[(j, k)] = mul(Cp[j], Dp[k], N) if k else Cp[j]
    return prods


def _eliminate(rows, cols, F, budget):
    """Gaussian elimination over the field F (fractions in the free coefficients).  rows: list of
    (dict col -> element, rhs).  Pivots that are nonzero constants (elements of the coefficient field of the
    parameters) are used first, in the order of `cols`; a pivot that depends on the free coefficients is used
    only when no constant pivot is left, and it is recorded as an assumption (its numerator must not vanish).
    Returns (pivot_rows (col -> (row dict, rhs)), free_cols, zero_rhs (list of residual rhs), assumptions)."""
    work = [(dict(r), b) for r, b in rows]
    used = set()
    pivots = {}
    assumptions = []
    unit_pivots = []
    todo = list(cols)

    def is_unit(x):
        return x.numer.is_ground and x.denom.is_ground

    def do_pivot(i, col):
        row, rhs = work[i]
        inv = 1 / row[col]
        row = dict((c, v * inv) for c, v in row.items() if v)
        rhs = rhs * inv
        work[i] = (row, rhs)
        used.add(i)
        pivots[col] = i
        for r in range(len(work)):
            if r == i or r in used:
                continue
            e = work[r][0].get(col)
            if not e:
                continue
            nr = dict(work[r][0])
            for c, v in row.items():
                nv = nr.get(c, F.zero) - e * v
                if nv:
                    nr[c] = nv
                else:
                    nr.pop(c, None)
            work[r] = (nr, work[r][1] - e * rhs)
    while todo:
        if budget.expired():
            raise _Timeout("elimination")
        found = None
        for col in todo:
            for i in range(len(work)):
                if i in used:
                    continue
                e = work[i][0].get(col)
                if e and is_unit(e):
                    found = (i, col)
                    break
            if found:
                break
        if found is None:
            # no constant pivot left: the first column with any nonzero entry
            for col in todo:
                cand = [i for i in range(len(work)) if i not in used and work[i][0].get(col)]
                if cand:
                    i = min(cand, key=lambda r: len(work[r][0][col].numer.terms()))
                    assumptions.append(work[i][0][col].numer)
                    found = (i, col)
                    break
        if found is None:
            break
        e = work[found[0]][0][found[1]]
        if is_unit(e):
            unit_pivots.append(e)
        do_pivot(found[0], found[1])
        todo.remove(found[1])
    free_cols = [c for c in cols if c not in pivots]
    zero_rhs = []
    for r in range(len(work)):
        if r in used:
            continue
        if work[r][0]:
            raise ArithmeticError("elimination left a nonzero row")
        if work[r][1]:
            zero_rhs.append(work[r][1])
    _eliminate.unit_pivots = unit_pivots
    return dict((c, work[i]) for c, i in pivots.items()), free_cols, zero_rhs, assumptions


def _param_pivot_factors(unit_pivots, a0s, params):
    """irreducible factors (in the parameters) of the constant pivots, other than factors of the leading
    coefficients a0 (whose vanishing removes the balance anyway)"""
    if not params:
        return []
    pset = set(params)
    skip = set()
    for a0 in a0s:
        num, den = sp.fraction(sp.together(sp.sympify(a0)))
        for x in (num, den):
            if x.free_symbols & pset:
                try:
                    for f, _ in sp.factor_list(x)[1]:
                        skip.add(sp.expand(f))
                        skip.add(sp.expand(-f))
                except Exception:
                    pass
    out = []
    for e in unit_pivots:
        try:
            ex = e.as_expr()
        except Exception:
            continue
        num, den = sp.fraction(sp.together(ex))
        for x in (num, den):
            if not (x.free_symbols & pset):
                continue
            try:
                facs = sp.factor_list(x)[1] if len(str(x)) < 400 else [(x, 1)]
            except Exception:
                facs = [(x, 1)]
            for f, _ in facs:
                f = sp.expand(f)
                if f.free_symbols & pset and f not in skip and f not in out and sp.expand(-f) not in out:
                    out.append(f)
    return out


def _back_substitute(pivot_rows, free_cols, cols, F):
    """values of the unknowns (field elements).  Every pivot row is reduced in the columns pivoted before it,
    so the values are found by repeated substitution (the dependency graph is acyclic)."""
    vals = {}
    pending = dict(pivot_rows)
    while pending:
        progress = False
        for c, (row, rhs) in list(pending.items()):
            deps = [c2 for c2 in row if c2 != c]
            if all(d in vals for d in deps):
                v = rhs
                for d in deps:
                    v = v - row[d] * vals[d]
                vals[c] = v
                del pending[c]
                progress = True
        if not progress:
            raise ArithmeticError("back substitution: free column or cycle")
    return vals


# ============================================================================== solving the conditions
def _univariate_roots(f, x, atoms, max_deg=None):
    """exact roots of a univariate polynomial expression f(x) (coefficients: numbers or rational functions of
    other symbols).  Returns (roots, complete): complete is False if some factor could not be solved exactly
    within the exact arithmetic of the engine (roots of expressions containing symbols, degree >= 3 over a
    number field, ...)."""
    f = sp.expand(_numer(f))
    if f == 0:
        return None, True
    if not f.has(x):
        return [], True
    atoms = set(atoms) | algebraic_atoms(f)
    roots, complete = [], True
    try:
        if atoms:
            K = algebraic_domain(atoms)
            other = sorted(f.free_symbols - {x}, key=lambda s_: s_.name)
            if other:
                facs = sp.factor_list(f, x, *other, extension=list(atoms))[1]
            else:
                facs = sp.Poly(f, x, domain=K).factor_list()[1]
                facs = [(fa.as_expr(), mu) for fa, mu in facs]
        else:
            facs = sp.factor_list(f)[1]
    except Exception:
        facs = [(f, 1)]
    for fac, mult in facs:
        if not fac.has(x):
            continue
        P = sp.Poly(fac, x)
        d = P.degree()
        cs = P.all_coeffs()
        if max_deg is not None and d > max_deg:
            complete = False
            continue
        if d == 1:
            roots.append(_canon(-cs[1] / cs[0], atoms))
            continue
        if d == 2 and not (fac.free_symbols - {x}):
            a, b, c = cs
            disc = _canon(b * b - 4 * a * c, atoms)
            if not algebraic_atoms(disc):
                r = sp.sqrt(disc)
                roots += [_canon((-b + r) / (2 * a)), _canon((-b - r) / (2 * a))]
                continue
            complete = False
            continue
        if d == 2 and not atoms:
            # coefficients in Q(parameters): the roots contain sqrt(D), D in Q(parameters) (not a square,
            # the factor being irreducible); later zero tests reduce modulo s^2 = D
            a, b, c = cs
            disc = sp.cancel(b * b - 4 * a * c)
            r = sp.sqrt(disc)
            roots += [(-b + r) / (2 * a), (-b - r) / (2 * a)]
            continue
        if not (fac.free_symbols - {x}) and not atoms:
            roots += [sp.CRootOf(P, i) for i in range(d)]
            continue
        complete = False
    return roots, complete


def _solve_system(polys, xs, atoms, budget, max_points=64):
    """exact solutions of a polynomial system in the variables xs (other symbols: generic parameters).

    Returns (solutions, complete, note): solutions is a list of dicts var -> value; a variable that is not
    determined by the system is absent from the dict (a free coefficient of a family).  complete is True if
    every solution is in the list (the system was decomposed exactly).  Square roots sqrt(D) of expressions in
    the parameters in the coefficients are replaced by new variables s with s^2 = D (solutions with s = sqrt(D)
    are kept)."""
    polys = [sp.sympify(q) for q in polys]
    bases = []
    syms_all = set()
    for q in polys:
        syms_all |= q.free_symbols
    with_params = bool(syms_all - set(xs))
    for q in polys:
        if not q.has(sp.Pow):
            continue
        for n in sp.preorder_traversal(q):
            if n.is_Pow and n.exp.is_Rational and n.exp.q == 2 and (n.base.free_symbols or with_params) \
                    and n.base not in bases and not (n.base.free_symbols & set(xs)):
                bases.append(n.base)
    if with_params and any(q.has(sp.I) for q in polys) and sp.Integer(-1) not in bases:
        bases.append(sp.Integer(-1))       # I = sqrt(-1) as a variable too (rational function field over QQ)
    if bases:
        keys = []
        for b in bases:
            k = _rkey(b)
            if k not in keys:
                keys.append(k)
        bases = keys
        rep = dict((b, sp.Symbol("_sq%d" % i)) for i, b in enumerate(bases))
        new = []
        for q in polys:
            q2 = _replace_radicals(q, rep)
            if sp.Integer(-1) in rep:
                q2 = q2.subs(sp.I, rep[sp.Integer(-1)])
            new.append(sp.expand(_numer(q2)))
        for b, s in rep.items():
            new.append(sp.expand(_numer(s ** 2 - b)))
        sols, complete, note = _solve_system(new, list(xs) + list(rep.values()), atoms, budget, max_points)
        out = []
        back = dict((s, sp.sqrt(b)) for b, s in rep.items())
        for so in sols:
            ok = True
            for b, s in rep.items():
                if s not in so or not _is_zero(sp.sympify(so[s]) - sp.sqrt(b), atoms):
                    ok = False
            if ok:
                out.append(dict((x, sp.sympify(v).subs(back)) for x, v in so.items() if x not in back))
        symbolic = any(sp.sympify(b).free_symbols for b in bases)
        if not symbolic:
            return out, complete, note
        return out, False, (note + "; " if note else "") + "square roots of expressions in the parameters " \
            "occur (every listed solution is checked exactly; the list may be incomplete)"
    polys = [sp.expand(_numer(q)) for q in polys]
    polys = [q for q in polys if q != 0]
    if not polys:
        return [{}], True, "no condition"
    xs = [x for x in xs if any(q.has(x) for q in polys)]
    if not xs:
        bad = [q for q in polys if not _is_zero(q, atoms)]
        return ([], True, "a condition is a nonzero constant") if bad else ([{}], True, "")
    atoms = set()
    for q in polys:
        atoms |= algebraic_atoms(q)          # only the algebraic numbers that occur (smaller domains)
    others = set()
    for q in polys:
        others |= q.free_symbols
    others = sorted(others - set(xs), key=lambda s_: s_.name)
    dom = _domain(atoms, others)
    lin = _linear_solve(polys, xs, dom, atoms, budget)
    if lin is not None:
        return lin
    if len(xs) == 1:
        x = xs[0]
        try:
            g = None
            for q in polys:
                Pq = sp.Poly(q, x, domain=dom)
                g = Pq if g is None else g.gcd(Pq)
                if g.degree() == 0:
                    break
                if budget.expired():
                    raise _Timeout("gcd")
            if g.degree() == 0:
                return [], True, "inconsistent (the conditions have no common root)"
            roots, ok = _univariate_roots(g.as_expr(), x, atoms)
            sols = [{x: r} for r in roots]
            good = [s_ for s_ in sols
                    if all(_is_zero(q.subs(s_), atoms | algebraic_atoms(s_[x])) for q in polys)]
            ok = ok and len(good) == len(sols)
            return good, ok, "" if ok else "a factor of the gcd %s was not solved exactly" % _short(g.as_expr(), 300)
        except _Timeout:
            raise
        except Exception:
            pass
    size = sum(len(str(q)) for q in polys)
    maxdeg = max(sp.Poly(q, *xs).total_degree() for q in polys)
    too_big = size > GB_SIZE_LIMIT
    if others:
        # over a field of rational functions SymPy's Buchberger algorithm can be very slow even for small inputs
        too_big = too_big or (len(xs) >= 3 and (size > GB_PARAM_LIMIT or maxdeg > 3)) or \
            (len(xs) == 2 and size > 4 * GB_PARAM_LIMIT)
    if too_big:
        return [], False, "Groebner basis not attempted (system of %d characters, degree %d, in %d unknowns over " \
                          "%s; SymPy has no time limit inside groebner; substitute numerical values of the " \
                          "parameters)" % (size, maxdeg, len(xs), dom)
    try:
        G = sp.groebner(polys, *xs, order="lex", domain=dom)
    except Exception as err:
        return [], False, "Groebner basis not computed (%s)" % err
    if budget.expired():
        raise _Timeout("groebner")
    G = list(G.exprs)
    if len(G) == 1 and not (G[0].free_symbols & set(xs)):
        return [], True, "inconsistent (the Groebner basis is {1})"
    sols = [({}, set())]          # (values, free variables) per branch
    complete = True
    note = ""
    for x in reversed(xs):
        new = []
        for sol, freev in sols:
            if budget.expired():
                raise _Timeout("solve")
            # polynomials in x whose other variables are free on this branch (later variables are solved)
            cand = []
            for g in G:
                gs = g.subs(sol) if sol else g
                gs = _canon(gs, atoms)
                if gs == 0:
                    continue
                fs = gs.free_symbols & set(xs)
                if not fs:
                    cand = None
                    break
                if x in fs and fs <= ({x} | freev):
                    cand.append(_numer(gs))
            if cand is None:          # inconsistent on this branch
                continue
            if not cand:
                new.append((dict(sol), freev | {x}))  # x is free on this branch
                continue
            f = cand[0]
            for h in cand[1:]:
                f = sp.gcd(f, h, x) if not atoms else _gcd_alg(f, h, x, atoms)
            roots, ok = _univariate_roots(f, x, atoms)
            if not ok:
                complete = False
                note = "a polynomial %s in %s was not solved exactly" % (_short(f, 300), x)
            for r in roots or []:
                s2 = dict(sol)
                s2[x] = r
                new.append((s2, freev))
        sols = new
        if len(sols) > max_points:
            return [s for s, _ in sols[:max_points]], False, "more than %d solutions" % max_points
    sols = [s for s, _ in sols]
    if any(_sym_sqrt_bases(sp.sympify(v)) for s_ in sols for v in s_.values()):
        complete = False
        note = (note + "; " if note else "") + "square roots of expressions in the parameters occur (the " \
            "solution list may be incomplete; every listed solution is checked exactly)"
    # check every polynomial on every solution (exact); a family keeps its free variables symbolic
    good = []
    for sol in sols:
        ok = True
        for q in polys:
            v = q.subs(sol) if sol else q
            if not _is_zero(v, atoms | set().union(*[algebraic_atoms(t) for t in sol.values()] or [set()])):
                ok = False
                break
        if ok:
            good.append(sol)
        else:
            complete = False
            note = (note + "; " if note else "") + "a family on which the system holds only partly was dropped"
    return good, complete, note


def _linear_solve(polys, xs, dom, atoms, budget):
    """fast path of _solve_system for a system that is linear in xs: exact Gauss-Jordan over the coefficient
    field (DomainMatrix).  Returns None if the system is not linear."""
    try:
        rows = []
        for q in polys:
            P = sp.Poly(q, *xs)
            if P.total_degree() > 1:
                return None
            d = P.as_dict()
            row = []
            for i in range(len(xs)):
                mon = tuple(1 if j == i else 0 for j in range(len(xs)))
                row.append(d.get(mon, 0))
            row.append(-d.get(tuple([0] * len(xs)), 0))
            rows.append(row)
        from sympy.polys.matrices import DomainMatrix
        M = DomainMatrix([[dom.convert(sp.sympify(x)) if x != 0 else dom.zero for x in r] for r in rows],
                         (len(rows), len(xs) + 1), dom)
        R, pivots = M.rref()
        if budget.expired():
            raise _Timeout("linear solve")
        n = len(xs)
        if n in pivots:
            return [], True, "inconsistent (linear)"
        Rl = R.to_Matrix()
        sol = {}
        free = [xs[j] for j in range(n) if j not in pivots]
        for i, pc in enumerate(pivots):
            val = Rl[i, n] - sum(Rl[i, j] * xs[j] for j in range(n) if j not in pivots)
            sol[xs[pc]] = sp.cancel(val) if not atoms else val
        return [sol], True, "" if not free else "linear family"
    except _Timeout:
        raise
    except Exception:
        return None


def _solve_incremental(eqs, xs, atoms, budget, need):
    """solve the first k equations (k = len(need), len(need)+1, ...) until every variable of `need` is determined
    on every solution, then keep the solutions that satisfy the remaining equations exactly.  Complete whenever
    the partial solves are (the solutions of a subsystem contain those of the system)."""
    eqs = [e_ for e_ in (sp.expand(sp.sympify(q)) for q in eqs) if e_ != 0]
    if not eqs:
        return [{}], True, ""
    k = min(len(eqs), max(1, len(need)))
    while True:
        if budget.expired():
            raise _Timeout("closed form")
        sols, complete, note = _solve_system(eqs[:k], xs, atoms, budget)
        if not sols:
            return sols, complete, note
        if k >= len(eqs) or all(all(x in s for x in need) for s in sols):
            good = []
            for s in sols:
                at = set(atoms)
                for v in s.values():
                    at |= algebraic_atoms(v)
                if all(_is_zero(e_.subs(s), at) for e_ in eqs[k:]):
                    good.append(s)
                elif any(sp.sympify(v).free_symbols & set(xs) for v in s.values()) or \
                        any(x not in s for x in need):
                    complete = False      # a family on which the later equations hold only partly
            return good, complete, note
        k = min(len(eqs), k + 2)


def _gcd_alg(f, h, x, atoms):
    try:
        return sp.gcd(f, h, x, extension=list(atoms))
    except Exception:
        return f


# ============================================================================== closed forms: series
def _bernoulli_x(N):
    """coefficients beta_n of x/(e^x - 1) = sum beta_n x^n (beta_1 = -1/2)"""
    b = [sp.Integer(1)]
    for n in range(1, N + 1):
        s = sp.Integer(0)
        for k in range(n):
            s += b[k] / sp.factorial(n - k + 1)
        b.append(-s)
    return b


def _wp_coeffs(K, g2, g3):
    """e_1..e_K of wp = z^-2 + sum_{n>=1} e_n z^(2n)"""
    e = [None, g2 / 20, g3 / 28]
    for k in range(3, K + 1):
        s = 0
        for i in range(1, k - 1):
            s += e[i] * e[k - 1 - i]
        e.append(sp.expand(sp.Rational(3, (2 * k + 3) * (k - 2)) * s))
    return e[:K + 1]


def _wp_deriv_coeff(i, mexp, e):
    """coefficient of z^mexp (mexp >= 0) in wp^(i)"""
    if (mexp + i) % 2:
        return 0
    n = (mexp + i) // 2
    if n < 1 or n >= len(e):
        return 0 if n < 1 else None
    return e[n] * sp.factorial(2 * n) / sp.factorial(mexp)


# ============================================================================== closed forms: verification
def _verify_elliptic(eq, q0, b, g2, g3, atoms):
    """E[w] for w = q0 + sum_j b_j wp^(j-2): exact reduction in K(params, ...)[Q, P] modulo
    Q^2 = 4P^3 - g2 P - g3.  Returns True / False."""
    exprs = [q0, g2, g3] + list(b.values()) + list(eq.terms.values())
    syms = set()
    for x in exprs:
        syms |= sp.sympify(x).free_symbols
    for x in exprs:
        atoms = set(atoms) | algebraic_atoms(x)
    dom = _domain(atoms, syms)
    R, Q, P = ring([QSYM, PSYM], dom, order="lex")
    g2r, g3r = R.from_expr(sp.sympify(g2)), R.from_expr(sp.sympify(g3))
    rel = Q ** 2 - (4 * P ** 3 - g2r * P - g3r)

    def red(f):
        return f.rem([rel]) if f else f

    def D(f):
        return red(f.diff(P) * Q + f.diff(Q) * (6 * P ** 2 - g2r / 2))
    w = R.from_expr(sp.sympify(q0))
    der = P
    jmax = max(b) if b else 2
    for j in range(2, jmax + 1):
        if j in b and b[j] != 0:
            w += R.from_expr(sp.sympify(b[j])) * der
        der = D(der)
    jets = [w]
    for _ in range(eq.K):
        jets.append(D(jets[-1]))
    tot = R.zero
    for mon, co in eq.terms.items():
        t = R.from_expr(sp.sympify(co))
        for j, e in enumerate(mon):
            if e:
                t = red(t * jets[j] ** e)
        tot += t
    tot = red(tot)
    return not tot, w


def _verify_T(eq, nu, gamma, b, ends, atoms):
    """E[w] for w = gamma + sum_j b_j T^j + sum_i u_i s^i + sum_i v_i s^-i, T = nu/(e^{nu z} - 1),
    s = 1 + nu/T.  Exact: E[w] is a rational function of T that must vanish."""
    T = TSYM
    w = sp.sympify(gamma) + sum(sp.sympify(bj) * T ** j for j, bj in b.items())
    s = 1 + nu / T
    for i, u in ends.get("u", {}).items():
        w += sp.sympify(u) * s ** i
    for i, v in ends.get("v", {}).items():
        w += sp.sympify(v) * s ** (-i)
    jets = [w]
    for _ in range(eq.K):
        jets.append(sp.together(-(T ** 2 + nu * T) * sp.diff(jets[-1], T)))
    tot = 0
    for mon, co in eq.terms.items():
        t = co
        for j, e in enumerate(mon):
            if e:
                t *= jets[j] ** e
        tot += t
    num = sp.expand(_numer(tot))
    return _is_zero(num, atoms), w


def _verify_rational(eq, w, atoms):
    res = eq.residual(w, ZSYM)
    return _is_zero(sp.together(res), atoms)


# ============================================================================== closed forms: recovery
def _elliptic_recovery(eq, p, c, atoms, budget, nmatch, extra=()):
    """w = q0 + sum_{j=2}^p b_j wp^(j-2)(z; g2, g3) from the Laurent coefficients c[0..]; None if the residue
    c[p-1] is not zero.  Returns (list of candidate dicts, complete flag, note)."""
    if p < 2 or not _is_zero(c[p - 1], atoms):
        return None
    b = {}
    for j in range(2, p + 1):
        b[j] = _canon(sp.Integer(-1) ** j * c[p - j] / sp.factorial(j - 1), atoms)
    K = (nmatch + p) // 2 + 3
    e = _wp_coeffs(K, G2, G3)
    eqs = []
    for k in range(p, min(len(c), p + nmatch + 1)):
        mexp = k - p
        tot = Q0 if mexp == 0 else 0
        for j, bj in b.items():
            if bj == 0:
                continue
            v = _wp_deriv_coeff(j - 2, mexp, e)
            if v is None:
                break
            tot += bj * v
        eqs.append(sp.expand(tot - c[k]))
    sols, complete, note = _solve_incremental(eqs, [Q0, G2, G3] + list(extra), atoms, budget,
                                              [Q0, G2, G3] + list(extra))
    out = []
    for s in sols:
        out.append({"q0": s.get(Q0, Q0), "g2": s.get(G2, G2), "g3": s.get(G3, G3), "b": b,
                    "h": dict((h, s[h]) for h in extra if h in s)})
    return out, complete, note


def _T_series_coeffs(j, M, beta, nu):
    """coefficients of (sum beta_n nu^n z^n)^j up to z^M"""
    base = [beta[n] * nu ** n for n in range(M + 1)]
    out = [sp.Integer(1)] + [sp.Integer(0)] * M
    for _ in range(j):
        new = [sp.Integer(0)] * (M + 1)
        for i, x in enumerate(out):
            if x == 0:
                continue
            for l in range(M + 1 - i):
                new[i + l] += x * base[l]
        out = [sp.expand(t) for t in new]
    return out


def _T_recovery(eq, p, c, atoms, budget, nmatch, g0=0, ginf=0, extra=()):
    """w = gamma + sum_{j=1}^p b_j T^j + sum_{i<=ginf} u_i s^i + sum_{i<=g0} v_i s^-i from the Laurent
    coefficients (nu = 0 allowed only without end terms: the rational form).  Returns (cands, complete, note)."""
    M = p + nmatch + 1
    beta = _bernoulli_x(M + 1)
    bs = [sp.Symbol("b%d_" % j) for j in range(1, p + 1)]
    gam = sp.Symbol("gamma_")
    us = [sp.Symbol("u%d_" % i) for i in range(1, ginf + 1)]
    vs = [sp.Symbol("v%d_" % i) for i in range(1, g0 + 1)]
    Tj = dict((j, _T_series_coeffs(j, M, beta, NU)) for j in range(1, p + 1))
    # the principal part is triangular in b_p, ..., b_1 (T^j = z^-j + ...): solve it first, as polynomials in nu
    bsol = {}
    for k in range(0, p):
        j0 = p - k                                 # the coefficient of z^(k-p) contains b_j0 with factor 1
        tot = 0
        for j in range(j0 + 1, p + 1):
            idx = k - p + j
            if 0 <= idx <= M:
                tot += bsol[bs[j - 1]] * Tj[j][idx]
        bsol[bs[j0 - 1]] = sp.expand(c[k] - tot)
    eqs = []
    for k in range(0, min(len(c), p + nmatch + 1)):
        mexp = k - p                               # power of z
        tot = 0
        for j in range(1, p + 1):
            idx = mexp + j
            if 0 <= idx <= M:
                tot += bs[j - 1] * Tj[j][idx]
        if mexp >= 0:
            if mexp == 0:
                tot += gam
            for i, u in enumerate(us, 1):
                tot += u * (i * NU) ** mexp / sp.factorial(mexp)
            for i, v in enumerate(vs, 1):
                tot += v * (-i * NU) ** mexp / sp.factorial(mexp)
        eqs.append(sp.expand(tot - c[k]))
    eqs = [sp.expand(e_.subs(bsol)) for e_ in eqs[p:]]
    xs = [gam] + us + vs + list(extra) + [NU]
    sols, complete, note = _solve_incremental(eqs, xs, atoms, budget, xs)
    sols2 = []
    for s in sols:
        s = dict(s)
        for bsym, bval in bsol.items():
            s[bsym] = _canon(sp.sympify(bval).subs(s), atoms) if not _sym_sqrt_bases(sp.sympify(s.get(NU, 0))) \
                else sp.expand(sp.sympify(bval).subs(s))
        sols2.append(s)
    sols = sols2
    out = []
    for s in sols:
        if NU not in s:
            complete = False
            note = (note + "; " if note else "") + "nu not determined"
            continue
        nu = s[NU]
        if (us or vs) and _is_zero(nu, atoms):
            continue
        b = dict((j, s.get(bs[j - 1], 0)) for j in range(1, p + 1))
        if any(sp.sympify(v).free_symbols & (set(xs) - set(extra)) for v in list(b.values()) + [s.get(gam, gam)]):
            complete = False
            continue
        out.append({"nu": nu, "gamma": s.get(gam, 0), "b": b,
                    "u": dict((i, s.get(u, 0)) for i, u in enumerate(us, 1)),
                    "v": dict((i, s.get(v, 0)) for i, v in enumerate(vs, 1)),
                    "h": dict((h, s[h]) for h in extra if h in s)})
    return out, complete, note


def _rational_recovery(eq, p, c, atoms, budget, nmatch, g=0):
    """w = gamma + sum_{j=1}^p beta_j z^-j + sum_{i=1}^g u_i z^i (exactly determined by the Laurent
    coefficients; consistency = the coefficients beyond agree)"""
    w = sum(c[k] * ZSYM ** (k - p) for k in range(0, min(len(c), p + g + 1)))
    return w


def _closed_forms(eq, p, coeffs, atoms, cfg, budget, nmatch):
    """closed forms for one pole of order p with the Laurent coefficients `coeffs` (h values substituted).
    Returns (list of Solution dicts (verified), notes)."""
    g0, ginf, g = cfg.get("g0", 0), cfg.get("ginf", 0), cfg.get("g", 0)
    sols, notes = [], []
    c = [sp.sympify(x) for x in coeffs]          # already canonical (computed by the caller)
    # (R) rational: the series must terminate
    if not (g0 or ginf):
        w = _rational_recovery(eq, p, c, atoms, budget, nmatch, g)
        if all(_is_zero(c[k], atoms) for k in range(p + g + 1, len(c))):
            if _verify_rational(eq, w, atoms):
                sols.append(_solution_rational(w, p, g))
    if g:
        return sols, notes
    # (E) elliptic form (residue zero), includes the degenerate g2^3 = 27 g3^2
    if not (g0 or ginf):
        er = _elliptic_recovery(eq, p, c, atoms, budget, nmatch)
        if er is not None:
            cands, complete, note = er
            if not complete:
                notes.append("elliptic form: " + note)
            for cd in cands:
                if budget.expired():
                    raise _Timeout("closed form")
                if any(sp.sympify(cd[k]).free_symbols & {Q0, G2, G3} for k in ("q0", "g2", "g3")):
                    notes.append("elliptic form: q0, g2, g3 not determined by %d coefficients" % nmatch)
                    continue
                ok, _ = _verify_elliptic(eq, cd["q0"], cd["b"], cd["g2"], cd["g3"], atoms)
                if ok:
                    disc = _canon(cd["g2"] ** 3 - 27 * cd["g3"] ** 2, atoms)
                    if disc == 0 or _is_zero(disc, atoms):
                        # degenerate: write it with exp (or as a rational function)
                        tr = _T_recovery(eq, p, c, atoms, budget, nmatch)
                        got = False
                        for cd2 in tr[0]:
                            if _is_zero(cd2["nu"], atoms):
                                continue
                            ok2, wT = _verify_T(eq, cd2["nu"], cd2["gamma"], cd2["b"], {}, atoms)
                            if ok2:
                                sols.append(_solution_T(cd2, p, 0, 0))
                                got = True
                                break
                        if not got and not sols:
                            sols.append(_solution_elliptic(cd, p, degenerate=True))
                    else:
                        sols.append(_solution_elliptic(cd, p))
            return sols, notes
    # (S) simply periodic form (residue not zero, or growth at the ends)
    tr = _T_recovery(eq, p, c, atoms, budget, nmatch, g0, ginf)
    cands, complete, note = tr
    if not complete and note:
        notes.append("simply periodic form: " + note)
    for cd in cands:
        if _is_zero(cd["nu"], atoms):
            continue
        ok, _ = _verify_T(eq, cd["nu"], cd["gamma"], cd["b"], cd, atoms)
        if ok:
            sols.append(_solution_T(cd, p, g0, ginf))
            break       # +nu and -nu describe the same function
    return sols, notes


def _family_members(eq, p, c, atoms, cfg, budget, nmatch, hs_free):
    """values of the free coefficients hs_free for which the Laurent data admit a closed form of Lemma 3
    (the free coefficients are unknowns of the closed-form systems).  Returns (list of dicts h -> value,
    complete flag, notes)."""
    g0, ginf, g = cfg.get("g0", 0), cfg.get("ginf", 0), cfg.get("g", 0)
    hs_free = list(hs_free)
    found, notes, complete = [], [], True

    def add(d):
        d = dict((h, v) for h, v in d.items() if h in hs_free)
        if not d:
            return
        for e in found:
            if set(e) == set(d) and all(_is_zero(sp.sympify(e[h]) - sp.sympify(d[h]), atoms) for h in d):
                return
        found.append(d)
    if not (g0 or ginf):
        tail = [c[k] for k in range(p + g + 1, len(c))]
        sols, ok, note = _solve_system(tail, hs_free, atoms, budget)
        complete = complete and ok
        for s in sols:
            add(s)
    if not g and not (g0 or ginf) and p >= 2:
        sols0, ok0, _ = _solve_system([c[p - 1]], hs_free, atoms, budget) if any(
            sp.sympify(c[p - 1]).has(h) for h in hs_free) else ([{}] if _is_zero(c[p - 1], atoms) else [], True, "")
        for s0 in sols0:
            c0 = [_canon(sp.sympify(x).subs(s0), atoms) if s0 else x for x in c]
            er = _elliptic_recovery(eq, p, c0, atoms, budget, nmatch, extra=[h for h in hs_free if h not in s0])
            if er is not None:
                cands, ok, note = er
                complete = complete and ok
                for cd in cands:
                    d = dict(s0)
                    d.update(cd.get("h", {}))
                    add(d)
    if not g:
        cands, ok, note = _T_recovery(eq, p, c, atoms, budget, nmatch, g0, ginf, extra=hs_free)
        complete = complete and ok
        for cd in cands:
            add(cd.get("h", {}))
    return found, complete, notes


# ============================================================================== Solution objects
def _wp_expr(cd, p):
    """w as a polynomial in wp, wpp (strings wp(z - z0, g2, g3), wpp(...))"""
    g2, g3 = cd["g2"], cd["g3"]
    P_, Q_ = sp.symbols("P_ Q_")
    # derivatives of wp as polynomials in P_, Q_
    ders = [P_, Q_]
    while len(ders) < p - 1:
        f = ders[-1]
        df = sp.expand(sp.diff(f, P_) * Q_ + sp.diff(f, Q_) * (6 * P_ ** 2 - g2 / 2))
        # reduce Q_^2
        df = sp.Poly(df, Q_)
        red = 0
        for (e,), co in df.terms():
            red += co * (4 * P_ ** 3 - g2 * P_ - g3) ** (e // 2) * Q_ ** (e % 2)
        ders.append(sp.expand(red))
    w = cd["q0"]
    for j, bj in cd["b"].items():
        w += bj * ders[j - 2]
    w = sp.expand(w)
    wps = sp.Function("wp")(ZSYM - Z0, g2, g3)
    wpps = sp.Function("wpp")(ZSYM - Z0, g2, g3)
    return w.subs({P_: wps, Q_: wpps}, simultaneous=True)


def _solution_elliptic(cd, p, degenerate=False):
    expr = _wp_expr(cd, p)
    disc = sp.simplify(cd["g2"] ** 3 - 27 * cd["g3"] ** 2)
    kind = "elliptic"
    if degenerate:
        kind = "rational" if (cd["g2"] == 0 and cd["g3"] == 0) else "simply-periodic"
    return {"kind": kind, "d": 1, "expr": str(expr), "latex": _latex(expr),
            "constants": {"g2": _s(cd["g2"]), "g3": _s(cd["g3"]), "q0": _s(cd["q0"])},
            "free": ["z0"], "conditions": [],
            "poles_per_period": 1, "pole_orders": [p],
            "certificate": {"type": "substitution", "method": "symbolic", "status": "pass",
                            "detail": "E reduced to 0 modulo wpp**2 = 4*wp**3 - g2*wp - g3 (mero.subeq)"},
            "origin": "live:subeq", "citations": [], "_form": "E", "_data": cd}


def _solution_T(cd, p, g0, ginf):
    nu = cd["nu"]
    Tz = nu / (sp.exp(nu * (ZSYM - Z0)) - 1)
    sz = sp.exp(nu * (ZSYM - Z0))
    expr = cd["gamma"] + sum(bj * Tz ** j for j, bj in cd["b"].items() if bj != 0)
    for i, u in cd.get("u", {}).items():
        expr += u * sz ** i
    for i, v in cd.get("v", {}).items():
        expr += v * sz ** (-i)
    return {"kind": "simply-periodic", "d": 1, "expr": str(expr), "latex": _latex(expr),
            "constants": {"nu": _s(nu)}, "free": ["z0"], "conditions": [],
            "poles_per_period": 1, "pole_orders": [p],
            "growth": {"g0": g0, "ginf": ginf},
            "certificate": {"type": "substitution", "method": "symbolic", "status": "pass",
                            "detail": "E[w] is a rational function of T = nu/(exp(nu*(z - z0)) - 1), "
                                      "T' = -T**2 - nu*T; its numerator is exactly 0 (mero.subeq)"},
            "origin": "live:subeq", "citations": [], "_form": "S", "_data": cd}


def _solution_rational(w, p, g):
    expr = w.subs(ZSYM, ZSYM - Z0)
    return {"kind": "rational", "d": 1, "expr": str(expr),
            "latex": _latex(expr), "constants": {}, "free": ["z0"], "conditions": [],
            "poles_per_period": 1, "pole_orders": [p], "growth": {"g": g},
            "certificate": {"type": "substitution", "method": "symbolic", "status": "pass",
                            "detail": "E[w] = 0 exactly (rational function of z; mero.subeq)"},
            "origin": "live:subeq", "citations": [], "_form": "R", "_data": {"w": w}}


# ============================================================================== one configuration
def _run_config(eq, cfg, budget, extra=None, want_closed=True):
    res = {"config": _config_json(cfg), "status": None, "subequations": [], "incomplete": [], "notes": []}
    m, S, bounds = support(cfg)
    res["m"] = m
    res["degree_bounds"] = dict((str(k), bounds[k]) for k in sorted(bounds))
    res["support"] = [list(t) for t in S]
    poles = _pole_list(cfg)
    multi = len(poles) > 1
    # Laurent series at every pole of the configuration
    Ls = []
    atoms = set(eq.alg_numbers)
    for i, P in enumerate(poles):
        p = int(P["p"])
        Wi = max(_weight(t, p) for t in S)
        ext = extra if extra is not None else max(8, 2 * p + 6)
        N = Wi + ext
        prefix = "h%d_" % (i + 1) if multi else "h"
        try:
            L = _lt.LaurentSeries(eq, p, P["a0"], free_prefix=prefix, budget_s=budget.left(), factor=False)
            if L.positive_indices:
                N = max(N, max(L.positive_indices) + p + 4)     # beyond the largest Fuchs index (Lemma 4')
            L.extend(N)
        except Exception as err:
            res["status"] = "incomplete"
            res["incomplete"].append({"what": "Laurent series p = %s, a0 = %s" % (p, P["a0"]), "why": str(err)})
            return res
        if L.truncated:
            res["status"] = "incomplete"
            res["incomplete"].append({"what": "Laurent series p = %s" % p, "why": "time budget (index %d of %d)"
                                      % (L.N, N)})
            return res
        Ls.append((L, p, Wi, N))
        atoms |= set(L.atoms)
        spec = L.index_data.get("special") or []
        if spec:
            res["incomplete"].append({"what": "parameter values at which a further integer becomes a Fuchs index",
                                      "why": "the series is the generic one; on %s the Laurent series changes and "
                                             "these values are not treated" % "; ".join(
                                                 "%s == 0 (k = %s)" % (s_["condition"], s_["k"]) for s_ in spec)})
    hs = []
    for L, p, Wi, N in Ls:
        hs += [L.free[k] for k in sorted(L.free)]
    res["free_coefficients"] = [str(h) for h in hs]
    res["laurent"] = [{"p": p, "a0": _s(L.a0), "W": Wi, "N": N,
                       "indices": sorted(L.positive_indices), "free": dict((str(k), str(v)) for k, v in L.free.items())}
                      for L, p, Wi, N in Ls]
    params = list(eq.params)
    hset = set(hs)
    # stage 1: the compatibility conditions of the Laurent series themselves
    ode_conds = []
    for L, p, Wi, N in Ls:
        for k in sorted(L._cond):
            q = L._cond[k]
            if q:
                e = sp.expand(_numer(q.as_expr()))
                if e != 0:
                    ode_conds.append(e)
    res["laurent_conditions"] = [_short(_nice(q, atoms)) for q in ode_conds]
    if params:
        ponly = [q for q in ode_conds if not (q.free_symbols & hset)]
        if ponly:
            res["status"] = "parameter-conditions"
            res["_ponly"] = ponly
            res["parameter_conditions"] = [_short(_nice(q, atoms)) for q in ponly]
            res["notes"].append("the Laurent series exist only on these parameter conditions")
            return res
    try:
        sols1, complete1, note1 = _solve_system(ode_conds, hs, atoms, budget)
    except _Timeout:
        res["status"] = "incomplete"
        res["incomplete"].append({"what": "Laurent conditions", "why": "time budget"})
        return res
    if not complete1:
        res["incomplete"].append({"what": "Laurent conditions", "why": note1 or "not decomposed"})
    if not sols1:
        if params and complete1:
            el = _eliminate_free(ode_conds, hs, params, atoms, budget)
            el = [q for q in (el or []) if q != 0]
            if el:
                res["status"] = "parameter-conditions"
                res["_ponly"] = el
                res["parameter_conditions"] = [_short(_nice(q, atoms)) for q in el]
                return res
        res["laurent_exists"] = False
        res["status"] = "inconsistent" if complete1 else "incomplete"
        res["notes"].append("no Laurent series of this kind: a compatibility condition fails")
        return res
    res["laurent_exists"] = True
    res["unknowns"] = len(S) - 1
    res["equations"] = sum(N + 1 for _, _, _, N in Ls)
    res["conditions"] = []
    cols = sorted([t for t in S if t != (0, m)], key=lambda t: (-_weight(t, poles[0]["p"]), t))
    any_open = not complete1
    for sub1 in sols1:
        st = _solve_branch(eq, cfg, S, m, cols, Ls, hs, sub1, atoms, params, budget, want_closed, res, depth=3)
        any_open = any_open or st
    if res.get("_ponly"):
        res["status"] = "parameter-conditions"
        return res
    if res["subequations"]:
        res["status"] = "solved"
    else:
        res["status"] = "incomplete" if (any_open or res["incomplete"]) else "inconsistent"
    if want_closed and any(it["status"] == "candidate" for it in res["subequations"]):
        res["incomplete"].append({"what": "closed form", "why": "some subequations are candidates only"})
    return res


def _solve_branch(eq, cfg, S, m, cols, Ls, hs, sub, atoms, params, budget, want_closed, res, depth):
    """the linear system for F with the free coefficients in `sub` substituted; appends to res.  Returns True
    if something was left open."""
    rest = [h for h in hs if h not in sub]
    atoms = set(atoms)
    for v in sub.values():
        atoms |= algebraic_atoms(v)
    dom = _domain(atoms, params)
    R = ring(rest if rest else [sp.Symbol("_u_")], dom)[0]
    Fld = R.to_field()
    rows = []
    for L, p, Wi, N in Ls:
        C = []
        for n in range(N + 1):
            if budget.expired():
                raise _Timeout("linear system")
            if not sub:
                # the coefficient as a ring element directly (no expression round trip, no cancellation)
                try:
                    C.append(R.from_expr(L._c[n].as_expr()))
                    continue
                except Exception:
                    pass
            e = L._c[n].as_expr()
            if sub:
                e = e.subs(sub)
            if e == 0:
                C.append(R.zero)
                continue
            try:
                C.append(R.from_expr(e))
            except Exception:
                C.append(R.from_expr(_canon(e, atoms)))
        Dd = [x * (n - p) for n, x in enumerate(C)]
        prods = _series_products(C, Dd, S, N, R, budget)
        for n in range(N + 1):
            row, rhs = {}, R.zero
            for t in S:
                idx = n - (Wi - _weight(t, p))
                if idx < 0:
                    continue
                v = prods[t][idx]
                if not v:
                    continue
                if t == (0, m):
                    rhs -= v
                else:
                    row[t] = row.get(t, R.zero) + v
            rows.append((dict((t_, Fld(v)) for t_, v in row.items() if v), Fld(rhs)))
        if budget.expired():
            raise _Timeout("linear system")
    pivot_rows, free_cols, zero_rhs, assumptions = _eliminate(rows, cols, Fld, budget)
    ppf = _param_pivot_factors(getattr(_eliminate, "unit_pivots", []), [P_["a0"] for P_ in _pole_list(cfg)], params)
    if ppf:
        res["incomplete"].append({"what": "special parameter values (linear system)",
                                  "why": "the elimination divided by expressions in the parameters; the values on "
                                         "which %s vanish are not treated" % ", ".join("%s" % f for f in ppf)})
    conds = []
    for q in zero_rhs:
        e = sp.expand(_numer(q.numer.as_expr()))
        if e != 0:
            conds.append(e)
    tag = dict((str(h), str(v)) for h, v in sub.items())
    res["conditions"].append({"free_values": tag, "conditions": [_short(_nice(q, atoms)) for q in conds],
                              "pivot_assumptions": [_short(a.as_expr()) for a in assumptions]})
    rset = set(rest)
    if params:
        ponly = [q for q in conds if not (q.free_symbols & rset)]
        if ponly:
            res["_ponly"] = (res.get("_ponly") or []) + ponly
            res["parameter_conditions"] = [_short(_nice(q, atoms)) for q in res["_ponly"]]
            return False
    sols, complete, note = _solve_system(conds, rest, atoms, budget)
    open_ = not complete
    if not complete:
        res["incomplete"].append({"what": "conditions (free values %s)" % tag, "why": note or "not decomposed"})
    if params and conds and not sols and complete:
        el = _eliminate_free(conds, rest, params, atoms, budget)
        if el is None:
            res["incomplete"].append({"what": "conditions", "why": "elimination of the free coefficients %s from "
                                      "the conditions not attempted (system too large)" % rest})
            return True
        el = [q for q in el if q != 0]
        if el:
            res["_ponly"] = (res.get("_ponly") or []) + el
            res["parameter_conditions"] = [_short(_nice(q, atoms)) for q in res["_ponly"]]
            return False
    if params and conds and sols and rest:
        res["incomplete"].append({"what": "special parameter values",
                                  "why": "the conditions were solved for the free coefficients over the field of "
                                         "the parameters; values of the parameters at which a leading "
                                         "coefficient of that elimination vanishes are not treated"})
        open_ = True
    # pivots that depend on the free coefficients: the generic solutions must keep them nonzero, the zeros are
    # treated as separate branches (one remaining free coefficient), or reported
    special = []
    if assumptions:
        if len(rest) == 1 and depth > 0:
            h = rest[0]
            for a in assumptions:
                roots, ok = _univariate_roots(a.as_expr(), h, atoms, max_deg=2)
                if not ok:
                    open_ = True
                    res["incomplete"].append({"what": "pivot %s" % _short(a.as_expr()),
                                              "why": "zeros of degree > 2 over the ground field are not explored "
                                                     "(the linear system is not solved at those values of %s)" % h})
                for r in roots or []:
                    if all(not _is_zero(sp.sympify(r) - sp.sympify(r2), atoms) for r2 in special):
                        special.append(r)
        else:
            open_ = True
            res["incomplete"].append({"what": "pivots that depend on the free coefficients",
                                      "why": "the cases where one of %s vanishes are not explored"
                                             % ", ".join(str(a.as_expr()) for a in assumptions)})
    good = []
    for sol in sols:
        bad = False
        for a in assumptions:
            v = a.as_expr().subs(sol) if sol else a.as_expr()
            if _is_zero(v, atoms | set().union(*[algebraic_atoms(t) for t in sol.values()] or [set()])):
                bad = True
        if not bad:
            good.append(sol)
    if good and free_cols:
        # F is not determined by the system (e.g. reducible F of solutions with a smaller configuration); the
        # closed forms of Lemma 3 need only the Laurent data
        res["notes"].append("free values %s: the linear system leaves the coefficients %s of F free; the closed "
                            "forms are computed from the Laurent data" % (tag, ", ".join("a_%d,%d" % t for t in free_cols)))
        for sol in good:
            full = dict(sub)
            full.update(sol)
            items, ok = _items_without_F(eq, cfg, S, m, full, hs, Ls, atoms, budget, want_closed)
            if not ok:
                open_ = True
                res["incomplete"].append({"what": "subequation (free values %s)" % tag,
                                          "why": "F not determined by the linear system and the closed-form "
                                                 "search was not complete"})
            for item in items:
                if not any(_same_F(item, it2, atoms) for it2 in res["subequations"]):
                    res["subequations"].append(item)
        good = []
    vals = _back_substitute(pivot_rows, free_cols, cols, Fld) if good else None
    for sol in good:
        if budget.expired():
            res["incomplete"].append({"what": "closed forms", "why": "time budget"})
            return True
        full = dict(sub)
        full.update(sol)
        for item in _make_item(eq, cfg, S, m, vals, full, hs, Ls, atoms, budget, want_closed, params):
            if not any(_same_F(item, it2, atoms) for it2 in res["subequations"]):
                res["subequations"].append(item)
    for r in special:
        sub2 = dict(sub)
        sub2[rest[0]] = r
        open_ = _solve_branch(eq, cfg, S, m, cols, Ls, hs, sub2, atoms, params, budget, want_closed, res,
                              depth - 1) or open_
    return open_


def _items_without_F(eq, cfg, S, m, full, hs, Ls, atoms, budget, want_closed):
    """closed forms (Lemma 3) directly from the Laurent data when the linear system does not determine F; the
    F of a verified solution is computed from its closed form.  Returns (items, complete)."""
    if not want_closed or len(Ls) != 1:
        return [], False
    L, p, Wi, N = Ls[0]
    atoms2 = set(atoms)
    for v in full.values():
        atoms2 |= algebraic_atoms(v)
    c = []
    for n in range(N + 1):
        e = L._c[n].as_expr()
        if full:
            e = e.subs(full)
        c.append(_canon(e, atoms2))
    nmatch = _nmatch(L, p, N)
    hs_free = [h for h in hs if h not in full]
    cand_subs, complete = [dict()], True
    sols, notes = _closed_forms(eq, p, c, atoms2, cfg, budget, nmatch)
    found = [(s_, {}) for s_ in sols]
    if not sols and hs_free:
        members, complete, _ = _family_members(eq, p, c, atoms2, cfg, budget, nmatch, hs_free)
        for d in members:
            c2 = [_canon(sp.sympify(x).subs(d), atoms2 | set().union(*[algebraic_atoms(v) for v in d.values()]))
                  for x in c]
            s2, _ = _closed_forms(eq, p, c2, atoms2, cfg, budget, nmatch)
            found += [(s_, d) for s_ in s2]
    items = []
    for s0, d in found:
        fs = subequation_of_solution(s0["expr"], cfg, constants=s0.get("constants"))
        allv = dict(full)
        allv.update(d)
        item = {"F": fs.get("F") or "", "F_latex": _latex(sp.Eq(sp.sympify(fs["F"]), 0)) if fs.get("F") else "",
                "coefficients": {}, "free_values": dict((str(h), str(v)) for h, v in allv.items()),
                "free_left": [str(h) for h in hs if h not in allv], "status": "verified",
                "solution": dict((k, v) for k, v in s0.items() if not k.startswith("_")),
                "notes": ["F computed from the verified closed form (the linear system did not determine it)"]}
        if not fs.get("unique"):
            item["notes"].append("F of the closed form is not unique for this support: %s" % fs.get("note"))
        items.append(item)
    return items, complete


def _same_F(a, b, atoms):
    if a["free_left"] != b["free_left"]:
        return False
    try:
        return _is_zero(sp.sympify(a["F"]) - sp.sympify(b["F"]), atoms)
    except Exception:
        return False


def _eliminate_free(polys, hs, params, atoms, budget):
    """generators of the elimination ideal (conditions on the parameters alone) of a small system; None if the
    system is considered too large for a Groebner basis without a time limit"""
    polys = [sp.expand(q) for q in polys if q != 0]
    if not polys:
        return []
    if len(hs) > 2 or len(params) > 3:
        return None
    try:
        if max(sp.Poly(q, *(hs + params)).total_degree() for q in polys) > 12 or len(polys) > 40:
            return None
        dom = algebraic_domain(atoms)
        Gb = sp.groebner(polys, *(hs + params), order="lex", domain=dom)
    except Exception:
        return None
    return [g for g in Gb.exprs if not (g.free_symbols & set(hs))]


def _branches(ponly, params, atoms):
    """split the parameter space along the conditions `ponly` (every point where all of them vanish lies on
    one of the branches).  Returns (branches, complete): a branch is (x, value, note) meaning the
    substitution x = value."""
    best = None
    small = []
    for q in ponly:
        try:
            if len(str(q)) <= 6000:
                small.append(q)
        except ValueError:
            pass
    if not small:
        return [], False
    for q in small:
        try:
            if atoms:
                facs = sp.factor_list(q, extension=list(atoms))[1]
            else:
                facs = sp.factor_list(q)[1]
        except Exception:
            facs = [(q, 1)]
        facs = [f for f, _ in facs if f.free_symbols & set(params)]
        if not facs:
            return [], True           # a nonzero constant: no parameter value satisfies the conditions
        bad = 0
        for f in facs:
            sol = _lt._linear_solution(f, params)
            if sol is None:
                bad += 0 if len(f.free_symbols) == 1 else 2
            elif sol[2] is not None:
                bad += 1
        score = (bad, len(facs), sum(sp.Poly(f, *params).total_degree() for f in facs))
        if best is None or score < best[0]:
            best = (score, facs)
    out, complete = [], True
    for f in best[1]:
        sol = _lt._linear_solution(f, params)
        if sol is not None:
            x, val, c1 = sol
            note = "%s == 0" % f
            if c1 is not None:
                note += " (with %s != 0; the case %s == 0 is not treated)" % (c1, c1)
                complete = False
            out.append((x, val, note))
            continue
        if len(f.free_symbols) == 1:
            x = list(f.free_symbols)[0]
            roots, ok = _univariate_roots(f, x, atoms)
            complete = complete and ok
            for r in roots or []:
                out.append((x, r, "%s == 0" % f))
            continue
        complete = False
    return out, complete


def _make_item(eq, cfg, S, m, vals, sol, hs, Ls, atoms, budget, want_closed, params, _depth=0):
    """list of subequation items for one solution of the conditions (a family whose closed form needs special
    values of its free coefficients is split into those members)"""
    sub = dict(sol)
    atoms2 = set(atoms)
    for v in sub.values():
        atoms2 |= algebraic_atoms(v)
    Fexpr = YSYM ** m
    coeffs = {}
    for t, v in vals.items():
        e = v.as_expr()
        if sub:
            e = e.subs(sub)
        e = _canon(e, atoms2)
        coeffs[t] = e
        j, k = t
        Fexpr += e * WSYM ** j * YSYM ** k
    Fexpr = sp.expand(Fexpr)
    free_left = [str(h) for h in hs if h not in sub]
    item = {"F": str(Fexpr), "F_latex": _latex(sp.Eq(Fexpr, 0)),
            "coefficients": dict(("%d,%d" % t, str(v)) for t, v in sorted(coeffs.items())),
            "free_values": dict((str(h), str(v)) for h, v in sub.items()),
            "free_left": free_left, "status": "candidate", "solution": None, "notes": []}
    if not want_closed:
        return [item]
    if len(Ls) != 1:
        item["notes"].append("closed form: only configurations with one pole are converted")
        return [item]
    L, p, Wi, N = Ls[0]
    c = []
    for n in range(N + 1):
        if budget.expired():
            item["notes"].append("closed form: time budget")
            return [item]
        e = L._c[n].as_expr()
        if sub:
            e = e.subs(sub)
        c.append(_canon(e, atoms2))
    nmatch = _nmatch(L, p, N)
    try:
        sols, notes = _closed_forms(eq, p, c, atoms2, cfg, budget, nmatch)
    except _Timeout:
        item["notes"].append("closed form: time budget")
        return [item]
    except Exception as err:
        item["notes"].append("closed form failed: %s" % err)
        return [item]
    item["notes"] += notes
    if sols:
        s0 = sols[0]
        if free_left and s0.get("_form") == "E":
            s0, Fexpr, free_left = _reparametrise(s0, Fexpr, free_left, p)
            item["F"] = str(Fexpr)
            item["F_latex"] = _latex(sp.Eq(Fexpr, 0))
            item["free_left"] = free_left
        if free_left:
            s0["free"] = s0["free"] + [f for f in free_left if f not in s0["free"]]
            s0["constants"].update(dict((h, "free") for h in free_left))
        item["solution"] = dict((k, v) for k, v in s0.items() if not k.startswith("_"))
        item["status"] = "verified"
        _check_F(item, cfg, atoms2)
        return [item]
    hs_free = [h for h in hs if h not in sub]
    if not hs_free or _depth > 0:
        return [item]
    # a family of subequations without a closed form for general members: look for special members
    try:
        members, ok, mnotes = _family_members(eq, p, c, atoms2, cfg, budget, nmatch, hs_free)
    except _Timeout:
        item["notes"].append("special members of the family: time budget")
        return [item]
    except Exception as err:
        item["notes"].append("special members of the family not searched (%s)" % err)
        return [item]
    out = []
    for d in members:
        full = dict(sub)
        full.update(d)
        for it in _make_item(eq, cfg, S, m, vals, full, hs, Ls, atoms, budget, want_closed, params, _depth + 1):
            if it["status"] == "verified":
                it["notes"].append("special member of the family %s (free coefficients %s)"
                                   % (item["F"], ", ".join(str(h) for h in hs_free)))
                out.append(it)
    if ok:
        item["status"] = "no-solution"
        item["notes"].append("no solution of class W with this configuration for other values of %s: the "
                             "closed-form systems of Lemma 3 were solved with the free coefficients as unknowns "
                             "(%d special member(s) found)" % (", ".join(str(h) for h in hs_free), len(out)))
    else:
        item["notes"].append("the general member of this family has no closed form of the configuration; "
                             "%d special member(s) found (search not complete)" % len(out))
    return out + [item]


def _nmatch(L, p, N):
    """number of Laurent coefficients beyond c_p used to fit a closed form: at least up to the largest Fuchs
    index + 1 (then the verified closed form has exactly the Laurent data of the item), at most N - p"""
    kmax = max(L.positive_indices) if L.positive_indices else 0
    return min(N - p, max(8, 2 * p + 6, kmax - p + 2))


def _check_F(item, cfg, atoms):
    """F of the verified closed form (exact elimination of z) must be the F of the item (statement, Lemma 5:
    F_w is determined by the Laurent data, which the closed form matches beyond the largest Fuchs index)"""
    s0 = item["solution"]
    try:
        ex = _parse_solution_expr(s0["expr"], s0.get("constants"))
        nsym = len(ex.free_symbols - {ZSYM})
        if _sym_sqrt_bases(ex) or nsym > 2:
            item["F_check"] = "skipped (symbolic radicals or more than two symbols; the substitution certificate " \
                              "is unaffected)"
            return
    except Exception:
        pass
    try:
        cfg2 = {"poles": [{"p": P["p"]} for P in cfg["poles"]], "g0": cfg.get("g0", 0), "ginf": cfg.get("ginf", 0),
                "g": cfg.get("g", 0)}
        fs = subequation_of_solution(s0["expr"], cfg2, constants=s0.get("constants"))
    except Exception as err:
        item["notes"].append("F of the closed form not recomputed (%s)" % err)
        return
    if not fs.get("F") or not fs.get("unique"):
        item["notes"].append("F of the closed form not recomputed (%s)" % fs.get("note"))
        return
    if _is_zero(sp.sympify(fs["F"]) - sp.sympify(item["F"]), atoms):
        item["F_check"] = "F recomputed from the closed form by elimination of z: equal"
    else:
        item["F_check"] = "MISMATCH: F of the closed form is %s" % fs["F"]
        item["status"] = "candidate"
        item["notes"].append("the verified closed form has a different F; the item is kept as a candidate")


def _reparametrise(s0, Fexpr, free_left, p):
    """a free Laurent coefficient h that enters g3 (or g2) linearly is replaced by that invariant"""
    cd = dict(s0["_data"])
    left = list(free_left)
    for hname in list(free_left):
        h = sp.Symbol(hname)
        for gname, gsym in (("g3", G3), ("g2", G2)):
            gv = sp.sympify(cd[gname])
            other = "g2" if gname == "g3" else "g3"
            if not gv.has(h) or sp.sympify(cd[other]).has(h) or sp.sympify(cd["q0"]).has(h) \
                    or any(sp.sympify(v).has(h) for v in cd["b"].values()):
                continue
            try:
                P = sp.Poly(gv, h)
            except Exception:
                continue
            if P.degree() != 1:
                continue
            c1, c0 = P.all_coeffs()
            if c1.free_symbols & {sp.Symbol(x) for x in free_left}:
                continue
            hval = (gsym - c0) / c1
            cd[gname] = gsym
            Fexpr = sp.expand(Fexpr.subs(h, hval))
            left = [x for x in left if x != hname] + [gname]
            break
    s1 = _solution_elliptic(cd, p)
    return s1, Fexpr, left


# ============================================================================== public functions
def _run_branching(eq, cfg, budget, extra, closed_forms, depth, pvals, visited=None):
    """one configuration; if its conditions restrict the parameters, the parameter space is split along them
    (substitution of a parameter, recursively up to `depth` levels).  A parameter point reached a second time
    along another path is not recomputed."""
    visited = set() if visited is None else visited
    rps = [P_["reparam"] for P_ in cfg.get("poles", []) if P_.get("reparam")]
    if rps:
        x, val = rps[0]
        eq = eq.subs({x: val})
        cfg = dict(cfg)
        cfg["poles"] = [dict((k, v) for k, v in P_.items() if k != "reparam") for P_ in cfg["poles"]]
        A0 = sp.sympify(cfg["poles"][0]["a0"])
        pvals = list(pvals) + [(x, val, "reparametrisation: the leading Laurent coefficient %s is a parameter, "
                                         "%s = %s" % (A0, x, val))]
    key = tuple(sorted((str(x), str(sp.cancel(sp.sympify(v)))) for x, v, _ in pvals))
    if key in visited:
        return []
    visited.add(key)
    try:
        r = _run_config(eq, cfg, budget, extra=extra, want_closed=closed_forms)
    except _Timeout as err:
        r = {"config": _config_json(cfg), "status": "incomplete",
             "incomplete": [{"what": "computation", "why": "time budget (%s)" % err}], "subequations": []}
    r["parameter_values"] = dict((str(x), str(v)) for x, v, _ in pvals)
    r["branch"] = [note for _, _, note in pvals]
    ponly = r.pop("_ponly", None)
    out = [r]
    if r.get("status") != "parameter-conditions":
        return out
    r["generic"] = "no solution with this configuration for generic values of the parameters"
    if depth <= 0:
        r["incomplete"].append({"what": "parameter conditions", "why": "branching depth reached: the parameter "
                                "values on which %s vanish are not treated" % r.get("parameter_conditions")})
        return out
    atoms = set(eq.alg_numbers)
    branches, complete = _branches(ponly, list(eq.params), atoms)
    if not complete:
        r["incomplete"].append({"what": "parameter conditions", "why": "some components of %s were not split "
                                "into substitutions" % r.get("parameter_conditions")})
    if not branches and complete:
        r["generic"] = "no solution with this configuration for any values of the parameters"
    for x, val, note in branches:
        if budget.expired():
            r["incomplete"].append({"what": "branch %s = %s" % (x, val), "why": "time budget"})
            continue
        try:
            eq2 = eq.subs({x: val})
            cfg2 = dict(cfg)
            cfg2["poles"] = [dict(P, a0=sp.sympify(P["a0"]).subs(x, val)) for P in cfg["poles"]]
            pv2 = [(x2, sp.sympify(v2).subs(x, val), n2) for x2, v2, n2 in pvals] + [(x, val, note)]
            out += _run_branching(eq2, cfg2, budget, extra, closed_forms, depth - 1, pv2, visited)
        except Exception as err:
            out.append({"config": _config_json(cfg), "status": "incomplete", "subequations": [],
                        "parameter_values": dict([(str(a), str(b)) for a, b, _ in pvals] + [(str(x), str(val))]),
                        "incomplete": [{"what": "branch %s = %s" % (x, val), "why": str(err)}]})
    return out


def find_subequations(eq, config=None, local=None, budget_s=120, extra=None, closed_forms=True, depth=3):
    with _BigInts():
        return _find_subequations(eq, config, local, budget_s, extra, closed_forms, depth)


def _find_subequations(eq, config=None, local=None, budget_s=120, extra=None, closed_forms=True, depth=3):
    """Briot-Bouquet subequations F(w, w') = 0 of the solutions of class W with a given configuration.

    eq       an Equation (or a string for mero.parse.parse_ode)
    config   None (one configuration per Laurent series of eq, one pole in a period, bounded ends) or a dict
             (module docstring); with symbolic parameters the answer is for generic values plus the
             polynomial conditions found
    local    optional result of mero.laurent.local_analysis(eq) (only used for its notes)
    budget_s time budget in seconds;  extra: number of Laurent conditions beyond the top weight

    Returns {"schema": "mero-subeq/1", "configs": [per configuration: config, m, support, degree_bounds,
    unknowns, equations, free_coefficients, conditions (polynomials that must vanish), status ('solved',
    'inconsistent' = no solution with this configuration, 'incomplete'), subequations: [{F, coefficients,
    free_values, free_left, status ('verified' | 'candidate'), solution (Solution dict or None)}],
    incomplete, notes}], "count": number of verified subequations, "incomplete": [...], "elapsed_s"}."""
    if isinstance(eq, str):
        from .parse import parse_ode
        eq = parse_ode(eq)
    budget = _Budget(budget_s)
    out = {"schema": "mero-subeq/1", "engine": VERSION, "equation": str(eq.E), "configs": [],
           "incomplete": [], "notes": []}
    if config is None:
        cfgs, notes = _default_configs(eq, budget)
        out["incomplete"] += notes
    else:
        cfgs, notes = _normalise_config(eq, config)
        out["incomplete"] += notes
    if not cfgs:
        out["notes"].append("no configuration to treat (no Laurent series with a pole of integer order)")
    for cfg in cfgs:
        if budget.expired():
            out["incomplete"].append({"what": "configuration %s" % _config_json(cfg), "why": "time budget"})
            continue
        out["configs"] += _run_branching(eq, cfg, budget, extra, closed_forms, depth, [])
    k = 0
    for r in out["configs"]:
        for it in r.get("subequations", []):
            k += 1
            it["id"] = "subeq-%d" % k
            if it.get("solution"):
                it["solution"]["id"] = "subeq-%d" % k
                it["solution"]["conditions"] = ["%s == %s" % (x, v) for x, v in r.get("parameter_values", {}).items()]
    out["count"] = sum(1 for r in out["configs"] for it in r.get("subequations", []) if it["status"] == "verified")
    out["candidates"] = sum(1 for r in out["configs"] for it in r.get("subequations", []))
    out["elapsed_s"] = budget.elapsed()
    return out


class SolutionCount(int):
    """an int (the number of verified subequations F) that carries the details: n.details (dict), n["key"]"""
    def __new__(cls, value, details):
        obj = int.__new__(cls, value)
        obj.details = details
        return obj

    def __getitem__(self, key):
        return self.details[key]

    def get(self, key, default=None):
        return self.details.get(key, default)


def count_solutions(eq, config=None, budget_s=120):
    """Number of distinct subequations F for the configuration(s), i.e. (for one pole in a period and bounded
    ends, where every F is irreducible) the number of solutions of class W with that configuration up to
    translation.  Returns a SolutionCount: an int (= count) with the details n["key"] / n.details:
        count       number of F found with a verified closed form (an int)
        families    number of those F that contain free coefficients (each is a family of solutions)
        candidates  number of F found (verified or not)
        complete    True if every configuration was decided (status 'solved' or 'inconsistent' and nothing
                    in 'incomplete'); only then is `count` the exact number
        per_config  [(config, status, number of verified F)]"""
    r = find_subequations(eq, config=config, budget_s=budget_s)
    fam = sum(1 for c in r["configs"] for it in c.get("subequations", [])
              if it["status"] == "verified" and it.get("free_left"))
    complete = not r["incomplete"] and all(c.get("status") in ("solved", "inconsistent") and not c.get("incomplete")
                                           for c in r["configs"])
    details = {"count": r["count"], "families": fam, "candidates": r["candidates"], "complete": complete,
               "per_config": [(c["config"], c.get("status"),
                               sum(1 for it in c.get("subequations", []) if it["status"] == "verified"))
                              for c in r["configs"]],
               "subequations": [it["F"] for c in r["configs"] for it in c.get("subequations", [])
                                if it["status"] == "verified"],
               "report": r}
    return SolutionCount(r["count"], details)


# ============================================================================== F of an explicit solution
_WPF = sp.Function("wp")
_WPPF = sp.Function("wpp")


def _parse_solution_expr(expr, constants=None):
    """SymPy expression of a Solution 'expr' with the known constants substituted and z0 = 0"""
    if isinstance(expr, str):
        loc = {"wp": _WPF, "wpp": _WPPF, "z": ZSYM, "z0": Z0, "exp": sp.exp, "I": sp.I, "E": sp.E,
               "sqrt": sp.sqrt, "tanh": sp.tanh, "sinh": sp.sinh, "cosh": sp.cosh, "coth": sp.coth,
               "tan": sp.tan, "sin": sp.sin, "cos": sp.cos, "cot": sp.cot, "sech": sp.sech, "csch": sp.csch,
               "sec": sp.sec, "csc": sp.csc}
        expr = sp.sympify(expr, locals=loc)
    expr = sp.sympify(expr)
    sub = {}
    for k, v in (constants or {}).items():
        if v is None or str(v).strip() in ("free", ""):
            continue
        try:
            sub[sp.Symbol(k)] = sp.sympify(v, locals={"I": sp.I})
        except Exception:
            continue
    if sub:
        # constants may refer to each other (q0 = -g2/2, ...): substitute repeatedly
        for _ in range(4):
            new = expr.subs(sub)
            if new == expr:
                break
            expr = new
    return expr.subs(Z0, 0)


def _exp_base(expr):
    """(nu, s-substitution) for an expression in exp(alpha*z + beta): nu with every alpha = n*nu, n integer"""
    alphas = []
    for node in sp.preorder_traversal(expr):
        if isinstance(node, sp.exp):
            arg = sp.expand(node.args[0])
            al = sp.diff(arg, ZSYM)
            if al.has(ZSYM):
                raise ValueError("exponent not linear in z: %s" % arg)
            if al != 0:
                alphas.append(al)
    if not alphas:
        return None
    a1 = alphas[0]
    rs = []
    for al in alphas:
        r = sp.nsimplify(sp.simplify(al / a1))
        if not r.is_Rational:
            raise ValueError("exponents %s and %s are not commensurable" % (al, a1))
        rs.append(r)
    d = 1
    for r in rs:
        d = sp.ilcm(d, r.q)
    ns = [int(r * d) for r in rs]
    g = 0
    for n in ns:
        g = sp.igcd(g, n)
    return sp.simplify(a1 * g / d)


def _solve_F_columns(cols, keys, S, m, dom):
    """the a_jk from the coefficient vectors cols[(j,k)] (dicts monomial -> domain element): sum a_jk col = 0
    with a_{0m} = 1.  Returns (values dict or None, unique flag, note)."""
    from sympy.polys.matrices import DomainMatrix
    unk = [t for t in S if t != (0, m)]
    mons = sorted(set(k_ for t in S for k_ in cols[t].keys()))
    if not mons:
        return None, False, "no equations"
    rows = []
    for mo in mons:
        row = [cols[t].get(mo, dom.zero) for t in unk]
        row.append(-cols[(0, m)].get(mo, dom.zero))
        rows.append(row)
    M = DomainMatrix(rows, (len(rows), len(unk) + 1), dom)
    R, piv = M.rref()
    if len(unk) in piv:
        return None, False, "the function does not satisfy an equation with this support (configuration)"
    Rl = R.to_Matrix()
    vals, free = {}, [unk[j] for j in range(len(unk)) if j not in piv]
    if free:
        return None, False, "F is not unique for this support (%d free coefficients)" % len(free)
    for i, pc in enumerate(piv):
        vals[unk[pc]] = Rl[i, len(unk)]
    return vals, True, ""


def subequation_of_solution(expr, config, constants=None, budget_s=60):
    """F(w, w') = 0 for an explicit function (exact elimination of z).

    expr       Solution 'expr' (string or SymPy) in z: polynomial in wp(z - z0, g2, g3), wpp(...), or a rational
               function of exponentials (exp, tanh, ... of linear arguments), or a rational function of z
    config     a configuration (the support of F is taken from it) or an int m (then the classical one-pole
               support of order m is used)
    constants  the 'constants' dict of the Solution ("free" entries stay symbolic)
    Returns {"F": str or None, "unique": bool, "kind": ..., "note": ...}.  Arithmetic: polynomial rings over the
    field generated by the constants (number field, parameters), linear algebra by DomainMatrix."""
    if isinstance(config, int):
        config = {"poles": [{"p": config}]}
    m, S, _ = support(config)
    w = _parse_solution_expr(expr, constants)
    out = {"F": None, "unique": False, "kind": None, "note": ""}
    jmax = max(j for j, _ in S)
    kmax = max(k for _, k in S)
    if w.has(_WPF) or w.has(_WPPF):
        out["kind"] = "elliptic"
        apps = [n for n in sp.preorder_traversal(w) if isinstance(n, sp.Function) and n.func in (_WPF, _WPPF)]
        keys = set((n.args[0], n.args[1], n.args[2]) for n in apps)
        if len(keys) != 1:
            out["note"] = "several different wp arguments: %s" % keys
            return out
        arg, g2, g3 = list(keys)[0]
        if sp.diff(arg, ZSYM) != 1:
            out["note"] = "wp argument %s is not z + constant" % arg
            return out
        wP = sp.expand(w.subs({_WPF(arg, g2, g3): PSYM, _WPPF(arg, g2, g3): QSYM}))
        consts = [wP, g2, g3]
        atoms, syms = set(), set()
        for x in consts:
            atoms |= algebraic_atoms(x)
            syms |= sp.sympify(x).free_symbols
        syms -= {PSYM, QSYM}
        rep = {}
        dom = _domain(atoms, syms)
        R, Q, P = ring([QSYM, PSYM], dom, order="lex")
        g2r, g3r = R.from_expr(sp.sympify(g2)), R.from_expr(sp.sympify(g3))
        rel = Q ** 2 - (4 * P ** 3 - g2r * P - g3r)
        wr = R.from_expr(wP)
        yr = (wr.diff(P) * Q + wr.diff(Q) * (6 * P ** 2 - g2r / 2)).rem([rel])
        wpow = [R.one]
        for _ in range(jmax):
            wpow.append((wpow[-1] * wr).rem([rel]))
        ypow = [R.one]
        for _ in range(kmax):
            ypow.append((ypow[-1] * yr).rem([rel]))
        cols = {}
        for (j, k) in S:
            t = (wpow[j] * ypow[k]).rem([rel])
            cols[(j, k)] = dict(t.terms())
    else:
        w2 = w
        for fn in (sp.tanh, sp.sinh, sp.cosh, sp.coth, sp.sech, sp.csch, sp.tan, sp.sin, sp.cos, sp.cot,
                   sp.sec, sp.csc):
            if w2.has(fn):
                w2 = w2.rewrite(fn, sp.exp)
        try:
            nu = _exp_base(w2)
        except Exception as err:
            out["note"] = str(err)
            return out
        if nu is not None:
            out["kind"] = "simply-periodic"
            var = sp.Symbol("s_")
            ws = sp.powsimp(sp.expand(w2)).replace(
                lambda e_: isinstance(e_, sp.exp),
                lambda e_: sp.exp(sp.expand(e_.args[0]).subs(ZSYM, 0)) *
                var ** sp.nsimplify(sp.simplify(sp.diff(sp.expand(e_.args[0]), ZSYM) / nu)))
            if ws.has(ZSYM):
                out["note"] = "could not write the function as a rational function of exp(nu z)"
                return out
        else:
            out["kind"] = "rational"
            var, nu = ZSYM, None
            ws = w
        num, den = sp.fraction(sp.together(ws))
        numeric = bool(_sym_sqrt_bases(num) or _sym_sqrt_bases(den) or (nu is not None and _sym_sqrt_bases(nu)))
        num, rep1 = _sqrt_to_symbols(num, numeric)
        den, rep2 = _sqrt_to_symbols(den, numeric)
        rep = dict(rep1)
        for b, s in rep2.items():
            if b in rep:
                den = den.subs(s, rep[b])
            else:
                rep[b] = s
        if nu is not None:
            nu, rep3 = _sqrt_to_symbols(nu, numeric)
            for b, s in rep3.items():
                if b in rep:
                    nu = nu.subs(s, rep[b])
                else:
                    rep[b] = s
        atoms, syms = set(), set()
        for x in (num, den) + ((nu,) if nu is not None else ()):
            atoms |= algebraic_atoms(x)
            syms |= sp.sympify(x).free_symbols
        syms -= {var}
        try:
            dom = _domain(atoms, syms)
            R, V = ring([var], dom)
            Nw, Dw = R.from_expr(sp.expand(num)), R.from_expr(sp.expand(den))
            fac = R.from_expr(nu * var) if nu is not None else R.one
        except Exception as err:
            out["note"] = "not a rational function with exact coefficients (%s)" % err
            return out
        # y = fac * (Nw' Dw - Nw Dw') / Dw^2;  w^j y^k = Nw^j Ny^k / Dw^(j + 2k)
        Ny = fac * (Nw.diff(V) * Dw - Nw * Dw.diff(V))
        top = max(j + 2 * k for j, k in S)
        Np = [R.one]
        for _ in range(jmax):
            Np.append(Np[-1] * Nw)
        Yp = [R.one]
        for _ in range(kmax):
            Yp.append(Yp[-1] * Ny)
        Dp = [R.one]
        for _ in range(top):
            Dp.append(Dp[-1] * Dw)
        cols = {}
        for (j, k) in S:
            t = Np[j] * Yp[k] * Dp[top - j - 2 * k]
            cols[(j, k)] = dict(t.terms())
    try:
        vals, unique, note = _solve_F_columns(cols, None, S, m, dom)
    except Exception as err:
        out["note"] = "linear system not solved: %s" % err
        return out
    if vals is None:
        out["note"] = note
        return out
    Fexpr = YSYM ** m + sum(_reduce_symbols(sp.sympify(v), rep) * WSYM ** t[0] * YSYM ** t[1]
                            for t, v in vals.items())
    out["F"] = str(sp.expand(Fexpr))
    out["unique"] = unique
    return out


def _match_F(Fmine, Fgiven, params, atoms):
    """True if the family of subequations Fmine (free symbols other than the parameters and w, wp1 are free
    constants) contains Fgiven (whose free constants are kept symbolic), with equal dimensions"""
    A = sp.sympify(Fmine)
    B = sp.sympify(Fgiven)
    base = set(params) | {WSYM, YSYM}
    fa = sorted(A.free_symbols - base, key=lambda s_: s_.name)
    fb = sorted(B.free_symbols - base, key=lambda s_: s_.name)
    dummies = [sp.Symbol("_f%d" % i) for i in range(len(fa))]
    A = A.subs(dict(zip(fa, dummies)))
    diff = sp.expand(A - B)
    if not diff.has(*dummies) if dummies else True:
        return _is_zero(diff, atoms)
    coeffs = sp.Poly(diff, WSYM, YSYM).coeffs()
    try:
        sols = sp.solve(coeffs, dummies, dict=True)
    except Exception:
        return False
    for so in sols:
        if all(_is_zero(sp.together(c.subs(so)), atoms) for c in coeffs):
            return len(fa) == len(fb)
    return False


def solution_config(expr, constants=None):
    """the configuration of an explicit function of class W (poles in a period with their orders, growth at
    the ends), or None if it cannot be read off.  wp-forms: polynomials in wp, wpp (one pole per period);
    exp-forms: rational functions of exp(nu z) (poles = roots of the denominator in C*, g0/ginf = orders at
    s = 0, oo, normalised to g0 <= ginf since nu -> -nu exchanges them); rational functions of z."""
    w = _parse_solution_expr(expr, constants)
    if w.has(_WPF) or w.has(_WPPF):
        apps = [n for n in sp.preorder_traversal(w) if isinstance(n, sp.Function) and n.func in (_WPF, _WPPF)]
        keys = set((n.args[0], n.args[1], n.args[2]) for n in apps)
        if len(keys) != 1:
            return None
        arg, g2, g3 = list(keys)[0]
        wP = sp.expand(w.subs({_WPF(arg, g2, g3): PSYM, _WPPF(arg, g2, g3): QSYM}))
        try:
            Pw = sp.Poly(wP, PSYM, QSYM)
        except Exception:
            return None
        order = 0
        for (a, b), co in Pw.terms():
            order = max(order, 2 * a + 3 * b)
        return {"poles": [{"p": order}], "g0": 0, "ginf": 0, "g": 0} if order else None
    w2 = w
    for fn in (sp.tanh, sp.sinh, sp.cosh, sp.coth, sp.sech, sp.csch, sp.tan, sp.sin, sp.cos, sp.cot, sp.sec, sp.csc):
        if w2.has(fn):
            w2 = w2.rewrite(fn, sp.exp)
    try:
        nu = _exp_base(w2)
    except Exception:
        return None
    if nu is not None:
        s = sp.Symbol("s_")
        ws = sp.powsimp(sp.expand(w2)).replace(
            lambda e_: isinstance(e_, sp.exp),
            lambda e_: sp.exp(sp.expand(e_.args[0]).subs(ZSYM, 0)) *
            s ** sp.nsimplify(sp.simplify(sp.diff(sp.expand(e_.args[0]), ZSYM) / nu)))
        var = s
    else:
        ws, var = w, ZSYM
    ws = sp.cancel(sp.together(ws))
    if ws.has(ZSYM) and var is not ZSYM:
        return None
    num, den = sp.fraction(ws)
    try:
        N_, D_ = sp.Poly(num, var), sp.Poly(den, var)
    except Exception:
        return None
    ginf = max(0, N_.degree() - D_.degree())
    def ord0(P_):
        for i, cf in enumerate(reversed(P_.all_coeffs())):
            if cf != 0:
                return i
        return 0
    poles = []
    try:
        Dfac = sp.factor_list(D_.as_expr(), var, extension=list(algebraic_atoms(D_.as_expr())) or None)[1]
    except Exception:
        Dfac = sp.factor_list(D_.as_expr(), var)[1]
    for fac, mult in Dfac:
        Pf = sp.Poly(fac, var)
        if Pf.degree() <= 0:
            continue
        if var is not ZSYM and Pf.monoms() == [(1,)]:
            continue                       # the factor s: an end, not a pole
        poles += [{"p": int(mult)}] * Pf.degree()
    if var is ZSYM:
        return {"poles": poles, "g0": 0, "ginf": 0, "g": ginf} if poles else None
    g0 = max(0, ord0(D_) - ord0(N_))
    return {"poles": poles, "g0": min(g0, ginf), "ginf": max(g0, ginf), "g": 0} if poles else None


def _cfg_key(cfg):
    return (tuple(sorted(int(P["p"]) for P in cfg["poles"])), int(cfg.get("g0", 0)), int(cfg.get("ginf", 0)),
            int(cfg.get("g", 0)))


def cross_check(eq, solutions, config=None, budget_s=120, growth=(0,)):
    """Do the given closed-form solutions correspond one-to-one to the subequations?

    solutions  list of Solution dicts (SCHEMA section 2; 'expr' with wp, wpp, exp, ... and 'constants'),
               claimed to be all solutions of the configurations considered
    config     None: the configurations considered are one pole of each Laurent type with bounded ends, the
               one-pole configurations with total end growth in `growth` (e.g. growth=(0, 1, 2)), and the
               configuration of every given solution (read off its formula); or an explicit configuration
    The subequations are computed with closed forms (find_subequations); a given solution is matched to a
    subequation F when the F of its formula (exact elimination of z) equals F, or lies in the same family of F.
    Returns {"agree": True | False | None, "pairs": [(solution id, configuration key, F)],
             "unmatched_solutions": [ids], "unmatched_subequations": [{"config", "F", "status"}],
             "configs": [keys], "complete": bool, "notes": [...], "reports": [find_subequations reports]}.
    agree is True when every given solution is matched and every verified subequation is matched, and the
    subequation side is complete; False when a mismatch is certain (a given solution without subequation, or a
    verified subequation without a given solution); None otherwise (the subequation side is incomplete or has
    unverified candidates)."""
    if isinstance(eq, str):
        from .parse import parse_ode
        eq = parse_ode(eq)
    budget = _Budget(budget_s)
    atoms = set(eq.alg_numbers)
    out = {"agree": None, "pairs": [], "unmatched_solutions": [], "unmatched_subequations": [],
           "configs": [], "complete": True, "notes": [], "reports": []}
    cfgs = []
    if config is not None:
        cfgs.append(config)
    else:
        cfgs.append(None)                      # the default configurations
        orders = sorted(set(int(r["p"]) for r in _lt.balances(eq)))
        for gtot in growth:
            if gtot:
                for p in orders:
                    cfgs.append({"poles": [{"p": p}], "g0": 0, "ginf": int(gtot)})
                    cfgs.append({"poles": [{"p": p}], "g": int(gtot)})
        for sol in solutions:
            try:
                sc = solution_config(sol.get("expr", ""), sol.get("constants"))
            except Exception:
                sc = None
            if sc is not None and (sc.get("g0") or sc.get("ginf") or sc.get("g") or len(sc["poles"]) > 1):
                cfgs.append(sc)
    items, seen_keys = [], set()
    for cfg in cfgs:
        if budget.expired():
            out["complete"] = False
            out["notes"].append("time budget: configuration %s not treated" % cfg)
            continue
        try:
            rep = find_subequations(eq, config=cfg, budget_s=budget.left())
        except Exception as err:
            out["complete"] = False
            out["notes"].append("configuration %s: %s" % (cfg, err))
            continue
        out["reports"].append(rep)
        if rep["incomplete"]:
            out["complete"] = False
        for c in rep["configs"]:
            if c.get("parameter_values"):
                continue                   # cross checks are made for the equation as given
            key = _cfg_key(c["config"])
            if key in seen_keys and cfg is not None:
                continue
            if c.get("status") not in ("solved", "inconsistent") or c.get("incomplete"):
                out["complete"] = False
            for it in c.get("subequations", []):
                if it["status"] in ("verified", "candidate"):
                    items.append((key, c["config"], it))
        for c in rep["configs"]:
            seen_keys.add(_cfg_key(c["config"]))
    out["configs"] = sorted(seen_keys)
    matched = set()
    for k, sol in enumerate(solutions):
        sid = sol.get("id", "s%d" % (k + 1))
        if sol.get("kind") in ("constant", "entire", "polynomial"):
            out["notes"].append("%s: no pole; not a case of the subequation method" % sid)
            continue
        hit = None
        for idx, (key, cfgj, it) in enumerate(items):
            cfg = {"poles": [{"p": P["p"]} for P in cfgj["poles"]], "g0": cfgj.get("g0", 0),
                   "ginf": cfgj.get("ginf", 0), "g": cfgj.get("g", 0)}
            try:
                fs = subequation_of_solution(sol["expr"], cfg, constants=sol.get("constants"))
            except Exception as err:
                fs = {"F": None, "note": str(err)}
            if not fs.get("F") or not fs.get("unique"):
                continue
            if _match_F(it["F"], fs["F"], eq.params, atoms):
                hit = idx
                break
        if hit is None:
            out["unmatched_solutions"].append(sid)
        else:
            out["pairs"].append((sid, items[hit][0], items[hit][2]["F"]))
            matched.add(hit)
    unverified = False
    for idx, (key, cfgj, it) in enumerate(items):
        if idx not in matched:
            out["unmatched_subequations"].append({"config": key, "F": it["F"], "status": it["status"],
                                                  "free_values": it.get("free_values")})
            if it["status"] != "verified":
                unverified = True
    certain_mismatch = bool(out["unmatched_solutions"]) or any(
        u["status"] == "verified" for u in out["unmatched_subequations"])
    if certain_mismatch:
        out["agree"] = False
    elif out["complete"] and not unverified:
        out["agree"] = True
    else:
        out["notes"].append("the subequation side is incomplete or has unverified candidates: agreement is not "
                            "decided")
    return out


def _with_big_ints(fn):
    def wrapper(*args, **kwargs):
        with _BigInts():
            return fn(*args, **kwargs)
    wrapper.__name__ = fn.__name__
    wrapper.__doc__ = fn.__doc__
    return wrapper


subequation_of_solution = _with_big_ints(subequation_of_solution)
solution_config = _with_big_ints(solution_config)
cross_check = _with_big_ints(cross_check)
