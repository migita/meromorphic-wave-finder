"""mero.freecoeff -- the free Laurent coefficient of the pure-power class (worker REDUCE, 6 Oct 2026).

Class (BRIEF section 3 notation).  c*w_K = lambda*w0**n + Psi(w0, ..., w_{K-1}),  c, lambda != 0,  n >= 2,
p = K/(n-1), weight of w_j = p + j, every monomial of Psi of weight < n*p  (hypothesis (H)).

At a pole: order p, leading coefficient a0 with lambda*a0**(n-1) = c*lambda0,
lambda0 = (-1)**K * p*(p+1)*...*(p+K-1).  For even K the Fuchs index k0 = K + 2p is the only positive integer
index; if the compatibility condition holds, the Laurent coefficient h = c_{k0} is free.

What this module computes (lemmas/freecoeff/project note):
  the pole-free differential polynomial  Theta = sum_{i=1}^{n} l_i(D) E_i,  E_i = w**i (i <= n-1),
  E_n = H(w) = w*w'' - ((p+1)/p)*w'**2  (project note, Lemma 4.4, written here without normalising lambda),
  and gamma_{a0,j}(h) = [x^j] Theta[w(x; h)] on the Laurent family with leading coefficient a0.
For a solution meromorphic in C, Theta[w] is constant (project note Theorems 3.8 and 4.2), so at every pole
with leading coefficient a0 and free coefficient h:  gamma_{a0,j}(h) = 0 for all j >= 1 and
gamma_{a0,0}(h) = kappa, the same number at all poles.  gamma_{a0,jk} has degree exactly k in h
(project note Theorem 4.6; k = 2 for n <= 5), so at most k values of h per a0.

Pure SymPy (sparse polynomial rings over QQ); time budget via time.monotonic().
"""
from __future__ import annotations

import time
from fractions import Fraction
from math import factorial

import sympy as sp
from sympy.polys.rings import ring as _ring
from sympy.polys.domains import QQ

VERSION = "freecoeff/1 (REDUCE, 2026-10-06)"
LABEL = "agent-proof"
SOURCE = {
    "citation": "agent RESCALE, 'Rescaling at poles with large Laurent data', working paper, 2 Oct 2026",
    "where": "Lemma 4.4, Theorems 3.8, 4.2, 4.6; project note Lemmas 5-6, Remark 2",
    "path": "project note",
    "lemma": "project note",
}


class _Budget(Exception):
    pass


# ----------------------------------------------------------------------------------------------- utilities
def _ff(x, j):
    """falling factorial x (x-1) ... (x-j+1) for integers"""
    r = 1
    for i in range(j):
        r *= (x - i)
    return r


def _rising(x, j):
    r = 1
    for i in range(j):
        r *= (x + i)
    return r


def _jet_symbols(K):
    return sp.symbols("w0:%d" % (K + 1))


def _equation_data(eq):
    """(K, w, terms {mon: coeff}, params) from an Equation of mero.equation / mero.bootstrap, or a string."""
    if isinstance(eq, str):
        try:
            from .parse import parse_ode
            eq = parse_ode(eq)
        except Exception:   # fall back to a jet expression  'E'  or  'lhs = rhs'
            txt = eq
            if "=" in txt:
                lhs, rhs = txt.split("=", 1)
                expr = sp.sympify(lhs) - sp.sympify(rhs)
            else:
                expr = sp.sympify(txt)
            js = [int(str(s)[1:]) for s in expr.free_symbols
                  if str(s).startswith("w") and str(s)[1:].isdigit()]
            K = max(js) if js else 0
            w = _jet_symbols(K)
            loc = dict((str(s), s) for s in w)
            expr = sp.sympify(str(expr), locals=loc)
            poly = sp.Poly(expr, *w)
            terms = dict((tuple(m), c) for m, c in poly.terms())
            params = sorted(set().union(*[c.free_symbols for c in terms.values()]) if terms else set(),
                            key=str)
            return K, w, terms, list(params)
    K = int(eq.K)
    w = tuple(eq.w)
    terms = dict((tuple(int(e) for e in m), sp.sympify(c)) for m, c in eq.terms.items() if c != 0)
    params = list(getattr(eq, "params", []) or [])
    present = set()
    for c in terms.values():
        present |= c.free_symbols
    params = [s for s in params if s in present] + sorted(present - set(params), key=str)
    return K, w, terms, params


def _mono_expr(w, mon):
    r = sp.Integer(1)
    for j, e in enumerate(mon):
        if e:
            r *= w[j] ** e
    return r


# ----------------------------------------------------------------------------------------- class check
def check_pure_power(eq):
    """Is the equation in the pure-power class?  Returns a dict
    {holds, reason, K, n, p (Fraction), c, lam, psi: [(mon, coeff)], hypotheses: [...]}  (SymPy objects)."""
    K, w, terms, params = _equation_data(eq)
    out = {"holds": False, "K": K, "w": w, "params": params, "hypotheses": [], "conditions": []}
    if K < 1:
        out["reason"] = "the equation contains no derivative"
        return out
    top = tuple([0] * K + [1])
    if top not in terms or any(m[K] != 0 for m in terms if m != top):
        out["reason"] = ("the equation is not solved for the highest derivative w%d with a coefficient free of "
                         "the unknown (required form c*w%d = lambda*w0**n + Psi)" % (K, K))
        return out
    c = terms[top]
    out["hypotheses"].append({"text": "solved: E = c*w%d - Phi with c free of the jets" % K, "status": "verified",
                              "how": "c = %s" % sp.sstr(c)})
    phi = dict((m, -co) for m, co in terms.items() if m != top)        # c*wK = Phi
    pure = [m[0] for m in phi if all(e == 0 for e in m[1:]) and m[0] >= 2]
    if not pure:
        out["reason"] = "Phi contains no pure power w0**n with n >= 2"
        return out
    n = max(pure)
    lam = phi[tuple([n] + [0] * K)]
    p = Fraction(K, n - 1)

    def wt(m):
        return sum(e * (p + j) for j, e in enumerate(m))

    bad = [m for m in phi if m != tuple([n] + [0] * K) and wt(m) >= n * p]
    out.update({"n": n, "p": p, "c": c, "lam": lam})
    if bad:
        out["reason"] = ("hypothesis (H) fails: the monomial(s) %s have weight >= n*p = %s (weight of w_j is "
                         "p + j, p = K/(n-1) = %s); the pure-power class requires their coefficients to vanish"
                         % (", ".join(sp.sstr(_mono_expr(w, m)) for m in bad), n * p, p))
        return out
    out["holds"] = True
    out["psi"] = [(m, co) for m, co in phi.items() if m != tuple([n] + [0] * K)]
    out["hypotheses"].append({"text": "dominant pure power lambda*w0**n, n >= 2", "status": "verified",
                              "how": "n = %d, lambda = %s" % (n, sp.sstr(lam))})
    out["hypotheses"].append({"text": "(H): every other monomial has weight < n*p, weight(w_j) = p + j",
                              "status": "verified", "how": "p = K/(n-1) = %s, n*p = %s" % (p, n * p)})
    for name, val in (("c", c), ("lambda", lam)):
        if not val.is_number:
            out["conditions"].append("%s != 0" % sp.sstr(val))
    return out


# --------------------------------------------------------------------------------------- the engine
class _Ctx(object):
    """polynomial ring over QQ:  parameters, [ic = 1/c], [il = 1/lambda], A (= a0), eta (= c_{k0}/a0), rho."""

    def __init__(self, cls, deadline):
        self.deadline = deadline
        K, n, p = cls["K"], cls["n"], cls["p"]
        assert p.denominator == 1
        p = int(p)
        self.K, self.n, self.p, self.m = K, n, p, n - 1
        self.lam0 = (-1) ** K * _rising(p, K)
        self.k0 = K + 2 * p
        w = cls["w"]
        # replace non-rational constants (sqrt(2), I, pi, ...) by formal symbols: every identity used here is
        # polynomial in the coefficients, so it may be specialised afterwards.
        coeffs = [cls["c"], cls["lam"]] + [co for _, co in cls["psi"]]
        self.formal = {}
        clean = []
        for co in coeffs:
            co = sp.sympify(co)
            num, den = sp.fraction(sp.together(co))
            clean.append((num, den))
        # common denominator of all coefficients (a polynomial in the parameters): multiply through
        den_all = sp.Integer(1)
        for num, den in clean:
            den_all = sp.lcm(den_all, den)
        vals = [sp.expand(sp.cancel(num * den_all / den)) for num, den in clean]
        atoms = set()
        for v in vals:
            for a in v.atoms(sp.Pow, sp.Function, sp.NumberSymbol):
                if a.is_number and not a.is_Rational:
                    atoms.add(a)
            if v.has(sp.I):
                atoms.add(sp.I)
        for i, a in enumerate(sorted(atoms, key=sp.default_sort_key)):
            self.formal[a] = sp.Symbol("_k%d" % i)
        if self.formal:
            vals = [v.xreplace(self.formal) for v in vals]
        self.c_expr, self.lam_expr = vals[0], vals[1]
        self.psi_vals = vals[2:]
        self.params = sorted(set().union(*[v.free_symbols for v in vals]), key=str)
        names = [str(s) for s in self.params]
        self.c_num = self.c_expr.is_number
        self.lam_num = self.lam_expr.is_number
        extra = []
        if not self.c_num:
            extra.append("_ic")
        if not self.lam_num:
            extra.append("_il")
        allnames = names + extra + ["_A", "_eta", "_rho"]
        R_and_gens = _ring(",".join(allnames), QQ)
        self.R = R_and_gens[0]
        gens = R_and_gens[1:]
        self.gp = dict(zip(names, gens[:len(names)]))
        self.ic = gens[len(names)] if not self.c_num else None
        self.il = gens[len(names) + (0 if self.c_num else 1)] if not self.lam_num else None
        self.A, self.eta, self.rho = gens[-3], gens[-2], gens[-1]
        self.iA = len(allnames) - 3
        self.ieta = len(allnames) - 2
        self.irho = len(allnames) - 1
        self.syms = [sp.Symbol(s) for s in allnames]
        R = self.R
        cR = R.from_expr(self.c_expr) if not self.c_num else R(QQ(int(sp.numer(self.c_expr)),
                                                                   int(sp.denom(self.c_expr))))
        lamR = R.from_expr(self.lam_expr) if not self.lam_num else R(QQ(int(sp.numer(self.lam_expr)),
                                                                         int(sp.denom(self.lam_expr))))
        self.cR, self.lamR = cR, lamR
        icR = self.ic if not self.c_num else R(1) * QQ(int(sp.denom(self.c_expr)), int(sp.numer(self.c_expr)))
        ilR = self.il if not self.lam_num else R(1) * QQ(int(sp.denom(self.lam_expr)),
                                                         int(sp.numer(self.lam_expr)))
        self.icR, self.ilR = icR, ilR
        # A**m = r = c*lam0/lam ;  1/A = A**(m-1) / r,  1/r = lam*ic/lam0
        self.r = cR * self.lam0 * ilR
        self.rinv = lamR * icR * QQ(1, self.lam0)
        self.r_is_const = self.r.is_ground
        self.Ainv = self.reduce(self.A ** (self.m - 1) * self.rinv)
        # normalised coefficients  at_mu = (a_mu/c) * A**(d_mu - 1)
        self.mons = []
        for (mon, _), val in zip(cls["psi"], self.psi_vals):
            d = sum(mon)
            factors = []
            for j, e in enumerate(mon):
                factors += [j] * e
            wt = sum(e * (p + j) for j, e in enumerate(mon))
            omega = n * p - wt
            aR = R.from_expr(val) if val != 0 else R(0)
            if aR == 0:
                continue
            at = aR * icR * (self.A ** (d - 1) if d >= 1 else self.Ainv)
            self.mons.append({"mon": mon, "factors": factors, "omega": omega, "at": self.reduce(at), "d": d})
        self.w = w

    def check(self):
        if time.monotonic() > self.deadline:
            raise _Budget()

    def reduce(self, f):
        """reduce the powers of A modulo A**m = r"""
        m, iA = self.m, self.iA
        if f == 0:
            return f
        if all(mon[iA] < m for mon in f.keys()):
            return f
        R = self.R
        if self.r_is_const:
            rc = self.r.LC if self.r != 0 else QQ(0)
            out = {}
            for mon, co in f.items():
                e = mon[iA]
                if e >= m:
                    t, s = divmod(e, m)
                    mon = mon[:iA] + (s,) + mon[iA + 1:]
                    co = co * rc ** t
                out[mon] = out.get(mon, QQ(0)) + co
            g = R.zero
            for mon, co in out.items():
                if co != 0:
                    g[mon] = co
            return g
        groups = {}
        for mon, co in f.items():
            t, s = divmod(mon[iA], m)
            mon2 = mon[:iA] + (s,) + mon[iA + 1:]
            groups.setdefault(t, {})
            groups[t][mon2] = groups[t].get(mon2, QQ(0)) + co
        g = R.zero
        for t, d in groups.items():
            part = R.zero
            for mon, co in d.items():
                if co != 0:
                    part[mon] = co
            g += part * self.r ** t if t else part
        return g

    # ---------------------------------------------------------------------------- Laurent recursion
    def series(self, N):
        """normalised series u = w/A = x^-p (1 + sum b_k x^k), b_{k0} = eta.  Returns b, the powers
        Pw[e][t] = [x^t] B^e (e = 1..n) and the compatibility polynomial F (in the parameters and A)."""
        n, p, K, k0, R = self.n, self.p, self.K, self.k0, self.R
        b = [R(1)]
        Pw = {e: [R(1)] for e in range(1, n + 1)}
        prods = []
        for mu in self.mons:
            prods.append([[] for _ in mu["factors"]])
        F = None

        def bj(j, l):
            return b[l] * _ff(l - p, j)

        for k in range(1, N + 1):
            self.check()
            # lam0 * [x^k] (B_{<k})^n
            T = R(0)
            Ts = {0: R(0), 1: R(0)}
            for e in range(2, n + 1):
                s = Ts[e - 1]
                prev = Pw[e - 1]
                for l in range(1, k):
                    if b[l] != 0 and prev[k - l] != 0:
                        s = s + b[l] * prev[k - l]
                Ts[e] = self.reduce(s)
            rhs = Ts[n] * self.lam0
            # Psi terms
            for mu, pr in zip(self.mons, prods):
                t = k - mu["omega"]
                if t < 0:
                    continue
                facs = mu["factors"]
                if not facs:
                    if t == 0:
                        rhs = rhs + mu["at"]
                    continue
                # extend partial products to order t
                for r_, j in enumerate(facs):
                    while len(pr[r_]) <= t:
                        tt = len(pr[r_])
                        if r_ == 0:
                            pr[r_].append(bj(j, tt))
                        else:
                            s = R(0)
                            for l in range(tt + 1):
                                x1 = pr[r_ - 1][l]
                                if x1 != 0 and b[tt - l] != 0:
                                    s = s + x1 * bj(j, tt - l)
                            pr[r_].append(self.reduce(s))
                rhs = rhs + mu["at"] * pr[-1][t]
            rhs = self.reduce(rhs)
            Ik = _ff(k - p, K) - n * self.lam0
            if k == k0:
                assert Ik == 0
                F = rhs
                bk = self.eta
            else:
                assert Ik != 0
                bk = rhs * QQ(1, Ik)
            b.append(bk)
            for e in range(1, n + 1):
                Pw[e].append(Ts[e] + bk * e if e >= 2 else bk)
        return b, Pw, F

    def hseries(self, b, N):
        """[x^t] (B*B_2 - ((p+1)/p) B_1**2), t = 0..N   (H[u] = x^(-2p-2) * this)"""
        p, R = self.p, self.R
        cst = QQ(p + 1, p)
        out = []
        for t in range(N + 1):
            self.check()
            s = R(0)
            for l in range(t + 1):
                if b[l] == 0 or b[t - l] == 0:
                    continue
                s = s + b[l] * b[t - l] * (_ff(t - l - p, 2) - cst * _ff(l - p, 1) * _ff(t - l - p, 1))
            out.append(self.reduce(s))
        return out


def _det(M, R):
    """determinant (Laplace expansion along the first row; m <= 6)"""
    k = len(M)
    if k == 0:
        return R(1)
    if k == 1:
        return M[0][0]
    if k == 2:
        return M[0][0] * M[1][1] - M[0][1] * M[1][0]
    s = R(0)
    for j in range(k):
        if M[0][j] == 0:
            continue
        minor = [row[:j] + row[j + 1:] for row in M[1:]]
        term = M[0][j] * _det(minor, R)
        s = s + term if j % 2 == 0 else s - term
    return s


def _split_rho(ctx, f):
    """f = sum_t f_t rho^t  ->  {t: f_t}"""
    out = {}
    ir = ctx.irho
    for mon, co in f.items():
        t = mon[ir]
        mon2 = mon[:ir] + (0,) + mon[ir + 1:]
        out.setdefault(t, {})
        out[t][mon2] = out[t].get(mon2, QQ(0)) + co
    res = {}
    for t, d in out.items():
        g = ctx.R.zero
        for mon, co in d.items():
            if co != 0:
                g[mon] = co
        if g != 0:
            res[t] = g
    return res


def _split_A(ctx, f):
    """f (reduced) = sum_{s<m} A^s f_s  ->  [f_0, ..., f_{m-1}]"""
    m, iA = ctx.m, ctx.iA
    parts = [dict() for _ in range(m)]
    for mon, co in f.items():
        s = mon[iA]
        assert s < m
        mon2 = mon[:iA] + (0,) + mon[iA + 1:]
        parts[s][mon2] = parts[s].get(mon2, QQ(0)) + co
    out = []
    for d in parts:
        g = ctx.R.zero
        for mon, co in d.items():
            if co != 0:
                g[mon] = co
        out.append(g)
    return out


def _core_kappa(n, p, K, kmax):
    """kappa'_k (k = 1..kmax) of the core:  H(L(x;eta;0)) = sum kappa'_k eta^k x^(kJ-2p-2)  (rescale (4.3))"""
    J = K + 2 * p
    lam0 = (-1) ** K * _rising(p, K)
    N = kmax * J
    b = [Fraction(1)] + [Fraction(0)] * N
    pw = {e: [Fraction(1)] + [Fraction(0)] * N for e in range(1, n + 1)}
    for k in range(1, N + 1):
        Ts = {1: Fraction(0)}
        for e in range(2, n + 1):
            Ts[e] = Ts[e - 1] + sum(b[l] * pw[e - 1][k - l] for l in range(1, k))
        Ik = _ff(k - p, K) - n * lam0
        if k == J:
            bk = Fraction(1)
        else:
            bk = Fraction(lam0) * Ts[n] / Ik
        b[k] = bk
        for e in range(1, n + 1):
            pw[e][k] = Ts[e] + e * bk if e >= 2 else bk
    cst = Fraction(p + 1, p)
    kap = {}
    for k in range(1, kmax + 1):
        t = k * J
        s = Fraction(0)
        for l in range(t + 1):
            s += b[l] * b[t - l] * (_ff(t - l - p, 2) - cst * _ff(l - p, 1) * _ff(t - l - p, 1))
        kap[k] = s
    return kap


def choose_k(n, p, K):
    """(k, j_k, N_D, W, J, kappa'_k): the least k >= 2 with e_k >= N_D and kappa'_k != 0 (rescale Thm 4.6)"""
    m = n - 1
    J = K + 2 * p
    ND = sum(i * p - 1 for i in range(1, m + 1))
    W = ND + 2 * p + 2
    k = 2
    while True:
        ek = k * J - 2 * p - 2
        if ek >= ND:
            kap = _core_kappa(n, p, K, k)[k]
            if kap != 0:
                return k, ek - ND, ND, W, J, kap
        k += 1
        if k > 12:
            raise RuntimeError("no admissible k <= 12")


# ------------------------------------------------------------------------------------------- output
def _to_expr(ctx, f, h=None):
    """ring element -> SymPy expression in the parameters (ic, il replaced; A kept as a0)"""
    e = f.as_expr()
    rep = {}
    if ctx.ic is not None:
        rep[sp.Symbol("_ic")] = 1 / ctx.c_expr
    if ctx.il is not None:
        rep[sp.Symbol("_il")] = 1 / ctx.lam_expr
    rep[sp.Symbol("_A")] = sp.Symbol("a0")
    if h is not None:
        rep[sp.Symbol("_eta")] = h
    e = e.xreplace(rep)
    if ctx.formal:
        e = e.xreplace(dict((v, k) for k, v in ctx.formal.items()))
    return e


def _nice(c):
    """factor a coefficient only when it is small and rational (display only; never slow)"""
    if c.is_number or c.has(sp.I) or len(c.free_symbols) == 0:
        return c
    if sp.count_ops(c) > 60:
        return c
    try:
        return sp.factor(c)
    except Exception:
        return c


def _poly_str(expr, var):
    try:
        P = sp.Poly(expr, var)
        return sp.sstr(sum(_nice(c) * var ** m[0] for m, c in P.terms()))
    except Exception:
        return sp.sstr(expr)


def free_coefficient_values(eq, local=None, budget_s=120, extra=4, n_series=None):
    """Values of the free Laurent coefficient for the pure-power class (lemmas/freecoeff).

    Returns a dict (see lemmas/freecoeff/project note):
      applies, reason, class, K_parity, statement, label, source,
      a0: [ {a0, compatibility, gamma, gamma_index, degree, leading_coefficient, conditions_j, candidates, ...} ],
      k, bound_series, bound_poles_per_period, candidates (numeric parameters), certificate, status, elapsed_s.
    h denotes the Laurent coefficient c_{k0} of (z - z0)^(k0 - p) (the free symbol of local_analysis).
    """
    t0 = time.monotonic()
    deadline = t0 + budget_s
    res = {"module": "freecoeff", "engine": VERSION, "label": LABEL, "source": SOURCE, "warnings": []}
    try:
        cls = check_pure_power(eq)
    except Exception as err:   # pragma: no cover
        res.update({"applies": False, "reason": "could not read the equation: %s" % err})
        return res
    res["hypotheses"] = cls.get("hypotheses", [])
    res["conditions"] = cls.get("conditions", [])
    if not cls["holds"]:
        res.update({"applies": False, "reason": "not in the pure-power class: " + cls["reason"]})
        return res
    K, n, p = cls["K"], cls["n"], cls["p"]
    res["class"] = {"K": K, "n": n, "p": str(p), "c": sp.sstr(cls["c"]), "lambda": sp.sstr(cls["lam"])}
    if K < 3:
        res.update({"applies": False,
                    "reason": "order K = %d < 3: the pure-power theorem needs K >= 3 (for K = 2 the free "
                              "coefficient takes infinitely many values on some solutions, note 1 Example 1)" % K})
        return res
    if p.denominator != 1:
        res.update({"applies": True, "K_parity": "even" if K % 2 == 0 else "odd", "no_poles": True,
                    "statement": "p = K/(n-1) = %s is not an integer: no meromorphic solution has a pole, so every "
                                 "meromorphic solution is constant (note 1, Lemmas 2 and 5)." % p,
                    "bound_series": 0, "bound_poles_per_period": 0, "status": "complete",
                    "elapsed_s": round(time.monotonic() - t0, 3)})
        return res
    p = int(p)
    lam0 = (-1) ** K * _rising(p, K)
    a0sym = sp.Symbol("a0")
    rel = sp.sstr(sp.Eq(cls["lam"] * a0sym ** (n - 1), cls["c"] * lam0))
    res["class"].update({"lambda0": lam0, "a0_relation": rel, "k0": K + 2 * p if K % 2 == 0 else None})
    a0_roots = None
    rr = sp.cancel(cls["c"] * lam0 / cls["lam"])
    if rr.is_number:
        a0_roots = sp.roots(sp.Poly(a0sym ** (n - 1) - rr, a0sym), multiple=True)
    if K % 2 == 1:
        res.update({
            "applies": True, "K_parity": "odd", "free_coefficient": False,
            "statement": ("K = %d is odd: the indicial polynomial has no positive integer root, so for each of the "
                          "n - 1 = %d leading coefficients a0 (%s) there is exactly one formal Laurent series, with "
                          "no compatibility condition (note 1, Lemmas 5-6(a)). A meromorphic solution therefore has "
                          "at most %d different Laurent series at its poles; two poles with the same series differ "
                          "by a period, so it has at most %d poles modulo its periods (rational solutions: at most "
                          "%d poles)." % (K, n - 1, rel, n - 1, n - 1, n - 1)),
            "k": 1, "bound_series": n - 1, "bound_poles_per_period": n - 1,
            "a0": [{"a0": sp.sstr(a), "latex": sp.latex(a)} for a in (a0_roots or [])] if a0_roots else
                  [{"a0": "root of " + rel}],
            "status": "complete", "elapsed_s": round(time.monotonic() - t0, 3)})
        return res
    # ------------------------------------------------------------------------- even K
    k0 = K + 2 * p
    try:
        k, jk, ND, W, J, kap = choose_k(n, p, K)
        ctx = _Ctx(cls, deadline)
        m = ctx.m
        N = jk + max(0, int(extra)) + W + 2
        b, Pw, F = ctx.series(N)
        Hs = ctx.hseries(b, N)
        R = ctx.R
        A = ctx.A
        # series of E_i[w] = A^i u^i (valuation -i p) and H[w] = A^2 H[u] (valuation -2p-2)
        Eser = []
        for i in range(1, m + 1):
            Eser.append((-i * p, [ctx.reduce(A ** i * x) for x in Pw[i]]))
        Eser.append((-2 * p - 2, [ctx.reduce(A ** 2 * x) for x in Hs]))
        # principal-part polynomials hat e_i(rho) = sum_r [x^-r] (-rho)^(r-1)/(r-1)!
        rho = ctx.rho
        G = []
        for val, co in Eser:
            pp = R(0)
            for r_ in range(1, -val + 1):
                cr = co[-val - r_]
                if cr != 0:
                    assert all(mon[ctx.ieta] == 0 for mon in cr.keys()), "principal part depends on h"
                    pp = pp + cr * QQ((-1) ** (r_ - 1), factorial(r_ - 1)) * rho ** (r_ - 1)
            G.append(_split_A(ctx, ctx.reduce(pp)))
        ctx.check()
        ell = []
        for i in range(m + 1):
            minor = [G[ii] for ii in range(m + 1) if ii != i]
            d = _det(minor, R)
            ell.append(d if (i + 1) % 2 == 0 else -d)            # l_i = (-1)^i det(G without row i), i 1-based
        # normalise: make the leading rho-coefficient of l_{m+1} monic over QQ where possible
        lead = _split_rho(ctx, ell[m])
        top = max(lead)
        lc = lead[top]
        if lc.is_ground and lc != 0:
            ell = [x * (QQ(1) / lc.LC) for x in ell]
        else:
            cont = None
            for x in ell:
                for co in x.coeffs():
                    cont = co if cont is None else QQ.gcd(cont, co)
            if cont:
                ell = [x * (QQ(1) / cont) for x in ell]
        ellrho = [_split_rho(ctx, x) for x in ell]
        # divide out the largest common power D^s: Theta_a = D^s Theta, and Theta is pole-free as well
        # (D^s kills no negative power of x).  Theta gives the same conditions shifted by s, plus new ones
        # (its coefficients of x^1 .. x^(s-1) and its constant value).
        shift = min(min(d) for d in ellrho if d)
        if shift > 0:
            ellrho = [dict((t - shift, v) for t, v in d.items()) for d in ellrho]
        jk_s = jk + shift
        jmax = jk_s + max(0, int(extra))
        degl = [max(d) if d else -1 for d in ellrho]
        # coefficients of Theta[w]:  [x^j] = sum_i sum_t l_{i,t} ff(j+t, t) [x^(j+t)] E_i
        def coef(j):
            ctx.check()
            s = R(0)
            for (val, co), lr in zip(Eser, ellrho):
                for t, lt in lr.items():
                    e = j + t
                    idx = e - val
                    if idx < 0:
                        continue
                    if idx >= len(co):
                        raise RuntimeError("series too short (internal)")
                    if co[idx] == 0:
                        continue
                    s = s + lt * co[idx] * _ff(e, t)
            return ctx.reduce(s)
        maxpole = max(-val + degl[i] for i, (val, _) in enumerate(Eser))
        principal = {}
        for j in range(-maxpole, 0):
            principal[j] = coef(j)
        polefree = all(v == 0 for v in principal.values())
        gam = {}
        for j in range(0, jmax + 1):
            gam[j] = coef(j)
    except _Budget:
        res.update({"applies": True, "K_parity": "even", "status": "timeout",
                    "statement": "time budget of %s s exhausted before gamma was computed" % budget_s,
                    "elapsed_s": round(time.monotonic() - t0, 3)})
        return res

    hsym = sp.Symbol("h")
    # gamma in terms of h = c_{k0} = A * eta:  eta = h * A^(m-1) / r
    eta_of_h = ctx.reduce(ctx.A ** (m - 1) * ctx.rinv)          # 1/A
    def eta_deg(f):
        return max((mon[ctx.ieta] for mon in f.keys()), default=-1) if f != 0 else -1
    degs = dict((j, eta_deg(g)) for j, g in gam.items())

    def expr_h(f):
        """ring element in eta -> SymPy polynomial in h (a0 symbolic)"""
        e = _to_expr(ctx, f, h=hsym * _to_expr(ctx, eta_of_h))
        return sp.expand(e)

    gamma_k = expr_h(gam[jk_s])
    Fexpr = sp.expand(_to_expr(ctx, F))
    res.update({
        "applies": True, "K_parity": "even", "free_coefficient": True,
        "k0": k0, "k": k, "gamma_index": jk_s, "gamma_index_rescale": jk, "D_power_removed": shift, "N_D": ND, "weight_W": W, "kappa_core": str(kap),
        "h_meaning": "h = c_%d, the Laurent coefficient of (z - z0)^%d; the normalised datum is eta = h/a0" % (k0, k0 - p),
    })
    # ------------------------------------------------------------- statement
    res["statement"] = (
        "Pure-power class, K = %d even, n = %d, p = %d, Fuchs index k0 = %d. Let w be a solution meromorphic in C "
        "and z_i a pole, with leading coefficient a0 (%s) and free coefficient h = c_%d. Then gamma_{a0}(h) = 0, "
        "where gamma_{a0} = gamma_{a0,%d} is a polynomial of degree exactly %d in h with a leading coefficient that "
        "does not depend on the coefficients of Psi; moreover gamma_{a0,j}(h) = 0 for every j >= 1 and "
        "gamma_{a0,0}(h) takes the same value at all poles of w. Hence at most %d values of h per a0, at most %d "
        "Laurent series and at most %d poles modulo the periods."
        % (K, n, p, k0, rel, k0, jk_s, k, k, k * (n - 1), k * (n - 1)))
    # ------------------------------------------------------------- per a0 (symbolic a0 with relation)
    lc_expr = sp.Poly(gamma_k, hsym).LC() if gamma_k != 0 else sp.Integer(0)
    entry = {
        "a0": "a0", "a0_relation": rel,
        "compatibility": sp.sstr(Fexpr),
        "gamma": _poly_str(gamma_k, hsym), "gamma_latex": sp.latex(gamma_k),
        "gamma_index": jk_s, "degree": sp.Poly(gamma_k, hsym).degree() if gamma_k != 0 else None,
        "leading_coefficient": sp.sstr(sp.factor(lc_expr)),
        "conditions_j": [{"j": j, "degree": degs[j], "poly": _poly_str(expr_h(gam[j]), hsym)}
                         for j in range(1, jmax + 1) if j != jk_s],
        "kappa_poly": _poly_str(expr_h(gam[0]), hsym),
    }
    # low-degree conditions: degree 0 (no h) must vanish for a pole with this a0; degree 1 pins h if its
    # h-coefficient is nonzero (then at most one value of h per a0)
    pins, pole_conds = [], []
    for j in range(1, jmax + 1):
        if j == jk_s or degs[j] not in (0, 1):
            continue
        gj = expr_h(gam[j])
        if degs[j] == 0:
            pole_conds.append({"j": j, "condition": sp.sstr(gj) + " == 0"})
        else:
            Pj = sp.Poly(gj, hsym)
            c1, c0 = Pj.coeff_monomial(hsym), Pj.coeff_monomial(1)
            pins.append({"j": j, "h": sp.sstr(-c0 / c1) if len(sp.sstr(c0)) + len(sp.sstr(c1)) < 4000 else
                         "-(%s)/(%s)" % (sp.sstr(c0), sp.sstr(c1)), "valid_if": sp.sstr(c1) + " != 0",
                         "unconditional": bool(c1.is_number and c1 != 0)})
    entry["pole_conditions"] = pole_conds
    entry["affine_conditions"] = pins
    if pins:
        entry["note"] = ("gamma_{a0,%d} is affine in h: where its h-coefficient is nonzero, h is determined and there "
                         "is at most one value of h per a0" % pins[0]["j"])
    res["a0_symbolic"] = entry
    res["certificate"] = {
        "type": "pole-free differential polynomial",
        "E": ["w0**%d" % i if i > 1 else "w0" for i in range(1, m + 1)] +
             ["w0*w2 - %s*w1**2" % sp.sstr(sp.Rational(p + 1, p))],
        "ell": [{"i": i + 1, "operator": sp.sstr(sum(_to_expr(ctx, lt) * sp.Symbol("D") ** t
                                                    for t, lt in sorted(lr.items())))}
                for i, lr in enumerate(ellrho)],
        "theta_note": "Theta = sum_i ell_i(D) E_i, D = d/dz; the coefficients are rational in the parameters "
                      "(a0 does not occur).",
        "pole_free": {"status": "verified" if polefree else "FAILED",
                      "detail": "the coefficients of x^%d .. x^-1 of Theta[w(x;h)] vanish identically in h, a0 "
                                "(modulo %s) and the parameters; Laurent series computed to order %d"
                                % (-maxpole, rel, N)},
        "gamma_index": jk_s, "D_power_removed": shift, "series_order": N,
        "how_to_check": "lemmas/freecoeff/project note",
    }
    if not polefree:
        res["warnings"].append("pole-free identity FAILED: internal error, result must not be used")
        res["status"] = "error"
        res["elapsed_s"] = round(time.monotonic() - t0, 3)
        return res
    if degs[jk_s] != k:
        res["warnings"].append("degree of gamma_%d is %d, expected %d (internal error)" % (jk_s, degs[jk_s], k))
    # ------------------------------------------------------------- numeric parameters: candidates
    res["a0"] = []
    numeric = not ctx.params and not ctx.formal
    if local:
        _cross_check_local(res, local, p, a0_roots)
    cand_ok = False
    if a0_roots is not None and numeric:
        reader = None
        try:
            reader = _reader(ctx, deadline)
            if not reader.get("exists"):
                res["certificate"]["reader"] = {"exists": False, "note": "no polynomial J + sum mu_i(D) E_i of weight "
                                                "<= k0 without poles (linear system over QQ has no solution)"}
                reader = None
                raise StopIteration
            res["certificate"]["reader"] = {
                "J": "1/2*sum_{i=1}^{K-1} (-1)**(i-1) w_i*w_{K-i} - (lambda/c)/(n+1)*w0**(n+1)  (first integral of "
                     "the truncated equation, note 1 (eq:E))",
                "R": "R = sum_i op_i(D) E_i, rows E_1..E_{n-1}, H, J",
                "operators": reader["ops"], "pole_free": "verified" if reader["pole_free"] else "FAILED",
                "series_order": reader["series_order"]}
            if not reader["pole_free"]:
                res["warnings"].append("reader construction not pole-free (internal); not used")
                reader = None
        except StopIteration:
            pass
        except _Budget:
            res["warnings"].append("time budget exhausted in the reader construction; not used")
            reader = None
        except Exception as err:
            res["warnings"].append("reader construction failed (%s); not used" % (str(err)[:160],))
            reader = None
        try:
            cand = _candidates(ctx, gam, F, jk_s, jmax, hsym, eta_of_h, b, n_series, deadline, reader=reader)
            res.update(cand)
            cand_ok = True
        except _Budget:
            res["warnings"].append("time budget exhausted while solving for the candidate values; the theorem's "
                                   "bound k(n-1) is reported instead")
            res["status"] = "partial"
        except Exception as err:          # exact solving/verification did not go through: fall back
            res["warnings"].append("exact solution of the candidate system failed (%s); the theorem's bound "
                                   "k(n-1) is reported instead" % (str(err)[:200],))
            res["status"] = "partial"
            res["a0"] = []
    if not cand_ok:
        # symbolic: one entry per a0 root if the roots are explicit, else the symbolic entry
        if a0_roots is not None:
            for a in a0_roots:
                g = sp.expand(gamma_k.subs(a0sym, a))
                res["a0"].append({"a0": sp.sstr(a), "latex": sp.latex(a),
                                  "compatibility": sp.sstr(sp.expand(Fexpr.subs(a0sym, a))),
                                  "gamma": _poly_str(g, hsym), "gamma_latex": sp.latex(g),
                                  "degree": sp.Poly(g, hsym).degree()})
        res["bound_series"] = k * (n - 1)
        res["bound_poles_per_period"] = k * (n - 1)
        res["bound_basis"] = "project note Theorem 4.6: at most k = %d values of h per a0" % k
        unc = [pn for pn in res["a0_symbolic"].get("affine_conditions", []) if pn.get("unconditional")]
        if unc:
            res["bound_series"] = n - 1
            res["bound_poles_per_period"] = n - 1
            res["bound_basis"] = ("gamma_{a0,%d} is affine in h with a nonzero numerical h-coefficient: at most one "
                                  "value of h per a0 (certificate: a0_symbolic.affine_conditions)" % unc[0]["j"])
        elif res["a0_symbolic"].get("affine_conditions"):
            res["bound_note"] = ("at most one value of h per a0 (bound n - 1 = %d) where %s"
                                 % (n - 1, res["a0_symbolic"]["affine_conditions"][0]["valid_if"]))
    res.setdefault("status", "complete")
    res["elapsed_s"] = round(time.monotonic() - t0, 3)
    return res


def _series_E(ctx, N, with_J=False):
    """series (valuation, coefficients) of E_1..E_m, H and (optionally) the first integral J of the truncated equation,
    all on the family with leading coefficient A (normalised recursion), to order N."""
    b, Pw, F = ctx.series(N)
    R, A, p, K, m, n = ctx.R, ctx.A, ctx.p, ctx.K, ctx.m, ctx.n
    Eser = [(-i * p, [ctx.reduce(A ** i * x) for x in Pw[i]]) for i in range(1, m + 1)]
    Eser.append((-2 * p - 2, [ctx.reduce(A ** 2 * x) for x in ctx.hseries(b, N)]))
    if with_J:
        # J[w] = A^2 x^(-k0) ( 1/2 sum_{i=1}^{K-1} (-1)^(i-1) B_i B_{K-i} - lam0/(n+1) B^(n+1) )
        Bn1 = []
        for t in range(N + 1):
            s = R(0)
            for l in range(t + 1):
                if b[l] != 0 and Pw[n][t - l] != 0:
                    s = s + b[l] * Pw[n][t - l]
            Bn1.append(ctx.reduce(s))
        Jc = []
        for t in range(N + 1):
            ctx.check()
            s = R(0)
            for i in range(1, K):
                sg = QQ((-1) ** (i - 1), 2)
                for l in range(t + 1):
                    if b[l] == 0 or b[t - l] == 0:
                        continue
                    s = s + b[l] * b[t - l] * (sg * _ff(l - p, i) * _ff(t - l - p, K - i))
            s = s - Bn1[t] * QQ(ctx.lam0, n + 1)
            Jc.append(ctx.reduce(A ** 2 * s))
        Eser.append((-(K + 2 * p), Jc))
    return b, F, Eser


def _pp_graded(ctx, val, co):
    """principal-part polynomial in rho of a series, graded by powers of A"""
    R, rho = ctx.R, ctx.rho
    pp = R(0)
    for r_ in range(1, -val + 1):
        cr = co[-val - r_]
        if cr != 0:
            if any(mon[ctx.ieta] != 0 for mon in cr.keys()):
                raise RuntimeError("principal part depends on h")
            pp = pp + cr * QQ((-1) ** (r_ - 1), factorial(r_ - 1)) * rho ** (r_ - 1)
    return _split_A(ctx, ctx.reduce(pp))


def _reader(ctx, deadline):
    """numeric parameters only: a pole-free polynomial R = g(D) J - sum_i mu_i(D) E_i built from the first integral J
    of the truncated equation (project note Theorem 4.2(d) 'reader').  Returns a dict with the operators, the pole-free
    verification, and gamma0 = [x^0] R[w(x; eta)] as a ring element (in A, eta)."""
    rs = sp.Symbol("_rho")
    m, p, K = ctx.m, ctx.p, ctx.K
    k0 = K + 2 * p
    b, F, Eser = _series_E(ctx, max(k0, 2 * p + 2) + 2, with_J=True)
    G = [_pp_graded(ctx, val, co) for val, co in Eser]          # rows E_1..E_m, H, J ; m columns
    toP = lambda f: sp.Poly(f.as_expr().xreplace({sp.Symbol("_rho"): rs}), rs, domain="QQ")
    Gm = [[toP(x) for x in row] for row in G[:m + 1]]
    v = [toP(x) for x in G[m + 1]]
    # R = J + sum_i mu_i(D) E_i with deg mu_i <= k0 - w_i (weight <= k0, so [x^0] R[w] is affine in h):
    # solve sum_i mu_i * G[i][s] = -v[s] (s < m) as a linear system over QQ
    weights = [i * p for i in range(1, m + 1)] + [2 * p + 2]
    dmax = [k0 - wt for wt in weights]
    unknowns = []
    for i in range(m + 1):
        for t in range(dmax[i] + 1):
            unknowns.append((i, t))
    rowsA, rhs = [], []
    maxdeg = max([dmax[i] + max((Gm[i][s].degree() for s in range(m) if not Gm[i][s].is_zero), default=0)
                  for i in range(m + 1)] + [x.degree() for x in v if not x.is_zero] + [0])
    for s in range(m):
        cols = []
        for (i, t) in unknowns:
            gpoly = Gm[i][s]
            cols.append([gpoly.coeff_monomial(rs ** (e - t)) if e - t >= 0 else 0 for e in range(maxdeg + 1)])
        for e in range(maxdeg + 1):
            rowsA.append([cols[u][e] for u in range(len(unknowns))])
            rhs.append(-v[s].coeff_monomial(rs ** e))
    if time.monotonic() > deadline:
        raise _Budget()
    Amat = sp.Matrix(rowsA)
    bvec = sp.Matrix(rhs)
    try:
        sol, params_ = Amat.gauss_jordan_solve(bvec)
    except ValueError:
        return {"exists": False}
    sol = sol.subs(dict((t_, 0) for t_ in params_))
    mu = [sp.Poly(0, rs, domain="QQ") for _ in range(m + 1)]
    for u, (i, t) in enumerate(unknowns):
        if sol[u] != 0:
            mu[i] = mu[i] + sp.Poly(sol[u] * rs ** t, rs, domain="QQ")
    g = sp.Poly(1, rs, domain="QQ")
    # operators of R: E_i -> mu_i, J -> 1
    ops = [x for x in mu] + [g]
    degs = [x.degree() if not x.is_zero else -1 for x in ops]
    weights = [i * p for i in range(1, m + 1)] + [2 * p + 2, k0]
    need = max(dg + wt for dg, wt in zip(degs, weights)) + 2
    b, F, Eser = _series_E(ctx, need, with_J=True)
    R = ctx.R
    opsR = []
    for x in ops:
        d = {}
        for (t,), co in x.terms():
            d[t] = R(QQ(int(sp.numer(co)), int(sp.denom(co))))
        opsR.append(d)

    def coefR(j):
        if time.monotonic() > deadline:
            raise _Budget()
        s = R(0)
        for (val, co), lr in zip(Eser, opsR):
            for t, lt in lr.items():
                e = j + t
                idx = e - val
                if idx < 0 or co[idx] == 0:
                    continue
                s = s + lt * co[idx] * _ff(e, t)
        return ctx.reduce(s)
    maxpole = max(-val + dg for (val, _), dg in zip(Eser, degs) if dg >= 0)
    polefree = all(coefR(j) == 0 for j in range(-maxpole, 0))
    D = sp.Symbol("D")
    return {"exists": True, "ops": [sp.sstr(x.as_expr().xreplace({rs: D})) for x in ops],
            "pole_free": polefree, "gamma0": coefR(0), "series_order": need}


def _cross_check_local(res, local, p, a0_roots):
    """compare with local_analysis (CORE): pole order and leading coefficients; warnings only"""
    try:
        bals = [bb for bb in local.get("balances", []) if str(bb.get("p")) == str(p)]
        if not bals:
            res["warnings"].append("local_analysis lists no balance with p = %s" % p)
            return
        if a0_roots is not None:
            given = [sp.sympify(bb.get("a0")) for bb in bals if bb.get("a0") not in (None, "")]
            for g in given:
                if not any(sp.simplify(g - a) == 0 for a in a0_roots):
                    res["warnings"].append("local_analysis a0 = %s is not a root of the a0 relation" % g)
    except Exception as err:   # pragma: no cover
        res["warnings"].append("could not compare with local_analysis: %s" % err)


def _candidates(ctx, gam, F, jk, jmax, hsym, eta_of_h, b, n_series, deadline, reader=None):
    """numeric parameters: all pairs (a0, h) with a0^m = r, F(a0) = 0, gamma_j(a0, h) = 0 (1 <= j <= jmax);
    exact (Groebner basis over QQ, then explicit roots); grouping by the value kappa = gamma_0 of Theta and, if a
    reader R is available, by the value kappa_R = [x^0] R[w] as well (both are constant on a meromorphic solution)."""
    Asym = sp.Symbol("a0")
    m = ctx.m
    r = sp.Rational(ctx.r.LC) if ctx.r != 0 else sp.Integer(0)

    def ex(f, eta=None):
        e = _to_expr(ctx, f, h=eta)
        return sp.expand(e)

    eta_h = hsym * ex(eta_of_h)
    polys = [Asym ** m - r]
    Fe = ex(F)
    if Fe != 0:
        polys.append(Fe)
    gj = {}
    for j in range(0, jmax + 1):
        gj[j] = sp.expand(ex(gam[j], eta=eta_h))
    for j in range(1, jmax + 1):
        if gj[j] != 0:
            polys.append(gj[j])
    if time.monotonic() > deadline:
        raise _Budget()
    GB = sp.groebner(polys, hsym, Asym, order="lex")
    out = {"groebner_basis": [sp.sstr(g) for g in GB.exprs]}
    a0_list = sp.roots(sp.Poly(Asym ** m - r, Asym), multiple=True)
    per = []
    sols = []
    if list(GB.exprs) == [1]:
        sols = []
    else:
        sols = sp.solve(list(GB.exprs), [hsym, Asym], dict=True)
    gR = sp.expand(ex(reader["gamma0"], eta=eta_h)) if reader is not None else None
    # verify each solution exactly
    verified = []
    for s in sols:
        a0v, hv = s[Asym], s[hsym]
        ok = True
        for P in polys:
            val = sp.simplify(sp.expand(P.subs({Asym: a0v, hsym: hv})))
            if val != 0:
                ok = False
                break
        if not ok:
            raise RuntimeError("candidate failed exact verification: %s" % s)
        kap = sp.simplify(gj[0].subs({Asym: a0v, hsym: hv}))
        kapR = sp.simplify(gR.subs({Asym: a0v, hsym: hv})) if gR is not None else sp.Integer(0)
        verified.append({"a0": a0v, "h": hv, "kappa": kap, "kappa_R": kapR})
    # kappa classes
    classes = []
    for v in verified:
        for cl in classes:
            if sp.simplify(cl[0]["kappa"] - v["kappa"]) == 0 and sp.simplify(cl[0]["kappa_R"] - v["kappa_R"]) == 0:
                cl.append(v)
                break
        else:
            classes.append([v])
    gamma_k_h = gj[jk]
    for a in a0_list:
        g = sp.expand(gamma_k_h.subs(Asym, a))
        Fa = sp.simplify(Fe.subs(Asym, a)) if Fe != 0 else sp.Integer(0)
        hs = [v for v in verified if sp.simplify(v["a0"] - a) == 0]
        ent = {"a0": sp.sstr(a), "latex": sp.latex(a),
               "compatibility": sp.sstr(Fa), "compatible": bool(Fa == 0),
               "gamma": _poly_str(g, hsym), "gamma_latex": sp.latex(g), "gamma_index": jk,
               "degree": sp.Poly(g, hsym).degree() if g != 0 else None,
               "gamma_roots": [sp.sstr(x) for x in sp.roots(sp.Poly(g, hsym), multiple=True)] if g != 0 else [],
               "admissible_h": [sp.sstr(v["h"]) for v in hs],
               "admissible_h_latex": [sp.latex(v["h"]) for v in hs]}
        if gR is not None:
            gRa = sp.Poly(sp.expand(gR.subs(Asym, a)), hsym)
            ent["reader_value"] = _poly_str(gRa.as_expr(), hsym)
            ent["reader"] = bool(gRa.degree() == 1)
        # Laurent series of the candidates: c_k = a0 * b_k(eta = h/a0)
        nshow = n_series if n_series is not None else ctx.k0 + 2
        ser = []
        for v in hs:
            etav = sp.simplify(v["h"] / a)
            cs = []
            for kk in range(0, min(nshow, len(b) - 1) + 1):
                e = _to_expr(ctx, b[kk], h=etav).subs(sp.Symbol("a0"), a)
                cs.append(sp.sstr(sp.simplify(a * e)))
            ser.append({"h": sp.sstr(v["h"]), "kappa": sp.sstr(v["kappa"]), "kappa_R": sp.sstr(v["kappa_R"]),
                        "coeffs": cs})
        ent["series"] = ser
        per.append(ent)
    nser = len(verified)
    bound = max((len(cl) for cl in classes), default=0)
    out.update({
        "a0": per,
        "candidates_count": nser,
        "kappa_classes": [{"kappa": sp.sstr(cl[0]["kappa"]), "kappa_R": sp.sstr(cl[0]["kappa_R"]),
                           "series": [{"a0": sp.sstr(v["a0"]), "h": sp.sstr(v["h"])} for v in cl]}
                          for cl in classes],
        "bound_series": nser,
        "bound_poles_per_period": bound,
        "bound_basis": ("exact: the %d pairs (a0, h) that satisfy the compatibility condition and "
                        "gamma_j = 0 for 1 <= j <= %d (Groebner basis); the poles of one solution all carry the "
                        "same value kappa = gamma_0 of Theta%s, so at most %d poles modulo the periods"
                        % (nser, jmax, " and kappa_R of the reader R" if gR is not None else "", bound)),
        "no_poles": nser == 0,
    })
    if nser == 0:
        out["statement_no_poles"] = ("No Laurent series with a pole is compatible with global meromorphy: every "
                                     "meromorphic solution is constant.")
    return out
