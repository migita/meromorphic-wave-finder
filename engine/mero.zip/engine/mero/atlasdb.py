# -*- coding: utf-8 -*-
"""
mero.atlasdb -- look up an equation in the atlas of 4 October 2026 (converted cards).  Worker LOOKUP.

    from mero.atlasdb import lookup
    res = lookup(eq, mode='fast', budget_s=20)          # eq: mero Equation (or bootstrap Equation), see equation_rhs()

The database is project file (written by project file from
project note and project file*.jsonl).  `lookup(..., db=...)` accepts the path of
atlas_index.json or of the folder, a pre-loaded index dict (with `shard_data` = {order: shard dict}), one shard dict, a
list of converted cards, or an AtlasDB.  In the browser the site fetches atlas_index.json and the shard of the order
and passes them (see load_db).

What a match means is exactly what the old look-up tool project script decides (atlas_20261004/project note,
project file note): the card's right-hand side Phi_R(x; pi) at some complex parameter values pi (locus
equalities satisfied, '!=' conditions and denominators nonzero), transformed by v = alpha*w + beta, z = gamma*zeta +
delta (alpha*gamma != 0), equals the given right-hand side.  Three modes in this order: no change; the changes that the
card's normalisation declares; the full group (a member found only there is an 'undeclared-change' match).  Exact
arithmetic throughout (pre-elimination of linear unknowns, Groebner bases with the Rabinowitsch trick).  A decision that
does not finish within the time budget is reported as undecided, never as a non-match.

Pure Python + SymPy (+ mpmath); no threads, signals or subprocesses (it runs under Pyodide).  The Groebner bases are
computed by a copy of SymPy's Buchberger algorithm with a deadline check (same reduced basis as sympy.groebner).

Speed (the old tool parsed every same-order record at every query and worked with SymPy expressions):
  * the cards are pre-parsed by convert.py (support, coefficients, locus conditions, declared changes, and the
    coefficients as polynomials over Q with one inverse variable per denominator);
  * a support prefilter without SymPy (the old tool's two exact necessary conditions);
  * the decision in SymPy's sparse polynomial rings: unknowns = card parameters, alpha, 1/alpha, beta, gamma,
    1/gamma, the Rabinowitsch variable; the old tool's linear pre-elimination; then the numerators with
    1/alpha -> alpha^-1 cleared (exactly the old tool's system) and the Groebner/Rabinowitsch decision.  Ground field
    Q, or Q(visitor's symbols) (sym_method='field', default; 'block' = elimination order over Q, also exact).
    Cards with algebraic numbers (3 cards) and equations with algebraic coefficients use the old expression path.
A decision is given up (undecided) when its time budget is exhausted or a coefficient swells beyond SWELL_LIMIT; the
budget is checked between polynomial operations, so one long SymPy operation can overrun it.
"""
import json
import os
import re
import time

import sympy as sp

__all__ = ['lookup', 'load_db', 'AtlasDB', 'equation_rhs', 'SUMMARY_LINES']

AL, BE, GA, TT = sp.symbols('ATL_alpha ATL_beta ATL_gamma ATL_t')
AI, GI = sp.symbols('ATL_alphainv ATL_gammainv')          # 1/alpha, 1/gamma (polynomial-ring path)
KINDS = ('wave', 'nowave', 'sector', 'open')
STRONG = ('PROVED-HERE', 'EXACT-COMPUTATION', 'IMPORTED-CHECKED', 'IMPORTED', 'QUOTED')
LADDER = ['complete list', 'complete list (qualified)', 'list of solutions with a pole', 'structure',
          'solutions (no completeness)', 'formal', 'open (unresolved)', 'none']
LABEL_RANK = {'PROVED-HERE': 0, 'EXACT-COMPUTATION': 0, 'IMPORTED-CHECKED': 1, 'IMPORTED': 2, 'QUOTED': 2}
ASPECTS = ('formal', 'identity', 'global_meromorphy', 'field_dimension', 'coverage', 'completeness')
SUMMARY_LINES = {
    'complete': 'all meromorphic solutions are known: sector record X (completeness LABEL: "..."; locus ...)',
    'qualified': 'sector record(s) with a completeness label whose statement reads as qualified',
    'known': 'known solutions, list not known to be complete',
    'none': 'no record contains this equation; formal data only',
}
_HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_DB = os.path.abspath(os.path.join(_HERE, '..', '..', 'atlas', 'cards_converted'))
CHANGE_NOTE = ('card variables in terms of yours: v = alpha*w + beta, z_card = gamma*z + delta (delta arbitrary); '
               "'free' = any value on a family of solutions of the matching problem, 'any' = not constrained")


class Undecided(Exception):
    """the time budget of one decision is exhausted"""


class InputError(Exception):
    pass


def _now():
    return time.time()


def _check(deadline):
    if deadline is not None and _now() > deadline:
        raise Undecided('time budget exhausted')


# ------------------------------------------------------------------------------------------------ monomials
def _deg(m):
    return sum(m)


def _Jw(m):
    return sum(j * e for j, e in enumerate(m))


def _xs(p):
    return [sp.Symbol('x%d' % j) for j in range(p)]


def _mono_expr(m):
    return sp.Mul(*[sp.Symbol('x%d' % j) ** e for j, e in enumerate(m)])


def _rhs_of(C):
    return sp.Add(*[c * _mono_expr(m) for m, c in C.items()])


def _coeff_dict(expr, p):
    Xs = _xs(p)
    e = sp.expand(expr)
    if e == 0:
        return {}
    P = sp.Poly(e, *Xs)
    out = {}
    for mon, c in P.terms():
        c = sp.cancel(c)
        if c != 0:
            out[tuple(mon)] = c
    return out


def transform(C, p, al, be, ga):
    """coefficients of the equation for w, where v = al*w + be, z = ga*zeta + delta and v^(p) = Phi:
    c'_m = al^(|m|-1) ga^(p-J(m)) sum_k binom(m0+k, k) be^k c_{m+k e0}   (the old tool's transform)"""
    acc = {}
    for m, c in C.items():
        m0, rest = m[0], tuple(m[1:])
        for k in range(m0 + 1):
            if k > 0 and be == 0:
                break
            mm = (m0 - k,) + rest
            acc[mm] = acc.get(mm, 0) + sp.binomial(m0, k) * be ** k * c
    return {mm: al ** (_deg(mm) - 1) * ga ** (p - _Jw(mm)) * s for mm, s in acc.items()}


def is_zero_exact(e):
    """exact zero test (ENUM's is_zero): rationals, algebraic numbers, rational functions of symbols"""
    e = sp.sympify(e)
    if e == 0:
        return True
    if e.is_Rational:
        return False
    if e.has(sp.Float):
        raise ValueError('floating-point number in an exact computation: %s' % e)
    e2 = sp.cancel(sp.together(e))
    if e2 == 0:
        return True
    if e2.is_number:
        return sp.simplify(e2) == 0
    return False


# ------------------------------------------------------------------------------------------------ input
def equation_rhs(eq):
    """-> (p, U, usyms, info): U = {monomial in x0..x(p-1): exact coefficient} of the solved form
    v^(p) = Phi, usyms = the visitor's symbols (renamed <name>_user), info = names for display.

    Accepted: a mero Equation (CORE's mero.equation.Equation or bootstrap.Equation; jets w0..wK); a dict
    {'order': K, 'rhs': text} or {'E': text} (jets w0.. or x0..); a pair (K, rhs text)."""
    xsyms = None
    K = None
    E = None
    params = []
    unknown, var = 'w', 'z'
    if isinstance(eq, (tuple, list)) and len(eq) == 2:
        eq = {'order': eq[0], 'rhs': eq[1]}
    if isinstance(eq, dict):
        txt = eq.get('E') or eq.get('ode')
        rhs_t = eq.get('rhs')
        names = set(re.findall(r'[A-Za-z_][A-Za-z_0-9]*', str(txt or rhs_t)))
        jets_w = sorted(int(n[1:]) for n in names if re.fullmatch(r'w\d+', n))
        jets_x = sorted(int(n[1:]) for n in names if re.fullmatch(r'x\d+', n))
        letter = 'w' if jets_w or not jets_x else 'x'
        loc = {n: sp.Symbol(n) for n in names if n not in ('sqrt', 'Rational', 'I', 'pi')}
        if txt is not None:
            if re.search(r'(?<![A-Za-z_0-9])\d+\.\d', str(txt)):
                raise InputError('inexact (decimal) number: use exact rationals')
            if '=' in str(txt):
                l_, r_ = str(txt).split('=', 1)
                E = sp.sympify(l_, locals=loc) - sp.sympify(r_.lstrip('='), locals=loc)
            else:
                E = sp.sympify(txt, locals=loc)
            js = jets_w if letter == 'w' else jets_x
            K = max(js) if js else 0
        else:
            K = int(eq['order'])
            if re.search(r'(?<![A-Za-z_0-9])\d+\.\d', str(rhs_t)):
                raise InputError('inexact (decimal) number: use exact rationals')
            E = sp.Symbol('%s%d' % (letter, K)) - sp.sympify(rhs_t, locals=loc)
        wsyms = [sp.Symbol('%s%d' % (letter, j)) for j in range(K + 1)]
    else:
        K = int(eq.K)
        wsyms = list(eq.w)
        if getattr(eq, 'E', None) is not None:
            E = sp.sympify(eq.E)
        elif getattr(eq, 'terms', None):
            E = sp.Add(*[sp.sympify(c) * sp.Mul(*[w ** e for w, e in zip(wsyms, mon)]) for mon, c in eq.terms.items()])
        else:
            E = wsyms[K] - sp.sympify(eq.rhs)
        params = [str(s) for s in (getattr(eq, 'params', None) or [])]
        unknown = getattr(eq, 'unknown', None) or 'w'
        var = getattr(eq, 'var', None) or 'z'
    E = sp.expand(E)
    if E.atoms(sp.Float):
        raise InputError('inexact (decimal) number in the equation: use exact rationals')
    wset = set(wsyms)
    # the visitor's symbols: renamed <name>_user (never equal to a card parameter); jets -> x0..x(K-1)
    others = sorted((s for s in E.free_symbols if s not in wset), key=str)
    ren = {s: sp.Symbol(s.name if s.name.endswith('_user') else s.name + '_user') for s in others}
    E = E.xreplace(ren)
    wK = wsyms[K]
    c = sp.expand(sp.diff(E, wK))
    if c == 0:
        raise InputError('the equation does not contain the top jet')
    if c.free_symbols & wset:
        raise InputError('the equation is not linear in the top jet with a constant coefficient')
    rest = sp.expand(E - c * wK)
    if rest.has(wK):
        raise InputError('the equation is not linear in the top jet')
    rhs = sp.expand(-rest / c) if c != 1 else sp.expand(-rest)
    X = {wsyms[j]: sp.Symbol('x%d' % j) for j in range(K)}
    rhs = rhs.xreplace(X)
    if K < 1:
        raise InputError('order must be >= 1')
    U = _coeff_dict(rhs, K)
    xset = set(_xs(K))
    for m, cc in U.items():
        if sp.sympify(cc).free_symbols & xset:
            raise InputError('not polynomial in the jets')
    usyms = sorted(set().union(*[sp.sympify(cc).free_symbols for cc in U.values()]) if U else set(), key=str)
    info = {'unknown': unknown, 'var': var, 'params': params,
            'user_symbols': {str(v): str(k) for k, v in ren.items()}}
    return K, U, usyms, info


# ------------------------------------------------------------------------------------------------ database
class Card(object):
    """one converted card; the expressions are parsed lazily"""

    def __init__(self, d):
        self.d = d
        self.id = d.get('id')
        self.kind = d.get('kind')
        self.card = d.get('card') or {}
        self.derived = d.get('derived') or {}
        m = d.get('match')
        self.ok = m is not None
        if not self.ok:
            self.reason = self.derived.get('not_testable') or 'not testable'
            return
        self.m = m
        self.p = m['p']
        self.mons = [tuple(x) for x in m['support']]
        self.S = set(self.mons)
        self.numeric = {mm for mm, isn in zip(self.mons, m['numeric']) if isn}
        self.maxm0 = {}
        for mm in self.mons:
            r = mm[1:]
            if self.maxm0.get(r, -1) < mm[0]:
                self.maxm0[r] = mm[0]
        self.forced = {mm for mm in self.numeric if self.maxm0.get(mm[1:]) == mm[0]}
        self.group = set(m.get('group') or [])
        self.restricting = list(m.get('restricting') or [])
        self.harmless = list(m.get('harmless') or [])
        self.order_texts = list(m.get('order_texts') or [])
        self.existential = list(m.get('existential') or [])
        self._parsed = False

    def parse(self):
        if self._parsed:
            return
        m = self.m
        self.psyms = [sp.Symbol(n) for n in m['syms']]
        loc = {'P%d' % i: s for i, s in enumerate(self.psyms)}
        loc.update({'I': sp.I, 'sqrt': sp.sqrt, 'Rational': sp.Rational})

        def P(s):
            return sp.sympify(s, locals=loc)
        self.C = {mm: P(s) for mm, s in zip(self.mons, m['coef'])}
        self.eqs = [P(s) for s in m['eqs']]
        self.ineqs = [P(s) for s in m['ineqs']]
        self.dens = [P(s) for s in m['dens']]
        self.orders = [(P(s), op) for s, op in m['orders']]
        self._parsed = True


class AtlasDB(object):
    def __init__(self, src=None):
        self.index = None
        self.base = None
        self.by_order = {}
        self.shard_data = {}
        if src is None:
            src = DEFAULT_DB
        if isinstance(src, AtlasDB):
            self.__dict__.update(src.__dict__)
            return
        if isinstance(src, str):
            path = src
            if os.path.isdir(path):
                path = os.path.join(path, 'atlas_index.json')
            self.base = os.path.dirname(os.path.abspath(path))
            with open(path, encoding='utf-8') as f:
                d = json.load(f)
            src = d
        if isinstance(src, list):
            self._add_cards(src)
            return
        if isinstance(src, dict):
            if 'cards' in src and src.get('schema', '').startswith('mero-atlasdb-shard'):
                self._add_cards(src['cards'])
                return
            if 'shards' in src:
                self.index = src
                for k, v in (src.get('shard_data') or {}).items():
                    self.shard_data[str(k)] = v
                return
            if 'cards' in src:
                self._add_cards(src['cards'])
                return
        raise ValueError('unknown database format')

    def _add_cards(self, cards):
        for c in cards:
            if not isinstance(c, dict) or c.get('match') is None:
                continue
            self.by_order.setdefault(c['match']['p'], []).append(Card(c))

    def cards_of_order(self, p):
        if p in self.by_order:
            return self.by_order[p]
        if self.index is not None:
            key = str(p)
            sh = self.shard_data.get(key)
            if sh is None:
                info = (self.index.get('shards') or {}).get(key)
                if info is None or self.base is None:
                    self.by_order[p] = []
                    return []
                with open(os.path.join(self.base, info['file']), encoding='utf-8') as f:
                    sh = json.load(f)
            self.by_order[p] = [Card(c) for c in sh.get('cards') or [] if c.get('match') is not None]
            return self.by_order[p]
        return []

    def not_testable_of_order(self, p):
        if self.index is None:
            return []
        return [{'id': x['id'], 'kind': x['kind'], 'reason': x.get('not_testable')}
                for x in self.index.get('cards') or []
                if x.get('order') == p and not x.get('testable') and x.get('kind') in KINDS]


_DB = {}


def load_db(src=None):
    """an AtlasDB from a path / dict / list (cached for the default path)"""
    if isinstance(src, AtlasDB):
        return src
    if src is None or isinstance(src, str):
        key = os.path.abspath(src or DEFAULT_DB)
        if key not in _DB:
            _DB[key] = AtlasDB(src)
        return _DB[key]
    return AtlasDB(src)


# ------------------------------------------------------------------------------------------------ Groebner bases
def _poly_ring(F, gens, kw):
    from sympy.polys.rings import PolyRing
    polys, opt = sp.parallel_poly_from_expr(F, *gens, order='grevlex', **kw)
    ring = PolyRing(opt.gens, opt.domain, opt.order)
    elems = [ring.from_dict(dict(P.rep.to_dict())) for P in polys if not P.is_zero]
    dom = ring.domain
    if not dom.is_Field or not dom.has_assoc_Field:
        fring = ring.clone(domain=dom.get_field())
        elems = [e.set_ring(fring) for e in elems]
        ring = fring
    return ring, elems, opt


SWELL_LIMIT = 1500         # coefficient size (terms of numerators and denominators) beyond which a decision is
                           # given up as undecided (keeps single SymPy operations short in the browser)


def _size(poly):
    """a cheap measure of the size of a ring element: number of terms plus the sizes of the coefficients (terms of
    numerator and denominator over Q(symbols); bit length / 64 over Q)"""
    from sympy.polys.fields import FracElement
    n = 0
    for c in poly.values():
        if isinstance(c, FracElement):
            n += len(c.numer) + len(c.denom)
        elif hasattr(c, 'numerator'):
            try:
                n += 1 + (int(c.numerator).bit_length() + int(c.denominator).bit_length()) // 64
            except Exception:
                n += 1
        else:
            n += 1
    return n


_SWELL = [SWELL_LIMIT]      # the limit of the running look-up (fast: SWELL_LIMIT; exact: SWELL_LIMIT_EXACT)
SWELL_LIMIT_EXACT = 200000


def _guard(poly, limit=None):
    sz = _size(poly)
    if sz > (limit or _SWELL[0]):
        raise Undecided('expression swell (coefficient size %d)' % sz)
    return poly


def _buchberger(f, ring, deadline):
    """SymPy's _buchberger (project script, [BW] page 232) with a deadline check and a size guard; reduced
    basis"""
    order = ring.order
    monomial_mul = ring.monomial_mul
    monomial_div = ring.monomial_div
    monomial_lcm = ring.monomial_lcm

    def select(P):
        return min(P, key=lambda pair: order(monomial_lcm(f[pair[0]].LM, f[pair[1]].LM)))

    def normal(g, J):
        _check(deadline)
        h = g.rem([f[j] for j in J])
        if not h:
            return None
        _guard(h)
        h = h.monic()
        if h not in I:
            I[h] = len(f)
            f.append(h)
        return h.LM, I[h]

    def update(G, B, ih):
        h = f[ih]
        mh = h.LM
        C = G.copy()
        D = set()
        while C:
            ig = C.pop()
            g = f[ig]
            mg = g.LM
            LCMhg = monomial_lcm(mh, mg)

            def lcm_divides(ip):
                m = monomial_lcm(mh, f[ip].LM)
                return monomial_div(LCMhg, m)
            if monomial_mul(mh, mg) == LCMhg or (
                    not any(lcm_divides(ipx) for ipx in C) and not any(lcm_divides(pr[1]) for pr in D)):
                D.add((ih, ig))
        E = set()
        while D:
            ih_, ig = D.pop()
            mg = f[ig].LM
            LCMhg = monomial_lcm(mh, mg)
            if not monomial_mul(mh, mg) == LCMhg:
                E.add((ih_, ig))
        B_new = set()
        while B:
            ig1, ig2 = B.pop()
            mg1 = f[ig1].LM
            mg2 = f[ig2].LM
            LCM12 = monomial_lcm(mg1, mg2)
            if not monomial_div(LCM12, mh) or monomial_lcm(mg1, mh) == LCM12 or monomial_lcm(mg2, mh) == LCM12:
                B_new.add((ig1, ig2))
        B_new |= E
        G_new = set()
        while G:
            ig = G.pop()
            mg = f[ig].LM
            if not monomial_div(mg, mh):
                G_new.add(ig)
        G_new.add(ih)
        return G_new, B_new

    if not f:
        return []
    f1 = f[:]
    while True:
        _check(deadline)
        f = f1[:]
        f1 = []
        for i in range(len(f)):
            _check(deadline)
            p = f[i]
            r = p.rem(f[:i])
            if r:
                f1.append(_guard(r).monic())
        if f == f1:
            break
    I = {}
    Fs = set()
    G = set()
    CP = set()
    for i, h in enumerate(f):
        I[h] = i
        Fs.add(i)
    while Fs:
        h = min([f[x] for x in Fs], key=lambda ff: order(ff.LM))
        ih = I[h]
        Fs.remove(ih)
        G, CP = update(G, CP, ih)
    while CP:
        _check(deadline)
        ig1, ig2 = select(CP)
        CP.remove((ig1, ig2))
        p1, p2 = f[ig1], f[ig2]
        LCM12 = monomial_lcm(p1.LM, p2.LM)
        h = p1.mul_monom(monomial_div(LCM12, p1.LM)) - p2.mul_monom(monomial_div(LCM12, p2.LM))
        G1 = sorted(G, key=lambda g: order(f[g].LM))
        ht = normal(h, G1)
        if ht:
            G, CP = update(G, CP, ht[1])
    Gr = set()
    for ig in G:
        ht = normal(f[ig], G - {ig})
        if ht:
            Gr.add(ht[1])
    Gr = [f[ig] for ig in Gr]
    return sorted(Gr, key=lambda ff: order(ff.LM), reverse=True)


def groebner_deadline(F, gens, kw, deadline):
    """-> (ring, reduced Groebner basis (grevlex) as ring elements, opt)"""
    ring, elems, opt = _poly_ring(F, gens, kw)
    return ring, _buchberger(elems, ring, deadline), opt


def _is_unit_basis(G):
    return any(g.is_ground and bool(g) for g in G)


def _domain(usyms, exprs):
    alg = any(e.has(sp.sqrt) or e.has(sp.I) or any(a.is_Pow and not a.exp.is_Integer for a in e.atoms(sp.Pow))
              for e in exprs)
    kw = {}
    if alg:
        kw['extension'] = True
    elif usyms:
        kw['domain'] = sp.QQ.frac_field(*usyms)
    return kw


# ------------------------------------------------------------------------------------------------ the decision
def support_prefilter(card, U):
    """exact necessary conditions, no SymPy: (i) every monomial of U is reachable from the card's support by lowering
    the power of x0; (ii) a card monomial with a nonzero numerical coefficient at the top of its x0-chain survives
    every change, so it occurs in U.  -> None (pass) or a reason"""
    for m in U:
        if card.maxm0.get(m[1:], -1) < m[0]:
            return 'monomial %s of the equation cannot occur in the card' % _mono_expr(m)
    for mm in card.forced:
        if mm not in U:
            return 'the card forces the monomial %s (constant coefficient)' % _mono_expr(mm)
    return None


def presolve(eqs, unknowns, deadline=None):
    """the old tool's exact pre-elimination: an equation of degree one in an unknown (not alpha, gamma) with a nonzero
    numerical leading coefficient determines it.  -> (substitution, remaining) or (None, None) if inconsistent"""
    uset = set(unknowns)
    sub = {}
    eqs = [sp.expand(e) for e in eqs]
    changed = True
    while changed:
        _check(deadline)
        changed = False
        rest = []
        for e in eqs:
            e = sp.expand(e.subs(sub, simultaneous=True)) if sub else e
            if e == 0:
                continue
            fs = e.free_symbols & uset
            if not fs:
                if not is_zero_exact(e):
                    return None, None
                continue
            if not (fs - {AL, GA}):
                rest.append(e)
                continue
            done = False
            if not changed:
                for u in sorted(fs - {AL, GA}, key=str):
                    try:
                        P = sp.Poly(e, u)
                    except Exception:
                        continue
                    if P.degree() == 1:
                        lc = P.coeffs()[0]
                        if lc.is_number and lc != 0:
                            val = sp.expand(-(e - lc * u) / lc)
                            sub = {k: sp.expand(v.subs(u, val)) for k, v in sub.items()}
                            sub[u] = val
                            changed = True
                            done = True
                            break
            if not done:
                rest.append(e)
        eqs = rest
    return sub, eqs


def _greek(t):
    return t.replace('ATL_alpha', 'α').replace('ATL_beta', 'β').replace('ATL_gamma', 'γ')


def _match(card, U, usyms, mode, deadline, witness_policy, ctx=None):
    """decide whether some member of the card, transformed by (alpha, beta, gamma) restricted to `mode`, is U.
    -> dict(decision = 'yes' | 'no' | 'undecided', by, witness)"""
    p = card.p
    res = {'mode': sorted(mode)}
    if 'beta' not in mode:
        for m in U:
            if m not in card.S:
                res.update({'decision': 'no', 'by': 'monomial %s not in the card (mode without shift)' % _mono_expr(m)})
                return res
        for m in card.numeric:
            if m not in U:
                res.update({'decision': 'no', 'by': 'the card forces %s (mode without shift)' % _mono_expr(m)})
                return res
    card.parse()
    if 'beta' not in mode and not mode:
        for m in card.numeric:
            if not is_zero_exact(card.C[m] - U[m]):
                res.update({'decision': 'no', 'by': 'fixed coefficient of %s differs' % _mono_expr(m)})
                return res
    try:
        return _match_algebra(card, U, usyms, mode, deadline, witness_policy, res, ctx)
    except Undecided as ex:
        res.update({'decision': 'undecided', 'by': str(ex) or 'time budget exhausted'})
        return res
    except Exception as ex:                                          # never turned into a 'no'
        res.update({'decision': 'undecided', 'by': 'error in the decision (%s: %s)' % (type(ex).__name__,
                                                                                       str(ex)[:120])})
        return res


class _Ctx(object):
    """per look-up data for the polynomial-ring path.  Without symbols in the equation: ground field Q, grevlex.
    With symbols u (treated as indeterminates, generic values): the polynomial ring over Q in the unknowns X followed
    by u (and one inverse variable per denominator of the equation's coefficients, among X), with a block order
    X >> u; the system has a solution over the algebraic closure of Q(u) iff the ideal contains no nonzero
    polynomial in u alone, i.e. iff no element of the reduced Groebner basis lies in Q[u] (elimination property).
    Over Q only: no rational-function arithmetic."""

    def __init__(self, U, usyms, sym_method='field'):
        self.ok = False
        self.U = U
        if usyms and sym_method == 'field':
            # ground field Q(u) (SymPy's FracField), grevlex: as the old tool
            exprs = list(U.values())
            if any(e.has(sp.sqrt) or e.has(sp.I) or any(a.is_Pow and not a.exp.is_Integer for a in e.atoms(sp.Pow))
                   for e in exprs):
                return
            try:
                self.K = sp.QQ.frac_field(*usyms)
                self.UK = {m: self.K.from_sympy(sp.sympify(c)) for m, c in U.items()}
            except Exception:
                return
            self.usyms, self.dens, self.dsyms, self.Uexpr = [], [], [], None
            self.rings = {}
            self.ok = True
            return
        self.usyms = list(usyms)
        exprs = list(U.values())
        if any(e.has(sp.sqrt) or e.has(sp.I) or any(a.is_Pow and not a.exp.is_Integer for a in e.atoms(sp.Pow))
               for e in exprs):
            return                                   # algebraic numbers: the Expr path (as the old tool)
        self.K = sp.QQ
        self.rings = {}
        try:
            if not usyms:
                self.UK = {m: sp.QQ.from_sympy(sp.sympify(c)) for m, c in U.items()}
                self.Uexpr = None
                self.dens, self.dsyms = [], []
            else:
                dens, Ue = [], {}
                for m, c in U.items():
                    n, d = sp.fraction(sp.together(sp.sympify(c)))
                    n, d = sp.expand(n), sp.expand(d)
                    if d.free_symbols:
                        k = None
                        for j, x in enumerate(dens):
                            if sp.expand(d - x) == 0:
                                k = j
                                break
                        if k is None:
                            dens.append(d)
                            k = len(dens) - 1
                        Ue[m] = n * sp.Symbol('LOOKUP_D%d' % k)
                    else:
                        Ue[m] = sp.expand(n / d)
                self.Uexpr = Ue
                self.dens = dens
                self.dsyms = [sp.Symbol('LOOKUP_D%d' % k) for k in range(len(dens))]
                self.UK = None
        except Exception:
            return
        self.ok = True


def _qq(s):
    if '/' in s:
        n, d = s.split('/')
        return sp.QQ(int(n), int(d))
    return sp.QQ(int(s))


def _ring_of(card, ctx, mode):
    from sympy.polys.rings import PolyRing
    from sympy.polys.orderings import grevlex, ProductOrder
    key = (card.id, tuple(sorted(mode)))
    if key not in ctx.rings:
        card.parse()
        P = card.m['poly']
        nq = len(P.get('qeqs') or [])
        qsyms = [sp.Symbol('LOOKUP_Q%d' % j) for j in range(nq)]
        gens = list(card.psyms) + qsyms + ([AL, AI] if 'alpha' in mode else []) + ([BE] if 'beta' in mode else []) + \
            ([GA, GI] if 'gamma' in mode else []) + [TT] + list(ctx.dsyms)
        nX = len(gens)
        gens = gens + list(ctx.usyms)
        if ctx.usyms:
            order = ProductOrder((grevlex, lambda mm: mm[:nX]), (grevlex, lambda mm: mm[nX:]))
        else:
            order = grevlex
        R = PolyRing(gens, ctx.K, order)
        n = len(card.psyms)
        extra = len(gens) - n - nq

        def el(pl):
            d = {}
            for exps, c in pl:
                mon = tuple(exps) + (0,) * extra if exps else (0,) * len(gens)
                if len(mon) != len(gens):
                    raise ValueError('bad polynomial data')
                d[mon] = ctx.K.convert(_qq(c), sp.QQ)
            return R.from_dict(d) if d else R.zero
        loc = {'P%d' % i: sy for i, sy in enumerate(card.psyms)}
        if ctx.usyms:
            Uel = {m: R(e) for m, e in ctx.Uexpr.items()}
            deqs = [R(sp.expand(d * D - 1)) for d, D in zip(ctx.dens, ctx.dsyms)]
        else:
            Uel = {m: R(u) for m, u in ctx.UK.items()}
            deqs = []
        qinv = {q: 1 / sp.sympify(dd, locals=loc) for q, dd in zip(qsyms, P.get('qdens') or [])}
        qinv.update({D: 1 / d for d, D in zip(ctx.dens, ctx.dsyms)})
        data = {'R': R, 'C': {mm: el(pl) for mm, pl in zip(card.mons, P['coef'])},
                'eqs': [el(pl) for pl in P['eqs']] + [el(pl) for pl in P.get('qeqs') or []] + deqs,
                'ineqs': [el(pl) for pl in P['ineqs']], 'n': n, 'nX': nX, 'U': Uel, 'qinv': qinv,
                'qden': [(gens.index(q), R(sp.expand(sp.sympify(dd, locals=loc))))
                         for q, dd in zip(qsyms, P.get('qdens') or [])]}
        ctx.rings[key] = data
    return ctx.rings[key]


def _clear_q(e, qd, R):
    """the numerator of e after Q_j -> 1/d_j for each (Q_j index, d_j): sum_k coeff_k(e) d_j^(K-k), K the largest
    power of Q_j; the equations d_j*Q_j - 1 become 0"""
    for qi, d in qd:
        if not e:
            return e
        K = max(mm[qi] for mm in e.keys())
        if K == 0:
            continue
        parts = {}
        for mm, c in e.items():
            k = mm[qi]
            m2 = list(mm)
            m2[qi] = 0
            parts.setdefault(k, {})[tuple(m2)] = c
        out = R.zero
        for k, dct in parts.items():
            out += R.from_dict(dct) * d ** (K - k)
        e = _guard(out)
    return e


def _clear_inv(e, pairs, R, divide=True):
    """the numerator of e after x_inv -> 1/x for each (x index, x_inv index) pair: e * x^K with K the largest power
    of x_inv, every x_inv^k x^j -> x^(j + K - k); the equations x*x_inv - 1 become 0"""
    if not e:
        return e
    for ix, ii in pairs:
        K = max(mm[ii] for mm in e.keys())
        if K == 0:
            continue
        d = {}
        for mm, c in e.items():
            m2 = list(mm)
            m2[ix] = mm[ix] + K - mm[ii]
            m2[ii] = 0
            m2 = tuple(m2)
            d[m2] = d.get(m2, R.domain.zero) + c
        e = R.from_dict({k: v for k, v in d.items() if v})
        if not e:
            return e
    # divide out the largest power of x that divides every term (x != 0 is imposed separately); equations only
    for ix, ii in (pairs if divide else []):
        lo = min(mm[ix] for mm in e.keys())
        if lo > 0:
            e = R.from_dict({tuple(v - lo if j == ix else v for j, v in enumerate(mm)): c for mm, c in e.items()})
    return e


def _no_solution(G, D, ctx):
    """True if the reduced basis G certifies 'no solution': [1] over Q; with symbols u: an element in Q[u]"""
    if not ctx.usyms:
        return _is_unit_basis(G)
    nX = D['nX']
    return any(not any(g.LM[:nX]) for g in G if g)


def _match_ring(card, ctx, usyms, mode, deadline, witness_policy, res):
    """the decision of _match_algebra in sparse polynomial arithmetic (SymPy's PolyElement) over K = Q or
    Q(visitor's symbols): the same polynomial system up to the nonzero factors alpha, gamma (cleared), the same
    pre-elimination rule and the same Groebner/Rabinowitsch decision"""
    p = card.p
    D = _ring_of(card, ctx, mode)
    R = D['R']
    K = ctx.K
    gidx = {g: i for i, g in enumerate(R.symbols)}
    a = R.gens[gidx[AL]] if 'alpha' in mode else None
    b = R.gens[gidx[BE]] if 'beta' in mode else None
    g_ = R.gens[gidx[GA]] if 'gamma' in mode else None
    # S_m(params, beta) = sum_k binom(m0+k, k) beta^k c_{m+k e0}
    S = {}
    for m, c in D['C'].items():
        m0, rest = m[0], tuple(m[1:])
        for k in range(m0 + 1):
            if k > 0 and b is None:
                break
            mm = (m0 - k,) + rest
            term = c if k == 0 else c * (b ** k) * int(sp.binomial(m0, k))
            S[mm] = S.get(mm, R.zero) + term
    ai = R.gens[gidx[AI]] if a is not None else None
    gi = R.gens[gidx[GI]] if g_ is not None else None
    # S_m = u_m alpha^(1-|m|) gamma^(J(m)-p), negative powers written with ai = 1/alpha, gi = 1/gamma
    eqs = []
    for m in set(S) | set(D['U']):
        Sm = S.get(m, R.zero)
        dm, J = _deg(m), _Jw(m)
        right = D['U'].get(m, R.zero)
        if right and a is not None:
            right = right * (a ** (1 - dm) if dm <= 1 else ai ** (dm - 1))
        if right and g_ is not None:
            right = right * (g_ ** (J - p) if J >= p else gi ** (p - J))
        e = Sm - right
        if e:
            eqs.append(e)
    eqs += [e for e in D['eqs'] if e]
    if a is not None:
        eqs.append(a * ai - 1)
    if g_ is not None:
        eqs.append(g_ * gi - 1)
    nz = list(D['ineqs'])                     # alpha, gamma != 0 follow from alpha*ai = 1, gamma*gi = 1
    nX = D['nX']
    # pre-elimination: degree one in a parameter or beta with a constant (ground) leading coefficient
    elig = list(range(D['n'])) + ([gidx[BE]] if b is not None else [])
    elig.sort(key=lambda i: str(R.symbols[i]))
    subs = []                                            # (index, value) in order of elimination
    eqs = [e for e in eqs if e]
    while True:
        _check(deadline)
        found = None
        for idx, e in enumerate(eqs):
            if e.is_ground or not any(any(mm[:nX]) for mm in e.keys()):
                res.update({'decision': 'no', 'by': 'inconsistent after exact pre-elimination of linear unknowns'})
                return res
            if found is not None:
                continue
            degs = e.degrees()
            for i in elig:
                if degs[i] != 1:
                    continue
                lc = None
                okc = True
                for mon, cf in e.items():
                    if mon[i] == 1:
                        if any(mon[j] for j in range(len(mon)) if j != i):
                            okc = False
                            break
                        lc = cf
                if okc and lc is not None:
                    found = (idx, i, lc)
                    break
        if found is None:
            break
        idx, i, lc = found
        xi = R.gens[i]
        val = (xi * lc - eqs[idx]).quo_ground(lc)
        subs.append((i, val))
        _guard(val)
        eqs = [_guard(x.compose(xi, val)) for j, x in enumerate(eqs) if j != idx]
        eqs = [x for x in eqs if x]
    # back to the old tool's form (numerators): first Q_j = 1/d_j (d_j != 0 becomes a nonvanishing condition),
    # then ai = 1/alpha, gi = 1/gamma (alpha, gamma nonvanishing)
    clear = []
    if D.get('qden'):
        qidxs = [qi for qi, d in D['qden']]
        for qi, d in D['qden']:
            for i, val in subs:
                d = d.compose(R.gens[i], val)
            # only where d_j (after the pre-elimination) is free of the Q variables; otherwise Q_j stays a variable
            # with its equation d_j*Q_j - 1 = 0 (equivalent, nothing is lost)
            if not any(mm[q] for mm in d.keys() for q in qidxs):
                clear.append((qi, d))
        eqs = [x for x in (_clear_q(e, clear, R) for e in eqs) if x]
        nz = list(nz) + [d for qi, d in clear]
    pairs = []
    if a is not None:
        pairs.append((gidx[AL], gidx[AI]))
    if g_ is not None:
        pairs.append((gidx[GA], gidx[GI]))
    if pairs:
        eqs = [x for x in (_clear_inv(e, pairs, R) for e in eqs) if x]
    for e in eqs:
        if e.is_ground or not any(any(mm[:nX]) for mm in e.keys()):
            res.update({'decision': 'no', 'by': 'coefficient mismatch independent of the card parameters'})
            return res
    nz2 = []
    for g in nz:
        for i, val in subs:
            g = g.compose(R.gens[i], val)
        if clear:
            g = _clear_q(g, clear, R)
        if pairs:
            g = _clear_inv(g, pairs, R, divide=False)
        if g.is_ground or not any(any(mm[:nX]) for mm in g.keys()):
            if not g:
                res.update({'decision': 'no', 'by': 'a nonvanishing condition of the card fails identically'})
                return res
            continue
        nz2.append(g)
    nz2 += [x for x in (a, g_) if x is not None]          # alpha, gamma != 0 (as in the old tool)
    if eqs or nz2:
        if eqs:
            G0 = _buchberger([_guard(e).monic() for e in eqs], R, deadline)
            if _no_solution(G0, D, ctx):
                res.update({'decision': 'no', 'by': 'Groebner basis of the coefficient equations = [1]'})
                return res
            for g in nz2:
                _check(deadline)
                if not g.rem(G0):
                    res.update({'decision': 'no', 'by': 'the nonvanishing condition %s lies in the ideal of the '
                                                        'coefficient equations' % str(g.as_expr())[:60]})
                    return res
        prod = R.one
        for g in nz2:
            prod = prod * g
        F = eqs + ([R.one - R.gens[gidx[TT]] * prod] if nz2 else [])
        G = _buchberger([_guard(f).monic() for f in F], R, deadline)
        if _no_solution(G, D, ctx):
            res.update({'decision': 'no', 'by': 'Groebner basis = [1] (no complex solution with the nonvanishing '
                                                'conditions)'})
            return res
    res.update({'decision': 'yes', 'by': "Groebner basis != [1]: complex solutions exist with alpha, gamma, the "
                                         "denominators and the card's != conditions nonzero"})
    # the witness in SymPy expressions (the old tool's method)
    inv = {AI: 1 / AL, GI: 1 / GA}
    inv.update(D.get('qinv') or {})
    pre = {}
    for i, val in subs:
        s_i = R.symbols[i]
        ve = val.as_expr().xreplace(inv)
        pre = {k: sp.expand(v.subs(s_i, ve)) for k, v in pre.items()}
        pre[s_i] = sp.expand(ve)
    for _ in range(len(pre)):                    # values may mention parameters eliminated earlier (through 1/d_j)
        new_pre = {k: sp.together(v.subs(pre, simultaneous=True)) for k, v in pre.items()}
        if new_pre == pre:
            break
        pre = new_pre
    unknowns = list(card.psyms) + [s for s, nm in ((AL, 'alpha'), (BE, 'beta'), (GA, 'gamma')) if nm in mode]
    eqs_e = []
    for e in eqs:
        x = sp.expand(sp.numer(sp.together(e.as_expr().xreplace(inv))))
        if x != 0:
            eqs_e.append(x)
    nz_e = [sp.expand(sp.numer(sp.together(g.as_expr().xreplace(inv)))) for g in nz2] + \
        [sp.expand(sp.numer(sp.together(sp.sympify(d).subs(pre, simultaneous=True)))) for d in card.dens]
    nz_e = [g for g in nz_e if g != 0 and (sp.sympify(g).free_symbols & set(unknowns))]
    res['witness'] = _witness(card, eqs_e, unknowns, nz_e, pre, deadline, witness_policy)
    return res


def _match_algebra(card, U, usyms, mode, deadline, witness_policy, res, ctx=None):
    if ctx is not None and ctx.ok and card.m.get('poly') is not None:
        return _match_ring(card, ctx, usyms, mode, deadline, witness_policy, res)
    p = card.p
    al = AL if 'alpha' in mode else sp.Integer(1)
    be = BE if 'beta' in mode else sp.Integer(0)
    ga = GA if 'gamma' in mode else sp.Integer(1)
    S = transform(card.C, p, sp.Integer(1), be, sp.Integer(1))
    eqs = []
    for m in set(S) | set(U):
        e = S.get(m, 0) - U.get(m, 0) * al ** (1 - _deg(m)) * ga ** (_Jw(m) - p)
        if e != 0:
            eqs.append(e)
    eqs += [sp.expand(sp.numer(sp.together(g))) for g in card.eqs if g != 0]
    unknowns = list(card.psyms) + [s for s in (AL, BE, GA) if s in (al, be, ga)]
    uset = set(unknowns)
    nz = [s for s in (AL, GA) if s in (al, ga)] + list(card.dens) + \
        [sp.expand(sp.numer(sp.together(g))) for g in card.ineqs]
    pre, eqs = presolve(eqs, unknowns, deadline)
    if pre is None:
        res.update({'decision': 'no', 'by': 'inconsistent after exact pre-elimination of linear unknowns'})
        return res
    eqs = [sp.expand(sp.numer(sp.together(e))) for e in eqs]
    eqs = [e for e in eqs if e != 0]
    if pre:
        nz = [sp.expand(sp.numer(sp.together(sp.sympify(g).subs(pre, simultaneous=True)))) for g in nz]
    for e_ in eqs:
        if not (e_.free_symbols & uset):
            if not is_zero_exact(e_):
                res.update({'decision': 'no', 'by': 'coefficient mismatch independent of the card parameters'})
                return res
    eqs = [e_ for e_ in eqs if e_.free_symbols & uset]
    nz2 = []
    for g in nz:
        if not (sp.sympify(g).free_symbols & uset):
            if is_zero_exact(g):
                res.update({'decision': 'no', 'by': 'a nonvanishing condition of the card fails identically'})
                return res
            continue
        nz2.append(g)
    if eqs or nz2:
        if eqs:
            g0 = [s_ for s_ in unknowns if any(f.has(s_) for f in eqs)]
            ring, G0, opt = groebner_deadline(eqs, g0, _domain(usyms, eqs), deadline)
            if _is_unit_basis(G0):
                res.update({'decision': 'no', 'by': 'Groebner basis of the coefficient equations = [1]'})
                return res
            for g in nz2:
                if set(sp.sympify(g).free_symbols) - set(usyms) <= set(g0):
                    try:
                        Pg = sp.Poly(sp.expand(g), *opt.gens, domain=opt.domain)
                        rg = ring.from_dict(dict(Pg.rep.to_dict())) if ring.domain == opt.domain else \
                            ring.from_dict(dict(Pg.rep.to_dict()), opt.domain)
                        if not rg.rem(G0):
                            res.update({'decision': 'no', 'by': 'the nonvanishing condition %s lies in the ideal of '
                                                                'the coefficient equations' % str(g)[:60]})
                            return res
                    except Undecided:
                        raise
                    except Exception:
                        pass
        prod = sp.Integer(1)
        for g in nz2:
            prod *= g
        F = eqs + ([1 - TT * prod] if nz2 else [])
        gens = [s for s in unknowns if any(f.has(s) for f in F)] + ([TT] if nz2 else [])
        if not gens:
            res.update({'decision': 'no', 'by': 'inconsistent constants'})
            return res
        ring, G, opt = groebner_deadline(F, gens, _domain(usyms, F), deadline)
        if _is_unit_basis(G):
            res.update({'decision': 'no', 'by': 'Groebner basis = [1] (no complex solution with the nonvanishing '
                                                'conditions)'})
            return res
    res.update({'decision': 'yes', 'by': "Groebner basis != [1]: complex solutions exist with alpha, gamma, the "
                                         "denominators and the card's != conditions nonzero"})
    res['witness'] = _witness(card, eqs, unknowns, nz2, pre, deadline, witness_policy)
    return res


def _witness(card, eqs, unknowns, nz, pre, deadline, policy):
    """explicit parameter values and (alpha, beta, gamma) by SymPy's solve (the old tool's witness), checked by
    substitution; real order conditions of the locus evaluated at it.  policy: 'full' (always try), 'cheap' (only
    small systems), 'none'."""
    pre = pre or {}
    used = [s for s in unknowns if any(e.has(s) for e in eqs)]

    def partial(note):
        # without a solve: the pre-eliminated parameters in terms of the remaining unknowns, and the remaining
        # equations (an exact description of the matching parameter values)
        return {'note': note,
                'values_partial': {_greek(str(k)): _greek(str(v)) for k, v in pre.items()
                                   if k not in (AL, BE, GA)},
                'change_partial': {{AL: 'alpha', BE: 'beta', GA: 'gamma'}[k]: _greek(str(v)) for k, v in pre.items()
                                   if k in (AL, BE, GA)},
                'remaining_equations': [_greek(str(e))[:300] for e in eqs[:12]],
                'remaining_unknowns': [_greek(str(u)) for u in used]}
    if policy == 'none':
        return partial('witness not computed (fast mode)')
    symbolic = any(e.free_symbols - set(unknowns) for e in eqs)
    if policy == 'cheap' and eqs:
        lim = (2, 4, 2) if symbolic else (4, 8, 4)
        if len(used) > lim[0] or len(eqs) > lim[1] or max(sp.Poly(e, *used).total_degree() for e in eqs) > lim[2]:
            return partial('witness not computed (system too large for an unbounded SymPy solve); the decision '
                           'above stands')
    if policy == 'full' and eqs and (len(used) > 10 or len(eqs) > 16):
        return partial('witness not attempted (system too large for SymPy solve); the decision above stands')
    if deadline is not None and _now() > deadline:
        return partial('witness not computed (time budget); the decision above stands')
    try:
        sols = sp.solve(eqs, used, dict=True) if eqs else [{}]
    except Exception as ex:
        return {'note': 'solve failed (%s); the decision above stands' % type(ex).__name__}
    sols2 = []
    for s0 in sols:
        full = {k: sp.expand(sp.sympify(v).subs(s0, simultaneous=True)) for k, v in pre.items()}
        full.update(s0)
        sols2.append((s0, full))
    best = None
    for s0, s in sols2:
        bad = False
        for g in nz:
            v = sp.sympify(g).subs(s0, simultaneous=True)
            if is_zero_exact(v):
                bad = True
                break
        if bad:
            continue
        chk = all(is_zero_exact(sp.sympify(e).subs(s0, simultaneous=True)) for e in eqs)
        fs_vals = set().union(*[sp.sympify(v).free_symbols for v in s.values()]) if s else set()
        free = [str(x) for x in unknowns if x not in s and (x in used or x in fs_vals)]
        vals, change, raw = {}, {}, {}
        for k, v in s.items():
            vs = sp.simplify(v) if len(str(v)) < 300 else v
            vv = _greek(str(vs))
            if k in (AL, BE, GA):
                change[{AL: 'alpha', BE: 'beta', GA: 'gamma'}[k]] = vv
            else:
                vals[str(k)] = vv
            raw[k] = vs
        for k in (AL, BE, GA):
            nm = {AL: 'alpha', BE: 'beta', GA: 'gamma'}[k]
            if k in unknowns and k not in s:
                change[nm] = 'free' if (k in used or k in fs_vals) else 'any'
        conds = []
        for d, op in card.orders:
            v = sp.sympify(d).subs(s, simultaneous=True)
            if v.free_symbols:
                conds.append(('%s %s 0' % (d, op), 'not decided (depends on free values)'))
                continue
            try:
                if not v.is_real:
                    conds.append(('%s %s 0' % (d, op), 'FAILS (not real)'))
                    continue
                x = v if v.is_Rational else sp.Float(sp.N(v, 50), 50)
                okv = {'<': x < 0, '<=': x <= 0, '>': x > 0, '>=': x >= 0}[op]
                conds.append(('%s %s 0' % (d, op), 'holds' if okv else 'FAILS'))
            except Exception:
                conds.append(('%s %s 0' % (d, op), 'not decided'))
        w = {'values': vals, 'change': change, 'free_unknowns': [_greek(x) for x in free],
             'verified_by_substitution': bool(chk), 'order_conditions': conds, 'n_solutions_listed_by_solve': len(sols),
             '_raw': raw}
        rank = (sum(1 for c in conds if c[1].startswith('FAILS')), sum(1 for c in conds if not c[1].startswith('holds')),
                0 if chk else 1)
        if best is None or rank < best[0]:
            best = (rank, w)
    if best is not None:
        return best[1]
    return {'note': 'solve returned no solution with the nonvanishing conditions; the Groebner decision stands '
                    '(witness not computed)', 'n_solutions_listed_by_solve': len(sols)}


def membership(card, U, usyms, deadline_fn, witness_policy, ctx=None):
    """-> (category, entry); category in 'prefilter', 'no', 'undecided', 'exact', 'conditional', 'undeclared',
    'special' (the old tool's categories)"""
    why = support_prefilter(card, U)
    if why:
        return 'prefilter', {'decision': 'no', 'by': 'prefilter: ' + why}
    modes = [frozenset()]
    if card.group:
        modes.append(frozenset(card.group))
    if card.group != {'alpha', 'beta', 'gamma'}:
        modes.append(frozenset({'alpha', 'beta', 'gamma'}))
    final = None
    und = []
    for mode in modes:
        wp = witness_policy
        if wp == 'full' and not card.m.get('orders'):
            wp = 'cheap'           # SymPy's solve cannot be interrupted: unbounded only where the category needs it
        res = _match(card, U, usyms, mode, deadline_fn(), wp, ctx)
        if res['decision'] == 'yes':
            final = res
            break
        if res['decision'] == 'undecided':
            und.append(res)
    if final is None:
        if und:
            return 'undecided', {'id': card.id, 'kind': card.kind, 'modes': [u['mode'] for u in und],
                                 'by': und[0]['by']}
        return 'no', {'decision': 'no', 'by': 'no member in any mode'}
    declared = set(final['mode']) <= card.group
    w = final.get('witness') or {}
    entry = {'card': card, 'mode': final['mode'], 'declared': sorted(card.group), 'decision_by': final['by'],
             'witness': w}
    fails = [c for c in (w.get('order_conditions') or []) if c[1].startswith('FAILS')]
    free = w.get('free_unknowns')
    if fails and not free:
        entry['why'] = 'a real order condition fails at the (unique) witness'
        return 'special', entry
    open_orders = [c for c in (w.get('order_conditions') or []) if not c[1].startswith('holds')]
    reasons = []
    if card.restricting:
        reasons.append('locus conditions not checked by the tool: %s' % '; '.join(card.restricting))
    if open_orders:
        reasons.append('real order conditions not decided at the witness: %s' % '; '.join(c[0] for c in open_orders))
    if card.orders and w.get('values') is None:
        reasons.append('real order conditions not checked (no explicit witness): %s' % '; '.join(card.order_texts))
    entry['conditional_on'] = reasons
    if not declared:
        return 'undeclared', entry
    if reasons:
        return 'conditional', entry
    return 'exact', entry


# ------------------------------------------------------------------------------------------------ output
def _cut(s, n=240):
    s = '' if s is None else str(s)
    s = ' '.join(s.split())
    return s if len(s) <= n else s[:n - 3] + '...'


def _comp(card):
    return (card.derived.get('labels') or {}).get('completeness') or {}


def _statement(card):
    return card.derived.get('statement')


_FUNCS = {'exp': sp.exp, 'sqrt': sp.sqrt, 'sin': sp.sin, 'cos': sp.cos, 'tan': sp.tan, 'sinh': sp.sinh,
          'cosh': sp.cosh, 'tanh': sp.tanh, 'coth': sp.coth, 'sech': sp.sech, 'csch': sp.csch, 'cot': sp.cot,
          'log': sp.log, 'I': sp.I, 'pi': sp.pi}
_WP = sp.Function('wp')
_WPP = sp.Function('wpp')


def _parse_closed_form(text, card):
    """the card's closed form as a SymPy expression in z and the card's parameters, if it reads as one formula
    (a leading 'v =' allowed; 'wp(z, g2, g3)' / 'wpp' kept as functions); otherwise None"""
    if not text or not isinstance(text, str):
        return None
    t = text.strip()
    t = re.sub(r'^\s*v\s*(\(\s*z\s*\))?\s*=\s*', '', t)
    if re.search(r'[;:{}\[\]℘′²³_]|\^|\bfor\b|\bwhere\b|\bwith\b|\bor\b|\band\b|\bthe\b|,\s*[A-Za-z]+\s*=', t):
        return None
    if '=' in t:
        return None
    names = set(re.findall(r'[A-Za-z][A-Za-z0-9]*', t))
    loc = {}
    for n in names:
        if n in _FUNCS:
            loc[n] = _FUNCS[n]
        elif n == 'wp':
            loc[n] = _WP
        elif n == 'wpp':
            loc[n] = _WPP
        elif len(n) > 6:
            return None
        else:
            loc[n] = sp.Symbol(n)
    try:
        e = sp.sympify(t, locals=loc)
    except Exception:
        return None
    if not isinstance(e, sp.Expr) or e.atoms(sp.Float):
        return None
    if sp.Symbol('z') not in e.free_symbols:
        return None
    for f in e.atoms(sp.Function):
        if f.func not in (sp.exp, sp.sin, sp.cos, sp.tan, sp.sinh, sp.cosh, sp.tanh, sp.coth, sp.sech, sp.csch,
                          sp.cot, sp.log, _WP, _WPP):
            return None
    return e


def _solution_kind(e, desc):
    t = '%s %s' % (e, desc or '')
    if 'wp' in str(e):
        return 'elliptic'
    if e is not None and e.has(sp.exp, sp.tanh, sp.coth, sp.sinh, sp.cosh, sp.tan, sp.cot, sp.sin, sp.cos):
        return 'simply-periodic'
    if e is not None and not e.atoms(sp.Function):
        return 'rational' if e.is_rational_function(sp.Symbol('z')) else 'other'
    return 'other' if 'wp' not in t else 'elliptic'


def _kind_from_steps(sol):
    """a display hint from the card's solution steps (d = 1 only); 'other' otherwise"""
    if sol.get('d') != 1:
        return 'other'
    t = ' '.join(str(sol.get(k) or '') for k in ('description', 'closed_form', 'K'))
    if re.search(r'\bwp\b|℘|elliptic|\bsn\b|\bcn\b|\bdn\b', t):
        return 'elliptic'
    if re.search(r'exp|e\^|\btanh|\bcoth|\bsech|\bcosh|\bsinh|\btan\b|\bcot\b', t):
        return 'simply-periodic'
    types = {st.get('type') for st in (sol.get('steps') or []) if isinstance(st, dict)}
    if 'elliptic' in types:
        return 'elliptic'
    if 'multiplicative' in types:
        return 'simply-periodic'
    if types and types <= {'additive', 'straight', 'algebraic'}:
        return 'rational'
    return 'other'


def _site_items(entry, cat, info):
    """site.found / ruled_out / not_decided for one match (the card's own statements, transported when possible)"""
    card = entry['card']
    r = card.card
    sol = r.get('solution') if isinstance(r.get('solution'), dict) else {}
    comp = _comp(card)
    w = entry.get('witness') or {}
    found, ruled, nd = [], [], []
    basis = {'atlas_card': card.id, 'kind': card.kind, 'label': card.derived.get('site_label'),
             'card_label': comp.get('label'), 'text': comp.get('by')}
    if cat in ('conditional',):
        nd.append({'what': 'statements of atlas card %s (%s)' % (card.id, card.kind),
                   'why': 'the card contains this equation only if: %s' % ' | '.join(entry.get('conditional_on') or []),
                   'partial': _cut(sol.get('description'), 400) or None})
        return found, ruled, nd
    if card.kind == 'wave':
        cf = _parse_closed_form(sol.get('closed_form'), card)
        item = {'id': 'atlas:%s' % card.id, 'kind': 'other', 'd': sol.get('d'),
                'description': sol.get('description'), 'closed_form_card': sol.get('closed_form'),
                'origin': 'atlas:%s' % card.id, 'label': card.derived.get('site_label'),
                'certificate': {'type': 'substitution', 'method': 'symbolic', 'status': 'not-run',
                                'detail': 'identity of the card checked in the atlas run: %s' % (
                                    ((card.derived.get('labels') or {}).get('identity') or {}).get('site_note') or
                                    ((card.derived.get('labels') or {}).get('identity') or {}).get('label'))},
                'citations': list(r.get('sources') or [])[:3]}
        raw = w.get('_raw') or {}
        if cf is not None and w.get('values') is not None and not w.get('free_unknowns'):
            zc = sp.Symbol('z')
            z0 = sp.Symbol('z0')
            alpha = raw.get(AL, sp.Integer(1))
            beta = raw.get(BE, sp.Integer(0))
            gamma = raw.get(GA, sp.Integer(1))
            sub = {k: v for k, v in raw.items() if k not in (AL, BE, GA)}
            try:
                vexpr = cf.xreplace(sub)
                wexpr = sp.simplify((vexpr.xreplace({zc: gamma * zc + (z0 if z0 not in vexpr.free_symbols else 0)})
                                     - beta) / alpha)
                item['expr'] = str(wexpr)
                item['latex'] = sp.latex(wexpr)
                item['kind'] = _solution_kind(wexpr, sol.get('description'))
                others = sorted(str(s) for s in wexpr.free_symbols if str(s) not in ('z', 'z0'))
                item['free'] = ['z0'] if 'z0' in [str(s) for s in wexpr.free_symbols] else []
                item['constants'] = {s: 'as in the card (see its description; not necessarily free)' for s in others}
                item['transport'] = 'closed form of the card transported by v = alpha*w + beta, z_card = gamma*z + ' \
                                    'delta; substitution check not run here'
            except Exception:
                pass
        if 'expr' not in item:
            item['note'] = 'formula in the card\'s variables (v, z, the card\'s parameters); transform with the change ' \
                           'of variables of this match'
            item['kind'] = _solution_kind(cf, sol.get('description')) if cf is not None else _kind_from_steps(sol)
        found.append(item)
        if card.kind == 'wave' and _statement(card) == 'complete list':
            item['card_completeness'] = {'label': comp.get('label'), 'site': comp.get('site'), 'text': comp.get('by'),
                                         'note': 'a wave card\'s own completeness statement (not a sector card)'}
    elif card.kind == 'nowave':
        ruled.append({'what': 'as stated by atlas card %s: %s' % (card.id, _cut(comp.get('by'), 300)),
                      'basis': basis, 'conditions': []})
    elif card.kind == 'sector':
        if _statement(card) == 'complete list' and comp.get('label') in STRONG:
            ruled.append({'what': 'meromorphic solutions outside the families of sector card %s' % card.id,
                          'basis': basis, 'statement': sol.get('description'), 'conditions': []})
    elif card.kind == 'open':
        nd.append({'what': _cut(r.get('open') or sol.get('description'), 400) or 'open locus of card %s' % card.id,
                   'why': 'atlas card %s is an open record (completeness %s)' % (card.id, comp.get('label')),
                   'partial': _cut(sol.get('description'), 400) or None})
    if cat == 'undeclared':
        note = ('member of card %s only after the change of variables %s, which the card\'s normalisation does not '
                'declare; the card\'s statements transfer by this change, the card itself does not state it'
                % (card.id, w.get('change')))
        for x in found + ruled + nd:
            x['match_note'] = note
    return found, ruled, nd


def _entry_out(entry, cat, info):
    card = entry['card']
    r = card.card
    sol = r.get('solution') if isinstance(r.get('solution'), dict) else {}
    comp = _comp(card)
    w = entry.get('witness') or {}
    loc = r.get('locus') or {}
    found, ruled, nd = _site_items(entry, cat, info)
    out = {'id': card.id, 'kind': card.kind,
           'match': {'exact': 'exact', 'conditional': 'conditional', 'undeclared': 'undeclared-change'}[cat],
           'params': w.get('values'), 'free_params': w.get('free_unknowns'),
           'change': w.get('change') or {}, 'change_note': CHANGE_NOTE,
           'mode': entry['mode'], 'declared_changes': entry['declared'], 'decision_by': entry['decision_by'],
           'witness_note': w.get('note'), 'witness_verified': w.get('verified_by_substitution'),
           'params_partial': w.get('values_partial'), 'change_partial': w.get('change_partial'),
           'remaining_equations': w.get('remaining_equations'),
           'order_conditions': w.get('order_conditions') or [],
           'conditional_on': entry.get('conditional_on') or [],
           'label': card.derived.get('site_label'),
           'completeness': {'label': comp.get('site'), 'original': comp.get('label'), 'text': comp.get('by'),
                            'range': comp.get('range'), 'ref': comp.get('ref'), 'note': comp.get('site_note')},
           'statement': _statement(card),
           'evidence': card.derived.get('labels'),
           'solution': {'description': sol.get('description'), 'closed_form': sol.get('closed_form'),
                        'd': sol.get('d'), 'K': sol.get('K'), 'clock': sol.get('clock'), 'target': sol.get('target')},
           'locus': {'conditions': loc.get('conditions'), 'omitted': loc.get('omitted'),
                     'normalisation': loc.get('normalisation')},
           'card_equation': {'order': card.p, 'rhs': (r.get('equation') or {}).get('rhs'),
                             'rhs_source': card.m.get('rhs_source')},
           'conditions_checked': {'equalities_applied': list(card.m.get('eqs') or []),
                                  'existential_names': card.existential,
                                  'nonvanishing_checked': list(card.m.get('ineqs') or []) +
                                  ['denominator %s' % x for x in card.m.get('dens') or []],
                                  'real_order_conditions': card.order_texts,
                                  'not_checked_restricting': card.restricting,
                                  'ignored_harmless': card.harmless,
                                  'note': 'pre-parsed expressions use P<k> = the k-th name of card_syms'},
           'card_syms': list(card.m.get('syms') or []),
           'worker': r.get('worker'), 'referee': card.derived.get('referee'), 'status': r.get('status'),
           'sources': r.get('sources') or [], 'errata': r.get('errata') or [], 'open': r.get('open'),
           'origin': card.d.get('origin'),
           'site': {'found': found, 'ruled_out': ruled, 'not_decided': nd}}
    if card.d.get('card', {}).get('site'):
        out['card_site'] = card.d['card']['site']
    return out


def _rank(e):
    c = e['completeness']
    st = e.get('statement')
    unchecked = len(e['conditions_checked']['not_checked_restricting']) + \
        sum(1 for x in (e.get('order_conditions') or []) if not x[1].startswith('holds'))
    return (LADDER.index(st) if st in LADDER else 99, unchecked > 0, LABEL_RANK.get(c.get('original'), 9), e['id'])


def _sectors(lst):
    return sorted([e for e in lst if e['kind'] == 'sector' and e['completeness'].get('original') in STRONG], key=_rank)


def _cond_note(e):
    c = e['conditions_checked']
    extra = []
    if c['not_checked_restricting']:
        extra.append('provided the conditions not checked by the tool hold: %s' % '; '.join(c['not_checked_restricting']))
    nd = [x[0] for x in (e.get('order_conditions') or []) if not x[1].startswith('holds')]
    if nd:
        extra.append('real order conditions not decided: %s' % '; '.join(nd))
    return (' [' + ' | '.join(extra) + ']') if extra else ''


def _quote(e):
    c = e['completeness']
    return ('sector record %s (completeness %s: "%s"; statement read as: %s; locus: %s; worker %s, referee %s)%s'
            % (e['id'], c.get('original'), _cut(c.get('text'), 200), e.get('statement'),
               '; '.join(e['locus'].get('conditions') or []) or 'no conditions', e['worker'], e['referee'],
               _cond_note(e)))


def summarize(ex, cond, und, undecided):
    """the old tool's summary lines (project note section 2) -> (lines, complete, by, kind)"""
    lines = []
    cs = _sectors(ex)
    full = [e for e in cs if e.get('statement') == 'complete list']
    waves = sorted([e for e in ex if e['kind'] == 'wave'], key=_rank)
    nowaves = [e for e in ex if e['kind'] == 'nowave']
    kind = None
    if full:
        kind = 'complete'
        lines.append('all meromorphic solutions are known: ' + _quote(full[0]))
        rest = [x for x in cs if x is not full[0]]
        if rest:
            lines.append('further sector records with a completeness label that contain it: %s' % ', '.join(
                '%s (%s, %s)' % (x['id'], x['completeness'].get('original'), x.get('statement')) for x in rest[:8]))
        if waves:
            lines.append('wave records containing it (solution families): %s' % ', '.join(
                '%s (%s)' % (e['id'], _cut(e['solution'].get('description'), 80)) for e in waves[:6]))
        if nowaves:
            lines.append('nowave record(s) containing it: %s' % ', '.join(
                '%s (completeness %s: "%s")' % (e['id'], e['completeness'].get('original'),
                                               _cut(e['completeness'].get('text'), 80)) for e in nowaves[:4]))
    elif ex:
        qual = ('sector record(s) with a completeness label whose statement reads as qualified (not an unqualified '
                'complete list; quoted, judge the text): ' + ' ; '.join(_quote(e) for e in cs[:3])) if cs else None
        listing = waves + [e for e in ex if e['kind'] == 'sector' and
                           (e['solution'].get('description') or '').strip() not in ('', '-')]
        if listing:
            kind = 'known'
            lines.append('known solutions, list not known to be complete (no sector record whose completeness '
                         'statement reads as a complete list contains it); records containing it: %s%s' % (
                             ', '.join('%s [%s]' % (e['id'], e['kind']) for e in ex[:8]), ' ...' if len(ex) > 8 else ''))
            lab = [e for e in waves if e.get('statement') == 'complete list']
            if lab:
                lines.append('note: wave record(s) whose own completeness label reads as a complete list (a wave '
                             'record, not a sector record; see its evidence): %s' % ', '.join(
                                 '%s (%s: "%s")' % (e['id'], e['completeness'].get('original'),
                                                    _cut(e['completeness'].get('text'), 100)) for e in lab[:4]))
        else:
            kind = 'records-without-solutions'
            lines.append('records contain this equation (kinds %s) but none lists a solution family: %s' % (
                ', '.join(sorted({e['kind'] for e in ex})), ', '.join(e['id'] for e in ex[:8])))
        if qual:
            if kind == 'known' or kind == 'records-without-solutions':
                lines.insert(1, qual)
        if nowaves:
            lines.append('nowave record(s) contain it: %s' % ', '.join(
                '%s (completeness %s)' % (e['id'], e['completeness'].get('original')) for e in nowaves))
    complete_up_to = None
    if not full:
        cu = _sectors(und)
        fullu = [e for e in cu if e.get('statement') == 'complete list' and not e.get('conditional_on')]
        if fullu:
            ch = fullu[0].get('change')
            complete_up_to = fullu[0]['id']
            lines.append('%sup to an affine change %s that the record does not declare (meromorphy, d and completeness '
                         'transfer by the change of variables) all meromorphic solutions are known: %s' % (
                             '' if ex else 'no record contains this equation within its declared normalisation; ',
                             ch, _quote(fullu[0])))
            kind = kind or 'complete-up-to-undeclared-change'
        elif und and not ex:
            kind = 'undeclared-only'
            lines.append('no record contains this equation within its declared normalisation; affinely equivalent '
                         'members (undeclared change of v and z) in: %s; list not known to be complete'
                         % ', '.join('%s [%s]' % (e['id'], e['kind']) for e in und[:8]))
        elif not ex:
            kind = 'none'
            lines.append('no record contains this equation; formal data only')
    condc = [e for e in _sectors(cond) if e.get('statement') == 'complete list']
    if condc and not full:
        lines.append('conditional: sector record(s) whose statement reads as a complete list contain this equation only '
                     'if conditions that the tool does not check hold: %s' % ' ; '.join(
                         '%s [%s]' % (e['id'], ' | '.join(e['conditional_on'])) for e in condc[:3]))
    if undecided:
        lines.append('undecided within the time limit for %d record(s): %s' % (
            len(undecided), ', '.join(x['id'] for x in undecided[:10])))
    return lines, bool(full), (full[0]['id'] if full else None), kind, complete_up_to


# ------------------------------------------------------------------------------------------------ the look-up
def lookup(eq, mode='fast', budget_s=20, db=None, only=None, total_s=None, use_ring=True, sym_method='field'):
    """Look up the equation in the converted atlas.

    mode 'exact': every candidate card is decided as by project script: budget_s is the limit per card and
                  transformation mode (the old tool's --timeout, default 20 s), total_s the limit of the whole
                  look-up (default 900 s); the witness is computed with SymPy's solve.
    mode 'fast' : budget_s is the limit of the whole look-up; each card gets at most min(remaining, 3 s) per
                  transformation mode; witnesses only for small systems.  Cards not decided in time are listed in
                  `undecided` (never as non-matches).
    Returns a JSON-able dict (see the module docstring and project note)."""
    t0 = _now()
    out = {'schema': 'mero-atlas-lookup/1', 'mode': mode}
    try:
        p, U, usyms, info = equation_rhs(eq)
    except InputError as ex:
        out.update({'error': str(ex), 'matches': [], 'undecided': [], 'summary': {
            'line': 'input not read: %s' % ex, 'lines': [], 'complete': False, 'by': None}, 'elapsed_s': 0.0})
        return out
    database = load_db(db)
    if total_s is None:
        total_s = 900.0 if mode == 'exact' else float(budget_s)
    t_end = t0 + total_s
    _SWELL[0] = SWELL_LIMIT_EXACT if mode == 'exact' else SWELL_LIMIT
    if mode == 'exact':
        per = float(budget_s)
        witness_policy = 'full'
    else:
        per = min(3.0, float(budget_s))
        witness_policy = 'cheap'

    def deadline_fn():
        return min(_now() + per, t_end)
    out['input'] = {'order': p, 'rhs': str(_rhs_of(U)), 'notation': 'v^(p) = rhs in jets x0..x(p-1) (x0 = v = w)',
                    'user_symbols': [str(s) for s in usyms],
                    'note': ('symbolic parameters %s are treated as indeterminates: a match holds for generic values '
                             'of them (the card parameters are then algebraic functions of them), i.e. the family of '
                             'equations is generically contained in the card\'s family' % ', '.join(
                                 info['user_symbols'].get(str(s), str(s)) for s in usyms)) if usyms else None}
    cards = database.cards_of_order(p)
    ctx = _Ctx(U, usyms, sym_method) if use_ring else None
    if only:
        cards = [c for c in cards if c.id in set(only)]
    cats = {'exact': [], 'conditional': [], 'undeclared': [], 'special': [], 'undecided': []}
    npref = 0
    nno = 0
    stopped = []
    for c in cards:
        if c.kind not in KINDS:
            continue
        if _now() > t_end:
            if support_prefilter(c, U) is None:
                stopped.append(c.id)
            else:
                npref += 1
            continue
        try:
            cat, entry = membership(c, U, usyms, deadline_fn, witness_policy, ctx)
        except Exception as ex:
            cat, entry = 'undecided', {'id': c.id, 'kind': c.kind, 'modes': [], 'by': 'error (%s: %s)' % (
                type(ex).__name__, str(ex)[:100])}
        if cat == 'prefilter':
            npref += 1
        elif cat == 'no':
            nno += 1
        else:
            cats[cat].append(entry)
    ex = [_entry_out(e, 'exact', info) for e in cats['exact']]
    co = [_entry_out(e, 'conditional', info) for e in cats['conditional']]
    un = [_entry_out(e, 'undeclared', info) for e in cats['undeclared']]
    undecided = list(cats['undecided']) + [{'id': i, 'kind': None, 'modes': [], 'by': 'not reached within the '
                                                                                     'total time budget'}
                                            for i in stopped]
    lines, complete, by, kind, up_to = summarize(ex, co, un, undecided)
    out['matches'] = ex + co + un
    out['outside_order_conditions'] = [{'id': e['card'].id, 'why': e['why']} for e in cats['special']]
    out['undecided'] = [x['id'] for x in undecided]
    out['undecided_detail'] = undecided
    out['not_testable'] = database.not_testable_of_order(p)
    out['counts'] = {'same_order_cards': len(cards), 'excluded_by_prefilter': npref, 'decided_no': nno,
                     'exact': len(ex), 'conditional': len(co), 'undeclared_change': len(un),
                     'outside_order_conditions': len(cats['special']), 'undecided': len(undecided)}
    out['summary'] = {'line': lines[0] if lines else '', 'lines': lines, 'kind': kind, 'complete': complete,
                      'by': by, 'complete_up_to_undeclared_change': up_to,
                      'meaning': 'a match says what the cited workers and referees of the atlas run of 4 October 2026 '
                                 'established at agent level, with the labels of the card; "complete" only as in '
                                 'project note section 2 (a sector card with a completeness label whose statement '
                                 'reads as an unqualified complete list, every locus condition decided)'}
    found, ruled, nd = [], [], []
    for e in out['matches']:
        found += e['site']['found']
        ruled += e['site']['ruled_out']
        nd += e['site']['not_decided']
    for x in undecided:
        nd.append({'what': 'membership in atlas card %s' % x['id'], 'why': 'not decided within the time budget (%s)'
                   % x['by'], 'partial': None})
    out['site'] = {'found': found, 'ruled_out': ruled, 'not_decided': nd}
    out['elapsed_s'] = round(_now() - t0, 3)
    return _jsonable(out)


def _jsonable(x):
    if isinstance(x, dict):
        return {str(k): _jsonable(v) for k, v in x.items() if not (isinstance(k, str) and k.startswith('_'))}
    if isinstance(x, (list, tuple)):
        return [_jsonable(v) for v in x]
    if isinstance(x, (str, int, float, bool)) or x is None:
        return x
    return str(x)
