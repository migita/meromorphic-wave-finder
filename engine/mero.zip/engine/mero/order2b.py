"""mero.order2b -- second-order autonomous equations that are even in w' (worker ORDER2B, run of 6 October 2026).

    A(w) w'' + B(w) w'^2 + C(w) = 0,        A, B, C polynomials in w over Q(parameters), A != 0.

With y(w) = w'^2 one has w'' = y'(w)/2, so y solves the LINEAR equation  A y'/2 + B y + C = 0,

    y(w; h) = (h - N(w)) / M(w),     M = exp(int 2B/A dw),   N = int 2 C M / A dw,

and   d/dz [ M(w) w'^2 + N(w) ] = (2 M(w) w' / A(w)) * E.   Statements and proofs: lemmas/order2b/project note
(items A-F).  Public function

    order2b_answer(eq, budget_s=20) -> dict  (SCHEMA section 3 fragment: applies, first_integral, found,
                                              ruled_out, not_decided, verdict, certificate, strata, d_summary)

Cases (project note, item B):
  rational      M rational and N rational: y(w; h) is rational in w for every h.  Lemma C (w'^2 = R(w), R rational,
                has a nonconstant meromorphic solution iff R is a polynomial of degree <= 4) and the classical
                closed forms give the complete list, for every h.                  verdict 'complete'
  algebraic     one root e of A carries a rational non-integer residue r/s of 2B/A, all others integer: with
                w = e + V^s the first integral is rational in V; the monodromy lemma (item D) shows that
                V' = (w - e)^(1/s') is meromorphic for every meromorphic solution; Lemma C in V'.   'complete'
  log           M rational, N with a logarithmic term: no nonconstant solution has d <= 1 (item E); the omitted
                value count decides some cases (>= 3 omitted values: constants only).
  transcendental / generic exponent    (M not algebraic): at most one h gives an algebraic y; the solutions with
                d <= 1 are exactly the ones on that h (item B3).                   verdict 'complete-W'

Pure SymPy; budgets with time.monotonic(); never raises (errors are reported in 'warnings').
"""
import time
import sympy as sp

z = sp.Symbol('z')
w0, w1, w2 = sp.symbols('w0 w1 w2')
_t, _S, _P, _Q, _X, _T = sp.symbols('_t _S _P _Q _X _T')

LEMMA = "lemmas/order2b/project note"

# names of auxiliary constants shown in the output; renamed per call if a parameter has the same name
_NM_DEFAULT = {"K": "K", "z0": "z0", "r": "r", "sigma": "sigma", "b": "b", "c0": "c0", "c": "c"}
_NM = dict(_NM_DEFAULT)


def _sym(key):
    return sp.Symbol(_NM[key])


# algebraic irrational numbers among the coefficients (set per call): factorisations, gcds and squarefree
# decompositions of univariate numerical polynomials are then computed over Q(_EXT) (referee N1)
_EXT = []


def _algebraic_generators(E):
    gens = []
    try:
        for co in sp.Poly(sp.expand(E), *sorted([s_ for s_ in E.free_symbols if s_.name in ("w0", "w1", "w2")],
                                               key=str)).coeffs():
            co = sp.sympify(co)
            if co.is_number and not co.is_Rational:
                for a in co.atoms(sp.Pow):
                    if a.exp.is_Rational and not a.exp.is_Integer and a.base.is_Rational:
                        g = sp.root(a.base, a.exp.q)
                        if g not in gens:
                            gens.append(g)
                if co.has(sp.I) and sp.I not in gens:
                    gens.append(sp.I)
    except Exception:
        pass
    return gens


def _ext_ok(expr, x):
    return bool(_EXT) and not (sp.sympify(expr).free_symbols - {x})


def _sqf(P, x):
    if _ext_ok(P, x):
        return sp.sqf_list(sp.expand(P), x, extension=_EXT)
    return sp.sqf_list(P, x)


def _fac(P, x):
    if _ext_ok(P, x):
        return sp.factor_list(sp.expand(P), x, extension=_EXT)
    return sp.factor_list(P, x)


def _gcdx(a, b, x):
    a_ = a.as_expr() if hasattr(a, "as_expr") else sp.sympify(a)
    b_ = b.as_expr() if hasattr(b, "as_expr") else sp.sympify(b)
    if _ext_ok(a_ + b_, x):
        return sp.Poly(sp.gcd(a_, b_, x, extension=_EXT), x)
    return sp.Poly(sp.gcd(sp.Poly(a_, x), sp.Poly(b_, x)), x)


def _set_names(params):
    taken = set(str(p) for p in params) | {"h", "z", "w", "t", "S", "P", "Q", "X", "V", "U"}
    for key, base in _NM_DEFAULT.items():
        name = base
        k = 1
        while name in taken:
            name = "%s_%d" % (base, k)
            k += 1
        _NM[key] = name
        taken.add(name)
REF_FIRST = "T-FIRSTORDER"
REF_WW = "Whittaker and Watson, A Course of Modern Analysis, sec. 20.6 (solution of y'^2 = quartic)"
REF_CNW = ("R. Conte, T.-W. Ng, C.-F. Wu, Hayman's classical conjecture on some nonlinear second-order algebraic "
           "ODEs, Complex Var. Elliptic Equ. 60 (2015) 1539-1552 (arXiv:1503.07074)")
REF_CNW31 = "Conte-Ng-Wu 2015, Theorem 3.1"
REF_CNW32 = "Conte-Ng-Wu 2015, Theorem 3.2(2)"

try:                                    # display functions of the run (worker WSOLVE); fall back to plain names
    from .special import wp as _wp_f, wpp as _wpp_f
except Exception:                       # pragma: no cover
    _wp_f, _wpp_f = sp.Function('wp'), sp.Function('wpp')


# ================================================================================================ exact helpers
def _iszero(x):
    """exact zero test for numbers (rational, algebraic) and expressions in symbols"""
    x = sp.sympify(x)
    if x == 0:
        return True
    if x.is_Rational:
        return False
    try:
        x2 = sp.expand(x)
        if x2 == 0:
            return True
        if x2.free_symbols:
            x3 = sp.cancel(sp.together(x2))
            if x3 == 0:
                return True
            if not any(not (a.exp.is_Integer) for a in x3.atoms(sp.Pow)) and not x3.atoms(sp.Function):
                return False                     # a rational function of the symbols: cancel is canonical
            if sp.count_ops(x3) > 400:
                return False
            try:
                return sp.simplify(x3) == 0
            except Exception:
                return False
        x3 = sp.radsimp(sp.nsimplify(x2)) if not x2.is_Rational else x2
        if x3 == 0:
            return True
        X = sp.Dummy('X')
        mp = sp.minimal_polynomial(x2, X)
        return sp.expand(mp - X) == 0
    except Exception:
        try:
            return sp.simplify(x) == 0
        except Exception:
            return False


def _status(x):
    """'zero' | 'nonzero' | 'unknown' (unknown = depends on parameters, generically nonzero)"""
    x = sp.sympify(x)
    if _iszero(x):
        return 'zero'
    num = sp.numer(sp.together(sp.expand(x)))
    if sp.expand(num).free_symbols:
        return 'unknown'
    return 'nonzero'


def _nice(x):
    x = sp.sympify(x)
    try:
        if x.free_symbols:
            y = sp.factor(sp.cancel(sp.together(x)))
            return y
        if x.is_Rational:
            return x
        y = sp.radsimp(sp.expand(x))          # no nsimplify: it may create nested radicals (sqrt(7/2 + sqrt 6))
        return y if sp.count_ops(y) <= sp.count_ops(x) else x
    except Exception:
        return x


def _sqrt(x):
    x = _nice(x)
    r = sp.sqrt(x)
    try:
        r2 = sp.sqrtdenest(r)
        return r2
    except Exception:
        return r


_COND_EXPR = {}


def _cond_str(expr, op):
    e = _nice(expr)
    st = "%s %s 0" % (sp.sstr(e), op)
    if op == "==":
        _COND_EXPR[st] = e
    return st


def _poly(expr, x):
    return sp.Poly(sp.expand(expr), x)


# ================================================================================================ input
def _get_E(eq):
    """(E in the symbols w0, w1, w2, ..., K, params, display names) from a mero Equation, a string or a dict"""
    unknown, var = 'w', 'z'
    if isinstance(eq, dict):
        from .equation import Equation as _Eq
        eq = _Eq.from_dict(eq)
    if isinstance(eq, str):
        txt = eq
        try:
            from .parse import parse_ode
            eq = parse_ode(txt)
        except Exception:
            from .equation import Equation as _Eq
            eq = _Eq(E=txt)
    K = int(getattr(eq, 'K'))
    jets = list(getattr(eq, 'w'))
    E = getattr(eq, 'E', None)
    if E is None:
        E = jets[K] - eq.rhs
    unknown = getattr(eq, 'unknown', 'w') or 'w'
    var = getattr(eq, 'var', 'z') or 'z'
    mine = sp.symbols('w0:%d' % (K + 1))
    E = sp.expand(sp.sympify(E).subs(dict(zip(jets, mine)), simultaneous=True))
    params = [sp.Symbol(str(p)) for p in getattr(eq, 'params', [])]
    others = sorted(E.free_symbols - set(mine) - set(params), key=str)
    return E, K, params + others, unknown, var


def recognise(E):
    """(A, B, C) if E = A(w0) w2 + B(w0) w1^2 + C(w0) with A != 0, else None"""
    E = sp.expand(E)
    jets = [s for s in E.free_symbols if s.name.startswith('w') and s.name[1:].isdigit()]
    if any(int(s.name[1:]) > 2 for s in jets) or not E.has(w2):
        return None
    try:
        P = sp.Poly(E, w1, w2)
    except Exception:
        return None
    A = B = C = sp.Integer(0)
    for (e1, e2), co in P.terms():
        if (e1, e2) == (0, 1):
            A = co
        elif (e1, e2) == (2, 0):
            B = co
        elif (e1, e2) == (0, 0):
            C = co
        else:
            return None
    if A == 0:
        return None
    return sp.expand(A), sp.expand(B), sp.expand(C)


# ================================================================================================ carriers
class Carrier(object):
    """carrier variables with a derivation D, relations {Q: Q**2 value}, display map, kind"""

    def __init__(self, D, rels=None, display=None, kind=''):
        self.D = dict(D)
        self.rels = dict(rels or {})
        self.display = dict(display or {})
        self.kind = kind

    def deriv(self, expr):
        return sum((sp.diff(expr, v) * dv for v, dv in self.D.items()), sp.Integer(0))

    def reduce(self, num):
        num = sp.expand(num)
        for Qs, val in self.rels.items():
            if num.has(Qs):
                p = sp.Poly(num, Qs)
                out = sp.Integer(0)
                for (k,), co in p.terms():
                    out += co * sp.expand(val ** (k // 2)) * Qs ** (k % 2)
                num = sp.expand(out)
        return num


def car_t():
    return Carrier({_t: 1}, display={_t: z - _sym('z0')}, kind='t')


def car_exp(lam):
    return Carrier({_S: lam * _S}, display={_S: sp.exp(lam * z)}, kind='exp')


def car_wp(g2, g3):
    arg = z - _sym('z0')
    return Carrier({_P: _Q, _Q: 6 * _P ** 2 - g2 / 2}, {_Q: 4 * _P ** 3 - g2 * _P - g3},
                   {_P: _wp_f(arg, g2, g3), _Q: _wpp_f(arg, g2, g3)}, kind='wp')


def _rad_replace(x, table):
    """replace square roots b**(k/2) (k odd) and I by ring symbols: sqrt(b) = rho/den(b), rho**2 = num(b)*den(b),
    I = iota, iota**2 = -1.  table: base -> (symbol, den, rho**2 value).  Nested radicals raise ValueError."""
    x = sp.sympify(x)
    reps = {}
    for pw in x.atoms(sp.Pow):
        ex = pw.exp
        if not (ex.is_Rational and not ex.is_Integer):
            if ex.is_Rational:
                continue
            raise ValueError("non-rational exponent")
        if ex.q != 2:
            raise ValueError("radical of order %d" % ex.q)
        b = pw.base
        if any(q.exp.is_Rational and not q.exp.is_Integer for q in b.atoms(sp.Pow)) or b.has(sp.I):
            raise ValueError("nested radical")
        if b not in table:
            n, d = sp.fraction(sp.together(b))
            table[b] = (sp.Symbol('_rho%d' % len(table)), sp.expand(d), sp.expand(n * d))
        sym, d, _v = table[b]
        reps[pw] = (sym / d) * b ** ((ex.p - 1) // 2)
    x = x.xreplace(reps) if reps else x
    if x.has(sp.I):
        if sp.I not in table:
            table[sp.I] = (sp.Symbol('_iota'), sp.Integer(1), sp.Integer(-1))
        x = x.xreplace({sp.I: table[sp.I][0]})
    return x


def _reduce_square(num, idx, Rn, Rd, R):
    """num (ring element) modulo gen[idx]**2 = Rn/Rd (Rn, Rd ring elements free of gen[idx]); result times a
    power of Rd (a nonzero constant)"""
    by_k = {}
    for mon, co in num.terms():
        k = mon[idx]
        m2 = list(mon)
        m2[idx] = 0
        by_k.setdefault(k, []).append((tuple(m2), co))
    if not by_k or max(by_k) < 2:
        return num
    Kmax = max(by_k) // 2
    g = R.gens[idx]
    out = R.zero
    for k, terms in by_k.items():
        ck = R.from_dict(dict(terms))
        out += ck * Rn ** (k // 2) * Rd ** (Kmax - k // 2) * g ** (k % 2)
    return out


def fast_verify(E, w_expr, car, subs=None, sqrt_symbols=None, relations=None):
    """the same check as verify(), computed in a polynomial ring over QQ: w = N/D, w' = n1/(L D^2),
    w'' = n2/(L^2 D^3), the numerator of E reduced modulo wpp**2 = 4 wp**3 - g2 wp - g3, the square-root
    relations (and the relation f(r) = 0 by pseudo-division)."""
    Es = sp.expand(sp.sympify(E).subs(subs)) if subs else sp.expand(sp.sympify(E))
    table = {}
    # square-root symbols of the closed form (sigma**2 = S): sigma = rho/den
    sq_map = {}
    for sig, val in (sqrt_symbols or {}).items():
        n, d = sp.fraction(sp.together(sp.sympify(val)))
        rho = sp.Symbol('_rs%d' % len(sq_map))
        sq_map[sig] = rho / d
        table[('sig', sig)] = (rho, sp.expand(d), sp.expand(n * d))
    wx = _rad_replace(sp.sympify(w_expr).xreplace(sq_map), table)
    Dv = dict((v, _rad_replace(sp.sympify(dv).xreplace(sq_map), table)) for v, dv in car.D.items())
    rels = dict((q, _rad_replace(sp.sympify(val).xreplace(sq_map), table)) for q, val in car.rels.items())
    N0, D0 = sp.fraction(sp.together(wx))
    # E with integer coefficients
    Ecl = sp.together(Es)
    En, Ed = sp.fraction(Ecl)
    En = sp.expand(En)
    carr = list(car.D.keys())
    rads = [t[0] for t in table.values()]
    others = set()
    for x in [N0, D0, En] + list(Dv.values()) + list(rels.values()) + [t[1] for t in table.values()] + \
            [t[2] for t in table.values()]:
        others |= sp.sympify(x).free_symbols
    others -= set(carr) | set(rads) | {w0, w1, w2}
    gens = carr + rads + sorted(others, key=str)
    R, *G = sp.ring(gens, sp.QQ)
    # derivation with a common constant denominator L
    nums, dens = {}, []
    for v, dv in Dv.items():
        n_, d_ = sp.fraction(sp.together(dv))
        nums[v] = (sp.expand(n_), sp.expand(d_))
        dens.append(sp.expand(d_))
    Lexpr = sp.Integer(1)
    for d_ in dens:
        Lexpr = sp.lcm(Lexpr, d_)
    Lr = R(sp.expand(Lexpr))
    tilde = dict((gens.index(v), R(sp.expand(n_ * sp.cancel(Lexpr / d_)))) for v, (n_, d_) in nums.items())

    def Dr(g):
        out = R.zero
        for i, nv in tilde.items():
            out += g.diff(G[i]) * nv
        return out
    N = R(sp.expand(N0))
    Dd = R(sp.expand(D0))
    N1, D1 = Dr(N), Dr(Dd)
    N2, D2 = Dr(N1), Dr(D1)
    n1 = N1 * Dd - N * D1
    n2 = N2 * Dd ** 2 - 2 * N1 * D1 * Dd - N * D2 * Dd + 2 * N * D1 ** 2
    PE = sp.Poly(En, w0, w1, w2)
    terms = PE.terms()
    Wmax = max(a + 2 * b + 3 * c for (a, b, c), _co in terms)
    Lmax = max(b + 2 * c for (a, b, c), _co in terms)
    total = R.zero
    for (a, b, c), co in terms:
        total += R(sp.expand(co)) * N ** a * n1 ** b * n2 ** c * Lr ** (Lmax - b - 2 * c) * \
            Dd ** (Wmax - a - 2 * b - 3 * c)
    for q, val in rels.items():
        rn, rd = sp.fraction(sp.together(val))
        total = _reduce_square(total, gens.index(q), R(sp.expand(rn)), R(sp.expand(rd)), R)
    for key, (rho, d_, v2) in table.items():
        total = _reduce_square(total, gens.index(rho), R(v2), R.one, R)
    if total == 0:
        ok = True
    elif relations:
        (rsym, fr), = list(relations.items())
        if rsym in gens:
            ir = gens.index(rsym)
            xr = G[ir]

            def cw(g, dg):              # coefficient of xr**dg (version-independent PolyElement.coeff_wrt)
                return R.from_dict(dict((m[:ir] + (0,) + m[ir + 1:], c) for m, c in g.terms() if m[ir] == dg)) \
                    if any(m[ir] == dg for m in g.monoms()) else R.zero
            fR = R(sp.expand(fr))
            df = fR.degree(xr)
            lf = cw(fR, df)
            g = total
            while g != 0 and g.degree(xr) >= df:
                dg = g.degree(xr)
                g = g * lf - cw(g, dg) * xr ** (dg - df) * fR
            ok = (g == 0)
        else:
            ok = False
    else:
        ok = False
    rel = "; reduced modulo wpp**2 = 4*wp**3 - g2*wp - g3" if car.rels else ""
    der = {"t": "t = z - z0", "exp": "S = exp(lam*z), S' = lam*S", "wp": "wp' = wpp, wpp' = 6*wp**2 - g2/2"}
    extra = "; square roots as symbols with their squares" if table else ""
    if relations:
        extra += "; modulo %s" % ", ".join("%s = 0" % sp.sstr(v) for v in relations.values())
    return {"type": "substitution", "method": "symbolic", "status": "pass" if ok else "fail",
            "detail": ("numerator of E reduced to 0 in QQ[...] (%s%s%s)" % (der.get(car.kind, car.kind), rel, extra))
            if ok else "nonzero residual after reduction", "_radicals": len(table)}


def verify(E, w_expr, car, subs=None, deadline=None, sqrt_symbols=None, relations=None):
    try:
        res = fast_verify(E, w_expr, car, subs=subs, sqrt_symbols=sqrt_symbols, relations=relations)
        if res["status"] == "fail" and res.get("_radicals", 0) >= 2:
            # the radical symbols are independent in the fast check (sqrt2*sqrt3 = sqrt6 is not used): a 'fail' is
            # conclusive only with at most one radical; otherwise recheck with SymPy expressions
            if deadline is not None and deadline - time.monotonic() < 3:
                return {"type": "substitution", "method": "symbolic", "status": "not-run",
                        "detail": "fast check inconclusive (several square roots); slow check skipped (time budget)"}
            res2 = slow_verify(E, w_expr, car, subs=subs, sqrt_symbols=sqrt_symbols, relations=relations)
            res2["detail"] += " (rechecked with SymPy expressions: the fast check treats square roots as independent)"
            return res2
        res.pop("_radicals", None)
        return res
    except Exception as exc:
        if deadline is not None and deadline - time.monotonic() < 5:
            return {"type": "substitution", "method": "symbolic", "status": "not-run",
                    "detail": "fast check not applicable (%s); slow check skipped (time budget)" % exc}
        res = slow_verify(E, w_expr, car, subs=subs, sqrt_symbols=sqrt_symbols, relations=relations)
        res["detail"] += " (fast check not applicable: %s)" % exc
        return res


def slow_verify(E, w_expr, car, subs=None, deadline=None, sqrt_symbols=None, relations=None):
    """exact substitution of w = w_expr (rational in the carrier variables) into E(w0, w1, w2) = 0.
    sqrt_symbols {sigma: S}: constants with sigma**2 = S;  relations {r: f(r)}: r is a root of f."""
    try:
        Es = sp.sympify(E).subs(subs) if subs else sp.sympify(E)
        W0 = sp.together(sp.sympify(w_expr))
        W1 = sp.together(car.deriv(W0))
        W2 = sp.together(car.deriv(W1))
        res = Es.subs({w0: W0, w1: W1, w2: W2}, simultaneous=True)
        num = sp.numer(sp.together(res))
        num = car.reduce(num)
        extra = list((sqrt_symbols or {}).keys())
        if sqrt_symbols:
            num = Carrier({}, sqrt_symbols).reduce(num)
        if relations:
            (rsym, fr), = list(relations.items())
            zero = lambda c: _prem_zero(c, fr, rsym)
        else:
            zero = _iszero
        if num == 0:
            ok = True
        else:
            gens = [v for v in list(car.D) + extra if num.has(v)]
            if gens:
                ok = all(zero(c) for c in sp.Poly(num, *gens).coeffs())
            else:
                ok = zero(num)
        rel = ""
        if car.rels:
            rel = "; reduced modulo wpp**2 = 4*wp**3 - g2*wp - g3"
        der = {"t": "t = z - z0", "exp": "S = exp(lam*z), S' = lam*S", "wp": "wp' = wpp, wpp' = 6*wp**2 - g2/2"}
        return {"type": "substitution", "method": "symbolic", "status": "pass" if ok else "fail",
                "detail": ("E reduced to 0 (%s%s)" % (der.get(car.kind, car.kind), rel)) if ok
                else "nonzero residual after reduction"}
    except Exception as exc:                                     # pragma: no cover
        return {"type": "substitution", "method": "symbolic", "status": "not-run", "detail": "error: %s" % exc}


def _latex(expr):
    s = sp.latex(expr)
    return s.replace(r'\operatorname{wpp}', r"\wp'").replace(r'\operatorname{wp}', r'\wp')


# ================================================================================================ closed forms
def _wp_cubic(P3, X):
    """P3 cubic in X: X = alpha*wp + beta with P3(alpha wp + beta) = alpha^2 (4 wp^3 - g2 wp - g3)"""
    Pp = _poly(P3, X)
    a3 = Pp.coeff_monomial(X ** 3)
    a2 = Pp.coeff_monomial(X ** 2)
    alpha = 4 / a3
    beta = -a2 / (3 * a3)
    q = _poly(sp.expand(P3.subs(X, alpha * _T + beta) / alpha ** 2), _T)
    g2 = _nice(-q.coeff_monomial(_T))
    g3 = _nice(-q.coeff_monomial(1))
    return _nice(alpha), _nice(beta), g2, g3


def _riccati(a, b, c, sign_note=""):
    """all nonconstant solutions of X' = a X^2 + b X + c (constants a, b, c; a != 0 or b != 0 or c != 0)"""
    out = []
    if _status(a) == 'zero':
        if _status(b) == 'zero':
            out.append({"kind": "polynomial", "X": c * _t, "car": car_t(), "ppp": None, "pole_orders": [],
                        "free": [_NM["z0"]], "note": "linear in z" + sign_note})
            return out
        car = car_exp(b)
        out.append({"kind": "simply-periodic", "X": -c / b + _sym('K') * _S, "car": car, "ppp": 0,
                    "pole_orders": [], "free": [_NM["K"]], "constants": {_NM["K"]: "free, nonzero"},
                    "note": "entire (an exponential)" + sign_note})
        return out
    disc = _nice(b ** 2 - 4 * a * c)
    if _status(disc) == 'zero':
        r = _nice(-b / (2 * a))
        out.append({"kind": "rational", "X": r - 1 / (a * _t), "car": car_t(), "ppp": None, "pole_orders": [1],
                    "free": [_NM["z0"]], "note": "simple pole" + sign_note})
        return out
    sq = _sqrt(disc)
    r1 = _nice((-b + sq) / (2 * a))
    r2 = _nice((-b - sq) / (2 * a))
    lam = _nice(a * (r1 - r2))
    K = _sym('K')
    out.append({"kind": "simply-periodic", "X": (r1 - r2 * K * _S) / (1 - K * _S), "car": car_exp(lam), "ppp": 1,
                "pole_orders": [1], "free": [_NM["K"]], "constants": {_NM["K"]: "free, nonzero"},
                "note": "a tanh: rational in exp(%s*z)%s" % (sp.sstr(lam), sign_note)})
    return out


def closed_forms(P, X):
    """All nonconstant meromorphic solutions X(z) of X'^2 = P(X), P a nonzero polynomial of degree <= 4 in X
    (project note, item C).  Each item: kind, X (in carrier variables), car, ppp, pole_orders, free, note."""
    P = sp.expand(P)
    Pp = _poly(P, X)
    n = Pp.degree()
    lc = Pp.LC()
    K = _sym('K')
    out = []
    try:
        c0, sq = _sqf(P, X)
    except Exception:
        c0, sq = 1, [(P, 1)]
    mults = [m for f, m in sq if sp.Poly(f, X).degree() > 0]
    # ---- square case: P = c * F^2  ->  X' = +- sqrt(c) F(X)
    if all(m % 2 == 0 for m in mults):
        F = sp.Integer(1)
        for f, m in sq:
            F *= f ** (m // 2)
        sc = _sqrt(c0)
        Fp0 = _poly(F, X)
        lF = Fp0.LC()
        roots_F = None
        if Fp0.degree() == 2:
            try:
                lin = [g for g, _m in _fac(F, X)[1] if sp.Poly(g, X).degree() == 1]
                rts = [_nice(-sp.Poly(g, X).coeff_monomial(1) / sp.Poly(g, X).coeff_monomial(X)) for g in lin]
                if len(rts) == 2 or (len(rts) == 1 and [mm for g, mm in _fac(F, X)[1]
                                                         if sp.Poly(g, X).degree() == 1][0] == 2):
                    roots_F = rts if len(rts) == 2 else rts * 2
            except Exception:
                roots_F = None
            if roots_F is None:
                p1 = Fp0.coeff_monomial(X) / lF
                p0 = Fp0.coeff_monomial(1) / lF
                dsc = _nice(p1 ** 2 / 4 - p0)
                sqd = _sqrt(dsc)
                roots_F = [_nice(-p1 / 2 + sqd), _nice(-p1 / 2 - sqd)]
        for sgn in (1, -1):
            note = "; branch X' = %s" % sp.sstr(sp.expand(sgn * sc * F))
            if Fp0.degree() == 2:
                a = sgn * sc * lF
                r1, r2 = roots_F
                if _iszero(r1 - r2):
                    out.append({"kind": "rational", "X": r1 - 1 / (a * _t), "car": car_t(), "ppp": None,
                                "pole_orders": [1], "free": [_NM["z0"]], "note": "simple pole" + note})
                else:
                    lam = _nice(a * (r1 - r2))
                    Kc = _sym('K')
                    out.append({"kind": "simply-periodic", "X": (r1 - r2 * Kc * _S) / (1 - Kc * _S),
                                "car": car_exp(lam), "ppp": 1, "pole_orders": [1], "free": [_NM["K"]],
                                "constants": {_NM["K"]: "free, nonzero"},
                                "note": "a tanh: rational in exp(%s*z)%s" % (sp.sstr(lam), note)})
                continue
            Fp = _poly(sp.expand(sgn * sc * F), X)
            co = [Fp.coeff_monomial(X ** k) for k in (2, 1, 0)]
            for it in _riccati(co[0], co[1], co[2], sign_note=note):
                out.append(it)
        return out
    if n == 1:
        a1 = Pp.coeff_monomial(X)
        a0 = Pp.coeff_monomial(1)
        out.append({"kind": "polynomial", "X": -a0 / a1 + a1 * _t ** 2 / 4, "car": car_t(), "ppp": None,
                    "pole_orders": [], "free": [_NM["z0"]], "note": "quadratic polynomial in z"})
        return out
    if n == 2:
        a2, a1, a0 = [Pp.coeff_monomial(X ** k) for k in (2, 1, 0)]
        D = _nice(a1 ** 2 - 4 * a2 * a0)
        lam = _sqrt(a2)
        out.append({"kind": "simply-periodic", "X": -a1 / (2 * a2) + K * _S + D / (16 * a2 ** 2 * K * _S),
                    "car": car_exp(lam), "ppp": 0, "pole_orders": [], "free": [_NM["K"]],
                    "constants": {_NM["K"]: "free, nonzero"},
                    "note": "entire: a cosh, X = -a1/(2 a2) + sqrt(D)/(2 a2) cosh(sqrt(a2)(z - z0)), D = %s" % sp.sstr(D)})
        return out
    lin_multi = [(f, m) for f, m in sq if sp.Poly(f, X).degree() == 1 and m >= 2]
    if n == 3:
        if not lin_multi:
            alpha, beta, g2, g3 = _wp_cubic(P, X)
            out.append({"kind": "elliptic", "X": alpha * _P + beta, "car": car_wp(g2, g3), "ppp": 1,
                        "pole_orders": [2], "free": [_NM["z0"]],
                        "note": "g2**3 - 27*g3**2 = %s" % sp.sstr(_nice(g2 ** 3 - 27 * g3 ** 2))})
            return out
        f, m = lin_multi[0]
        fp = sp.Poly(f, X)
        e = _nice(-fp.coeff_monomial(1) / fp.coeff_monomial(X))
        if m == 3:
            out.append({"kind": "rational", "X": e + 4 / (lc * _t ** 2), "car": car_t(), "ppp": None,
                        "pole_orders": [2], "free": [_NM["z0"]], "note": "double pole"})
            return out
        b = _nice(-Pp.coeff_monomial(X ** 2) / lc - 2 * e)          # P = lc (X - e)^2 (X - b)
        lam = _sqrt(lc * (e - b))
        out.append({"kind": "simply-periodic", "X": e + 4 * (b - e) * K * _S / (1 + K * _S) ** 2,
                    "car": car_exp(lam), "ppp": 1, "pole_orders": [2], "free": [_NM["K"]],
                    "constants": {_NM["K"]: "free, nonzero"},
                    "note": "a sech^2: X = %s + (%s) sech^2(sqrt(%s)(z - z0)/2)" % (
                        sp.sstr(e), sp.sstr(_nice(b - e)), sp.sstr(_nice(lc * (e - b))))})
        return out
    # n == 4
    if lin_multi:                     # double or triple root e in the field: X = e + 1/U lowers the degree
        f, m = lin_multi[0]
        fp = sp.Poly(f, X)
        e = _nice(-fp.coeff_monomial(1) / fp.coeff_monomial(X))
        H = sp.expand(sp.cancel(_X ** 4 * P.subs(X, e + 1 / _X)))
        inner = closed_forms(H, _X)
        for it in inner:
            Xi = it["X"]
            new = dict(it)
            new["X"] = e + 1 / Xi
            new["kind"] = "rational" if it["kind"] in ("polynomial", "rational") else it["kind"]
            new["pole_orders"] = [1]
            if new["kind"] == "simply-periodic":
                new["ppp"] = 2 if sp.Poly(H, _X).degree() == 2 else 1
            new["note"] = "X = %s + 1/U with U'^2 = %s; %s" % (sp.sstr(e), sp.sstr(sp.factor(H.subs(_X, sp.Symbol('U')))),
                                                          it.get("note", ""))
            out.append(new)
        return out
    roots = []
    try:
        if len(P.free_symbols - {X}) > 2:
            raise ValueError("skip factorisation (many symbols)")
        for f, m in _fac(P, X)[1]:
            fp = sp.Poly(f, X)
            if fp.degree() == 1:
                roots.append(_nice(-fp.coeff_monomial(1) / fp.coeff_monomial(X)))
    except Exception:
        pass
    if roots:
        e = roots[0]
        H = sp.expand(sp.cancel(_X ** 4 * P.subs(X, e + 1 / _X)))
        alpha, beta, g2, g3 = _wp_cubic(H, _X)
        out.append({"kind": "elliptic", "X": e + 1 / (alpha * _P + beta), "car": car_wp(g2, g3), "ppp": 2,
                    "pole_orders": [1], "free": [_NM["z0"]],
                    "note": "X = %s + 1/U, U'^2 = %s (cubic)" % (sp.sstr(e), sp.sstr(sp.factor(H.subs(_X, sp.Symbol('U')))))})
        return out
    # Weierstrass's formula (Whittaker-Watson 20.6) with base point x0, P(x0) != 0 preferred
    x0 = sp.Integer(0)
    for cand in (0, 1, -1, 2, -2, 3):
        if _status(P.subs(X, cand)) != 'zero':
            x0 = sp.Integer(cand)
            break
    a0 = Pp.coeff_monomial(X ** 4)
    a1 = Pp.coeff_monomial(X ** 3) / 4
    a2 = Pp.coeff_monomial(X ** 2) / 6
    a3 = Pp.coeff_monomial(X) / 4
    a4 = Pp.coeff_monomial(1)
    g2 = _nice(a0 * a4 - 4 * a1 * a3 + 3 * a2 ** 2)
    g3 = _nice(a0 * a2 * a4 + 2 * a1 * a2 * a3 - a2 ** 3 - a0 * a3 ** 2 - a1 ** 2 * a4)
    f = [sp.expand(sp.diff(P, X, k).subs(X, x0)) for k in range(5)]
    sq0 = _sqrt(f[0])
    num = sq0 * _Q + sp.Rational(1, 2) * f[1] * (_P - f[2] / 24) + f[0] * f[3] / 24
    den = 2 * (_P - f[2] / 24) ** 2 - f[0] * f[4] / 48
    out.append({"kind": "elliptic", "X": x0 + num / den, "car": car_wp(g2, g3), "ppp": 2, "pole_orders": [1],
                "free": [_NM["z0"]], "citations": [REF_WW],
                "note": "Weierstrass's formula with X(z0) = %s; the other sign of the square root is z -> -z" % x0})
    return out


# ================================================================================================ first integral
class _Ctx(object):
    def __init__(self, E, params, deadline, hs):
        self.E = E
        self.params = params
        self.deadline = deadline
        self.hs = hs
        self.log = []
        self.warnings = []

    def time_left(self):
        return self.deadline - time.monotonic()


def _residue_data(num, den, x):
    """Rothstein-Trager for num/den proper with squarefree den: list of (residue, G) with int = sum res*log G.
    Returns (list, ok) ok=False if a residue is not in the coefficient field."""
    tt = sp.Dummy('t')
    R = sp.resultant(sp.Poly(den, x).as_expr(), sp.expand(num - tt * sp.diff(den, x)), x)
    R = sp.expand(R)
    out = []
    if R == 0:
        return out, False
    try:
        _c, facs = _fac(R, tt)
    except Exception:
        return out, False
    ok = True
    for f, _m in facs:
        fp = sp.Poly(f, tt)
        if fp.degree() == 0:
            continue
        if fp.degree() > 1:
            ok = False
            out.append((None, f))
            continue
        rho = _nice(-fp.coeff_monomial(1) / fp.coeff_monomial(tt))
        G = _gcdx(den, sp.expand(num - rho * sp.diff(den, x)), x)
        G = sp.Poly(G, x).monic().as_expr()
        out.append((rho, G))
    return out, ok


def _hermite(expr, x):
    """int expr dx for a rational function: (rational part, remaining proper fraction with squarefree denominator)"""
    from sympy.integrals.rationaltools import ratint_ratpart
    expr = sp.cancel(sp.together(expr))
    num, den = sp.fraction(expr)
    if not den.has(x):
        return sp.integrate(sp.expand(num / den), x), sp.Integer(0)
    q, r = sp.div(sp.Poly(num, x), sp.Poly(den, x))
    polypart = sp.integrate(q.as_expr(), x)
    if r.is_zero:
        return polypart, sp.Integer(0)
    rat, logp = ratint_ratpart(r, sp.Poly(den, x), x)
    return sp.cancel(polypart + rat), sp.cancel(logp)


def first_integral(A, B, C, ctx):
    """classify M = exp(int 2B/A) and compute y(w; h) where possible.  Returns a dict 'fi'."""
    hs = ctx.hs
    fi = {"case": None, "strata": [], "notes": []}
    try:                                    # strata from A itself (referee D2): LC_w(A) = 0, disc of sqf(A) = 0
        Ap = sp.Poly(A, w0)
        cands = [(Ap.LC(), "the leading coefficient of A(w) vanishes (the degree of A drops)")]
        if Ap.degree() >= 2:
            cands.append((sp.discriminant(sp.Poly(sp.sqf_part(A, w0), w0).as_expr(), w0), "A(w) acquires a multiple root"))
        for ex, why in cands:
            for g, _m in sp.factor_list(sp.numer(sp.together(ex)))[1]:
                if g.free_symbols and _status(g) == 'unknown':
                    fi["strata"].append({"conditions": [_cond_str(g, "==")], "note": why})
    except Exception:
        pass
    F = sp.cancel(sp.together(2 * B / A))
    num, den = sp.fraction(F)
    if not den.has(w0):
        num, den = sp.expand(num / den), sp.Integer(1)
    dp = sp.Poly(den, w0)
    lcd = dp.LC()
    num, den = sp.expand(num / lcd), dp.monic().as_expr()
    if den == 1 or not den.has(w0):
        q, r = sp.Poly(num, w0), sp.Poly(0, w0)
    else:
        q, r = sp.div(sp.Poly(num, w0), sp.Poly(den, w0))
    fi["2B/A"] = str(F)
    qe = q.as_expr()
    if qe != 0:
        st = all(_status(c) == 'zero' for c in q.coeffs())
        if not st:
            fi["case"] = "transcendental"
            fi["why"] = "2B/A has the polynomial part %s: M contains exp(%s)" % (qe, sp.integrate(qe, w0))
            for c in q.coeffs():
                if _status(c) == 'unknown':
                    fi["strata"].append({"conditions": [_cond_str(c, "==")], "note": "polynomial part of 2B/A changes"})
            return fi
    re_ = r.as_expr()
    if re_ == 0 or not den.has(w0):
        fi["case"] = "rational"
        fi["M"] = sp.Integer(1)
        fi["residues"] = []
    else:
        g = _gcdx(den, sp.diff(den, w0), w0)
        if sp.Poly(g, w0).degree() > 0:
            fi["case"] = "transcendental"
            fi["why"] = "2B/A has a pole of order >= 2: M contains the exponential of a rational function"
            return fi
        res, ok = _residue_data(re_, den, w0)
        fi["residues"] = [(str(a), str(b)) for a, b in res]
        if not ok:
            fi["case"] = "transcendental"
            par = any((g.free_symbols - {sp.Dummy}) and (sp.sympify(g).free_symbols & set(ctx.params))
                      for a, g in res if a is None)
            if par:
                fi["param_residues"] = True
                fi["why"] = ("the residues of 2B/A are roots of a polynomial with parameter-dependent coefficients; M "
                             "is not algebraic unless they are all rational")
            else:
                fi["why"] = "a residue of 2B/A is not in the coefficient field (irrational): M is not algebraic"
            return fi
        nonint, symbolic = [], []
        M = sp.Integer(1)
        irr = False
        for rho, G in res:
            M *= G ** rho
            if rho.free_symbols:
                symbolic.append((rho, G))
            elif not rho.is_Rational:
                irr = True
            elif not (rho.is_Integer):
                nonint.append((rho, G))
        if irr:
            fi["case"] = "transcendental"
            fi["why"] = "a residue of 2B/A is an irrational algebraic number: M is not algebraic"
            return fi
        fi["M"] = M
        fi["M_factors"] = res
        if symbolic:
            fi["case"] = "generic-exponent"
            fi["symbolic"] = symbolic
            fi["nonint"] = nonint
        elif nonint:
            fi["case"] = "algebraic"
            fi["nonint"] = nonint
        else:
            fi["case"] = "rational"
    # ---- N
    if fi["case"] == "rational":
        M = sp.cancel(fi["M"])
        fi["M"] = M
        integrand = sp.cancel(2 * C * M / A)
        rat, logp = _hermite(integrand, w0)
        fi["N"] = rat
        if logp != 0:
            # does the log part vanish for special parameters?
            lp_num = sp.numer(sp.together(logp))
            cs = sp.Poly(lp_num, w0).coeffs()
            if all(_status(c) == 'zero' for c in cs):
                logp = sp.Integer(0)
            else:
                fi["case"] = "log"
                fi["logpart"] = logp
                for c in cs:
                    if _status(c) == 'unknown':
                        fi["strata"].append({"conditions": [_cond_str(c, "==")],
                                             "note": "a coefficient of the logarithmic part vanishes"})
                return fi
        fi["y"] = sp.cancel((hs - rat) / M)
        fi["var"] = {"e": sp.Integer(0), "s": 1}
        return fi
    if fi["case"] == "algebraic":
        if len(fi["nonint"]) != 1 or sp.Poly(fi["nonint"][0][1], w0).degree() != 1:
            fi["case"] = "algebraic-multi"
            fi["why"] = "several roots of A carry non-integer residues: the closed forms are not generated"
            return fi
        rho, G = fi["nonint"][0]
        e = _nice(-sp.Poly(G, w0).coeff_monomial(1))
        s = int(sp.Rational(rho).q)
        rr = int(sp.Rational(rho).p)
        M1 = sp.Integer(1)
        for rr2, G2 in fi["M_factors"]:
            if G2 != G:
                M1 *= G2 ** rr2
        M1 = sp.cancel(M1)
        V = _X
        wV = e + V ** s
        R1 = sp.cancel((2 * C * M1 / A).subs(w0, wV))
        integrand = sp.cancel(V ** rr * R1 * s * V ** (s - 1))
        rat, logp = _hermite(integrand, V)
        if logp != 0:
            fi["case"] = "log-algebraic"
            fi["why"] = "the integral N has a logarithmic term (in V = (w - e)^(1/%d))" % s
            return fi
        y = sp.cancel((hs - rat) / (V ** rr * M1.subs(w0, wV)))
        fi["yV"] = y
        fi["var"] = {"e": e, "s": s}
        fi["N"] = rat
        fi["y_display"] = sp.sstr(y.subs(V, (w0 - e) ** sp.Rational(1, s)))
        return fi
    if fi["case"] == "generic-exponent":
        if len(fi["symbolic"]) != 1 or fi["nonint"] or sp.Poly(fi["symbolic"][0][1], w0).degree() != 1:
            fi["case"] = "transcendental"
            fi["param_residues"] = True
            fi["why"] = ("the residues of 2B/A depend on the parameters (at several roots): M is not algebraic unless "
                         "they are all rational")
            return fi
        rho, G = fi["symbolic"][0]
        e = _nice(-sp.Poly(G, w0).coeff_monomial(1))
        M1 = sp.Integer(1)
        for rr2, G2 in fi["M_factors"]:
            if G2 != G:
                M1 *= G2 ** rr2
        M1 = sp.cancel(M1)
        v = _X
        R1 = sp.cancel((2 * C * M1 / A).subs(w0, e + v))
        nR, dR = sp.fraction(R1)
        dpol = sp.Poly(dR, v)
        if len(dpol.terms()) != 1:
            fi["case"] = "transcendental"
            fi["param_residues"] = True
            fi["why"] = ("the exponent of M depends on the parameters and 2CM/A is not a Laurent polynomial; M is not "
                         "algebraic unless the exponent is rational")
            return fi
        (mdeg,), dc = dpol.terms()[0]
        Nsum = sp.Integer(0)
        logconds = []
        for (j,), c in sp.Poly(nR, v).terms():
            jj = j - mdeg
            ex = rho + jj + 1
            Nsum += (c / dc) * v ** (jj + 1) / ex
            logconds.append(ex)
        # y(.;h) = h v^-rho / M1 - Nsum / M1   (N = v^rho * Nsum)
        fi["rho"] = rho
        fi["e"] = e
        fi["y0"] = sp.cancel((-Nsum / M1.subs(w0, e + v)).subs(v, w0 - e))
        fi["y_display"] = "%s*(w0 - %s)**(-(%s))/(%s) + %s" % (hs, e, rho, sp.sstr(M1), sp.sstr(fi["y0"]))
        fi["M"] = (w0 - e) ** rho * M1
        for ex in logconds:
            fi["strata"].append({"conditions": [_cond_str(ex, "==")],
                                 "note": "logarithmic term in N (exponent %s = 0)" % sp.sstr(ex)})
        fi["strata"].append({"conditions": ["%s in ZZ" % sp.sstr(rho)], "note": "M rational: rerun with the value"})
        fi["strata"].append({"conditions": ["%s in QQ" % sp.sstr(rho)],
                             "note": "M algebraic: rerun with the value"})
        return fi
    return fi


def _rational_solution(A, B, C, ctx, maxdeg=4):
    """the polynomial solutions y of degree <= 4 of A y'/2 + B y + C = 0 (exact linear algebra).  By B3 and C2 only
    such a branch can carry nonconstant meromorphic solutions with d <= 1 when M is not rational.
    Returns (y1, how): y1 = None if there is none (how = 'none'); for a one-parameter family the particular solution
    with free coefficients set to 0 is returned (how = 'family')."""
    cs = sp.symbols('c0:%d' % (maxdeg + 1))
    Y = sum(cs[i] * w0 ** i for i in range(maxdeg + 1))
    numr = sp.expand(A * sp.diff(Y, w0) / 2 + B * Y + C)
    eqs = sp.Poly(numr, w0).coeffs() if numr.has(w0) else [numr]
    try:
        sol = sp.linsolve(eqs, cs)
    except Exception as exc:
        return None, "linear system not solved (%s)" % exc
    if not sol or sol == sp.EmptySet:
        return None, "none"
    (tup,) = list(sol)
    free = sorted(set().union(*[sp.sympify(t).free_symbols for t in tup]) & set(cs), key=str)
    y1 = sp.expand(sum(sp.sympify(tup[i]).subs(dict((f, 0) for f in free)) * w0 ** i for i in range(maxdeg + 1)))
    return y1, ("family" if free else "unique")


# ================================================================================================ Lemma C over h
def _ytilde(yV, s):
    """reduce y(V) to the meromorphic variable: largest d | s with y in Q(V^d); returns (Y(W), s', d)"""
    y = sp.cancel(sp.together(yV))
    num, den = sp.fraction(y)
    best = 1
    if s > 1:
        pn = sp.Poly(num, _X)
        pd = sp.Poly(den, _X)
        en = [m[0] for m in pn.monoms()]
        ed = [m[0] for m in pd.monoms()]
        for d in sorted([d for d in range(2, s + 1) if s % d == 0], reverse=True):
            c = (ed + en)[0] % d
            if all(x % d == c for x in en + ed):
                best = d
                break
    if best == 1:
        Y = y
    else:
        Y = sp.cancel(sp.together(y.subs(_X, _X ** sp.Rational(1, best))))
        Y = sp.powsimp(sp.expand(Y), force=True)
        Y = sp.cancel(Y)
    s2 = s // best
    yt = sp.cancel(Y / (s2 ** 2 * _X ** (2 * s2 - 2)))
    return yt, s2, best


def _single(yt, s2, e, ctx, conds, hval=None, tag=""):
    """X'^2 = yt(X) for fixed h; w = e + X^s2.  Returns (items, ruled, nd)"""
    items, ruled, nd = [], [], []
    yt = sp.cancel(yt)
    num, den = sp.fraction(yt)
    hdesc = ("the level h = %s" % sp.sstr(hval)) if hval is not None else ("w'^2 = %s" % sp.sstr(
        yt.subs(_X, sp.Symbol('w'))) if s2 == 1 and e == 0 else "the first integral %s" % sp.sstr(yt).replace("_X", "V"))
    if den.has(_X):
        ruled.append({"what": "nonconstant meromorphic solutions with %s%s" % (hdesc, tag),
                      "why": "the reduced first integral %s is not a polynomial in the variable (Lemma C)" % sp.sstr(yt),
                      "conditions": list(conds)})
        return items, ruled, nd
    P = sp.expand(num / den)
    if P == 0:
        ruled.append({"what": "nonconstant solutions with %s%s" % (hdesc, tag), "why": "w' = 0", "conditions": list(conds)})
        return items, ruled, nd
    deg = sp.Poly(P, _X).degree()
    if deg > 4:
        ruled.append({"what": "nonconstant meromorphic solutions with %s%s" % (hdesc, tag),
                      "why": "the reduced first integral is a polynomial of degree %d > 4 (Lemma C)" % deg,
                      "conditions": list(conds)})
        return items, ruled, nd
    if deg == 0 and not P.free_symbols and P == 0:
        return items, ruled, nd
    special = getattr(ctx, "special_sink", None)
    if special is not None and P.free_symbols - {_X}:
        try:
            exprs = [(sp.Poly(P, _X).LC(), "the degree of the first integral drops (h = %s)" % sp.sstr(hval))]
            if deg >= 2:
                exprs.append((sp.discriminant(P, _X), "the first integral for h = %s has a multiple root" % sp.sstr(hval)))
            for ex, why in exprs:
                for g, _m in sp.factor_list(sp.numer(sp.together(ex)))[1]:
                    if g.free_symbols and not g.has(ctx.hs) and _status(g) == 'unknown':
                        special.append({"conditions": [_cond_str(g, "==")], "note": why})
        except Exception:
            pass
    for it in closed_forms(P, _X):
        it = dict(it)
        it["w"] = e + it["X"] ** s2
        it["conditions"] = list(conds)
        it["h"] = hval
        it["first_order"] = "X'^2 = %s%s" % (sp.sstr(sp.factor(P)),
                                             "" if s2 == 1 and e == 0 else ", w = %s + X**%d" % (sp.sstr(e), s2))
        items.append(it)
    return items, ruled, nd


def _not_all_zero(exprs):
    """the condition 'not all of exprs vanish' as a list of condition strings ([] if one of them is a nonzero number;
    ['e != 0'] for one expression; ['e1 != 0 or e2 != 0 ...'] otherwise)"""
    parts = []
    for ex in exprs:
        st = _status(ex)
        if st == 'nonzero':
            return []
        if st == 'unknown':
            e2 = _nice(ex)
            if all(sp.sstr(e2) != sp.sstr(q) for q in parts):
                parts.append(e2)
    if not parts:
        return ["False"]
    if len(parts) == 1:
        return [_cond_str(parts[0], "!=")]
    return [" or ".join("%s != 0" % sp.sstr(q) for q in parts)]


def _poly_condition_loci(eqs, hs, special, why):
    """loci where a linear condition a_k + b_k h = 0 changes: a_k = 0 or b_k = 0 (audit N3 (iv))"""
    for eqn in eqs:
        try:
            pe = sp.Poly(sp.expand(eqn), hs)
            for co in pe.all_coeffs():
                for g, _m in sp.factor_list(sp.numer(sp.together(co)))[1]:
                    if g.free_symbols and not g.has(hs) and _status(g) == 'unknown':
                        special.append({"conditions": [_cond_str(g, "==")], "note": why})
        except Exception:
            pass


def _radical_condition(Pe, ctx):
    """c(h) * LC_X(rho) * disc_X(rho) (numerator), rho the squarefree part of Pe over K(h) (project note, C4).
    Sets ctx.multiple_root_warning if Pe has a multiple root for every h."""
    c0, facs = sp.sqf_list(sp.expand(Pe), _X)
    rho = sp.Integer(1)
    cand = sp.numer(sp.together(c0)) * sp.denom(sp.together(c0))
    for g, m in facs:
        gp = sp.Poly(g, _X)
        if gp.degree() <= 0:
            cand *= sp.numer(sp.together(g))
            continue
        if m > 1:
            ctx.multiple_root_warning = True
        # content of g in X (a polynomial in h and the parameters)
        cont = sp.gcd_list([sp.expand(cc) for cc in gp.all_coeffs()]) if len(gp.all_coeffs()) > 1 else gp.LC()
        cand *= sp.numer(sp.together(cont))
        rho *= g
    rp = sp.Poly(sp.expand(sp.numer(sp.together(rho))), _X)
    cand *= rp.LC()
    if rp.degree() >= 2:
        cand *= sp.discriminant(rp.as_expr(), _X)
    if getattr(ctx, "multiple_root_warning", False):
        ctx.warnings.append("the first integral has a multiple root for every h: special values of h from the "
                            "squarefree part (item C4)")
    return sp.expand(cand)


def _h_at_root(Pe, c, hs):
    """the value of h at which the multiplicity of the root X = c of Pe(X; h) increases (Pe linear in h): the first
    Taylor coefficient at c that is not identically zero in h decides (it covers a root that is multiple for every
    h); None if the multiplicity of c does not depend on h"""
    for k in range(0, 6):
        dk = sp.expand(sp.diff(Pe, _X, k).subs(_X, c) / sp.factorial(k))
        if dk.has(hs):
            pe = sp.Poly(dk, hs)
            if pe.degree() != 1:
                return None
            b1 = pe.coeff_monomial(hs)
            b0 = pe.coeff_monomial(1)
            if _iszero(b1):
                if _iszero(b0):
                    continue
                return None
            return _nice(-b0 / b1)
        if _iszero(dk):
            continue
        return None
    return None


def _prem_zero(expr, fr, r):
    """expr == 0 modulo the irreducible polynomial fr(r) (numerator test)"""
    num = sp.expand(sp.numer(sp.together(sp.expand(expr))))
    if num == 0:
        return True
    if not num.has(r):
        return _iszero(num)
    try:
        return sp.expand(sp.prem(num, fr, r)) == 0
    except Exception:
        return False


def _rootof_family(Pe, f, hs, conds, e, s2):
    """special h = h(r) for r a root of the irreducible factor f of C (degree >= 3): X = r is a double root of
    y(X; h(r)).  Closed forms with r kept symbolic (relation f(r) = 0) and sigma = sqrt(c2(r))."""
    r = _sym('r')
    fr = sp.expand(f.subs(_X, r))
    yc = sp.expand(Pe.subs(_X, r))
    if not yc.has(hs):
        return None
    pe = sp.Poly(yc, hs)
    if pe.degree() != 1:
        return None
    hr = sp.cancel(-pe.coeff_monomial(1) / pe.coeff_monomial(hs))
    ypc = sp.diff(Pe, _X).subs(_X, r).subs(hs, hr)
    if not _prem_zero(ypc, fr, r):
        return None
    yr = sp.expand(Pe.subs(hs, hr))
    c = [sp.cancel(sp.diff(yr, _X, k).subs(_X, r) / sp.factorial(k)) for k in range(5)]
    if not (_prem_zero(c[0], fr, r) and _prem_zero(c[1], fr, r)):
        return None
    sig = _sym('sigma')
    K = _sym('K')
    items = []
    base = {"conditions": list(conds), "h": hr, "free": [_NM["K"]], "constants": {_NM["K"]: "free, nonzero",
            _NM["r"]: "any root of %s = 0" % sp.sstr(fr), _NM["sigma"]: "sqrt(%s)" % sp.sstr(c[2])},
            "relations": {r: fr}, "sqrt_symbols": {sig: c[2]}}
    if _prem_zero(c[2], fr, r):
        if _prem_zero(c[3], fr, r):
            return None
        car = car_t()
        U = -c[4] / c[3] + c[3] * _t ** 2 / 4
        it = dict(base)
        it.update({"kind": "rational", "X": r + 1 / U, "car": car, "ppp": None, "pole_orders": [1, 1],
                   "free": [_NM["z0"]], "note": "triple root at X = r"})
        it["constants"] = {_NM["r"]: base["constants"][_NM["r"]]}
        it.pop("sqrt_symbols")
        items.append(it)
        return {"h": hr, "r": r, "fr": fr, "items": items}
    car = car_exp(sig)
    D = sp.cancel(c[3] ** 2 - 4 * c[2] * c[4])
    if _prem_zero(D, fr, r):
        for sg in (1, -1):
            U = -c[3] / (2 * c[2]) + K * _S
            it = dict(base)
            it.update({"kind": "simply-periodic", "X": r + 1 / U, "car": car_exp(sg * sig), "ppp": 1,
                       "pole_orders": [1], "note": "two double roots: a tanh (branch %+d)" % sg})
            items.append(it)
    else:
        U = -c[3] / (2 * c[2]) + K * _S + D / (16 * c[2] ** 2 * K * _S)
        it = dict(base)
        it.update({"kind": "simply-periodic", "X": r + 1 / U, "car": car, "ppp": 2 if not _prem_zero(c[4], fr, r) else 1,
                   "pole_orders": [1] if not _prem_zero(c[4], fr, r) else [2],
                   "note": "X = r + 1/U with U'^2 = c2 U^2 + c3 U + c4, U a cosh; r a root of %s" % sp.sstr(fr)})
        items.append(it)
    return {"h": hr, "r": r, "fr": fr, "items": items}


def _explicit_quadratic(fam):
    """for a quadratic factor f(r) of C: replace the symbolic root r by the two explicit roots when this creates no
    nested square roots (the r-form is kept otherwise).  Families of type 2+2 (two double roots) with the same h
    at both roots are listed once."""
    fr, r = fam["fr"], fam["r"]
    try:
        fp = sp.Poly(fr, r)
        if fp.degree() != 2:
            return fam
        roots = sp.roots(fp, multiple=True)
        if len(roots) != 2:
            return fam
        roots = [_nice(x) for x in roots]
        same_h = _iszero(sp.sympify(fam["h"]).subs(r, roots[0]) - sp.sympify(fam["h"]).subs(r, roots[1]))
        new_items = []
        for it in fam["items"]:
            two_double = "two double roots" in it.get("note", "")
            for k, rho in enumerate(roots):
                if two_double and same_h and k == 1:
                    continue
                subs_sig = {}
                for sig, val in (it.get("sqrt_symbols") or {}).items():
                    subs_sig[sig] = _sqrt(_nice(sp.sympify(val).subs(r, rho)))
                X = sp.sympify(it["X"]).subs(r, rho).xreplace(subs_sig)
                car = it["car"]
                if car.kind == "exp":
                    lam = _nice(sp.sympify(car.D[_S] / _S).subs(r, rho).xreplace(subs_sig))
                    car2 = car_exp(lam)
                    probe = [X, lam]
                else:
                    car2 = car
                    probe = [X]
                table = {}
                for x in probe:
                    _rad_replace(x, table)              # raises ValueError for nested radicals
                new = dict(it)
                new.pop("relations", None)
                new.pop("sqrt_symbols", None)
                new["X"] = X
                new["car"] = car2
                new["h"] = _nice(sp.sympify(fam["h"]).subs(r, rho))
                new["constants"] = dict((kk, vv) for kk, vv in it.get("constants", {}).items()
                                        if kk not in (_NM["r"], _NM["sigma"]))
                new["note"] = it.get("note", "").replace("r a root of", "at the root %s of" % sp.sstr(rho))
                new["note"] = (new["note"] + "; double root at w = %s" % sp.sstr(rho)).strip("; ")
                new_items.append(new)
        out = dict(fam)
        out["items"] = new_items
        return out
    except Exception:
        return fam


def _family(yV, s, e, ctx, conds, algebraic=False, equil=None):
    """wrapper: strata found inside _single (fixed h) are collected with those of the family"""
    prev = getattr(ctx, "special_sink", None)
    sink = []
    ctx.special_sink = sink
    try:
        items, ruled, nd, special = _family_inner(yV, s, e, ctx, conds, algebraic=algebraic, equil=equil)
    finally:
        ctx.special_sink = prev
    seen = set(c for st in special for c in st["conditions"])
    for st in sink:
        if not any(c in seen for c in st["conditions"]):
            special.append(st)
            seen.update(st["conditions"])
    return items, ruled, nd, special


def _family_inner(yV, s, e, ctx, conds, algebraic=False, equil=None):
    """Lemma C over all h.  yV rational in _X (= V) and ctx.hs.  w = e + V^s.
    equil: C(w0); with w = e + X^s' the multiple roots X != 0 of the first integral lie over the roots of
    C(e + X^s') (project note, item C4)."""
    hs = ctx.hs
    items, ruled, nd, special = [], [], [], []
    rootof = []
    if not sp.sympify(yV).has(hs):
        a, b, c = _single(*_ytilde(yV, s)[:2], e, ctx, conds)
        return a, b, c, special
    yt, s2, dgen = _ytilde(yV, s)
    num, den = sp.fraction(sp.cancel(yt))
    cand_h = []                      # (value, reason)
    generic_ok = True
    if den.has(_X):
        generic_ok = False
        q, r = sp.div(sp.Poly(num, _X), sp.Poly(den, _X))
        eqs = [sp.expand(c) for c in r.coeffs()]
        hsol = None
        for eqn in eqs:
            pe = sp.Poly(eqn, hs)
            if pe.degree() == 1:
                hsol = _nice(-pe.coeff_monomial(1) / pe.coeff_monomial(hs))
                break
        _poly_condition_loci(eqs, hs, special, "the condition for a polynomial first integral changes")
        if hsol is not None and all(_iszero(sp.expand(eqn.subs(hs, hsol))) for eqn in eqs):
            cand_h.append((hsol, "the only h for which the first integral is a polynomial"))
        else:
            hsol = None
        excl = ([hsol] if hsol is not None else []) + ([sp.Integer(0)] if algebraic and (hsol is None or not _iszero(hsol)) else [])
        hyp = _not_all_zero([c_ for eqn in eqs for c_ in sp.Poly(eqn, hs).all_coeffs()])
        ruled.append({"what": "nonconstant meromorphic solutions with h %s" % (
            ("not in {%s}" % ", ".join(sp.sstr(x) for x in excl)) if excl else "arbitrary"),
            "why": "y(w; h) (in the meromorphic variable) is not a polynomial: Lemma C",
            "conditions": list(conds) + [c_ for c_ in hyp if c_ != "False"],
            "excluded_h": [sp.sstr(x) for x in excl]})
    else:
        P = sp.Poly(sp.expand(num / den), _X)
        deg = P.degree()
        high = [sp.expand(P.coeff_monomial(_X ** k)) for k in range(5, deg + 1)]
        if high:
            generic_ok = False
            hsol = None
            for eqn in high:
                pe = sp.Poly(eqn, hs)
                if pe.degree() == 1:
                    hsol = _nice(-pe.coeff_monomial(1) / pe.coeff_monomial(hs))
                    break
            _poly_condition_loci(high, hs, special, "the degree condition (<= 4) on the first integral changes")
            if hsol is not None and all(_iszero(sp.expand(x.subs(hs, hsol))) for x in high):
                cand_h.append((hsol, "the only h for which the degree is <= 4"))
            else:
                hsol = None
            excl = ([hsol] if hsol is not None else []) + ([sp.Integer(0)] if algebraic and (hsol is None or not _iszero(hsol)) else [])
            hyp = _not_all_zero([c_ for eqn in high for c_ in sp.Poly(eqn, hs).all_coeffs()])
            ruled.append({"what": "nonconstant meromorphic solutions with h %s" % (
                ("not in {%s}" % ", ".join(sp.sstr(x) for x in excl)) if excl else "arbitrary"),
                "why": "the first integral is a polynomial of degree %d > 4 in the meromorphic variable (Lemma C)" % deg,
                "conditions": list(conds) + [c_ for c_ in hyp if c_ != "False"],
                "excluded_h": [sp.sstr(x) for x in excl]})
        else:
            # generic h: degree <= 4.  Special h: leading coefficient, discriminant
            Pe = P.as_expr()
            lcx = P.LC()
            try:
                lfacs = sp.factor_list(sp.numer(sp.together(lcx)))[1]
            except Exception:
                lfacs = []
            for f, _m in lfacs:
                if not f.has(hs):
                    if _status(f) == 'unknown':
                        special.append({"conditions": [_cond_str(f, "==")], "note": "the degree of the first integral drops"})
                    continue
                fp = sp.Poly(f, hs)
                if fp.degree() == 1:
                    cand_h.append((_nice(-fp.coeff_monomial(1) / fp.coeff_monomial(hs)), "the degree drops"))
            disc_hfac = []
            if deg >= 2:
                # corrected item C4: y(.; h) = c(h) prod g_i^{m_i} over K(h), rho = prod g_i; the root pattern of
                # y(.; h0) differs from the generic one iff c(h0) LC(rho)(h0) disc(rho)(h0) = 0
                dfacs = []
                try:
                    disc = _radical_condition(Pe, ctx)
                    if disc is None:
                        raise ValueError("radical not computed")
                    dfacs = sp.factor_list(sp.numer(sp.together(disc)))[1] if disc != 0 else []
                except Exception as exc:
                    ctx.radical_failed = True
                    nd.append({"what": "special values of h (multiple roots of the first integral)",
                               "why": "the squarefree decomposition over K(h) was not computed (%s)" % exc,
                               "partial": "the generic family is listed"})
                for f, _m in dfacs:
                    if not f.has(hs):
                        if _status(f) == 'unknown':
                            special.append({"conditions": [_cond_str(f, "==")],
                                            "note": "the root pattern of the first integral changes for every h"})
                        continue
                    disc_hfac.append(f)
            if equil is not None:
                equil = sp.expand(sp.sympify(equil).subs(w0, e + _X ** s2))
            use_equil = equil is not None and sp.sympify(equil).has(_X)
            if use_equil:
                # a double root c of y(.; h) is a root of C (item C4): explicit for linear factors of C,
                # a symbolic root r (relation f(r) = 0) for the other irreducible factors
                try:
                    cfacs = _fac(sp.expand(equil), _X)[1]
                except Exception:
                    cfacs = []
                Ax = getattr(ctx, "A", None)
                done_f = []
                for f, _m in cfacs:
                    fp = sp.Poly(f, _X)
                    if fp.degree() == 0:
                        continue
                    mirror = False
                    if s2 % 2 == 0 and fp.degree() >= 2:
                        fm = sp.expand(f.subs(_X, -_X))
                        mirror = any(not sp.cancel(fm / g).free_symbols & {_X} for g in done_f)
                    done_f.append(f)
                    if fp.degree() == 1:
                        c = _nice(-fp.coeff_monomial(1) / fp.coeff_monomial(_X))
                        hv = _h_at_root(Pe, c, hs)
                        if hv is not None:
                            cand_h.append((hv, "double root at w = %s (a constant solution)" % sp.sstr(c)))
                        continue
                    if _EXT:
                        ctx.ext_incomplete = True
                        nd.append({"what": "special values of h at the roots of %s" % sp.sstr(f.subs(_X, w0)),
                                   "why": "the coefficients are irrational algebraic numbers and this factor of C(w) is "
                                          "irreducible of degree %d over Q(%s): not treated exactly" % (
                                              fp.degree(), ", ".join(sp.sstr(g) for g in _EXT)),
                                   "partial": "simply periodic or rational solutions (Lemma C)"})
                        continue
                    if ctx.time_left() < 3:
                        nd.append({"what": "special values of h at the roots of %s" % sp.sstr(f.subs(_X, w0)),
                                   "why": "time budget", "partial": "simply periodic or rational solutions (Lemma C)"})
                        continue
                    fam = _rootof_family(Pe, f, hs, conds, e, s2)
                    if fam is not None:
                        if mirror:              # X -> -X gives the same w = e + X^s2: listed with the mirror factor
                            fam["items"] = []
                            rootof.append(fam)
                        else:
                            rootof.append(_explicit_quadratic(fam))
                    cands = [(fp.LC(), "a root of C escapes to infinity"),
                             (sp.discriminant(f, _X), "C has a multiple root")]
                    if Ax is not None and sp.sympify(Ax).has(w0):
                        cands.append((sp.resultant(f, sp.expand(Ax.subs(w0, _X)), _X), "a root of C is a root of A"))
                    for expr, why in cands:
                        try:
                            for g, _m2 in sp.factor_list(sp.numer(sp.together(expr)))[1]:
                                if g.free_symbols and not g.has(hs) and _status(g) == 'unknown':
                                    special.append({"conditions": [_cond_str(g, "==")], "note": why})
                        except Exception:
                            pass
                for g in (disc_hfac if not (_EXT and not getattr(ctx, "ext_incomplete", False)) else []):
                    # with algebraic coefficients the roots of C over Q(ext) are all linear here, and by item C4
                    # every multiple root lies over a root of C: the list of special h above is complete
                    gp = sp.Poly(g, hs)
                    explained = False
                    if gp.degree() == 1:
                        hv = _nice(-gp.coeff_monomial(1) / gp.coeff_monomial(hs))
                        explained = any(_iszero(hv - v) for v, _w in cand_h)
                    for fam in rootof:
                        if explained:
                            break
                        try:
                            Rh = sp.resultant(fam["fr"], sp.numer(sp.together(hs - fam["h"])), fam["r"])
                            explained = sp.expand(sp.prem(sp.expand(Rh), g, hs)) == 0
                        except Exception:
                            pass
                    if not explained:
                        if gp.degree() == 1:
                            cand_h.append((hv, "double root"))
                        else:
                            nd.append({"what": "solutions for the special values of h that are roots of %s = 0" % sp.sstr(g),
                                       "why": "not matched with a root of C",
                                       "partial": "for these h the first integral has a double root: the solutions are "
                                                  "simply periodic or rational (Lemma C)"})
            else:
                for g in disc_hfac:
                    gp = sp.Poly(g, hs)
                    if gp.degree() == 1:
                        cand_h.append((_nice(-gp.coeff_monomial(1) / gp.coeff_monomial(hs)), "double root"))
                    elif gp.degree() == 2:
                        for rt in sp.roots(gp, multiple=True):
                            cand_h.append((_nice(rt), "double root"))
                    else:
                        nd.append({"what": "solutions for the special values of h that are roots of %s = 0" % sp.sstr(g),
                                   "why": "degree %d in h: roots not computed" % gp.degree(),
                                   "partial": "for these h the first integral has a double root: the solutions are "
                                              "simply periodic or rational (Lemma C)"})
            for fam in rootof:
                for it in fam["items"]:
                    it = dict(it)
                    it["w"] = e + it["X"] ** s2
                    it["first_order"] = "X'^2 = y(X; h(r)) with the double root X = r"
                    items.append(it)
            if algebraic:
                cand_h.append((sp.Integer(0), "the h-term vanishes"))
            # dedupe
            uniq = []
            for v, why in cand_h:
                if not any(_iszero(v - u) for u, _w in uniq):
                    uniq.append((v, why))
            cand_h = uniq
            # parameter values where two special values of h coincide, or where a special value has a pole
            for i in range(len(cand_h)):
                for j in range(i + 1, len(cand_h)):
                    try:
                        dif = sp.numer(sp.together(cand_h[i][0] - cand_h[j][0]))
                        for f, _m in sp.factor_list(dif)[1]:
                            if f.free_symbols and not f.has(hs) and _status(f) == 'unknown':
                                special.append({"conditions": [_cond_str(f, "==")],
                                                "note": "two special values of h coincide"})
                    except Exception:
                        pass
                try:
                    dn = sp.denom(sp.together(cand_h[i][0]))
                    for f, _m in sp.factor_list(dn)[1]:
                        if f.free_symbols and _status(f) == 'unknown':
                            special.append({"conditions": [_cond_str(f, "==")],
                                            "note": "a special value of h has a pole"})
                except Exception:
                    pass
            hconds = ["h != %s" % sp.sstr(v) for v, _w in cand_h]
            for fam in rootof:
                if fam["items"] and not any(it.get("relations") for it in fam["items"]):
                    for hv in sorted(set(sp.sstr(it["h"]) for it in fam["items"])):
                        hconds.append("h != %s" % hv)
                else:
                    hconds.append("h != %s for every root %s of %s" % (sp.sstr(fam["h"]), fam["r"], sp.sstr(fam["fr"])))
            for it in closed_forms(Pe, _X):
                it = dict(it)
                it["w"] = e + it["X"] ** s2
                it["conditions"] = list(conds)
                it["h"] = None
                it["h_conditions"] = hconds
                it["first_order"] = "X'^2 = %s%s" % (sp.sstr(Pe), "" if s2 == 1 and e == 0 else
                                                     ", w = %s + X**%d" % (sp.sstr(e), s2))
                items.append(it)
    if not generic_ok and algebraic and not any(_iszero(v) for v, _w in cand_h):
        cand_h.append((sp.Integer(0), "the h-term vanishes"))
    for v, why in cand_h:
        if ctx.time_left() < 2:
            nd.append({"what": "solutions for h = %s" % sp.sstr(v), "why": "time budget", "partial": why})
            continue
        y_h = sp.cancel(sp.sympify(yV).subs(hs, v))
        yt_h, s2h, _dh = _ytilde(y_h, s)
        a, b, c = _single(yt_h, s2h, e, ctx, conds, hval=v, tag=" (%s)" % why)
        items += a
        ruled += b
        nd += c
    return items, ruled, nd, special


# ================================================================================================ main
def _constants(C, conds, params):
    out = []
    C = sp.expand(C)
    if C == 0:
        out.append({"kind": "constant", "expr": _NM["c"], "constants": {_NM["c"]: "free"}, "free": [_NM["c"]],
                    "conditions": list(conds), "note": "every constant is a solution (C = 0)", "_value": None})
        return out
    if not C.has(w0):
        return out
    try:
        facs = _fac(C, w0)[1]
    except Exception:
        facs = [(C, 1)]
    for f, _m in facs:
        fp = sp.Poly(f, w0)
        if fp.degree() <= 0:
            continue
        if fp.degree() <= 2:
            for r in sp.roots(fp, multiple=False):
                out.append({"kind": "constant", "expr": sp.sstr(_nice(r)), "_value": _nice(r),
                            "conditions": list(conds), "constants": {}, "free": []})
        else:
            out.append({"kind": "constant", "expr": _NM["r"], "constants": {_NM["r"]: "any root of %s = 0" % sp.sstr(f.subs(w0, _sym('r')))},
                        "free": [], "conditions": list(conds), "_value": None, "_factor": f})
    return out


def _solution_obj(it, idx, E, subs, hs, deadline):
    """Solution object of SCHEMA section 2 from an internal item, with verification on the original E"""
    car = it["car"]
    wexpr = sp.sympify(it["w"])
    disp = sp.sympify(wexpr).subs(car.display)
    constants = dict(it.get("constants", {}))
    free = list(it.get("free", []))
    if _NM["z0"] not in free and car.kind in ("t", "wp"):
        free.insert(0, _NM["z0"])
    if wexpr.has(hs) or disp.has(hs) or any(sp.sympify(dv).has(hs) for dv in car.D.values()):
        constants[str(hs)] = "free (first-integral constant)" + (
            "; " + ", ".join(it.get("h_conditions", [])) if it.get("h_conditions") else "")
        free.append(str(hs))
    conds = list(it.get("conditions", []))
    sol = {"id": "s%d" % idx, "kind": it["kind"], "d": 1, "expr": sp.sstr(disp), "latex": _latex(disp),
           "constants": constants, "free": free, "conditions": conds,
           "poles_per_period": it.get("ppp"), "pole_orders": it.get("pole_orders", []),
           "first_integral_h": None if it.get("h") is None else sp.sstr(it["h"]),
           "first_order": it.get("first_order"),
           "origin": "live:order2b", "citations": [REF_FIRST] + list(it.get("citations", [])),
           "note": it.get("note", "")}
    sq = it.get("sqrt_symbols")
    rel = it.get("relations")
    if sq:
        disp2 = disp.subs(dict((k, sp.sqrt(v)) for k, v in sq.items()))
        sol["expr"] = sp.sstr(disp2)
        sol["latex"] = _latex(disp2)
    if rel:
        sol["relations"] = dict((str(k), sp.sstr(v) + " = 0") for k, v in rel.items())
    if time.monotonic() < deadline:
        sol["certificate"] = verify(E, wexpr, car, subs=subs, sqrt_symbols=sq, relations=rel, deadline=deadline)
        if rel and sol["certificate"]["status"] == "pass":
            sol["certificate"]["detail"] += "; coefficients reduced modulo %s" % ", ".join(
                "%s(%s) = 0" % (sp.sstr(v), k) for k, v in rel.items())
    else:
        sol["certificate"] = {"type": "substitution", "method": "symbolic", "status": "not-run",
                              "detail": "time budget exhausted"}
    return sol


def _check_first_integral(A, B, C, M, N):
    """d/dz (M(w) w1^2 + N(w)) - (2 M(w) w1 / A(w)) * E == 0 symbolically"""
    try:
        I = M * w1 ** 2 + N
        dI = sp.diff(I, w0) * w1 + sp.diff(I, w1) * w2
        E = A * w2 + B * w1 ** 2 + C
        res = sp.simplify(sp.together(dI - 2 * M * w1 / A * E))
        return "pass" if res == 0 else "fail"
    except Exception as exc:                          # pragma: no cover
        return "not-run (%s)" % exc


def _analyse(A, B, C, ctx, conds, depth):
    """the core: returns dict with found items (unverified), ruled, nd, fi, verdict info, strata"""
    out = {"items": [], "ruled": [], "nd": [], "strata": [], "fi": None, "level": None, "basis": [], "text": "",
           "sub": []}
    fi = first_integral(A, B, C, ctx)
    out["fi"] = fi
    out["strata"] += _coefficient_loci(A, B, C, ctx)
    out["strata"] += fi.get("strata", [])
    case = fi["case"]
    hs = ctx.hs
    if case == "rational":
        items, ruled, nd, special = _family(fi["y"].subs(w0, _X), 1, sp.Integer(0), ctx, conds, equil=C)
        out["items"] += items
        out["ruled"] += ruled
        out["nd"] += nd
        out["strata"] += special
        out["level"] = "complete" if not nd else "partial"
        out["basis"] = [REF_FIRST, "lemma:order2b/A", "lemma:order2b/C"]
        out["text"] = ("rational first integral: every nonconstant solution satisfies w'^2 = y(w; h) for one h; "
                       "the list is complete for every h")
    elif case == "algebraic":
        e, s = fi["var"]["e"], fi["var"]["s"]
        items, ruled, nd, special = _family(fi["yV"], s, e, ctx, conds, algebraic=True, equil=C)
        out["items"] += items
        out["ruled"] += ruled
        out["nd"] += nd
        out["strata"] += special
        out["level"] = "complete" if not nd else "partial"
        out["basis"] = [REF_FIRST, "lemma:order2b/A", "lemma:order2b/C", "lemma:order2b/D"]
        out["text"] = ("algebraic first integral: the integrating factor M(w) of the first integral M(w) w'^2 + N(w) = h "
                       "has the residue %s at w = %s; with V = (%s)^(1/s') meromorphic (monodromy lemma) the list is "
                       "complete for every h" % (fi["nonint"][0][0], sp.sstr(e), sp.sstr(sp.Symbol('w') - e)))
    elif case == "generic-exponent":
        y0 = fi["y0"]
        items, ruled, nd, special = _family(y0.subs(w0, _X), 1, sp.Integer(0), ctx, conds)
        for it in items:
            it["h"] = sp.Integer(0) if it.get("h") is None else it["h"]
            it["note"] = (it.get("note", "") + "; first-integral constant h = 0").strip("; ")
        out["items"] += items
        out["ruled"] += ruled
        out["nd"] += nd
        out["strata"] += special
        rho = fi["rho"]
        out["level"] = "complete-W"
        out["basis"] = [REF_FIRST, "lemma:order2b/A", "lemma:order2b/B3", "lemma:order2b/C"]
        out["text"] = ("the integrating factor M(w) = (%s)^(%s) of the first integral M(w) w'^2 + N(w) = h is not "
                       "algebraic when %s is irrational: the solutions with d <= 1 are exactly those on the level h = 0 "
                       "(listed); solutions with d = 2 are not decided" % (sp.sstr(sp.Symbol('w') - fi["e"]),
                                                                          sp.sstr(rho), sp.sstr(rho)))
        out["ruled"].append({"what": "nonconstant solutions with d <= 1 (rational, simply periodic or elliptic) and h != 0",
                             "why": "for %s irrational, y(w; h) is algebraic only for h = 0 (item B3)" % rho,
                             "conditions": list(conds) + ["%s not in QQ" % sp.sstr(rho)],
                             "basis": {"theorem": "lemma:order2b/B3-B4", "label": "agent-proof"}})
        out["nd"].append({"what": "meromorphic solutions with d = 2 (w, w' algebraically independent)",
                          "why": "the first integral is not algebraic for h != 0",
                          "partial": "they would have h != 0; every solution with d <= 1 is listed"})
        out["nd"].append({"what": "parameter values with %s rational" % sp.sstr(rho),
                          "why": "M is then algebraic (rational if %s is an integer): the answer changes" % sp.sstr(rho),
                          "partial": "rerun with the numerical value of the parameter", "kind": "parameter-locus",
                          "conditions": ["%s in QQ" % sp.sstr(rho)]})
    elif case == "log":
        lc_ = _log_case(A, B, C, fi, ctx, conds)
        out["strata"] += lc_.pop("strata", [])
        out.update(lc_)
    elif case == "transcendental":
        y1, how = _rational_solution(A, B, C, ctx)
        cond_res = ["the residues of 2B/A are not all rational"] if fi.get("param_residues") else []
        cnw = (not A.has(w0)) and (not B.has(w0)) and _status(B) != 'zero' and not fi.get("param_residues")
        b3 = {"theorem": "lemma:order2b/B3 + C2", "label": "agent-proof"}
        if y1 is not None:
            items, ruled, nd, special = _family(y1.subs(w0, _X), 1, sp.Integer(0), ctx, conds)
            for it in items:
                it["note"] = (it.get("note", "") + "; the unique algebraic branch of the first integral").strip("; ")
            out["items"] += items
            out["ruled"] += ruled
            out["nd"] += nd
            out["fi"]["y1"] = y1
        out["ruled"].append({"what": "nonconstant solutions with d <= 1 other than those listed",
                             "why": "item B3: a solution with d <= 1 has an algebraic first integral; the only one "
                                    "that can carry meromorphic solutions is a polynomial of degree <= 4 (C2): %s" % (
                                        "y1 = %s" % sp.sstr(y1) if y1 is not None else "there is none"),
                             "conditions": list(conds) + cond_res, "basis": b3})
        out["basis"] = [REF_FIRST, "lemma:order2b/A", "lemma:order2b/B3", "lemma:order2b/C"]
        if cnw:
            out["level"] = "complete"
            out["basis"].append(REF_CNW32)
            out["text"] = ("w'' + c w'^2 + P(w) = 0 with c != 0: every meromorphic solution satisfies a polynomial "
                           "first-order equation (%s), hence lies on the polynomial branch %s" % (
                               REF_CNW32, ("y1 = %s" % sp.sstr(y1)) if y1 is not None else "(none: only constants)"))
            hyp32 = [_cond_str(x, "!=") for x in (A, B) if _status(x) == 'unknown']
            out["ruled"].append({"what": "meromorphic solutions with d = 2",
                                 "why": "%s, Theorem 3.2(2): every meromorphic solution of w'' + c w'^2 + P(w) = 0 with "
                                        "c != 0 satisfies a polynomial first-order equation; here c = %s" % (
                                            REF_CNW, sp.sstr(_nice(B / A))),
                                 "conditions": list(conds) + hyp32, "basis": {"theorem": REF_CNW32, "label": "published"}})
        else:
            out["level"] = "complete-W"
            out["text"] = ("the integrating factor M(w) = exp(int 2B/A dw) of the first integral M(w) w'^2 + N(w) = h "
                           "is not algebraic (%s); %s, so the solutions with d <= 1 are listed; d = 2 not decided" % (
                fi.get("why", ""), ("the only algebraic branch of the first integral that can carry meromorphic "
                                    "solutions is y = %s" % sp.sstr(y1)) if y1 is not None else
                "no polynomial branch of degree <= 4 exists: no nonconstant solution has d <= 1"))
            out["nd"].append({"what": "meromorphic solutions with d = 2", "why": "M is not algebraic",
                              "partial": "they are not in W"})
        if cond_res:
            out["nd"].append({"what": "parameter values for which all residues of 2B/A are rational",
                              "why": "M is algebraic there (rational for integer residues): the answer changes",
                              "partial": "rerun with the numerical values", "kind": "parameter-locus",
                              "conditions": ["the residues of 2B/A are all rational"]})
    elif case == "algebraic-multi":
        y1, how = _rational_solution(A, B, C, ctx)
        out["basis"] = [REF_FIRST, "lemma:order2b/A", "lemma:order2b/C"]
        if y1 is not None:
            items, ruled, nd, special = _family(y1.subs(w0, _X), 1, sp.Integer(0), ctx, conds)
            for it in items:
                it["note"] = (it.get("note", "") + "; on the rational branch of the first integral").strip("; ")
            out["items"] += items
            out["nd"] += nd
            out["fi"]["y1"] = y1
        out["level"] = "partial" if (y1 is not None and out["items"]) else "formal"
        out["text"] = ("the integrating factor M(w) of the first integral M(w) w'^2 + N(w) = h is algebraic with "
                       "non-integer residues at several roots of A(w) (%s): solutions on the "
                       "rational branch of the first integral are listed%s; the others are not decided"
                       % (", ".join("%s" % sp.sstr(a) for a, _g in fi.get("nonint", [])),
                          "" if y1 is not None else " (no rational branch found: %s)" % how))
        out["nd"].append({"what": "solutions with first integrals other than the rational branch",
                          "why": fi.get("why", ""),
                          "partial": "if N is algebraic every solution is in W (A4 with an algebraic first integral and "
                                     "T-FIRSTORDER), but the closed forms are not generated"})
    else:
        out["level"] = "formal"
        out["text"] = fi.get("why", "first integral not computed")
        out["nd"].append({"what": "closed forms", "why": fi.get("why", case), "partial": "the reduction to "
                          "w'^2 = y(w; h) holds (item A); every solution with an algebraic y is in W"})
    # ---- parameter strata (one level of recursion; linear conditions only)
    if depth <= 0 and ctx.params:
        seen0 = set()
        for st in out["strata"]:
            for cstr in st["conditions"]:
                if "==" in cstr and cstr not in seen0:
                    seen0.add(cstr)
                    out["nd"].append({"what": "parameter stratum %s%s" % (cstr, (" (inside %s)" % ", ".join(conds)) if conds else ""),
                                      "why": "not explored (one level of special parameter values is analysed)", "partial": st["note"],
                                      "kind": "parameter-locus", "conditions": list(conds) + [cstr]})
    if depth > 0 and ctx.params:
        seen = set()
        seen_sub = set()
        for st in out["strata"]:
            for cstr in st["conditions"]:
                if "==" not in cstr or cstr in seen:
                    continue
                seen.add(cstr)
                if ctx.time_left() < 4:
                    out["nd"].append({"what": "parameter stratum %s" % cstr, "why": "time budget", "partial": st["note"],
                                      "kind": "parameter-locus", "conditions": list(conds) + [cstr]})
                    continue
                loc = dict((q.name, q) for q in ctx.params)
                loc.update({"h": ctx.hs, "r": sp.Symbol("r")})
                lhs = _COND_EXPR.get(cstr)
                if lhs is None:
                    lhs = sp.sympify(cstr.split("==")[0], locals=loc)
                sol = _solve_linear_param(lhs, ctx.params)
                if sol is None:
                    out["nd"].append({"what": "parameter stratum %s" % cstr, "why": "not solved for a parameter",
                                      "partial": st["note"], "kind": "parameter-locus",
                                      "conditions": list(conds) + [cstr]})
                    continue
                p, val = sol
                if (p, sp.sstr(val)) in seen_sub:
                    continue                  # the same substitution reached through another condition
                seen_sub.add((p, sp.sstr(val)))
                A2, B2, C2 = [sp.expand(sp.cancel(x.subs(p, val))) for x in (A, B, C)]
                deg0 = sp.Poly(sp.expand(A * w2 + B * w1 ** 2 + C), w0, w1, w2).total_degree()
                E2_ = sp.expand(A2 * w2 + B2 * w1 ** 2 + C2)
                deg2 = sp.Poly(E2_, w0, w1, w2).total_degree() if E2_ != 0 else -1
                if A2 == 0 or deg2 < deg0:
                    ctx.degenerate.append(" and ".join(list(conds) + [cstr]))
                    out["nd"].append({"what": "parameter stratum %s" % cstr,
                                      "why": ("the equation is not of order two there" if A2 == 0 else
                                              "the degree of the equation drops there") +
                                             " (a different equation; not analysed here)",
                                      "partial": st["note"], "kind": "degenerate-locus",
                                      "conditions": list(conds) + [cstr]})
                    continue
                sub = _analyse(A2, B2, C2, ctx, conds + ["%s == %s" % (p, sp.sstr(val))], depth - 1)
                out["sub"].append({"subs": {p: val}, "cond": "%s == %s" % (p, sp.sstr(val)), "res": sub})
    return out


def _coefficient_loci(A, B, C, ctx):
    """audit N3 (i): every parameter-dependent coefficient of A, B, C vanishes on a locus where the analysis may
    change (e.g. k = 0 in w^3 w'' + omega^2 w^4 - k = 0)"""
    out = []
    try:
        for name, P in (("A", A), ("B", B), ("C", C)):
            P = sp.expand(P)
            if P == 0:
                continue
            coeffs = sp.Poly(P, w0).coeffs() if P.has(w0) else [P]
            for co in coeffs:
                for g, _m in sp.factor_list(sp.numer(sp.together(co)))[1]:
                    if g.free_symbols and _status(g) == 'unknown':
                        out.append({"conditions": [_cond_str(g, "==")],
                                    "note": "a coefficient of %s(w) vanishes (E = A(w) w'' + B(w) w'^2 + C(w))" % name})
    except Exception:
        ctx.loci_failed = True
    return out


def _solve_linear_param(expr, params):
    num = sp.numer(sp.together(sp.sympify(expr)))
    for p in params:
        if not num.has(p):
            continue
        try:
            pp = sp.Poly(num, p)
        except Exception:
            continue
        if pp.degree() == 1:
            c1 = pp.coeff_monomial(p)
            if _status(c1) == 'nonzero' or not (set(c1.free_symbols) & set(params)):
                return p, _nice(-pp.coeff_monomial(1) / c1)
    for p in params:
        if num.has(p):
            try:
                pp = sp.Poly(num, p)
                if pp.degree() == 1:
                    return p, _nice(-pp.coeff_monomial(1) / pp.coeff_monomial(p))
            except Exception:
                pass
    return None


def _log_case(A, B, C, fi, ctx, conds):
    """M rational, N with logarithmic part (item E; Conte-Ng-Wu 2015, Theorem 3.1 for (w - e) w'' - w'^2 + P(w))"""
    out = {"items": [], "ruled": [], "nd": [], "level": None, "basis": [], "text": "", "strata": []}
    logp = fi["logpart"]
    num, den = sp.fraction(sp.cancel(logp))
    dp = sp.Poly(den, w0)
    lcd = dp.LC()
    num, den = sp.expand(num / lcd), dp.monic().as_expr()
    res, ok = _residue_data(num, den, w0)
    omitted = []
    tot = sp.Integer(0)
    lam_desc = []
    for lam, G in res:
        if lam is None:
            ok = False
            continue
        if _status(lam) != 'zero':
            omitted.append(G)
            tot += lam * sp.Poly(G, w0).degree()
            lam_desc.append("%s at the roots of %s" % (sp.sstr(lam), sp.sstr(G)))
    # strata (referee D2): a residue of the log part vanishes, the residues sum to 0
    try:
        cands = [(lam, "a residue of the logarithmic part vanishes") for lam, G in res if lam is not None]
        cands.append((tot, "the residues of the logarithmic part sum to 0 (infinity is no longer omitted)"))
        cands.append((sp.resultant(den, num, w0), "a residue of the logarithmic part vanishes at one root"))
        for ex, why in cands:
            for g, _m in sp.factor_list(sp.numer(sp.together(ex)))[1]:
                if g.free_symbols and _status(g) == 'unknown':
                    out["strata"].append({"conditions": [_cond_str(g, "==")], "note": why})
    except Exception:
        pass
    nvals = sum(sp.Poly(G, w0).degree() for G in omitted) + (0 if _status(tot) == 'zero' else 1)
    out["basis"] = ["lemma:order2b/A", "lemma:order2b/E"]
    hyp_log = _not_all_zero([lam for lam, G in res if lam is not None])
    out["ruled"].append({"what": "nonconstant solutions with d <= 1 (rational, simply periodic or elliptic)",
                         "why": "the first integral contains logarithms for every h (item E1): the residues of the "
                                "logarithmic part do not all vanish",
                         "conditions": list(conds) + [c_ for c_ in hyp_log if c_ != "False"],
                         "basis": {"theorem": "lemma:order2b/E1", "label": "agent-proof"}})
    desc = "log part of N: residues %s" % "; ".join(lam_desc)
    omit_txt = "%s%s" % (", ".join("the roots of %s" % sp.sstr(G) for G in omitted),
                         "" if _status(tot) == 'zero' else " and infinity")
    # ---- (w - e) w'' - w'^2 + P(w) = 0 (up to a constant factor): Conte-Ng-Wu 2015, Theorem 3.1
    try:
        Ap = sp.Poly(A, w0)
        if Ap.degree() == 1 and _iszero(B + Ap.LC()):
            a = Ap.LC()
            e = _nice(-Ap.coeff_monomial(1) / a)
            Pv = sp.Poly(sp.expand(C.subs(w0, w0 + e) / a), w0)
            k = Pv.degree()
            a0, a1, a2 = [Pv.coeff_monomial(w0 ** j) for j in (0, 1, 2)]
            for ex, why in [(Pv.LC(), "the degree of P drops"), (a0, "P(e) = 0"), (a1, "P'(e) = 0")]:
                for g, _m in sp.factor_list(sp.numer(sp.together(ex)))[1]:
                    if g.free_symbols and _status(g) == 'unknown':
                        out["strata"].append({"conditions": [_cond_str(g, "==")],
                                              "note": "%s (Conte-Ng-Wu 2015, Theorem 3.1 changes)" % why})
            if k == 2 and _status(a0) == 'zero' and _status(a1) == 'zero':
                c = a2 * a
                bb, cc = _sym('b'), _sym('c0')
                wexp = e + sp.exp(-c / (2 * a) * z ** 2 + bb * z + cc)
                out["items"].append({"special_d2": True, "w": wexp, "conditions": list(conds),
                                     "kind": "entire", "free": [_NM["b"], _NM["c0"]],
                                     "note": "(log(w - e))'' = -c/a: entire, not in W (d = 2)"})
                out["level"] = "complete"
                out["basis"] = ["lemma:order2b/E3"]
                out["text"] = ("logarithmic first integral; the equation is (log(%s))'' = %s: all nonconstant "
                               "solutions are exp(quadratic), d = 2" % (sp.sstr(sp.Symbol('w') - e), sp.sstr(_nice(-c / a))))
                out["ruled"].append({"what": "meromorphic solutions other than exp(quadratic) and the constants",
                                     "why": "w - e omits 0 and infinity (E2), so w - e = exp(g), g'' = const",
                                     "conditions": list(conds),
                                     "basis": {"theorem": "lemma:order2b/E2-E3", "label": "agent-proof"}})
                return out
            # the hypotheses under which the theorem excludes nonconstant solutions, as conditions of the item
            hyp = []
            if _status(a) == 'unknown':
                hyp.append(_cond_str(a, "!="))
            if _status(Pv.LC()) == 'unknown':
                hyp.append(_cond_str(Pv.LC(), "!="))
            if k == 2:
                st0, st1 = _status(a0), _status(a1)
                if st0 == 'unknown' and st1 == 'unknown':
                    hyp.append("%s != 0 or %s != 0" % (sp.sstr(_nice(a0)), sp.sstr(_nice(a1))))
                elif st0 == 'zero' and st1 == 'unknown':
                    hyp.append(_cond_str(a1, "!="))
                elif st1 == 'zero' and st0 == 'unknown':
                    hyp.append(_cond_str(a0, "!="))
            elif k in (3, 4) and _status(a2) == 'unknown':
                hyp.append(_cond_str(a2, "!="))
            out["level"] = "complete"
            out["basis"] = [REF_CNW31, "lemma:order2b/E1"]
            out["text"] = ("(w - e) w'' - w'^2 + P(w) = 0 with e = %s, P = %s (degree %d)%s: no nonconstant meromorphic "
                           "solution (%s)" % (sp.sstr(e), sp.sstr(Pv.as_expr().subs(w0, sp.Symbol('w') - e)), k,
                                              (" under %s" % ", ".join(hyp)) if hyp else "", REF_CNW31))
            out["ruled"].append({"what": "nonconstant meromorphic solutions",
                                 "why": "%s, Theorem 3.1: w w'' - w'^2 + P(w) = 0 has nonconstant meromorphic solutions "
                                        "only if deg P <= 1, or deg P = 2 and P(0) = P'(0) = 0, or deg P in {3, 4} and "
                                        "P''(0) = 0 (applied to v = w - e); here P(v) = %s, and the item holds under "
                                        "the listed conditions" % (REF_CNW, sp.sstr(Pv.as_expr())),
                                 "conditions": list(conds) + hyp, "basis": {"theorem": REF_CNW31, "label": "published"}})
            return out
    except Exception:
        pass
    if ok and nvals >= 3:
        out["level"] = "complete"
        out["basis"] = ["lemma:order2b/E1", "lemma:order2b/E2", "Picard's little theorem"]
        out["text"] = ("logarithmic first integral; a nonconstant meromorphic solution would omit %d values "
                       "(item E2), impossible by Picard's theorem: only constants" % nvals)
        hyp_e2 = [_cond_str(lam, "!=") for lam, G in res if lam is not None and _status(lam) == 'unknown']
        if _status(tot) == 'unknown':
            hyp_e2.append(_cond_str(tot, "!="))
        out["ruled"].append({"what": "nonconstant meromorphic solutions",
                             "why": "%s; omitted values: %s, %d >= 3 values (item E2 + Picard)" % (desc, omit_txt, nvals),
                             "conditions": list(conds) + hyp_e2,
                             "basis": {"theorem": "lemma:order2b/E2 + Picard's little theorem", "label": "agent-proof"}})
        return out
    out["level"] = "complete-W"
    out["text"] = "logarithmic first integral: no nonconstant solution in W; d = 2 solutions only partly decided"
    out["nd"].append({"what": "meromorphic solutions with d = 2", "why": "logarithmic first integral",
                      "partial": "%s; every nonconstant meromorphic solution omits %s (item E2)" % (desc, omit_txt)})
    return out


def _wl(expr):
    """LaTeX with w for w0"""
    W = sp.Symbol('w')
    return _latex(sp.sympify(expr).subs(w0, W))


def _fi_payload(fi, hs):
    case = fi.get("case")
    d = {"case": case, "note": fi.get("why", "")}
    try:
        if case == "rational":
            y = sp.factor(fi["y"])
            d.update({"y": sp.sstr(y), "latex": "w'^2 = %s" % _wl(y), "algebraic": True, "rational": True,
                      "M": sp.sstr(fi["M"]), "N": sp.sstr(fi["N"])})
        elif case == "algebraic":
            e, s_ = fi["var"]["e"], fi["var"]["s"]
            yw = sp.sympify(fi["yV"]).subs(_X, (w0 - e) ** sp.Rational(1, s_))
            d.update({"y": sp.sstr(yw), "latex": "w'^2 = %s" % _wl(yw), "algebraic": True, "rational": False,
                      "M": sp.sstr(fi["M"]), "substitution": "w = %s + V**%d" % (sp.sstr(e), s_),
                      "y_in_V": sp.sstr(fi["yV"]).replace("_X", "V")})
        elif case == "generic-exponent":
            e, rho = fi["e"], fi["rho"]
            M1 = sp.cancel(fi["M"] / (w0 - e) ** rho)
            yw = hs * (w0 - e) ** (-rho) / M1 + fi["y0"]
            d.update({"y": sp.sstr(yw), "latex": "w'^2 = %s" % _wl(yw), "algebraic": False, "rational": False,
                      "M": sp.sstr(fi["M"]),
                      "note": "algebraic iff the exponent %s is rational; y(w; 0) = %s" % (sp.sstr(rho), sp.sstr(fi["y0"]))})
        elif case == "log":
            yw = (hs - fi["N"] - sp.Integral(fi["logpart"], w0)) / fi["M"]
            d.update({"y": "(%s - (%s) - Integral(%s, w0))/(%s)" % (hs, sp.sstr(fi["N"]), sp.sstr(fi["logpart"]),
                                                                  sp.sstr(fi["M"])),
                      "latex": "w'^2 = %s" % _wl(yw), "algebraic": False, "rational": False, "M": sp.sstr(fi["M"]),
                      "note": "N has a logarithmic part: Integral(%s, w0)" % sp.sstr(fi["logpart"])})
        else:
            d.update({"y": None, "latex": "", "algebraic": False, "rational": False})
            if "y1" in fi:
                d["y_algebraic_branch"] = sp.sstr(fi["y1"])
                d["latex"] = "w'^2 = %s \\text{ (%s)}" % (
                    _wl(fi["y1"]), "the only algebraic branch" if case == "transcendental" else "a rational branch")
    except Exception as exc:                                  # pragma: no cover
        d.setdefault("y", None)
        d["note"] = (d.get("note", "") + "; payload error: %s" % exc).strip("; ")
    return d


def order2b_answer(eq, budget_s=20, depth=1):
    """Answer for A(w) w'' + B(w) w'^2 + C(w) = 0 (see module docstring).  Never raises."""
    t0 = time.monotonic()
    deadline = t0 + float(budget_s)
    res = {"applies": False, "module": "mero.order2b", "first_integral": None, "found": [], "ruled_out": [],
           "not_decided": [], "verdict": {"level": "unsupported", "text": "", "basis": []}, "certificate": {},
           "strata": [], "warnings": [], "log": []}
    try:
        E, K, params, unknown, var = _get_E(eq)
    except Exception as exc:
        res["verdict"]["text"] = "input not read: %s" % exc
        return res
    if K != 2:
        res["verdict"]["text"] = "not a second-order equation"
        return res
    shape = recognise(E)
    if shape is None:
        res["verdict"]["text"] = "not of the form A(w) w'' + B(w) w'^2 + C(w) = 0"
        return res
    A, B, C = shape
    _set_names(params)
    global _EXT
    _EXT = _algebraic_generators(E)
    names = set(str(p) for p in params)
    hname = next(n for n in ("h", "h0", "H", "E0", "hh") if n not in names)
    hs = sp.Symbol(hname)
    res["applies"] = True
    res["shape"] = {"A": sp.sstr(A), "B": sp.sstr(B), "C": sp.sstr(C)}
    ctx = _Ctx(E, params, deadline, hs)
    ctx.A = A
    ctx.degenerate = []
    try:
        an = _analyse(A, B, C, ctx, [], depth if params else 0)
    except Exception as exc:                          # pragma: no cover
        res["warnings"].append("analysis error: %s" % exc)
        res["verdict"] = {"level": "formal", "text": "analysis failed: %s" % exc, "basis": []}
        return res
    fi = an["fi"]
    res["first_integral"] = _fi_payload(fi, hs)
    res["first_integral"]["h"] = hname
    if fi.get("case") == "rational":
        st = _check_first_integral(A, B, C, fi["M"], fi["N"])
        res["certificate"] = {"type": "first-integral", "identity": "d/dz(M(w) w'^2 + N(w)) = 2 M(w) w' E / A(w)",
                              "M": sp.sstr(fi["M"]), "N": sp.sstr(fi["N"]), "status": st,
                              "check": "mero.order2b._check_first_integral (SymPy simplify of the difference)"}
    elif fi.get("case") in ("algebraic", "generic-exponent", "log"):
        res["certificate"] = {"type": "first-integral", "M": sp.sstr(fi.get("M")), "case": fi.get("case")}
    # ---- solutions: constants, then families (main + strata)
    found = []
    for c in _constants(C, [], params):
        found.append(c)
    idx = 0
    sols = []

    def emit(items, subs, extra_conds):
        nonlocal idx
        for it in items:
            idx += 1
            if it.get("special_d2"):
                wexp = it["w"]
                try:
                    Es = E.subs(subs) if subs else E
                    r = Es.subs({w0: wexp, w1: sp.diff(wexp, z), w2: sp.diff(wexp, z, 2)}, simultaneous=True)
                    ok = sp.simplify(r) == 0
                except Exception:
                    ok = False
                sols.append({"id": "s%d" % idx, "kind": "entire", "d": 2, "expr": sp.sstr(wexp), "latex": _latex(wexp),
                             "constants": {_NM["b"]: "free", _NM["c0"]: "free"}, "free": [_NM["b"], _NM["c0"]],
                             "conditions": list(it.get("conditions", [])), "poles_per_period": 0, "pole_orders": [],
                             "certificate": {"type": "substitution", "method": "symbolic",
                                             "status": "pass" if ok else "fail",
                                             "detail": "E simplified to 0 on the explicit function"},
                             "origin": "live:order2b", "citations": [], "note": it.get("note", "")})
                continue
            s = _solution_obj(it, idx, E, subs, hs, deadline)
            sols.append(s)

    emit(an["items"], None, [])
    for sub in an.get("sub", []):
        emit(sub["res"]["items"], sub["subs"], [sub["cond"]])
        for r in sub["res"]["ruled"]:
            res["ruled_out"].append(_ruled(r))
        for n in sub["res"]["nd"]:
            res["not_decided"].append(n)
        res["strata"].append({"conditions": [sub["cond"]], "verdict": sub["res"]["level"],
                              "text": sub["res"]["text"],
                              "first_integral": _fi_payload(sub["res"]["fi"], hs)})
    # constants as Solution objects
    out_found = []
    k = 0
    for c in found:
        k += 1
        val = c.get("_value")
        if val is not None:
            st = "pass" if _iszero(C.subs(w0, val)) else "fail"
        else:
            st = "pass"
        out_found.append({"id": "c%d" % k, "kind": "constant", "d": 0, "expr": c["expr"],
                          "latex": _latex(val) if val is not None else c["expr"],
                          "constants": c.get("constants", {}), "free": c.get("free", []),
                          "conditions": c.get("conditions", []), "poles_per_period": 0, "pole_orders": [],
                          "certificate": {"type": "substitution", "method": "symbolic", "status": st,
                                          "detail": "E(c, 0, 0) = C(c) = 0"},
                          "origin": "live:order2b", "citations": [], "note": c.get("note", "")})
    # the families of the generic stratum are stated for generic parameters: list the strata where the answer
    # may change (explored ones are reported with their own families)
    top = []
    for st in an["strata"]:
        for c in st["conditions"]:
            if "==" in c and c not in top:
                top.append(c)
    for so in sols:
        if not so["conditions"] and top:
            so["valid_outside"] = list(top)
            # audit N3: the generic conditions (the "!=" of every locus) in each family's conditions
            so["conditions"] = [c.replace("==", "!=") for c in top]
    if params and getattr(ctx, "loci_failed", False):
        res["not_decided"].append({"what": "the parameter values at which the analysis changes were not enumerated",
                                   "why": "an error in the locus computation", "partial": "", "kind": "parameter-locus",
                                   "conditions": []})
    res["found"] = out_found + sols
    for r in an["ruled"]:
        res["ruled_out"].append(_ruled(r))
    res["not_decided"] = an["nd"] + res["not_decided"]
    res["strata"] = [s for s in an["strata"] if "==" not in " ".join(s["conditions"])] + res["strata"]
    if any(s["certificate"]["status"] == "fail" for s in res["found"]):
        res["warnings"].append("a substitution check failed: see the certificates")
    level = an["level"] or "formal"
    if getattr(ctx, "multiple_root_warning", False) and getattr(ctx, "radical_failed", False) and \
            level in ("complete", "complete-W"):
        level = "partial"            # referee rule: multiple root for every h and the radical computation failed
    if _EXT and (getattr(ctx, "ext_incomplete", False) or params) and level in ("complete", "complete-W"):
        level = "partial"            # algebraic coefficients that the module cannot treat exactly
        res["not_decided"].append({"what": "exactness over Q(%s)" % ", ".join(sp.sstr(g) for g in _EXT),
                                   "why": "irrational algebraic coefficients%s: some multiple roots were not decided "
                                          "exactly over the coefficient field" % (" together with parameters" if params else ""),
                                   "partial": "the listed families are verified by exact substitution"})
    basis = an["basis"] + ["certificate:substitution"]
    text = an["text"]
    explored = [sb["cond"] for sb in an.get("sub", [])]
    unexplored = []
    for n in res["not_decided"]:
        wh = n.get("what", "")
        if n.get("kind") == "degenerate-locus":
            continue
        if n.get("kind") == "parameter-locus" and n.get("conditions"):
            key = " and ".join(sorted(set(n["conditions"])))
        elif wh.startswith("parameter stratum") or wh.startswith("parameter values"):
            key = wh
            n.setdefault("kind", "parameter-locus")
        else:
            continue
        if key not in unexplored:
            unexplored.append(key)
    scope = {"parameters": "generic values" if params else "the given numerical values",
             "explored_strata": explored, "unexplored": unexplored,
             "degenerate_strata": list(dict.fromkeys(ctx.degenerate))}
    if params:
        text += ("; for generic parameter values (conditions listed with each family); special parameter values "
                 "explored: %s" % (", ".join(explored) or "none"))
        if unexplored:
            text += "; not explored: %s" % "; ".join(u.replace("parameter stratum ", "") for u in unexplored)
        if not explored and not unexplored and not top:
            res["not_decided"].append({"what": "the parameter values at which the analysis changes were not enumerated",
                                       "why": "no locus was produced for this input", "partial": "",
                                       "kind": "parameter-locus", "conditions": []})
            text += "; the parameter values at which the analysis changes were not enumerated"
    res["verdict"] = {"level": level, "text": text, "basis": basis, "scope": scope}
    if level == "complete":
        pub = all(b in (REF_FIRST, REF_CNW31, REF_CNW32) or b.startswith("certificate") for b in basis)
        res["ruled_out"].append({"what": "meromorphic solutions other than those listed" +
                                         (" (for generic parameter values)" if params else ""),
                                 "basis": {"theorem": " + ".join(b for b in basis if not b.startswith("certificate")),
                                           "label": "published" if pub else "agent-proof"},
                                 "certificate": res["certificate"], "conditions": []})
    try:
        res["self_check"] = _self_check(res, params, hname)
    except Exception as exc:                          # pragma: no cover
        res["self_check"] = {"error": str(exc)}
        if res["verdict"]["level"] in ("complete", "complete-W"):
            res["verdict"]["level"] = "partial"
    alg = fi.get("case") in ("rational", "algebraic")
    nonconst = len([s for s in res["found"] if s["kind"] != "constant" and s.get("d") == 1])
    has_d2 = any(s.get("d") == 2 for s in res["found"])
    if has_d2:
        d2 = {"status": "found", "basis": "explicit solutions outside W (item E3)"}
    elif level == "complete":
        d2 = {"status": "ruled out", "basis": "complete list (%s)" % ("algebraic first integral, item A4" if alg
                                                                     else "item E2-E3")}
    elif alg:
        d2 = {"status": "ruled out", "basis": "algebraic first integral: d <= 1 (item A4)"}
    else:
        d2 = {"status": "not ruled out", "basis": "the first integral is not algebraic for every h"}
    res["d_summary"] = {
        "1": {"status": "complete" if level in ("complete", "complete-W") else "partial", "count": nonconst},
        "2": d2,
        "3+": {"status": "ruled out", "basis": "second order with A != 0: w'' is in C(w, w'), so d <= 2"}}
    res["elapsed_s"] = round(time.monotonic() - t0, 3)
    res["warnings"] += ctx.warnings
    return res


# ------------------------------------------------------------------------------------------------ self-check
def _cond_eval(cstr, point, loc):
    """True / False / None (undecided) for one condition string at a numerical point"""
    try:
        if " or " in cstr:
            vals = [_cond_eval(c_, point, loc) for c_ in cstr.split(" or ")]
            if any(v is True for v in vals):
                return True
            return None if any(v is None for v in vals) else False
        if cstr.endswith(" not in QQ") or cstr.endswith(" in QQ"):
            neg = cstr.endswith(" not in QQ")
            ex = sp.sympify(cstr.rsplit(" not in QQ" if neg else " in QQ", 1)[0], locals=loc).subs(point)
            ex = sp.nsimplify(ex) if ex.is_number else ex
            if not ex.is_number:
                return None
            return (not ex.is_Rational) if neg else bool(ex.is_Rational)
        for op in ("==", "!="):
            if op in cstr:
                l_, r_ = cstr.split(op, 1)
                v = sp.sympify(l_, locals=loc) - sp.sympify(r_, locals=loc)
                v = v.subs(point)
                if v.free_symbols:
                    return None
                z_ = _iszero(v)
                return z_ if op == "==" else (not z_)
        if cstr == "False":
            return False
        return None
    except Exception:
        return None


def _item_excludes(item, sol):
    what = item.get("what", "")
    if sol["kind"] == "constant" or "other than" in what:
        return False
    d = sol.get("d", 1)
    if "d = 2" in what:
        return d == 2
    if "d <= 1" in what:
        if d != 1:
            return False
        if "and h != 0" in what and sol.get("first_integral_h") == "0":
            return False
        return True
    if what.startswith("nonconstant meromorphic solutions") or what.startswith("nonconstant solutions with"):
        h0 = sol.get("first_integral_h")
        if "excluded_h" in item:
            return h0 is None or h0 not in item["excluded_h"]
        if "the level h = " in what:
            lev = what.split("the level h = ", 1)[1].split(" (", 1)[0].strip()
            return h0 == lev
        if " with " in what:
            return False                 # a branch w'^2 = y(w) without a level: compared through its first_order
        return True
    return False


def _self_check(res, params, hname):
    """no listed family may be excluded by a listed ruled-out item: test the pair at 3 points of the family's
    locus; on a conflict add the negation of the family's defining equalities to the item, or withdraw the item"""
    import random as _random
    loc = dict((q.name, q) for q in params)
    loc[hname] = sp.Symbol(hname)
    rnd = _random.Random(1234)
    stats = {"pairs_checked": 0, "conflicts": 0, "resolved_by_condition": 0, "items_withdrawn": 0}
    keep = []
    for item in res["ruled_out"]:
        withdrawn = False
        for sol in res["found"]:
            if not _item_excludes(item, sol):
                continue
            stats["pairs_checked"] += 1
            eqs = [c_ for c_ in sol.get("conditions", []) if "==" in c_ and " or " not in c_]
            conflict = False
            for _trial in range(3):
                point = dict((q, sp.Rational(rnd.randint(2, 40), rnd.randint(2, 17)) * rnd.choice([1, -1]))
                             for q in params)
                ok_locus = True
                for c_ in eqs:
                    l_, r_ = c_.split("==", 1)
                    try:
                        ex = sp.sympify(l_, locals=loc) - sp.sympify(r_, locals=loc)
                    except Exception:
                        ok_locus = False
                        break
                    sol_ = _solve_linear_param(ex.subs(dict((q, v) for q, v in point.items()
                                                            if q not in ex.free_symbols or False)), params)
                    sol_ = _solve_linear_param(ex, params)
                    if sol_ is None:
                        ok_locus = False
                        break
                    pp, vv = sol_
                    point[pp] = sp.sympify(vv).subs(point)
                if not ok_locus:
                    break
                if not all(_cond_eval(c_, point, loc) is not False for c_ in sol.get("conditions", [])):
                    continue
                vals = [_cond_eval(c_, point, loc) for c_ in item.get("conditions", [])]
                if all(v is not False for v in vals):
                    conflict = True
                    break
            if not conflict:
                continue
            stats["conflicts"] += 1
            if eqs:
                neg = " or ".join(c_.replace("==", "!=") for c_ in eqs)
                if neg not in item["conditions"]:
                    item["conditions"] = list(item["conditions"]) + [neg]
                stats["resolved_by_condition"] += 1
            else:
                withdrawn = True
                res.setdefault("warnings", []).append(
                    "self-check: the item '%s' would exclude the listed family %s; the item is withdrawn" % (
                        item.get("what"), sol.get("id")))
                break
        if withdrawn:
            stats["items_withdrawn"] += 1
            res["not_decided"].append({"what": item.get("what"), "why": "withdrawn by the self-check (a listed family "
                                       "falls under it)", "partial": ""})
        else:
            keep.append(item)
    res["ruled_out"] = keep
    return stats


def _ruled(r):
    basis = r.get("basis") or {"theorem": "lemma:order2b/C (Lemma C, with item A; uses T-FIRSTORDER)",
                               "label": "agent-proof"}
    out = {"what": r["what"], "basis": basis,
           "certificate": {"type": "first-integral", "detail": r.get("why", "")}, "conditions": r.get("conditions", [])}
    if "excluded_h" in r:
        out["excluded_h"] = r["excluded_h"]
    return out


if __name__ == "__main__":                            # small demonstration
    import json
    for txt in ["w2 - a*w0 - b*w0**3", "w0*w2 - w1**2 + a*w0**2", "2*w0*w2 - w1**2 + a*w0**2 + b*w0**3"]:
        r = order2b_answer(txt)
        print(txt, r["verdict"]["level"], r["elapsed_s"], [s["kind"] for s in r["found"]],
              [s["certificate"]["status"] for s in r["found"]])
