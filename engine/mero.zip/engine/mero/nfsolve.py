"""mero.nfsolve -- rational, simply periodic and elliptic solutions found in the normal form.

    find_w_solutions_nf(eq, local=None, max_poles=1, ends=None, budget_s=60, cover_degenerate=False, **kw) -> dict
    reduce_equation(eq) -> dict          the reduced equation and the change of variables (raises NoGain)

The changes of variables  w = alpha*W + beta,  z = gamma*Z  (and a constant factor on E) remove parameters.
mero.transform.normalise computes the normal form; here every coefficient of it that still contains parameters
is replaced by a new symbol n1, n2, ... (coefficients that are rational multiples of one another share a symbol),
the solver mero.wsolve.find_w_solutions is run on this reduced equation, and every family is transported back:

    w(z) = alpha * W(z / gamma) + beta.

Exactness.  alpha and gamma may contain roots of parameter expressions.  The coefficients of the reduced equation
are recomputed here from the original equation: each radical b**(1/Q) is a symbol r with r**Q = b, and the
coefficient of every monomial of the normal form is required to be free of these symbols (so it is the same for
every choice of the roots).  Then for EVERY choice of the roots the map W -> w is a bijection between the
solutions of the reduced equation (with n_i = their expressions) and the solutions of the original equation, for
all parameter values at which the normal form is defined (the expressions in `assumed_nonzero` do not vanish);
it preserves the kind (rational / simply periodic / elliptic), the number of poles in a period and their orders.
The principal roots are written in the formulas.

One square root in the normal form.  If a coefficient of the normal form still contains sqrt(b0) (TRANSFORM's
parameter rho1), rho is kept as a symbol with rho**2 = b0 inside the new symbols n_i.  For each choice of rho the
map is again a bijection, so every choice gives all solutions.  A condition P(n) = 0 of a reduced family becomes
A + B*rho = 0 (A, B polynomials in the parameters); then either B != 0, rho = -A/B and A**2 - b0*B**2 = 0 (the
constant rho of the family is given by this value), or A = B = 0 (rho stays 'any root of rho**2 = b0').  The
conditions on the parameters are therefore free of roots.  Roots of higher order, or two different square roots,
in the normal form: the plain solver is used (stated in `nf_note`).

Every transported family is checked on the ORIGINAL equation with mero.verify.verify_solution (then, as in
mero.wsolve, the exact check at rational points if the symbolic one does not finish, and the floating-point
check); a family that fails is not returned (it goes to incomplete[*].rejected).  Each check runs in a forked
child with a hard time limit where processes can be started (not in the browser: there it is a direct call).

Parameter values at which the normal form is not defined are listed in nf["degenerate_loci"] (with a
substitution p = value when one exists); cover_degenerate=True solves them as well (recursively).
"""
import re
import time

import sympy as sp

from .special import wp, wpp, zeta_w

__all__ = ["find_w_solutions_nf", "reduce_equation", "NoGain", "SENTENCE"]

z = sp.Symbol("z")
SENTENCE = ("solved in the normal form; the families were transported by the change of variables and checked on "
            "the original equation")
# z-dimension k of the constants of the forms of mero.wsolve (the quantity scales like Z**k)
DIM = {"z0": 1, "a": 1, "nu": -1, "kappa": -2, "t": -1, "g2": -4, "g3": -6, "A": -2, "B": -3}
_IDENT = re.compile(r"[A-Za-z_][A-Za-z_0-9]*")
_FUNCS = {"wp", "wpp", "zeta_w", "exp", "sqrt", "I", "pi", "E", "log", "sinh", "cosh", "tanh", "coth", "sin",
          "cos", "tan", "cot", "Abs"}


class NoGain(Exception):
    """the normal form does not remove a parameter, or cannot be used exactly"""


# ---------------------------------------------------------------------------------------------- small helpers

def _S(text, syms):
    from .verify import parse_expression
    return parse_expression(text, syms)


def _jets(K):
    return [sp.Symbol("w%d" % j) for j in range(K + 1)]


def _terms(E, K):
    P = sp.Poly(sp.expand(E), *_jets(K))
    out = {}
    for m, c in P.terms():
        c = sp.cancel(c)
        if c != 0:
            out[tuple(int(e) for e in m)] = c
    return out


def _mono(m):
    r = sp.Integer(1)
    for j, e in enumerate(m):
        if e:
            r *= sp.Symbol("w%d" % j) ** e
    return r


def _irreducible_factors(e, params):
    """the non-constant irreducible factors (over Q) of numerator and denominator of e, sign-normalised"""
    out = []
    if e is None:
        return out
    e = sp.together(sp.sympify(e))
    if not (e.free_symbols & set(params)):
        return out
    for part in sp.fraction(e):
        part = sp.expand(part)
        if not (part.free_symbols & set(params)):
            continue
        try:
            _, fl = sp.factor_list(part)
        except Exception:                       # pragma: no cover
            fl = [(part, 1)]
        for f, _k in fl:
            if not (f.free_symbols & set(params)):
                continue
            if f.could_extract_minus_sign():
                f = -f
            out.append(sp.expand(f))
    return out


def _add_factor(lst, f):
    for g in lst:
        if sp.expand(g - f) == 0 or sp.expand(g + f) == 0:
            return
    lst.append(f)


def _is_assumed(f, assumed):
    return any(sp.expand(g - f) == 0 or sp.expand(g + f) == 0 for g in assumed)


def _split_radicals(x, params):
    """x = x0 * prod(base**e) with x0 free of roots of parameter expressions (numbers and rational functions);
    returns (x0, {base: e}) or raises NoGain"""
    x0, rad = sp.Integer(1), {}
    for f in sp.Mul.make_args(sp.sympify(x)):
        if isinstance(f, sp.Pow) and f.exp.is_Rational and not f.exp.is_Integer and (f.base.free_symbols & set(params)):
            rad[f.base] = rad.get(f.base, 0) + sp.Rational(f.exp)
            continue
        if f.free_symbols & set(params):
            bad = [a for a in f.atoms(sp.Pow) if not a.exp.is_Integer and (a.base.free_symbols & set(params))]
            if bad or f.has(sp.exp, sp.log, sp.Abs):
                raise NoGain("the change of variables has a factor %s that is not a power of a parameter "
                             "expression" % (f,))
        x0 *= f
    return x0, rad


def _short(e, params):
    """the shortest of a few equivalent forms of a rational function (with algebraic number coefficients)"""
    cands = [_tidy(e)]
    try:
        x = sp.cancel(sp.together(e))
        n, d = sp.fraction(x)
        cands.append(sp.collect(sp.expand(n), list(params)) / sp.factor(d))
        cands.append(sp.expand(x))
    except Exception:                           # pragma: no cover
        pass
    return min(cands, key=lambda c: (len(sp.sstr(c)), sp.count_ops(c)))


def _numer(e):
    return sp.expand(sp.fraction(sp.together(sp.sympify(e)))[0])


def _tidy(e, limit=600):
    e = sp.sympify(e)
    if e.is_number:
        try:
            return sp.radsimp(e) if not e.is_Rational else e   # exact only (no nsimplify: it guesses numerically)
        except Exception:                       # pragma: no cover
            return e
    if sp.count_ops(e) > limit:
        return e
    try:
        r = sp.factor(sp.cancel(e))
        return r if sp.count_ops(r) <= sp.count_ops(e) + 4 else e
    except Exception:                           # pragma: no cover
        return e


# ---------------------------------------------------------------------------------------------- reduction

def reduce_equation(eq, time_budget=20.0):
    """The reduced equation of `eq`.  Returns a dict
        {"equation": Equation (parameters n1, n2, ...), "E": reduced E, "symbols": {n_i: expression},
         "alpha", "beta", "gamma": SymPy expressions (principal roots), "radicals": {base: Q},
         "assumed_nonzero": [irreducible polynomials in the original parameters],
         "map": transform map, "normal_form": E of mero.transform.normalise}
    or raises NoGain (with the reason)."""
    from .transform import normalise
    from .pde import make_equation
    params = list(getattr(eq, "params", []) or [])
    if not params:
        raise NoGain("the equation has no parameters")
    K = eq.K
    terms = _terms(eq.E, K)
    top = tuple([0] * K + [1])
    if top not in terms or any(m[K] for m in terms if m != top):
        raise NoGain("the equation is not solved for the highest derivative")
    try:
        eqn, mp = normalise(eq, time_budget=time_budget)
    except Exception as err:
        raise NoGain("mero.transform.normalise failed: %r" % (err,))
    if mp.get("mstar") is None:
        raise NoGain("no normal form beyond the scale of E (no balance of the highest derivative with a nonlinear "
                     "monomial)")
    ex = mp.get("_exact") or {}
    alpha = sp.sympify(ex.get("alpha", mp["alpha"]))
    beta = sp.sympify(ex.get("beta", mp["beta"]))
    gamma = sp.sympify(ex.get("gamma", mp["gamma"]))
    if any(not a.exp.is_Integer for a in beta.atoms(sp.Pow) if a.base.free_symbols):
        raise NoGain("the shift contains a root of a parameter expression")
    a0, arad = _split_radicals(alpha, params)
    g0, grad = _split_radicals(gamma, params)
    bases = sorted(set(arad) | set(grad), key=sp.default_sort_key)
    lead = terms[top]
    shifted = sp.expand(sp.Add(*[c * _mono(m) for m, c in terms.items()]).subs(sp.Symbol("w0"),
                                                                                 sp.Symbol("w0") + beta))
    R = dict((m, sp.cancel(c / lead)) for m, c in _terms(shifted, K).items())
    # radical exponents of the coefficient of each monomial: coefficient = R_m alpha^(d-1) gamma^(K-o)
    Xs = {}
    for m in R:
        d, o = sum(m), sum(j * e for j, e in enumerate(m))
        Xs[m] = dict((b, sp.Rational((d - 1) * arad.get(b, 0) + (K - o) * grad.get(b, 0))) for b in bases)
    nonint = [b for b in bases if any(not Xs[m][b].is_Integer for m in R)]
    rsym, b0 = None, None
    if nonint:
        # one square root may remain in the normal form: it becomes the auxiliary constant rho (rho**2 = b0)
        if len(nonint) > 1 or any(not (2 * Xs[m][nonint[0]]).is_Integer for m in R):
            raise NoGain("the normal form contains roots of parameter expressions (%s) that are not one square "
                         "root; the plain solver is used"
                         % ", ".join("%s = %s" % kv for kv in (mp.get("radicals") or {}).items()))
        b0 = nonint[0]
        taken0 = set(str(q) for q in params)
        name = "rho1"
        while name in taken0:
            name += "_"
        rsym = sp.Symbol(name)
    nf_terms = _terms(eqn.E, K) if not mp.get("radicals") else {}
    warnings = []
    cm = {}
    for m, Rm in R.items():
        d, o = sum(m), sum(j * e for j, e in enumerate(m))
        c = Rm * a0 ** (d - 1) * g0 ** (K - o)
        for b in bases:
            X = Xs[m][b]
            if b == b0:
                fl = sp.floor(X)
                c *= b ** int(fl) * rsym ** int(2 * (X - fl))
            else:
                c *= b ** int(X)
        c = _tidy(c)
        if c == 0:
            continue
        if rsym is None:
            ref = nf_terms.get(m, sp.Integer(0))
            if sp.simplify(sp.cancel(c - ref)) != 0:
                warnings.append("the coefficient of %s recomputed from the change of variables (%s) differs from "
                                "mero.transform's normal form (%s); the recomputed one is used" % (_mono(m), c, ref))
        cm[m] = c
    # new symbols
    taken = set(str(q) for q in params) | ({str(rsym)} if rsym is not None else set())
    pr = list(params) + ([rsym] if rsym is not None else [])
    nsyms, red, k = [], {}, 0
    for m in sorted(cm, key=lambda m: (sum(j * e for j, e in enumerate(m)), m), reverse=True):
        c = cm[m]
        if not (c.free_symbols & set(pr)):
            red[m] = c
            continue
        cf = sp.factor(c)
        num, rest = cf.as_independent(*pr, as_Add=False)
        qnum = num.as_coeff_Mul()[0] if num.is_number else sp.Integer(1)
        if not qnum.is_Rational or qnum == 0:
            qnum = sp.Integer(1)
        if num != qnum:
            # an irrational number (sqrt(30), I, ...) goes into the new symbol: the reduced equation keeps rational
            # coefficients where possible (the elimination is much slower over an algebraic extension)
            rest = sp.factor(num / qnum * rest)
            num = qnum
        if rest.could_extract_minus_sign():
            num, rest = -num, -rest
        for s, e in nsyms:
            if sp.cancel(rest - e) == 0:
                break
        else:
            k += 1
            name = "n%d" % k
            while name in taken:
                name += "_"
            taken.add(name)
            s = sp.Symbol(name)
            nsyms.append((s, rest))
        red[m] = num * s
    if len(nsyms) >= len(params):
        raise NoGain("nothing is gained: the reduced equation has %d parameters, the equation %d"
                     % (len(nsyms), len(params)))
    E_red = sp.expand(sp.Add(*[c * _mono(m) for m, c in red.items()]))
    red_eq = make_equation(E_red, [s for s, _ in nsyms], unknown=getattr(eq, "unknown", "w"),
                           var=getattr(eq, "var", "z"))
    # parameter values at which the normal form is not defined
    assumed = []
    mstar = next((m for m in R if str(_mono(m)) == mp.get("mstar")), None)
    m1 = next((m for m in R if str(_mono(m)) == mp.get("m1")), None)
    full = [lead, R.get(mstar), R.get(m1) if m1 is not None else None, a0, g0] + list(bases)
    den_only = list(terms.values()) + [beta] + [e for _, e in nsyms]
    for e in full:
        for f in _irreducible_factors(e, params):
            _add_factor(assumed, f)
    for e in den_only:
        # only denominators matter for the coefficients, the shift and the new symbols
        for f in _irreducible_factors(sp.fraction(sp.together(sp.sympify(e)))[1], params):
            _add_factor(assumed, f)
    # factors of the denominators of the coefficients of E: there the equation itself is not defined
    undefined = []
    for e in terms.values():
        for f in _irreducible_factors(sp.fraction(sp.together(sp.sympify(e)))[1], params):
            _add_factor(undefined, f)
    alpha_r, gamma_r, rel = alpha, gamma, None
    if rsym is not None:
        ea, eg = sp.Rational(arad.get(b0, 0)), sp.Rational(grad.get(b0, 0))
        if not (2 * ea).is_Integer or not (2 * eg).is_Integer:
            raise NoGain("the change of variables needs a root of %s of order > 2" % (b0,))
        alpha_r = a0 * sp.Mul(*[b ** arad[b] for b in arad if b != b0]) * rsym ** int(2 * ea)
        gamma_r = g0 * sp.Mul(*[b ** grad[b] for b in grad if b != b0]) * rsym ** int(2 * eg)
        rel = _numer(rsym ** 2 - b0)
    return {"equation": red_eq, "E": E_red, "symbols": dict(nsyms), "alpha": alpha_r, "beta": beta,
            "gamma": gamma_r, "alpha_principal": alpha, "gamma_principal": gamma,
            "radicals": dict((b, max([sp.Rational(arad.get(b, 0)).q, sp.Rational(grad.get(b, 0)).q])) for b in bases),
            "rho": rsym, "rho_base": b0, "rho_relation": rel, "warnings": warnings, "undefined_factors": undefined,
            "assumed_nonzero": assumed, "map": mp, "normal_form": eqn.E, "params": params}


# ---------------------------------------------------------------------------------------------- transport

class _Ctx(object):
    pass


def _strip_assumed(N, ctx):
    """N (polynomial in the parameters) with factors from assumed_nonzero and numbers removed;
    returns (list of remaining irreducible factors with multiplicity 1, is_zero)"""
    N = sp.expand(N)
    if N == 0:
        return [], True
    fl = _irreducible_factors(N, ctx.params)
    return [f for f in fl if not _is_assumed(f, ctx.assumed)], False


def _linear_solve(f, ctx, solved):
    """'p == value' if f (irreducible) is linear in a parameter p whose coefficient is a nonzero number or a
    product of assumed-nonzero factors; else None"""
    best = None
    for p in sorted(f.free_symbols & set(ctx.params), key=str):
        if p in solved:
            continue
        P = sp.Poly(f, p)
        if P.degree() != 1:
            continue
        a, b = P.all_coeffs()
        ok = a.is_number or all(_is_assumed(g, ctx.assumed) for g in _irreducible_factors(a, ctx.params))
        if not ok or (a.is_number and a == 0):
            continue
        val = _short(-b / a, ctx.params)
        key = (0 if a.is_number else 1, sp.count_ops(val), str(p))
        if best is None or key < best[0]:
            best = (key, p, val)
    return None if best is None else (best[1], best[2])


def _ab(N, ctx):
    """N (polynomial in the parameters and rho) -> (A, B), polynomials in the parameters, with
    N = (A + B*rho) / L modulo rho**2 = b0 (L a product of factors of b0, nonzero)"""
    N = sp.expand(N)
    r = ctx.rho
    if r is None or not N.has(r):
        return N, sp.Integer(0)
    P = sp.Poly(N, r)
    A, B = sp.Integer(0), sp.Integer(0)
    for (k,), c in P.terms():
        if k % 2 == 0:
            A += c * ctx.b0 ** (k // 2)
        else:
            B += c * ctx.b0 ** ((k - 1) // 2)
    M = _numer(A + B * r)
    P = sp.Poly(M, r)
    return sp.expand(P.coeff_monomial(1)), sp.expand(P.coeff_monomial(r))


def _rho_alternatives(eqs, neqs, ctx):
    """eqs, neqs: lists of (A, B) meaning A + B*rho = 0 / != 0.  -> list of (equalities, inequalities in the
    parameters, value of rho or None, inequalities that still contain rho)"""
    k = next((i for i, (A, B) in enumerate(eqs) if B != 0), None)
    if k is None:
        pneq, rcons = [], []
        for C, D in neqs:
            if D == 0:
                pneq.append(C)
            else:
                rcons.append(C + D * ctx.rho)
        return [([A for A, _ in eqs], pneq, None, rcons)]
    A, B = eqs[k]
    rho0 = -A / B
    peq = [_numer(rho0 ** 2 - ctx.b0)] + [_numer(Aj + Bj * rho0) for j, (Aj, Bj) in enumerate(eqs) if j != k]
    pneq = [B] + [_numer(C + D * rho0) for C, D in neqs]
    out = [(peq, pneq, rho0, [])]
    for pe, pn, rv, rc in _rho_alternatives([e for j, e in enumerate(eqs) if j != k], neqs, ctx):
        out.append(([A, B] + pe, pn, rv, rc))
    return out


def _transport_conditions(conds, ctx):
    """conditions of a reduced family (strings in n_i) -> list of alternatives
    (condition strings in the original parameters, value of rho or None, constraints containing rho);
    several alternatives when a transported equality factors or when rho is fixed by a condition; [] = impossible"""
    eqs, neqs, other = [], [], []
    for c in conds:
        if "!=" in c:
            a, b = c.split("!=", 1)
            neqs.append(_ab(_numer((_S(a, ctx.nsyms) - _S(b, ctx.nsyms)).xreplace(ctx.nsub)), ctx))
        elif "==" in c:
            a, b = c.split("==", 1)
            eqs.append(_ab(_numer((_S(a, ctx.nsyms) - _S(b, ctx.nsyms)).xreplace(ctx.nsub)), ctx))
        else:
            other.append(c)
    out = []
    for peq, pneq, rv, rcons in _rho_alternatives(eqs, neqs, ctx):
        for conds_, solved in _param_conditions(peq, pneq, ctx):
            ce, cn = _cond_exprs(conds_, ctx.params)
            if ce and (len(ce) > 1 or cn) and _inconsistent(ce, cn, ctx):
                continue              # no parameter value where the normal form is defined (tied symbols)
            rv2 = _tidy(rv.xreplace(solved)) if (rv is not None and solved) else rv
            rc2 = [_numer(c.xreplace(solved)) if solved else c for c in rcons]
            if any(c == 0 for c in rc2):
                continue
            out.append((conds_ + other, rv2, rc2))
    return out


def _param_conditions(peqs, pneqs, ctx):
    """equalities / inequalities (expressions in the parameters) -> list of (condition strings, solved dict)"""
    alts = [([], {})]                      # (condition strings, solved parameters)
    peqs = sorted(peqs, key=lambda e: len(sp.sstr(e)))    # short conditions first: their solutions simplify the rest
    for e in peqs:
        N = _numer(e)
        new_alts = []
        for conds_, solved in alts:
            Ns = _numer(N.xreplace(solved)) if solved else N
            fl, zero = _strip_assumed(Ns, ctx)
            if zero:
                new_alts.append((conds_, solved))
                continue
            if not fl:                    # a nonzero constant (or a product of nonzero factors): impossible
                continue
            if len(fl) > 6:
                new_alts.append((conds_ + ["%s == 0" % sp.sstr(sp.factor(Ns))], solved))
                continue
            for f in fl:
                ls = _linear_solve(f, ctx, solved)
                if ls is not None:
                    p, val = ls
                    s2 = dict((k_, _tidy(v_.xreplace({p: val}))) for k_, v_ in solved.items())
                    s2[p] = val
                    new_alts.append((conds_ + ["%s == %s" % (p, sp.sstr(val))], s2))
                else:
                    new_alts.append((conds_ + ["%s == 0" % sp.sstr(f)], solved))
        alts = new_alts
    out = []
    for conds_, solved in alts:
        ok, extra = True, []
        for e in pneqs:
            N = _numer(e)
            if solved:
                N = _numer(N.xreplace(solved))
            fl, zero = _strip_assumed(N, ctx)
            if zero:
                ok = False
                break
            for f in fl:
                s = "%s != 0" % sp.sstr(f)
                if s not in extra:
                    extra.append(s)
        if ok:
            out.append((conds_ + extra, solved))
    return out


def _with(d, k, v):
    d2 = dict(d)
    d2[k] = v
    return d2


def _rescale_functions(X, gam):
    rep = {}
    for f in X.atoms(wp, wpp, zeta_w):
        u, a, b = f.args
        u2 = sp.expand(gam * u)
        a2, b2 = _tidy(a / gam ** 4), _tidy(b / gam ** 6)
        if isinstance(f, wp):
            rep[f] = gam ** 2 * wp(u2, a2, b2)
        elif isinstance(f, wpp):
            rep[f] = gam ** 3 * wpp(u2, a2, b2)
        else:
            rep[f] = gam * zeta_w(u2, a2, b2)
    X = X.xreplace(rep)
    rep = {}
    z0 = sp.Symbol("z0")
    for f in X.atoms(sp.exp):
        arg = sp.expand(f.args[0])
        arg2 = arg
        try:
            c = arg.coeff(z)
            if c != 0 and sp.expand(arg - c * (z - z0)) == 0:
                arg2 = sp.Mul(sp.factor(c), z - z0)
            else:
                arg2 = sp.factor(arg)
        except Exception:                       # pragma: no cover
            pass
        rep[f] = sp.exp(arg2)
    return X.xreplace(rep)


def _transport_solution(sol, ctx):
    """-> (list of Solution dicts for the original equation (unverified), reason if the list is empty)"""
    names = set(sol.get("constants") or {}) | set(sol.get("free") or [])
    texts = [sol["expr"]] + [v for v in (sol.get("constants") or {}).values() if isinstance(v, str)] + \
        list(sol.get("relations") or []) + list(sol.get("constraints") or [])
    for t in texts:
        names |= set(n for n in _IDENT.findall(t) if n not in _FUNCS)
    names -= set(str(s) for s in ctx.nsyms) | {"z"}
    taken = set(str(q) for q in ctx.params)
    ren = {}
    for n in sorted(names):
        nn = n
        while nn in taken:
            nn += "_"
        ren[n] = nn
    gam = ctx.gamma
    old = dict((n, sp.Symbol(n)) for n in names)
    rep = dict(ctx.nsub)
    for n in names:
        k = DIM.get(n, 0)
        rep[old[n]] = sp.Symbol(ren[n]) * gam ** (-k) if k else sp.Symbol(ren[n])
    syms = list(old.values()) + list(ctx.nsyms) + [z]

    def tr(text, k=0):
        return _S(text, syms).xreplace(rep) * gam ** k

    u = sp.Dummy("u")
    z0s = sp.Symbol("z0")
    X = _S(sol["expr"], syms).xreplace({z: u + z0s})
    if z0s not in X.free_symbols and "z0" in names and DIM.get("z0") == 1:
        # the forms depend on z - z0 only: W((z - z0)/gamma), z0 keeps its name (it is free)
        rep2 = dict(rep)
        rep2[old["z0"]] = sp.Symbol(ren["z0"])
        X = X.xreplace(rep2).xreplace({u: (z - sp.Symbol(ren["z0"])) / gam})
    else:
        X = _S(sol["expr"], syms).xreplace(_with(rep, z, z / gam))
    X = _rescale_functions(X, gam)
    expr0 = ctx.alpha * X + ctx.beta
    cs = {}
    for n, v in (sol.get("constants") or {}).items():
        nn = ren.get(n, n)
        if not isinstance(v, str):
            v = str(v)
        if v == "free":
            cs[nn] = ("free", None)
        elif v.startswith("any root of"):
            f = v[len("any root of"):].split("=")[0]
            cs[nn] = ("root", _numer(tr(f)))
        else:
            cs[nn] = ("val", tr(v, DIM.get(n, 0)))
    rels0 = [_numer(tr(r.split("=")[0])) for r in sol.get("relations") or []]
    cons0 = []
    for c in sol.get("constraints") or []:
        N = _numer(tr(c.split("!=")[0]))
        if N == 0:
            return [], "a non-vanishing condition of the family becomes 0"
        cons0.append(N)
    alts = _transport_conditions(list(sol.get("conditions") or []), ctx)
    if not alts:
        return [], ("no parameter value: the conditions of the family have no common solution where the normal "
                    "form is defined")
    out = []
    r = ctx.rho
    for conds, rv, rcons in alts:
        S = {}                     # rho stays a constant: given by its value (rv) or as any root of its relation

        def fin(e, numer=False):
            e = e.xreplace(S) if S else e
            return _numer(e) if numer else e
        expr = fin(expr0)
        consts, relations, constraints = {}, [], []
        for nn, (kind_, v) in cs.items():
            if kind_ == "free":
                consts[nn] = "free"
            elif kind_ == "root":
                consts[nn] = "any root of %s = 0" % sp.sstr(fin(v, True))
            else:
                consts[nn] = sp.sstr(_tidy(fin(v)))
        relations = [sp.sstr(fin(v, True)) for v in rels0]
        bad = False
        for v in cons0 + list(rcons):
            N = fin(v, True)
            if N == 0:
                bad = True
                break
            constraints.append("%s != 0" % sp.sstr(sp.factor(N)))
        if bad:
            continue
        uses_r = r is not None and (expr.has(r) or any(str(r) in _IDENT.findall(v) for v in
                                                         list(consts.values()) + relations + constraints))
        count = sol.get("count", 1)
        if uses_r and rv is not None:
            consts[str(r)] = sp.sstr(rv)
        elif uses_r:
            consts[str(r)] = "any root of %s = 0" % sp.sstr(ctx.rho_relation)
            relations.append(sp.sstr(ctx.rho_relation))
            count = count * 2 if isinstance(count, int) else count
        s2 = {"id": None, "kind": sol.get("kind"), "d": sol.get("d", 1), "expr": sp.sstr(expr), "latex": "",
              "constants": consts, "free": [ren.get(f, f) for f in sol.get("free") or []],
              "conditions": conds + [c for c in ctx.nf_conditions if c not in conds],
              "constraints": constraints, "relations": relations, "count": count,
              "poles_per_period": sol.get("poles_per_period"), "pole_orders": list(sol.get("pole_orders") or []),
              "certificate": {"type": "substitution", "method": "symbolic", "status": "not-run", "detail": ""},
              "origin": "live:wsolve+nf", "citations": [],
              "nf_origin": {"reduced_id": sol.get("id"), "reduced_expr": sol.get("expr"),
                            "reduced_constants": sol.get("constants"),
                            "reduced_conditions": sol.get("conditions"),
                            "map": ctx.map_text, "note": "w(z) = alpha*W(z/gamma) + beta"}}
        if sol.get("notes"):
            s2["notes"] = list(sol["notes"])
        s2["size"] = sum(len(str(v)) for v in consts.values()) + sum(len(c) for c in s2["conditions"])
        try:
            sub = {}
            for n, v in consts.items():
                if v != "free" and not v.startswith("any root"):
                    sub[sp.Symbol(n)] = _S(v, list(ctx.params))
            e2 = expr.xreplace(dict((sp.Symbol(ren.get(n, n)), sp.Symbol(ren.get(n, n))) for n in names))
            e3 = e2.xreplace(sub)
            s2["latex"] = sp.latex(e3 if sp.count_ops(e3) < 400 else e2)
        except Exception:
            s2["latex"] = sp.latex(expr)
        if sol.get("form_s"):
            try:
                ws = _S(sol["form_s"]["w"], syms + [sp.Symbol("s")]).xreplace(rep)
                ws = fin(ctx.alpha * ws + ctx.beta)
                sv = _S(sol["form_s"]["s"], syms).xreplace(_with(rep, z, z / gam))
                sv = fin(_rescale_functions(sv, gam))
                s2["form_s"] = {"s": sp.sstr(sv), "w": sp.sstr(ws), "latex": sp.latex(ws)}
            except Exception:
                pass
        if rv is not None:
            s2["nf_origin"]["rho"] = "%s = %s (the root fixed by the conditions)" % (r, sp.sstr(rv))
        out.append(s2)
    if not out:
        return [], "every case of the family has a non-vanishing condition that becomes 0"
    return out, ""


def _run_limited(fn, args, timeout, direct=True):
    """fn(*args) in a forked child with a hard time limit (None when it is reached); where processes cannot be
    started (the browser) fn is called directly, or None is returned when direct=False"""
    try:
        import multiprocessing as _mp
        mctx = _mp.get_context("fork")
        parent, child = mctx.Pipe(duplex=False)
    except Exception:
        return fn(*args) if direct else None

    def target():
        try:
            child.send(("ok", fn(*args)))
        except BaseException as err:            # pragma: no cover
            child.send(("err", repr(err)))
    try:
        proc = mctx.Process(target=target)
        proc.daemon = True
        proc.start()
    except Exception:
        return fn(*args) if direct else None
    try:
        if parent.poll(timeout):
            kind, res = parent.recv()
            proc.join(5)
            if kind == "ok":
                return res
            raise RuntimeError(res)
        return None
    finally:
        if proc.is_alive():
            proc.kill()
            proc.join(5)


def _symbolic_check(eq, s, budget):
    from . import verify as _v
    return _v.verify_solution(eq, s, time_limit=budget)


def _second(eq, s, budget):
    from . import verify as _v
    from . import wsolve as _ws
    s = dict(s)
    _ws._second_checks(eq, s, s.get("pole_orders") or [1], _v, budget)
    return {"certificate": s["certificate"], "numeric_check": s.get("numeric_check")}


def _verify(eq, s, budget):
    """the exact check on the original equation (symbolic; then, as in mero.wsolve, at rational points if it did
    not finish, and the floating-point check); each step in a child process with a hard time limit"""
    budget = max(5.0, float(budget))
    try:
        cert = _run_limited(_symbolic_check, (eq, s, budget), budget + 10.0)
    except Exception as err:                    # pragma: no cover
        cert = {"type": "substitution", "method": "symbolic", "status": "not-run",
                "detail": "verification raised %s" % (err,)}
    if cert is None:
        cert = {"type": "substitution", "method": "symbolic", "status": "not-run",
                "detail": "the symbolic check did not finish within %d s" % budget}
    s["certificate"] = cert
    try:
        res = _run_limited(_second, (eq, s, budget), 2 * budget + 15.0)
    except Exception as err:                    # pragma: no cover
        res = {"certificate": cert, "numeric_check": {"ok": None, "error": str(err)[:200]}}
    if res is None:
        s["numeric_check"] = {"ok": None, "error": "the second checks did not finish within %d s" % (2 * budget)}
    else:
        s["certificate"] = res["certificate"]
        if res.get("numeric_check") is not None:
            s["numeric_check"] = res["numeric_check"]
    return s["certificate"]["status"]


def _degenerate_loci(ctx):
    """the parameter values excluded by the normal form, with a substitution that reaches each of them when one
    exists (a parameter that occurs linearly with a numeric coefficient): the caller may analyse them separately"""
    out = []
    for f in ctx.assumed:
        item = {"condition": "%s == 0" % sp.sstr(f), "substitution": None}
        if _is_assumed(f, getattr(ctx, "undefined", [])):
            item["undefined"] = True            # a denominator of a coefficient: the equation is not defined there
            out.append(item)
            continue
        for p in sorted(f.free_symbols & set(ctx.params), key=str):
            P = sp.Poly(f, p)
            if P.degree() == 1 and P.all_coeffs()[0].is_number:
                a, b = P.all_coeffs()
                item["substitution"] = {str(p): sp.sstr(sp.expand(-b / a))}
                break
        out.append(item)
    return out


def _map_text(red):
    a, b, g = red["alpha"], red["beta"], red["gamma"]
    W, Z = sp.symbols("W Z")
    return {"w": sp.sstr(a * W + b), "z": sp.sstr(g * Z), "W": sp.sstr((sp.Symbol("w") - b) / a),
            "Z": sp.sstr(sp.Symbol("z") / g), "alpha": sp.sstr(a), "beta": sp.sstr(b), "gamma": sp.sstr(g),
            "rule": "w(z) = alpha*W(z/gamma) + beta for a solution W(Z) of the reduced equation",
            "rho": None if red.get("rho") is None else
            "%s = any root of %s = 0 (each choice gives all solutions)" % (red["rho"], sp.sstr(red["rho_relation"]))}


def _ends_for(red_eq, ends, budget):
    if ends is None:
        return None, "no `ends` data was passed: none used for the reduced equation either"
    try:
        from . import ends as _e
        if isinstance(ends, dict) and "options" in ends:
            return _e.ansatz_terms(red_eq, budget_s=budget), \
                "`ends` recomputed for the reduced equation with mero.ends.ansatz_terms"
        return _e.end_exponents(red_eq, budget_s=budget), \
            "`ends` recomputed for the reduced equation with mero.ends.end_exponents"
    except Exception as err:
        return None, "`ends` could not be recomputed for the reduced equation (%r): no growth forms" % (err,)


def _ne(a):
    """an assumption written as 'expr != 0' (mero.wsolve writes the bare expression)"""
    a = str(a).strip()
    return a if ("!=" in a or "==" in a) else "%s != 0" % a


def _not_examined(c):
    return [w for w in ((c.get("heavy") or {}).get("warnings") or []) if "not examined" in str(w)]


def _plain_result(out, why):
    """the result of the plain solver (NoGain): assumptions written as 'expr != 0'; a certificate whose external
    solver did not examine special parameter values is not a certificate (moved to `incomplete`)"""
    certs, inc = [], []
    for c in out.get("certificates") or []:
        c = dict(c)
        c["assumed_nonzero"] = [_ne(a) for a in c.get("assumed_nonzero") or []]
        hw = _not_examined(c)
        if hw:
            c["reason"] = ("mero.heavy reported '%s': the list of this form holds for generic parameter values "
                           "only and is not certified" % hw[0])
            inc.append(c)
        else:
            certs.append(c)
    for c in out.get("incomplete") or []:
        c = dict(c)
        if "assumed_nonzero" in c:
            c["assumed_nonzero"] = [_ne(a) for a in c.get("assumed_nonzero") or []]
        inc.append(c)
    out["certificates"], out["incomplete"] = certs, inc
    out["nf"] = None
    out["nf_note"] = "plain solver: %s" % (why,)
    out.setdefault("log", []).insert(0, "nfsolve: %s" % (why,))
    return out


def _cond_exprs(conds, params):
    """condition strings -> (equalities, inequalities) as expressions (lhs - rhs)"""
    eqs, neqs = [], []
    for c in conds or []:
        try:
            if "!=" in c:
                a, b = c.split("!=", 1)
                neqs.append(_S(a, params) - _S(b, params))
            elif "==" in c:
                a, b = c.split("==", 1)
                eqs.append(_S(a, params) - _S(b, params))
        except Exception:
            continue
    return eqs, neqs


def _algebraic_as_symbols(exprs):
    """I and numeric radicals q**(p/k) replaced by symbols with their defining polynomials (exact over Q); None if
    another kind of number occurs"""
    rep, rels, k = {}, [], 0
    for e in exprs:
        for a in e.atoms(sp.Pow):
            if a in rep or not (a.base.is_Rational and a.exp.is_Rational and not a.exp.is_Integer):
                continue
            k += 1
            t = sp.Symbol("alg%d_" % k)
            rep[a] = t
            q, ex = sp.Rational(a.base), sp.Rational(a.exp)
            v = q ** ex.p
            rels.append(sp.expand(t ** ex.q * sp.denom(v) - sp.numer(v)))
    out = [sp.expand(e.xreplace(rep)) for e in exprs]
    if any(e.has(sp.I) for e in out):
        k += 1
        t = sp.Symbol("alg%d_" % k)
        out = [sp.expand(e.xreplace({sp.I: t})) for e in out]
        rels.append(t ** 2 + 1)
    for e in out:
        for a in e.atoms(sp.Number):
            if not a.is_Rational:
                return None, None
        if e.atoms(sp.NumberSymbol) or e.has(sp.exp, sp.log):
            return None, None
    return out, rels


def _groebner_is_one(F, gens):
    G = sp.groebner(F, *gens, order="grevlex")
    return len(G.exprs) == 1 and G.exprs[0].is_number and G.exprs[0] != 0


def _inconsistent(eqs, neqs, ctx=None, timeout=15.0):
    """True if the equalities have no common zero (over C) at which the inequalities and the normal-form
    conditions are nonzero: the Groebner basis of the equalities and y*N - 1, with ALL parameters (and the
    algebraic numbers, with their defining polynomials) as variables, is {1}.  False if this is not proved (also
    when the test is too large, takes longer than `timeout`, or no child process can be started)"""
    eqs = [x for x in (_numer(e) for e in eqs) if x != 0]
    if not eqs:
        return False
    if any(not x.free_symbols for x in eqs):
        return True
    if ctx is not None:
        spent = getattr(ctx, "cons_spent", 0.0)
        if spent > 60.0:
            return False
    N = sp.Integer(1)
    for e in list(neqs) + list(getattr(ctx, "assumed", []) or []):
        n = _numer(e)
        if n != 0 and n.free_symbols:
            N *= n
    y = sp.Symbol("y_cons_")
    system, rels = _algebraic_as_symbols(eqs + [sp.expand(y * N - 1)])
    if system is None:
        return False
    F = system + rels
    gens = sorted(set().union(*[x.free_symbols for x in F]) - {y}, key=str) + [y]
    if len(gens) > 10 or sum(len(sp.Add.make_args(x)) for x in F) > 600:
        return False
    t1 = time.monotonic()
    try:
        res = _run_limited(_groebner_is_one, (F, gens), timeout, direct=False)
    except Exception:
        res = None
    if ctx is not None:
        ctx.cons_spent = getattr(ctx, "cons_spent", 0.0) + time.monotonic() - t1
    return res is True


def _cover_loci(eq, params, nf, ctx, sols, certs, incomplete, log, depth, t0, budget_s, max_poles, kw):
    """cover_degenerate=True: the excluded parameter values reached by a substitution p = value are solved
    (recursively).  Every part of an excluded value that is not covered goes to nf["loci_not_covered"] as
    {"conditions": [condition strings, from the outermost locus inwards], "why": reason}: excluded values without
    a substitution, beyond the depth or time limit, where the equation has no pole order, the uncovered parts
    reported by the recursive call, and the exclusions (assumptions) of the certificates of a locus that no
    deeper locus covers.  Values where a coefficient of E has a pole (E not defined) go to nf["loci_undefined"]."""
    from . import wsolve
    from .pde import make_equation
    nlc = nf["loci_not_covered"] = []
    seen = set()

    def add(conds, why):
        key = tuple(sorted(conds))           # the same values reached through two paths are listed once
        if key not in seen:
            seen.add(key)
            nlc.append({"conditions": list(conds), "why": why})
    nfc = set(_ne(c) for c in nf.get("conditions") or [])
    for c in list(certs):
        # assumptions of the main certificates other than the normal-form conditions: not covered by any locus
        if c.get("locus"):
            continue
        for a in c.get("assumed_nonzero") or []:
            if _ne(a) not in nfc:
                add([_ne(a).replace("!=", "==")], "the list of the form '%s' assumes %s" % (c.get("ansatz"), _ne(a)))
    for loc in nf["degenerate_loci"]:
        cond0 = loc["condition"]
        if loc.get("undefined"):
            nf.setdefault("loci_undefined", []).append(cond0)
            continue
        if depth >= 4:
            add([cond0], "the depth limit (4) of the recursion over excluded values was reached")
            continue
        if not loc.get("substitution"):
            add([cond0], "no substitution p = value reaches these values (no parameter occurs linearly with a "
                         "numeric coefficient)")
            continue
        if time.monotonic() - t0 > 1.5 * float(budget_s):
            add([cond0], "time budget")
            continue
        (pn, pv), = loc["substitution"].items()
        psym = next(q for q in params if str(q) == pn)
        cond = "%s == %s" % (pn, pv)
        try:
            Es = sp.expand(sp.together(eq.E.xreplace({psym: _S(pv, params)})))
            Es = sp.expand(sp.fraction(sp.together(Es))[0])
            if Es == 0:
                raise ValueError("the equation vanishes identically")
            eqs = make_equation(Es, [q for q in params if q != psym], unknown=getattr(eq, "unknown", "w"),
                                var=getattr(eq, "var", "z"))
        except Exception as err:
            add([cond], "the equation could not be formed there (%s)" % (err,))
            continue
        try:
            no_pole = not wsolve.pole_orders(eqs)
        except Exception:
            no_pole = False
        if no_pole:
            add([cond], "the equation has no admissible pole order there (lower order or linear)")
            continue
        try:
            sub = find_w_solutions_nf(eqs, None, max_poles=max_poles, ends=None,
                                      budget_s=max(10.0, 0.25 * float(budget_s)), cover_degenerate=True,
                                      _depth=depth + 1, **kw)
        except Exception as err:
            add([cond], "the solver failed there (%s)" % (err,))
            continue
        if not sub.get("certificates") and not sub.get("incomplete"):
            add([cond], "no form was solved there")
            continue
        sub_nf = sub.get("nf")
        for x in (sub_nf or {}).get("loci_not_covered") or []:
            add([cond] + list(x.get("conditions") or []), x.get("why") or "")
        for u in (sub_nf or {}).get("loci_undefined") or []:
            nf.setdefault("loci_undefined", []).append("%s, %s" % (cond, u))
        sub_conds = set(_ne(c) for c in (sub_nf or {}).get("conditions") or [])
        ids2 = {}
        for s3 in sub["solutions"]:
            s3 = dict(s3)
            ids2[s3.get("id")] = "s%d" % (len(sols) + 1)
            s3["id"] = ids2[s3.get("id")]
            s3["conditions"] = [cond] + [c for c in s3.get("conditions") or [] if c != cond]
            s3["locus"] = cond if not s3.get("locus") else "%s, %s" % (cond, s3["locus"])
            s3["locus_conditions"] = [cond] + list(s3.get("locus_conditions") or [])
            sols.append(s3)
        for c in sub["certificates"]:
            c = dict(c)
            own = [_ne(a) for a in c.get("assumed_nonzero") or []]
            c["assumed_nonzero"] = own
            if not c.get("locus"):
                # a certificate of this locus itself: it holds where its assumptions hold; the values where one
                # of them vanishes are covered only if the recursive call solved them (its own excluded values)
                c["locus_assumed"] = own
                for a in own:
                    if a not in sub_conds:
                        add([cond, a.replace("!=", "==")], "the list of the form '%s' on these values assumes %s"
                            % (c.get("ansatz"), a))
            c["solutions"] = [ids2.get(i, i) for i in c.get("solutions") or []]
            c["locus"] = cond if not c.get("locus") else "%s, %s" % (cond, c["locus"])
            c["locus_conditions"] = [cond] + list(c.get("locus_conditions") or [])
            c["scope"] = "on the locus %s (equation with this value substituted): %s" % (cond, c.get("scope"))
            certs.append(c)
        for c in sub["incomplete"]:
            c = dict(c)
            if "assumed_nonzero" in c:
                c["assumed_nonzero"] = [_ne(a) for a in c.get("assumed_nonzero") or []]
            c["locus"] = cond if not c.get("locus") else "%s, %s" % (cond, c["locus"])
            c["locus_conditions"] = [cond] + list(c.get("locus_conditions") or [])
            incomplete.append(c)
        log.append("nfsolve: locus %s: %d families, %d forms finished, %d not finished"
                   % (cond, len(sub["solutions"]), len(sub["certificates"]), len(sub["incomplete"])))


# ---------------------------------------------------------------------------------------------- main entry

def find_w_solutions_nf(eq, local=None, max_poles=1, ends=None, budget_s=60, cover_degenerate=False, **kw):
    """mero.wsolve.find_w_solutions through the normal form (see the module docstring).

    Returns the structure of find_w_solutions ({'solutions', 'certificates', 'incomplete', 'log'}) plus
      'nf': None (the plain solver was used; the reason is in 'nf_note') or
            {"map": {...}, "symbols": {"n1": expression, ...}, "conditions": ["f != 0", ...],
             "reduced_equation": E, "normal_form": E of mero.transform, "ends": how `ends` was treated,
             "statement": ...}.
    Each certificate keeps its system and solution set for the REDUCED equation and has in addition the keys
    'nf', 'statement' (= SENTENCE) and 'assumed_nonzero' (expressions in the ORIGINAL parameters: the normal-form
    conditions and the transported assumptions of the solver); 'solutions' lists the ids of the transported
    families.  kw are passed to find_w_solutions (kinds, numeric_only, verify, cross_check, accelerate, limits).

    cover_degenerate=True: the parameter values excluded by the normal form (nf["degenerate_loci"]) that can be
    reached by a substitution p = value are solved as well (recursively, depth <= 4, a quarter of the budget each);
    their families get the condition 'p == value' and the keys 'locus' (string "a == 0, b == 1"), and
    'locus_conditions' (list); the certificates and unfinished forms of a locus get 'locus', 'locus_conditions'
    and (certificates solved on that locus itself) 'locus_assumed' = its assumptions ("f != 0"): the certificate
    holds on the locus where these do not vanish.  The families of a locus were checked on the equation with
    p = value substituted (that is the original equation at those values).
    nf["loci_not_covered"]: None when cover_degenerate=False (then nothing in nf["degenerate_loci"] was solved);
    otherwise a list of {"conditions": ["a == 0", "b*c - 1 == 0"], "why": "..."}: the parameter values (all
    conditions together) at which no list is claimed - excluded values without a substitution, beyond the depth
    or time limit, without a pole order, and the exclusions of locus certificates that no deeper locus covers.
    nf["loci_undefined"] (only when cover_degenerate=True and such values exist): conditions at which a
    coefficient of E has a pole (E is not defined there).
    Every 'assumed_nonzero' entry is written 'expr != 0'.  A certificate keeps the key 'unchecked' (ids) when a
    family of its form was not confirmed by the checks (status not-run); a family whose conditions have no
    parameter value where the normal form is defined is recorded in 'empty_where_defined' of its certificate.
    """
    depth = int(kw.pop("_depth", 0))
    from . import wsolve
    t0 = time.monotonic()
    try:
        red = reduce_equation(eq, time_budget=min(20.0, max(2.0, 0.2 * float(budget_s))))
    except NoGain as err:
        out = wsolve.find_w_solutions(eq, local, max_poles=max_poles, ends=ends, budget_s=budget_s, **kw)
        return _plain_result(out, err)
    params = red["params"]
    ctx = _Ctx()
    ctx.params = params
    ctx.alpha, ctx.beta, ctx.gamma = red["alpha"], red["beta"], red["gamma"]
    ctx.nsyms = list(red["symbols"])
    ctx.nsub = dict(red["symbols"])
    ctx.assumed = list(red["assumed_nonzero"])
    ctx.map_text = _map_text(red)
    ctx.nf_conditions = ["%s != 0" % sp.sstr(f) for f in ctx.assumed]
    ctx.rho, ctx.b0, ctx.rho_relation = red.get("rho"), red.get("rho_base"), red.get("rho_relation")
    ctx.undefined = list(red.get("undefined_factors") or [])
    red_eq = red["equation"]
    ends_red, ends_text = _ends_for(red_eq, ends, min(20.0, max(3.0, 0.15 * float(budget_s))))
    log = ["nfsolve: reduced equation %s = 0 with %s; %s" % (
        sp.sstr(red["E"]), ", ".join("%s = %s" % (s, sp.sstr(e)) for s, e in red["symbols"].items()) or
        "no parameters", ends_text)]
    left = max(5.0, float(budget_s) - (time.monotonic() - t0))
    res = wsolve.find_w_solutions(red_eq, local, max_poles=max_poles, ends=ends_red, budget_s=left, **kw)
    nf = {"map": ctx.map_text,
          "symbols": dict((str(s), sp.sstr(e)) for s, e in red["symbols"].items()),
          "conditions": list(ctx.nf_conditions),
          "reduced_equation": sp.sstr(red["E"]),
          "normal_form": sp.sstr(red["normal_form"]),
          "parameters": [str(q) for q in params],
          "radicals": dict((sp.sstr(b), int(q)) for b, q in red["radicals"].items()),
          "rho": None if ctx.rho is None else {"symbol": str(ctx.rho), "relation": sp.sstr(ctx.rho_relation),
                                              "base": sp.sstr(ctx.b0)},
          "warnings": red.get("warnings") or [],
          "ends": ends_text,
          "degenerate_loci": _degenerate_loci(ctx),
          "statement": ("for parameter values at which none of %s vanishes, w(z) = alpha*W(z/gamma) + beta is a "
                        "bijection between the solutions W of the reduced equation (n_i = their expressions) and "
                        "the solutions w of the equation, for every choice of the roots in alpha and gamma; it "
                        "preserves the kind, the number of poles in a period and their orders; nothing is "
                        "claimed at other parameter values" % (", ".join(sp.sstr(f) for f in ctx.assumed) or
                                                                "(no expression)"))}
    # transport the solutions
    sols, idmap, rejected_by_form, empty_by_form, status_of = [], {}, {}, {}, {}
    vbudget = min(60.0, max(10.0, 0.1 * float(budget_s)))
    vcap, vspent = max(60.0, float(budget_s)), 0.0       # total time of the checks on the original equation
    for s in res.get("solutions", []):
        try:
            news, why = _transport_solution(s, ctx)
        except Exception as err:
            news, why = [], "transport failed: %r" % (err,)
        if not news:
            if why.startswith("transport failed"):
                rejected_by_form.setdefault(s.get("id"), []).append({"reduced": s, "reason": why})
            else:
                # the family is empty at every parameter value where the normal form is defined
                empty_by_form.setdefault(s.get("id"), []).append({"reduced_id": s.get("id"),
                                                                  "conditions": s.get("conditions"), "why": why})
            log.append("nfsolve: family %s not transported: %s" % (s.get("id"), why))
            continue
        for s2 in news:
            s2["id"] = "s%d" % (len(sols) + 1)
            tv = time.monotonic()
            if vspent < vcap:
                st = _verify(eq, s2, min(vbudget, max(5.0, vcap - vspent)))
            else:
                s2["certificate"] = {"type": "substitution", "method": "symbolic", "status": "not-run",
                                     "detail": "not checked on the original equation: the time for the checks "
                                               "(%d s) was used up; run mero.verify.verify_solution(eq, sol)" % vcap}
                st = "not-run"
            vspent += time.monotonic() - tv
            if st == "fail" and "empty" in (s2["certificate"].get("detail") or ""):
                # the exact check says that no point satisfies the family's relations; decide it here with all
                # parameters as variables (mero.verify decides it for generic values of some of them only)
                if _inconsistent(*_cond_exprs(s2["conditions"], params), ctx=ctx):
                    empty_by_form.setdefault(s.get("id"), []).append(
                        {"reduced_id": s.get("id"), "conditions": s2["conditions"],
                         "why": "no parameter value: the conditions have no common solution where the normal form "
                                "is defined (Groebner basis over all parameters, with y*N - 1, is {1})"})
                    log.append("nfsolve: a transported family of %s is empty (no parameter value)" % s.get("id"))
                    continue
                s2["certificate"] = {"type": "substitution", "method": s2["certificate"].get("method", "symbolic"),
                                     "status": "not-run",
                                     "detail": "not decided: the exact check reported an empty family, but its "
                                               "parameter conditions are consistent (Groebner basis over all "
                                               "parameters is not {1}); check said: %s"
                                               % (s2["certificate"].get("detail") or "")[:300]}
                st = "not-run"
            if st == "fail":
                rejected_by_form.setdefault(s.get("id"), []).append(
                    {"solution": s2, "reason": "the check on the original equation failed: %s"
                                               % s2["certificate"].get("detail", "")[:300]})
                log.append("nfsolve: transported family of %s FAILED the check on the original equation"
                           % s.get("id"))
                continue
            sols.append(s2)
            status_of[s2["id"]] = s2["certificate"].get("status")
            idmap.setdefault(s.get("id"), []).append(s2["id"])

    def tr_assumed(lst):
        """the solver's assumptions in the original parameters, and those that cannot be transported (an
        assumption that vanishes identically on the parameter values: the certificate then applies nowhere)"""
        outl, bad_ = list(ctx.nf_conditions), []
        for a in lst or []:
            try:
                e = _S(str(a).split("!=")[0], ctx.nsyms).xreplace(ctx.nsub)
            except Exception:
                bad_.append("%s (could not be read)" % a)
                continue
            if _numer(e) == 0:
                bad_.append(str(a))
                continue
            for f in _irreducible_factors(e, params):
                c = "%s != 0" % sp.sstr(f)
                if c not in outl:
                    outl.append(c)
        return outl, bad_

    def tr_cert(c):
        c2 = dict(c)
        c2["nf"] = nf
        c2["statement"] = SENTENCE
        c2["parameters_reduced"] = c.get("parameters")
        c2["parameters"] = [str(q) for q in params]
        c2["assumed_nonzero_reduced"] = c.get("assumed_nonzero")
        c2["assumed_nonzero"], bad_ = tr_assumed(c.get("assumed_nonzero"))
        if bad_:
            c2["withdrawn"] = ("the solver's assumption(s) %s vanish identically on the parameter values of this "
                               "equation: the statement of this form applies nowhere and is withdrawn"
                               % ", ".join("%s != 0" % b_ for b_ in bad_))
        c2["solutions_reduced"] = c.get("solutions")
        c2["solutions"] = [i for sid in c.get("solutions") or [] for i in idmap.get(sid, [])]
        unchecked = [i for i in c2["solutions"] if status_of.get(i) != "pass"]
        if unchecked:
            c2["unchecked"] = unchecked
        empty = [e for sid in c.get("solutions") or [] for e in empty_by_form.get(sid, [])]
        if empty:
            c2["empty_where_defined"] = empty
        c2["scope"] = (c.get("scope") or "") + "; " + SENTENCE + "; parameter values at which one of %s vanishes " \
            "are not covered" % ", ".join(c2["assumed_nonzero"])
        return c2

    certs, incomplete = [], []
    for c in res.get("certificates", []):
        bad = [r for sid in c.get("solutions") or [] for r in rejected_by_form.get(sid, [])]
        c2 = tr_cert(c)
        hw = _not_examined(c)
        if c2.get("withdrawn"):
            c2["reason"] = c2.pop("withdrawn")
            incomplete.append(c2)
            continue
        if hw:
            # the external solver worked over Q(free variables) only: the list is not complete at special values
            c2["reason"] = ("mero.heavy reported '%s': the list of this form holds for generic parameter values "
                            "only and is not certified" % hw[0])
            incomplete.append(c2)
            continue
        if bad:
            c2["rejected"] = bad
            c2["reason"] = ("%d transported cases were not confirmed on the original equation: the list of this "
                            "form is not certified" % len(bad))
            incomplete.append(c2)
        else:
            certs.append(c2)
    for c in res.get("incomplete", []):
        c2 = tr_cert(c)
        c2.pop("withdrawn", None)
        bad = [r for sid in c.get("solutions") or [] for r in rejected_by_form.get(sid, [])]
        if bad:
            c2["rejected"] = list(c2.get("rejected") or []) + bad
        incomplete.append(c2)
    log.extend(res.get("log", []))
    if cover_degenerate:
        _cover_loci(eq, params, nf, ctx, sols, certs, incomplete, log, depth, t0, budget_s, max_poles, kw)
    log.append("nfsolve total %.2f s" % (time.monotonic() - t0))
    return {"solutions": sols, "certificates": certs, "incomplete": incomplete, "log": log, "nf": nf,
            "nf_note": "solved in the normal form (%d parameters instead of %d)" % (len(ctx.nsyms), len(params))}
