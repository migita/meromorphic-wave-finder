"""Profiles of `mero.report.analyze` for the batch runner (tools/project script --analyze mero.profiles:<name>).

full    everything, as on the heavy site
lean    no special loci, no invariant surfaces, no changes of variable, one pole only: for equations on which the
        full analysis does not finish
local   local analysis, theorems and constants only
"""
from mero import report


def full(text, mode="heavy", budget_s=120, **kw):
    return report.analyze(text, mode=mode, budget_s=budget_s, **kw)


def lean(text, mode="heavy", budget_s=60, **kw):
    r = report.analyze(text, mode=mode, budget_s=budget_s, strata=False, darboux=False, twist=False,
                       substitutions=False, max_poles=1, **kw)
    r.setdefault("warnings", []).append("reduced analysis: special parameter loci, invariant surfaces and changes "
                                        "of variable were not examined (the full analysis did not finish)")
    return r


def local(text, mode="heavy", budget_s=30, **kw):
    import mero.report as R
    saved = R._mod

    def only(name):
        return saved(name) if name in ("parse", "pde", "laurent", "classes", "equation", "transform") else None
    R._mod = only
    try:
        r = R.analyze(text, mode=mode, budget_s=budget_s, strata=False, darboux=False, twist=False,
                      substitutions=False, atlas=False, **kw)
    finally:
        R._mod = saved
    r.setdefault("warnings", []).append("local analysis and theorems only: the search for solutions did not finish "
                                        "on this equation")
    return r
