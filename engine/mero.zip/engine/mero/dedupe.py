"""mero.dedupe -- when do two listed solutions denote the same family of functions?

A listed solution (project note section 2) denotes a set of functions: one function of z for every point of the
parameter locus given by its `conditions`, every value of its free constants (the translation constant z0
included) and every admissible root of the constants given as "any root of P = 0".  This module compares such
sets numerically, with safeguards:

* parameter points on a locus: random rationals for the independent parameters, every root for the dependent ones
  (equalities solved one parameter at a time; direct substitution for "parameter == expression");
* evaluation with mpmath at `digits + 20` digits; wp, wpp, zeta_w are evaluated here (Laurent series near 0 and the
  duplication formulas; ill-conditioned points are refused);
* family A is contained in family B if, for random values of A's constants, B's constants and translation can be
  solved for (Levenberg-Marquardt / Newton from several starting points) so that the two functions agree at further
  random points to 10^(-digits+8) relative accuracy, at two independent parameter points; a deliberately perturbed
  function must then fail the same test (self-check).

Floating point is used here only to decide which items of a list repeat others; nothing in this module certifies a
solution.  The answers err on the safe side: an item is dropped only after a containment was found and checked, and
any failure of the evaluation gives "undecided".

Public functions: same_family, copies, same_lists.
"""

import itertools
import random
import re
import time

import mpmath
import sympy as sp

__all__ = ["same_family", "copies", "same_lists"]

_KNOWN_FUNCS = {"wp", "wpp", "zeta_w", "exp", "sqrt", "log", "sin", "cos", "tan", "cot", "sinh", "cosh", "tanh",
                "coth", "sech", "csch", "sec", "csc", "I", "pi", "E", "Abs", "atan", "asin", "acos", "Rational",
                "Integer", "Float"}
_PY_KEYWORDS = {"lambda", "is", "in", "as", "if", "or", "and", "not", "def", "del", "for", "from", "global", "with",
                "yield", "class", "pass", "else", "elif", "try", "while", "return", "import", "None", "True",
                "False", "break", "continue", "raise", "assert", "except", "finally", "nonlocal", "async", "await"}
_TRANSLATION = ("z0", "z_0")
_WPF = sp.Function("wp")
_WPPF = sp.Function("wpp")
_ZETAF = sp.Function("zeta_w")


class _Fail(Exception):
    """an evaluation that cannot be trusted (ill-conditioned point, division by zero, unreadable input)"""


class _Deadline(Exception):
    pass


# ---------------------------------------------------------------------------------------------------------------
# Weierstrass functions: Laurent series at 0 and duplication
# ---------------------------------------------------------------------------------------------------------------

_COEFF_CACHE = {}


def _wp_coeffs(g2, g3, N):
    key = (mpmath.mp.prec, N, complex(g2), complex(g3), str(g2), str(g3))
    c = _COEFF_CACHE.get(key)
    if c is not None:
        return c
    c = [mpmath.mpc(0)] * (N + 1)
    if N >= 2:
        c[2] = g2 / 20
    if N >= 3:
        c[3] = g3 / 28
    for k in range(4, N + 1):
        s = mpmath.mpc(0)
        for m in range(2, k - 1):
            s += c[m] * c[k - m]
        c[k] = 3 * s / ((2 * k + 1) * (k - 3))
    if len(_COEFF_CACHE) > 400:
        _COEFF_CACHE.clear()
    _COEFF_CACHE[key] = c
    return c


def _weier(u, g2, g3):
    """(wp(u), wp'(u), zeta(u)) for the invariants g2, g3 at the current precision"""
    u = mpmath.mpmathify(u)
    g2 = mpmath.mpmathify(g2)
    g3 = mpmath.mpmathify(g3)
    if u == 0:
        raise _Fail("wp at a pole")
    dps = mpmath.mp.dps
    N = max(12, int(dps * 0.9) + 8)
    c = _wp_coeffs(g2, g3, N)
    # growth rate of the coefficients: about 1/(smallest lattice vector)^2
    r = mpmath.mpf(0)
    for k in range(2, N + 1):
        if c[k] != 0:
            r = max(r, abs(c[k]) ** (mpmath.mpf(1) / (k - 1)))
    rho = mpmath.sqrt(r) if r > 0 else mpmath.mpf(0)
    n = 0
    us = u
    target = mpmath.mpf("0.2")
    while rho * abs(us) > target:
        us = us / 2
        n += 1
        if n > 200:
            raise _Fail("wp: argument reduction")
    u2 = us * us
    x = 1 / u2
    y = -2 / (u2 * us)
    zt = 1 / us
    p = mpmath.mpc(1)          # us^(2k-2)
    for k in range(2, N + 1):
        p *= u2
        ck = c[k]
        x += ck * p
        y += (2 * k - 2) * ck * p / us
        zt -= ck * p * us / (2 * k - 1)
    for _ in range(n):
        scale = abs(x) ** 1.5 + abs(g2) ** 0.75 + abs(g3) ** 0.5 + 1
        if abs(y) < mpmath.mpf(10) ** (-(dps // 3)) * scale:
            raise _Fail("wp: duplication near a half period")
        lam = (6 * x * x - g2 / 2) / y
        x2 = lam * lam / 4 - 2 * x
        y2 = -(lam * (x2 - x) + y)
        zt = 2 * zt + lam / 2
        x, y = x2, y2
    return x, y, zt


def wp_mp(u, g2, g3):
    return _weier(u, g2, g3)[0]


def wpp_mp(u, g2, g3):
    return _weier(u, g2, g3)[1]


def zeta_mp(u, g2, g3):
    return _weier(u, g2, g3)[2]


_MODULES = [{"wp": wp_mp, "wpp": wpp_mp, "zeta_w": zeta_mp}, "mpmath"]


# ---------------------------------------------------------------------------------------------------------------
# reading an item
# ---------------------------------------------------------------------------------------------------------------

def _fix_kw(text):
    return re.sub(r"\b([A-Za-z_][A-Za-z_0-9]*)\b",
                  lambda m: m.group(1) + "_kw" if m.group(1) in _PY_KEYWORDS else m.group(1), str(text))


def _sym(name):
    name = str(name)
    return sp.Symbol(name + "_kw" if name in _PY_KEYWORDS else name)


def _parse(text, loc):
    text = _fix_kw(text)
    names = set(re.findall(r"[A-Za-z_][A-Za-z_0-9]*", text))
    l2 = dict(loc)
    for n in names:
        if n not in l2 and n not in _KNOWN_FUNCS:
            l2[n] = sp.Symbol(n)
    l2["wp"] = _WPF
    l2["wpp"] = _WPPF
    l2["zeta_w"] = _ZETAF
    e = sp.sympify(text, locals=l2)
    if not isinstance(e, sp.Expr):
        raise _Fail("not an expression: %s" % text[:80])
    return e


def _split_cond(c):
    c = str(c)
    for op in ("==", "!="):
        if op in c:
            a, b = c.split(op, 1)
            return op, a, b
    return None, None, None


class _Prepared(object):
    pass


_PREP_CACHE = {}


def _prepare(item, param_names):
    """read a Solution dict; returns a _Prepared with .ok False and .why if the item cannot be compared"""
    import json
    key = (json.dumps(item, sort_keys=True, default=str), tuple(param_names))
    if key in _PREP_CACHE:
        return _PREP_CACHE[key]
    P = _Prepared()
    P.ok = False
    P.why = ""
    P.id = item.get("id")
    P.kind = item.get("kind")
    try:
        _prepare_inner(P, item, param_names)
        P.ok = True
    except _Fail as exc:
        P.why = str(exc)
    except Exception as exc:                                  # unreadable input: the item is not compared
        P.why = "unreadable: %s" % str(exc)[:160]
    if len(_PREP_CACHE) > 2000:
        _PREP_CACHE.clear()
    _PREP_CACHE[key] = P
    return P


def _prepare_inner(P, item, param_names):
    params = [_sym(n) for n in param_names]
    z = sp.Symbol("z")
    loc = dict((str(q), q) for q in params)
    loc["z"] = z
    expr_text = item.get("expr")
    if expr_text is None or str(expr_text).strip() == "":
        raise _Fail("no expression")
    if re.search(r"RootOf|CRootOf|Integral|Derivative|hyper|besselj|airy", str(expr_text)):
        raise _Fail("implicit or special function in the expression")
    consts = item.get("constants") or {}
    if not isinstance(consts, dict):
        consts = {}
    declared_free = set(str(n) for n in (item.get("free") or []))
    values, roots = {}, {}
    word_neqs, unread = [], []
    for k, v in consts.items():
        ks = str(k)
        if ks in loc and ks != "z":
            raise _Fail("constant named like a parameter: %s" % ks)
        s = str(v).strip()
        low = s.lower()
        if low.startswith(("free", "arbitrary")):
            declared_free.add(ks)
            # restrictions written into the description: "nonzero", "h != 1/7, h != 0"
            if re.search(r"\bnon-?zero\b", low):
                word_neqs.append("%s != 0" % ks)
            rest = re.sub(r"^(free|arbitrary)\b[^;,]*", "", s, flags=re.I)
            for part in re.split(r"[;,]|\band\b", rest):
                part = part.strip()
                if not part or re.match(r"^(non-?zero|the value of the first integral|first-integral constant)"
                                        r"[ .()a-z-]*$", part.lower()):
                    continue
                m = re.match(r"^([A-Za-z_][A-Za-z_0-9]*)\s*!=\s*([-+0-9A-Za-z_*/(). ]+)$", part)
                if m and not re.search(r"[A-Za-z]{3,}", m.group(2).replace("sqrt", "")):
                    word_neqs.append("%s != %s" % (m.group(1), m.group(2)))
                elif "!=" in part or "<" in part or ">" in part or \
                        re.search(r"\bnot\b|\bexcept\b|\bexclud|\bunless\b", part.lower()):
                    unread.append(part)      # a restriction that is not read (explanations with '=' are not restrictions)
            continue
        m = re.match(r"^(?:any|a|one)\s+(?:root|zero)s?\s+of\s+(.*)$", s, re.I | re.S)
        if m:
            t = m.group(1).strip().rstrip(".")
            t = re.sub(r"\s*(?:==|=)\s*0\s*$", "", t)
            if "=" in t:
                lhs, rhs = t.split("==", 1) if "==" in t else t.split("=", 1)
                t = "(%s) - (%s)" % (lhs, rhs)
            roots[ks] = t
            continue
        if not re.match(r"^[-+0-9A-Za-z_*/(). ]+$", s):
            raise _Fail("a constant given in words: %s = %s" % (ks, s[:60]))
        values[ks] = s
    csym = dict((k, _sym(k)) for k in list(values) + list(roots) + list(declared_free))
    loc2 = dict(loc)
    loc2.update(csym)
    expr = _parse(expr_text, loc2)
    val_e = dict((csym[k], _parse(v, loc2)) for k, v in values.items())
    root_e = dict((csym[k], _parse(v, loc2)) for k, v in roots.items())
    # substitute the constants given by formulas (they may refer to each other and to the roots)
    for _ in range(8):
        hit = [s for s in val_e if s in expr.free_symbols]
        if not hit:
            break
        expr = expr.subs(dict((s, val_e[s]) for s in hit))
    if any(s in expr.free_symbols for s in val_e):
        raise _Fail("constants defined in a cycle")
    for r in list(root_e):
        e = root_e[r]
        for _ in range(8):
            hit = [s for s in val_e if s in e.free_symbols]
            if not hit:
                break
            e = e.subs(dict((s, val_e[s]) for s in hit))
        root_e[r] = e
    # conditions: on the parameters, or on free constants of the family
    eqs, neqs, fam_eqs, fam_neqs = [], [], [], []
    free_names = set(declared_free)
    for c in list(item.get("conditions") or []) + word_neqs:
        op, a, b = _split_cond(c)
        if op is None:
            raise _Fail("condition not of the form == / !=: %s" % str(c)[:80])
        g = _parse("(%s) - (%s)" % (a, b), loc2)
        for _ in range(8):
            hit = [s for s in val_e if s in g.free_symbols]
            if not hit:
                break
            g = g.subs(dict((s, val_e[s]) for s in hit))
        other = g.free_symbols - set(params)
        if other & set(root_e):
            raise _Fail("a condition on a constant given as a root")
        if other - set(csym.get(n, _sym(n)) for n in free_names) - {z}:
            # a symbol that is neither a parameter nor a constant of the item: read it as a free constant only if
            # the item declares it free
            unknown = sorted(str(s) for s in other - set(csym.values()))
            if unknown:
                raise _Fail("condition with unknown symbols %s" % unknown)
        if other:
            (fam_eqs if op == "==" else fam_neqs).append(g)
        else:
            (eqs if op == "==" else neqs).append(g)
    # equalities on free constants: only "constant == expression in the parameters" is read
    for g in fam_eqs:
        syms = [s for s in g.free_symbols if s not in params]
        if len(syms) != 1:
            raise _Fail("an equality between free constants")
        s = syms[0]
        sol = sp.solve(g, s)
        if len(sol) != 1:
            raise _Fail("an equality on a free constant with several solutions")
        expr = expr.subs(s, sol[0])
        fam_neqs = [h.subs(s, sol[0]) for h in fam_neqs]
        free_names.discard(str(s))
    # every remaining symbol of the expression must be a parameter, z, a root or a free constant
    fs = expr.free_symbols - set(params) - {z}
    free_syms = []
    for s in sorted(fs, key=str):
        n = str(s)
        if s in root_e:
            continue
        if n in free_names or n in _TRANSLATION:
            free_syms.append(s)
            continue
        raise _Fail("symbol %s is neither a parameter nor a declared constant" % n)
    # roots: polynomials in their own symbol, ordered by dependence
    order, pending = [], dict(root_e)
    for _ in range(len(root_e) + 1):
        for r, e in list(pending.items()):
            deps = (e.free_symbols - {r}) & set(root_e)
            if deps <= set(order):
                order.append(r)
                del pending[r]
        if not pending:
            break
    if pending:
        raise _Fail("roots defined in a cycle")
    used_roots = set()
    todo = [s for s in expr.free_symbols if s in root_e]
    while todo:
        r = todo.pop()
        if r in used_roots:
            continue
        used_roots.add(r)
        todo.extend(s for s in root_e[r].free_symbols if s in root_e and s not in used_roots)
    for g in fam_neqs:
        used_roots |= set(s for s in g.free_symbols if s in root_e)
    order = [r for r in order if r in used_roots]
    for s in free_syms:
        for r in order:
            if s in root_e[r].free_symbols:
                raise _Fail("a root depends on a free constant")
    # relations among the constants: they must not constrain a free constant
    for rel in item.get("relations") or []:
        try:
            g = _parse(rel, loc2)
        except Exception:
            raise _Fail("unreadable relation")
        if g.free_symbols & set(free_syms):
            raise _Fail("a relation constrains a free constant")
    root_polys = []
    prev = []
    for r in order:
        e = sp.together(root_e[r])
        num = sp.numer(e)
        if not num.is_polynomial(r):
            raise _Fail("a root of a non-polynomial equation")
        poly = sp.Poly(sp.expand(num), r)
        if poly.degree() < 1 or poly.degree() > 6:
            raise _Fail("a root of an equation of degree %s" % poly.degree())
        cl = [sp.lambdify(params + prev, co, modules="mpmath", dummify=True) for co in poly.all_coeffs()]
        root_polys.append((r, cl))
        prev = prev + [r]
    P.params = params
    P.z = z
    P.expr = expr
    P.free = free_syms
    P.roots = root_polys
    P.root_syms = list(order)
    P.root_exprs = dict((r, root_e[r]) for r in order)
    P.conds_written = [str(c) for c in (item.get("conditions") or [])]
    P.param_names = [str(n) for n in param_names]
    P.eqs = eqs
    P.neqs = neqs
    P.fam_neqs = fam_neqs
    P.nconds = len(item.get("conditions") or [])
    P.expr_len = len(str(expr_text))
    args = [z] + params + P.root_syms + free_syms
    P.f = sp.lambdify(args, expr, modules=_MODULES, dummify=True)
    P.fam_neq_f = [sp.lambdify(params + P.root_syms + free_syms, g, modules="mpmath", dummify=True)
                   for g in fam_neqs]
    P.translation = [s for s in free_syms if str(s) in _TRANSLATION]
    # restrictions on the free constants (a measure-zero set of members is excluded); a restriction written in
    # words that is not read makes the item unusable as a container
    P.unread = list(unread)
    P.fam_sig = frozenset(sp.srepr(sp.expand(g)) for g in fam_neqs)
    P.elliptic = bool(expr.atoms(_WPF, _WPPF, _ZETAF))


# ---------------------------------------------------------------------------------------------------------------
# numbers
# ---------------------------------------------------------------------------------------------------------------

def _rnd_rational(rnd):
    """a random rational, not an integer (small integers are the usual special values of parameters)"""
    for _ in range(50):
        p, q = rnd.randint(2, 300), rnd.randint(3, 97)
        if p % q:
            break
    return sp.Rational(p, q) * rnd.choice([1, -1])


def _close(a, b, tol):
    return abs(a - b) <= tol * (1 + abs(a) + abs(b))


def _num(e, pt):
    """value of a SymPy expression (in the parameters) at a point {Symbol: mpc}"""
    f = sp.lambdify(list(pt.keys()), e, modules="mpmath", dummify=True)
    return mpmath.mpc(f(*list(pt.values())))


_LAMBDA_CACHE = {}


def _lam(e, syms):
    key = (sp.srepr(e), tuple(str(s) for s in syms))
    f = _LAMBDA_CACHE.get(key)
    if f is None:
        f = sp.lambdify(list(syms), e, modules="mpmath", dummify=True)
        if len(_LAMBDA_CACHE) > 3000:
            _LAMBDA_CACHE.clear()
        _LAMBDA_CACHE[key] = f
    return f


def _val(e, pt):
    syms = list(pt.keys())
    try:
        return mpmath.mpc(_lam(e, syms)(*[pt[s] for s in syms]))
    except (ZeroDivisionError, ValueError, OverflowError, TypeError) as exc:
        raise _Fail("evaluation of a condition: %s" % str(exc)[:60])


# ---------------------------------------------------------------------------------------------------------------
# parameter points on a locus
# ---------------------------------------------------------------------------------------------------------------

_MAX_COMPONENTS = 16


def _locus_points(eqs, params, rnd, draws, deadline, complex_draw=False):
    """points of V(eqs), on every component: an equality whose numerator factors (a*b == 0) is split into its
    irreducible factors, and every choice of one factor per equality is sampled separately (at most 16 choices,
    otherwise the answer is incomplete).  Each point carries "_comp" (the choice) and "_draw".  Returns
    (points, complete); complete is False if some equation could not be solved for all of its roots or there are
    too many choices (then the points may miss components)."""
    eqs = [sp.numer(sp.together(g)) for g in eqs]
    eqs = [g for g in eqs if g != 0]
    fac_lists = []
    for g in eqs:
        fl = _factors(g)
        uniq = []
        for f in fl:
            if not any(sp.expand(f - h) == 0 or sp.expand(f + h) == 0 for h in uniq):
                uniq.append(f)
        fac_lists.append(uniq or [g])
    n_comb = 1
    for fl in fac_lists:
        n_comb *= len(fl)
    if n_comb > _MAX_COMPONENTS:
        return [], False
    out, complete = [], True
    for ci, combo in enumerate(itertools.product(*fac_lists) if fac_lists else [()]):
        pts, comp = _locus_points_one(list(combo), params, rnd, draws, deadline, complex_draw)
        complete = complete and comp
        for pt in pts:
            pt["_comp"] = ci
        out.extend(pts)
    return out, complete


def _locus_points_one(eqs, params, rnd, draws, deadline, complex_draw=False):
    """points of V(eqs) for equations that are not split further (one component per choice of factors)"""
    eqs = [g for g in eqs if g != 0]
    plan = []                                   # (equation, dependent parameter)
    dependent = []
    for g in eqs:
        cand = [q for q in params if q in g.free_symbols and q not in dependent]
        if not cand:
            plan.append((g, None))                # a check only
            continue

        def deg(q):
            try:
                return sp.Poly(g, q).degree() if g.is_polynomial(q) else 99
            except Exception:
                return 99
        cand.sort(key=lambda q: (deg(q), str(q)))
        plan.append((g, cand[0]))
        dependent.append(cand[0])
    indep = [q for q in params if q not in dependent]
    # solve in an order in which every equation, when reached, has only its dependent parameter unknown
    ordered, known = [], set(indep)
    rest = list(plan)
    for _ in range(len(plan) + 1):
        for item in list(rest):
            g, q = item
            others = g.free_symbols & set(params)
            if q is None:
                if others <= known:
                    ordered.append(item)
                    rest.remove(item)
            elif (others - {q}) <= known:
                ordered.append(item)
                rest.remove(item)
                known.add(q)
        if not rest:
            break
    if rest:
        return [], False
    complete = True
    out = []
    for d in range(draws):
        if time.time() > deadline:
            raise _Deadline()
        base = {}
        for q in indep:
            v = _rnd_rational(rnd)
            re_v = mpmath.mpf(v.p) / v.q
            im_v = mpmath.mpf(0)
            if complex_draw and d == draws - 1:
                w = _rnd_rational(rnd)
                im_v = mpmath.mpf(w.p) / w.q
            base[q] = mpmath.mpc(re_v, im_v)
        partial = [dict(base)]
        for g, q in ordered:
            nxt = []
            for pt in partial:
                if q is None:
                    try:
                        val = _val(g, dict((s, pt[s]) for s in g.free_symbols & set(params)))
                    except Exception:
                        continue
                    scale = _scale(g, pt, params)
                    if abs(val) <= mpmath.mpf(10) ** (-(mpmath.mp.dps - 12)) * scale:
                        nxt.append(pt)
                    continue
                try:
                    rts, comp = _solve_one(g, q, pt, params)
                except _Fail:
                    rts, comp = [], False
                complete = complete and comp
                for r in rts:
                    p2 = dict(pt)
                    p2[q] = r
                    nxt.append(p2)
            partial = nxt[:24]
        for pt in partial:
            pt["_draw"] = d
        out.extend(partial)
    return out, complete


_TERMS_CACHE = {}


def _scale(g, pt, params):
    """size of the terms of g at pt (for a relative zero test)"""
    try:
        key = sp.srepr(g)
        terms = _TERMS_CACHE.get(key)
        if terms is None:
            terms = sp.Add.make_args(sp.expand(g))
            if len(_TERMS_CACHE) > 2000:
                _TERMS_CACHE.clear()
            _TERMS_CACHE[key] = terms
        s = mpmath.mpf(1)
        for t in terms[:200]:
            s += abs(_val(t, dict((q, pt[q]) for q in t.free_symbols & set(params))))
        return s
    except Exception:
        return mpmath.mpf(1)


def _solve_one(g, q, pt, params):
    """all roots in q of g(pt, q) = 0; (roots, complete)"""
    others = sorted(g.free_symbols & set(params) - {q}, key=str)
    sub = dict((s, pt[s]) for s in others)
    if g.is_polynomial(q):
        poly = sp.Poly(g, q)
        coeffs = []
        for co in poly.all_coeffs():
            # numeric coefficients (sqrt(2), ...) at the working precision, never through a Python float
            coeffs.append(_val(co, dict((s, sub[s]) for s in co.free_symbols & set(others))) if co.free_symbols
                          else mpmath.mpc(mpmath.mpf(co.p) / co.q) if co.is_Rational else _val(co, {}))
        while coeffs and abs(coeffs[0]) < mpmath.mpf(10) ** (-(mpmath.mp.dps - 10)) * \
                (1 + max(abs(c) for c in coeffs)):
            coeffs = coeffs[1:]
        if len(coeffs) <= 1:
            return [], True
        if len(coeffs) == 2:
            return [-coeffs[1] / coeffs[0]], True
        if len(coeffs) > 13:
            return [], False
        try:
            rts = mpmath.polyroots(coeffs, maxsteps=200, extraprec=2 * mpmath.mp.prec)
        except Exception:
            return [], False
        return [mpmath.mpc(r) for r in rts], True
    # not polynomial in q: Newton from several starts, distinct roots
    f = _lam(g, others + [q])
    found = []
    rnd = random.Random(5)
    for _ in range(12):
        x0 = mpmath.mpc(rnd.uniform(-3, 3), rnd.uniform(-1, 1))
        try:
            r = mpmath.findroot(lambda x: f(*([sub[s] for s in others] + [x])), x0)
        except Exception:
            continue
        if all(abs(r - s) > mpmath.mpf(10) ** (-10) for s in found):
            found.append(mpmath.mpc(r))
    return found, False


def _holds(g, pt, params):
    """g == 0 at pt (relative to the size of its terms)"""
    val = _val(g, dict((s, pt[s]) for s in g.free_symbols & set(params)))
    return abs(val) <= mpmath.mpf(10) ** (-(mpmath.mp.dps - 14)) * _scale(g, pt, params)


# ---------------------------------------------------------------------------------------------------------------
# loci
# ---------------------------------------------------------------------------------------------------------------

_FACTOR_CACHE = {}


def _factors(g):
    key = sp.srepr(g)
    out = _FACTOR_CACHE.get(key)
    if out is None:
        try:
            _c, fl = sp.factor_list(sp.numer(sp.together(g)))
            out = [f for f, _m in fl if f.free_symbols]
        except Exception:
            out = [g]
        _FACTOR_CACHE[key] = out
    return out


def _locus_in(A, B, ptsA):
    """is the locus of A contained in that of B?  True / False / None, decided at the points of A's locus (all
    roots of the dependent parameters); inequalities of B must follow from those of A factor by factor"""
    try:
        with mpmath.workdps(max(60, mpmath.mp.dps)):
            return _locus_in_inner(A, B, ptsA)
    except _Fail:
        return None


def _locus_in_inner(A, B, ptsA):
    params = A.params
    if not ptsA:
        return None
    for g in B.eqs:
        for pt in ptsA:
            if not _holds(g, pt, params):
                return False
    afac = []
    for h in A.neqs:
        afac.extend(_factors(h))
    for g in B.neqs:
        for f in _factors(g):
            vals = [_val(f, dict((s, pt[s]) for s in f.free_symbols & set(params))) for pt in ptsA]
            scales = [_scale(f, pt, params) for pt in ptsA]
            tiny = [abs(v) <= mpmath.mpf(10) ** (-(mpmath.mp.dps - 14)) * sc for v, sc in zip(vals, scales)]
            if all(tiny):
                return False                        # B's inequality fails on A's locus
            if any(abs(v) <= mpmath.mpf(10) ** -15 * sc for v, sc in zip(vals, scales)):
                return None                         # too close to zero to be called nonzero: no decision
            draws = set(pt.get("_draw") for pt in ptsA)
            if len(ptsA) >= 3 and len(draws) >= 2 and not any(tiny) and \
                    all(_close(v, vals[0], mpmath.mpf(10) ** -25) for v in vals):
                continue                            # a nonzero constant on A's locus
            ok = False
            # f restricted to A's locus is a nonzero constant times a product of powers of A's inequality factors
            # (then it vanishes only where an inequality of A fails)
            hvs = []
            for h in afac:
                hv = [_val(h, dict((s, pt[s]) for s in h.free_symbols & set(params))) for pt in ptsA]
                if not any(abs(x) == 0 for x in hv):
                    hvs.append(hv)
            monos = [[(k, m)] for k in range(len(hvs)) for m in range(1, 9)]
            monos += [[(k1, m1), (k2, m2)] for k1 in range(len(hvs)) for k2 in range(k1 + 1, len(hvs))
                      for m1 in range(1, 5) for m2 in range(1, 5)]
            for mono in monos[:400]:
                den = [mpmath.mpc(1)] * len(ptsA)
                for k, m in mono:
                    den = [x * hvs[k][t] ** m for t, x in enumerate(den)]
                rat = [v / x for v, x in zip(vals, den)]
                if len(ptsA) >= 3 and len(draws) >= 2 and \
                        all(_close(r, rat[0], mpmath.mpf(10) ** -25) for r in rat) and abs(rat[0]) > mpmath.mpf(10) ** -20:
                    ok = True
                    break
            if not ok:
                return False
    return True


def _in_locus(B, pt):
    """B's conditions hold at the point (numerically)"""
    params = B.params
    for g in B.eqs:
        if not _holds(g, pt, params):
            return False
    for g in B.neqs:
        if _holds(g, pt, params):
            return False
    return True


# ---------------------------------------------------------------------------------------------------------------
# evaluation of an item at a parameter point
# ---------------------------------------------------------------------------------------------------------------

def _branches(A, pt):
    """the values of A's root constants at the parameter point: list of tuples (one per admissible root
    combination)"""
    pv = [pt[q] for q in A.params]
    combos = [[]]
    for r, cl in A.roots:
        nxt = []
        for cb in combos:
            try:
                coeffs = [mpmath.mpc(f(*(pv + cb))) for f in cl]
            except (ZeroDivisionError, ValueError, OverflowError, TypeError):
                raise _Fail("the equation of a constant cannot be evaluated")
            big = 1 + max(abs(c) for c in coeffs)
            while coeffs and abs(coeffs[0]) < mpmath.mpf(10) ** (-(mpmath.mp.dps - 10)) * big:
                coeffs = coeffs[1:]
            if len(coeffs) <= 1:
                continue
            if len(coeffs) == 2:
                rts = [-coeffs[1] / coeffs[0]]
            else:
                try:
                    rts = mpmath.polyroots(coeffs, maxsteps=200, extraprec=2 * mpmath.mp.prec)
                except Exception:
                    raise _Fail("roots of a constant's equation")
            uniq = []
            for x in rts:
                x = mpmath.mpc(x)
                if all(not _close(x, y, mpmath.mpf(10) ** -15) for y in uniq):
                    uniq.append(x)
            for x in uniq:
                nxt.append(cb + [x])
        combos = nxt[:36]
    return [tuple(c) for c in combos]


def _evalf(A, pt, br, fv, zval):
    try:
        v = A.f(zval, *([pt[q] for q in A.params] + list(br) + list(fv)))
        v = mpmath.mpc(v)
    except (ZeroDivisionError, ValueError, OverflowError, TypeError, _Fail) as exc:
        raise _Fail("evaluation: %s" % str(exc)[:80])
    if not (mpmath.isfinite(v.real) and mpmath.isfinite(v.imag)):
        raise _Fail("evaluation: not finite")
    return v


def _fam_ok(A, pt, br, fv):
    """the inequalities on A's free constants hold"""
    args = [pt[q] for q in A.params] + list(br) + list(fv)
    for f in A.fam_neq_f:
        try:
            v = mpmath.mpc(f(*args))
        except Exception:
            return False
        if abs(v) <= mpmath.mpf(10) ** (-12) * (1 + max([abs(x) for x in args] + [0])):
            return False
    return True


def _rnd_point_z(rnd):
    return mpmath.mpc(rnd.uniform(-1.1, 1.1), rnd.uniform(-1.1, 1.1))


def _sample_zs(A, pt, br, fv, rnd, n, dps):
    """n sample points z at which A's function is finite and well conditioned"""
    zs, vals = [], []
    tries = 0
    while len(zs) < n:
        tries += 1
        if tries > 6 * n + 20:
            raise _Fail("no regular sample points")
        zv = _rnd_point_z(rnd)
        try:
            with mpmath.workdps(dps):
                v = _evalf(A, pt, br, fv, zv)
        except _Fail:
            continue
        if abs(v) > mpmath.mpf(10) ** 25:
            continue
        zs.append(zv)
        vals.append(v)
    return zs, vals


# ---------------------------------------------------------------------------------------------------------------
# matching one function against a family (Levenberg-Marquardt)
# ---------------------------------------------------------------------------------------------------------------

def _lm(res, x0, deadline, tol, maxit=60):
    x = [mpmath.mpc(v) for v in x0]
    try:
        r = res(x)
    except _Fail:
        return None, None
    nr = mpmath.norm(r)
    mu = mpmath.mpf("1e-3")
    n = len(x)
    if n == 0:
        return x, nr
    h0 = mpmath.mpf(10) ** (-(mpmath.mp.dps * 2 // 5))
    for it in range(maxit):
        if time.time() > deadline:
            raise _Deadline()
        if nr < tol:
            return x, nr
        if it == 20 and nr > mpmath.mpf(10) ** -4:
            return x, nr                              # no convergence from this start
        cols = []
        for j in range(n):
            h = h0 * (1 + abs(x[j]))
            xj = list(x)
            xj[j] += h
            try:
                rj = res(xj)
            except _Fail:
                return x, nr
            cols.append([(rj[i] - r[i]) / h for i in range(len(r))])
        m = len(r)
        J = mpmath.matrix(m, n)
        for i in range(m):
            for j in range(n):
                J[i, j] = cols[j][i]
        JH = J.H
        A = JH * J
        g = JH * mpmath.matrix(r)
        improved = False
        for _k in range(14):
            M = A.copy()
            for j in range(n):
                M[j, j] += mu * (abs(A[j, j]) + 1)
            try:
                dx = mpmath.lu_solve(M, -g)
            except (ZeroDivisionError, ValueError):
                mu *= 10
                continue
            xn = [x[j] + dx[j] for j in range(n)]
            try:
                rn = res(xn)
                nrn = mpmath.norm(rn)
            except _Fail:
                mu *= 10
                continue
            if nrn < nr:
                x, r, nr = xn, rn, nrn
                mu = max(mu / 10, mpmath.mpf(10) ** (-(mpmath.mp.dps)))
                improved = True
                break
            mu *= 10
        if not improved:
            break
    return x, nr


def _match_one(B, pt, fa, zs, zv_extra, fa_extra, x_starts, deadline, digits, low_dps, high_dps):
    """find a branch of B and values of B's free constants that reproduce the function with values fa at zs;
    accepted only if the values at zv_extra agree to 10^(-digits+8).  Returns (branch, x) or None."""
    with mpmath.workdps(high_dps):
        brs = _branches(B, pt)
    nunk = len(B.free)
    for br in brs:
        for x0 in x_starts:
            if time.time() > deadline:
                raise _Deadline()
            with mpmath.workdps(low_dps):
                fal = [mpmath.mpc(v) for v in fa]

                def res_low(x):
                    return [(_evalf(B, pt, br, x, zz) - v) / (1 + abs(v)) for zz, v in zip(zs, fal)]
                x, nr = _lm(res_low, x0, deadline, mpmath.mpf(10) ** (-(low_dps - 6)))
            if x is None or nr is None or nr > mpmath.mpf(10) ** (-(low_dps // 2)):
                continue
            with mpmath.workdps(high_dps):
                def res_high(xx):
                    return [(_evalf(B, pt, br, xx, zz) - v) / (1 + abs(v)) for zz, v in zip(zs, fa)]
                x, nr = _lm(res_high, x, deadline, mpmath.mpf(10) ** (-(high_dps - 6)), maxit=12)
                if x is None:
                    continue
                if not _fam_ok(B, pt, br, x):
                    continue
                ok = True
                for zz, v in zip(zv_extra, fa_extra):
                    try:
                        w = _evalf(B, pt, br, x, zz)
                    except _Fail:
                        ok = False
                        break
                    if abs(w - v) > mpmath.mpf(10) ** (-(digits - 8)) * max(1, abs(v)):
                        ok = False
                        break
                if ok:
                    return br, x
            if nunk == 0:
                break
    return None


def _starts(A, fvA, B, rnd, extra=0):
    """starting values for B's free constants, given A's values (by name, sign, inverse; then random)"""
    names_a = dict((str(s), v) for s, v in zip(A.free, fvA))
    unk = [str(s) for s in B.free]
    base = []
    unmatched_b = [u for u in unk if u not in names_a]
    unmatched_a = [n for n in names_a if n not in unk]
    for u in unk:
        base.append(names_a.get(u, mpmath.mpc(1)))
    out = [list(base)]
    # unmatched names in B: take A's unmatched values in every order (at most three)
    if unmatched_b and unmatched_a and len(unmatched_b) <= 3:
        for perm in itertools.permutations(unmatched_a, min(len(unmatched_a), len(unmatched_b))):
            cand = list(base)
            for u, n in zip(unmatched_b, perm):
                cand[unk.index(u)] = names_a[n]
            out.append(cand)
    for j, u in enumerate(unk):
        if u in _TRANSLATION:
            continue
        v = base[j]
        for w in (-v, 1 / v if v != 0 else mpmath.mpc(1)):
            cand = list(base)
            cand[j] = w
            out.append(cand)
    for _ in range(4 + extra):
        out.append([mpmath.mpc(rnd.uniform(-1.5, 1.5), rnd.uniform(-1.5, 1.5)) for _u in unk])
    # scalings: exponential constants K = exp(-nu*z0)*... may be far from 1 (only when B has one such constant:
    # with several, these starts cost more time than they gain)
    nonshift = [u for u in unk if u not in _TRANSLATION]
    for j, u in enumerate(unk):
        if u in _TRANSLATION or len(nonshift) > 1:
            continue
        for k in (-3, -2, -1, 1, 2, 3):
            for ph in (1, 1j, -1, -1j):
                cand = list(base)
                cand[j] = mpmath.mpc(ph) * mpmath.mpf(10) ** k * mpmath.mpc(rnd.uniform(0.5, 2), 0)
                out.append(cand)
    uniq = []
    for c in out:
        if not any(all(_close(p, q, mpmath.mpf(10) ** -12) for p, q in zip(c, d)) for d in uniq):
            uniq.append(c)
    return uniq


def _perturb(zz):
    """a factor close to 1 that no family of the kinds listed here absorbs (exp(z^2) is entire of order two)"""
    return 1 + mpmath.mpf("1e-3") * mpmath.exp(zz * zz / 3 + zz / 7)


def _contained_at(A, B, pt, rnd, deadline, digits, self_check):
    """at the parameter point pt (in both loci): is every function of A a function of B?  True / False;
    raises _Fail if A cannot be evaluated"""
    high = digits + 20
    low = 20
    with mpmath.workdps(high):
        brsA = _branches(A, pt)
    if not brsA:
        raise _Fail("no admissible root for a constant of %s" % A.id)
    nunk = len(B.free)
    nz = nunk + 2
    for brA in brsA:
        fvA = None
        for _t in range(6):
            cand = [mpmath.mpc(rnd.uniform(-1.4, 1.4), rnd.uniform(-1.4, 1.4)) for _s in A.free]
            if _fam_ok(A, pt, brA, cand):
                fvA = cand
                break
        if fvA is None:
            raise _Fail("no admissible values of the free constants of %s" % A.id)
        zs, fa = _sample_zs(A, pt, brA, fvA, rnd, nz, high)
        zx, fx = _sample_zs(A, pt, brA, fvA, rnd, 4, high)
        starts = _starts(A, fvA, B, rnd, extra=6 if nunk >= 2 else 2)
        got = _match_one(B, pt, fa, zs, zx, fx, starts, deadline, digits, low, high)
        if got is None:
            return False
        if self_check:
            # the same test against a perturbed function must fail
            with mpmath.workdps(high):
                fa_p = [v * _perturb(zz) for v, zz in zip(fa, zs)]
                fx_p = [v * _perturb(zz) for v, zz in zip(fx, zx)]
            bad = _match_one(B, pt, fa_p, zs, zx, fx_p, [list(got[1])] + starts[:2], deadline, digits, low, high)
            if bad is not None:
                raise _Fail("self-check: a perturbed function also matched %s" % B.id)
    return True


# ---------------------------------------------------------------------------------------------------------------
# relations between two items
# ---------------------------------------------------------------------------------------------------------------

def _points_of(A, rnd, deadline, n=3):
    """points of A's locus at which A's inequalities hold; (points, note).  If no such point is found, points of
    the Zariski closure (A's equalities only) are returned and the note says so."""
    with mpmath.workdps(60):
        pts, complete = _locus_points(A.eqs, A.params, rnd, n, deadline, complex_draw=True)
    if not complete:
        return [], "an equality of %s could not be solved for all of its roots (or on all components)" % A.id
    if not pts:
        return [], "no point of the locus of %s was found" % A.id
    good = []
    with mpmath.workdps(60):
        for comp in sorted(set(pt.get("_comp", 0) for pt in pts)):
            pc = [pt for pt in pts if pt.get("_comp", 0) == comp]
            gc = []
            for pt in pc:
                try:
                    if all(not _holds(g, pt, A.params) for g in A.neqs):
                        gc.append(pt)
                except _Fail:
                    continue
            if gc:
                if len(set(pt.get("_draw") for pt in gc)) < 2:
                    return [], "fewer than two independent points on a component of the locus of %s" % A.id
                good.extend(gc)
                continue
            # no regular point on this component: it is left out only if one inequality of A vanishes at all of
            # its points (the component lies outside A's locus)
            try:
                outside = any(all(_holds(g, pt, A.params) for pt in pc) for g in A.neqs)
            except _Fail:
                outside = False
            if not outside and any(True for _ in pc):
                if good or len(pc) > 0:
                    return [], "a component of the locus of %s has no regular point" % A.id
    note = ""
    if not good:
        # inequalities that fail at every point fail on the whole locus of the equalities: the conditions are
        # inconsistent; the points of the equalities are used, except those where another inequality vanishes
        with mpmath.workdps(60):
            try:
                zero = [[_holds(g, pt, A.params) for pt in pts] for g in A.neqs]
            except _Fail:
                return [], "the conditions of %s could not be evaluated" % A.id
            ident = [all(zs) for zs in zero]
            pts2 = [pt for k, pt in enumerate(pts)
                    if all(ident[m] or not zero[m][k] for m in range(len(A.neqs)))]
        if len(set(pt.get("_draw") for pt in pts2)) < 2:
            return [], "no regular point of the locus of %s was found" % A.id
        return pts2, ("the conditions of %s are inconsistent at every point tried (equalities only were used)"
                      % A.id)
    return good, note


def _choose_points(pts, per_first):
    """on every component: every root of the first draw (at most per_first) and the first point of each further
    draw; None if a component has fewer than two independent draws"""
    chosen = []
    for comp in sorted(set(pt.get("_comp", 0) for pt in pts)):
        pc = [pt for pt in pts if pt.get("_comp", 0) == comp]
        seen = set()
        first = pc[0].get("_draw")
        part = []
        for pt in pc:
            d = pt.get("_draw")
            if d == first:
                if len([q for q in part if q.get("_draw") == d]) < per_first:
                    part.append(pt)
            elif d not in seen:
                part.append(pt)
            seen.add(d)
        if len(set(pt.get("_draw") for pt in part)) < 2:
            return None
        chosen.extend(part)
    return chosen


def _conditions_hold(item_conditions, param_names, pts):
    """every condition, as written ("lhs == rhs" / "lhs != rhs"), evaluated directly at every point (50 digits):
    an equality holds if |lhs - rhs| <= 1e-30 x scale, an inequality if |lhs - rhs| > 1e-15 x scale
    (scale = 1 + |lhs| + |rhs| + the sizes of the terms of lhs - rhs).  Returns (True, "") or (False, reason); a condition that cannot be read or
    evaluated gives False."""
    params = [_sym(n) for n in param_names]
    loc = dict((str(q), q) for q in params)
    if not pts:
        return False, "no point"
    with mpmath.workdps(50):
        for c in item_conditions or []:
            op, a, b = _split_cond(c)
            if op is None:
                return False, "condition not read: %s" % str(c)[:60]
            try:
                ea = _parse(a, loc)
                eb = _parse(b, loc)
            except Exception:
                return False, "condition not read: %s" % str(c)[:60]
            if (ea.free_symbols | eb.free_symbols) - set(params):
                continue                  # a condition on free constants of the family: checked at the match
            for pt in pts:
                try:
                    va = _val(ea, dict((q, pt[q]) for q in ea.free_symbols)) if ea.free_symbols else _val(ea, {})
                    vb = _val(eb, dict((q, pt[q]) for q in eb.free_symbols)) if eb.free_symbols else _val(eb, {})
                except _Fail:
                    return False, "condition %s cannot be evaluated at a point" % str(c)[:60]
                # scale: the sizes of the terms (a long polynomial cancels to a small number on its zero set)
                scale = 1 + abs(va) + abs(vb) + _scale(ea - eb, pt, params)
                d = abs(va - vb)
                if op == "==" and d > mpmath.mpf(10) ** -30 * scale:
                    return False, "condition %s fails at a point" % str(c)[:60]
                if op == "!=" and d <= mpmath.mpf(10) ** -15 * scale:
                    return False, "condition %s fails (value 0) at a point" % str(c)[:60]
    return True, ""


def _contains(A, B, rnd, deadline, digits, ptsA=None, self_check=True):
    """is the set of A contained in that of B, on A's locus?  (verdict, why, points)
    verdict: True, False ("A's locus is not inside B's" or "no match"), None (undecided)"""
    if ptsA is None:
        ptsA, note = _points_of(A, rnd, deadline)
    else:
        note = ""
    if not ptsA:
        return None, note or "no locus point", 0
    with mpmath.workdps(60):
        li = _locus_in(A, B, ptsA)
    if li is False:
        return False, "the locus of %s is not inside the locus of %s" % (A.id, B.id), 0
    if li is None:
        return None, "the loci could not be compared", 0
    ok, why_c = _conditions_hold(B.conds_written, B.param_names, ptsA)
    if not ok:
        return None, "conditions of %s at points of the locus of %s: %s" % (B.id, A.id, why_c), 0
    # test at every root of the dependent parameters of the first draw (at most four) and at the first point of
    # each further draw (the last draw has complex parameter values): at least two independent draws
    chosen = _choose_points(ptsA, 4)
    if chosen is None:
        return None, "fewer than two independent points on a component of the locus of %s" % A.id, 0
    count = 0
    for k, pt in enumerate(chosen):
        try:
            ok = _contained_at(A, B, pt, rnd, deadline, digits, self_check=self_check and k == 0)
        except _Fail as exc:
            return None, str(exc), count
        count += 1
        if not ok:
            return False, "no values of the constants of %s reproduce a function of %s at a point of the locus" \
                % (B.id, A.id), count
    why = "every function of %s is a function of %s at %d parameter points" % (A.id, B.id, count)
    if note:
        why += " (%s)" % note
    return True, why, count


def _locus_rel(A, B, rnd, deadline):
    with mpmath.workdps(60):
        pa, na = _points_of(A, rnd, deadline)
        pb, nb = _points_of(B, rnd, deadline)
        lab = _locus_in(A, B, pa) if pa else None
        lba = _locus_in(B, A, pb) if pb else None
    return pa, pb, lab, lba


def same_family(a, b, param_names, limit_s=5.0, digits=30):
    """compare the sets of functions denoted by the Solution dicts a and b (see the module docstring).
    Returns {"relation": "equal" | "a_in_b" | "b_in_a" | "different" | "undecided", "why": str, "points": int}."""
    deadline = time.time() + float(limit_s)
    param_names = [str(p) for p in param_names]
    A = _prepare(a, param_names)
    B = _prepare(b, param_names)
    if not A.ok or not B.ok:
        return {"relation": "undecided", "why": "not compared: %s" % (A.why if not A.ok else B.why), "points": 0}
    import zlib
    seed = zlib.crc32(("%s|%s|%s|%d" % (a.get("id"), a.get("expr"), b.get("expr"), digits)).encode("utf-8"))
    rnd = random.Random(seed)
    try:
        return _same_family(A, B, rnd, deadline, digits)
    except _Deadline:
        return {"relation": "undecided", "why": "time limit of %.1f s reached" % float(limit_s), "points": 0}
    except _Fail as exc:
        return {"relation": "undecided", "why": str(exc), "points": 0}
    except Exception as exc:                       # never a definite answer after an unexpected error
        return {"relation": "undecided", "why": "error: %s" % str(exc)[:160], "points": 0}


def _same_family(A, B, rnd, deadline, digits):
    pa, pb, lab, lba = _locus_rel(A, B, rnd, deadline)
    if lab is None and lba is None:
        return {"relation": "undecided", "why": "no point of either locus was found", "points": 0}
    pts = 0
    ab = ba = None
    wab = wba = ""
    if lab:
        ab, wab, n = _contains(A, B, rnd, deadline, digits, ptsA=pa)
        pts += n
    if lba:
        ba, wba, n = _contains(B, A, rnd, deadline, digits, ptsA=pb)
        pts += n
    if lab and lba:
        if ab and ba:
            return {"relation": "equal", "why": "same locus; " + wab + "; " + wba, "points": pts}
        if ab and ba is False:
            return {"relation": "a_in_b", "why": "same locus; " + wab + "; " + wba, "points": pts}
        if ba and ab is False:
            return {"relation": "b_in_a", "why": "same locus; " + wba + "; " + wab, "points": pts}
        if ab is False and ba is False:
            return {"relation": "different", "why": "same locus; " + wab + "; " + wba, "points": pts}
        return {"relation": "undecided", "why": "; ".join(w for w in (wab, wba) if w), "points": pts}
    if lab:
        if ab:
            return {"relation": "a_in_b", "why": "locus of %s inside that of %s; %s" % (A.id, B.id, wab),
                    "points": pts}
        if ab is False:
            return {"relation": "different", "why": wab, "points": pts}
        return {"relation": "undecided", "why": wab, "points": pts}
    if lba:
        if ba:
            return {"relation": "b_in_a", "why": "locus of %s inside that of %s; %s" % (B.id, A.id, wba),
                    "points": pts}
        if ba is False:
            return {"relation": "different", "why": wba, "points": pts}
        return {"relation": "undecided", "why": wba, "points": pts}
    if lab is None or lba is None:
        return {"relation": "undecided", "why": "a locus could not be compared", "points": pts}
    # neither locus contains the other: the sets differ; do the functions agree on the intersection?
    agree = _agree_on_intersection(A, B, rnd, deadline, digits)
    if agree:
        return {"relation": "undecided", "why": "the loci differ, and the functions agree on their intersection",
                "points": pts}
    return {"relation": "different", "why": "neither locus contains the other" +
            ("" if agree is False else " (the intersection was not examined)"), "points": pts}


def _agree_on_intersection(A, B, rnd, deadline, digits):
    C = _Prepared()
    C.__dict__.update(A.__dict__)
    C.eqs = list(A.eqs) + list(B.eqs)
    C.neqs = list(A.neqs) + list(B.neqs)
    C.id = "%s and %s" % (A.id, B.id)
    try:
        pts, _note = _points_of(C, rnd, deadline, n=2)
    except _Deadline:
        raise
    if "inconsistent" in (_note or ""):
        return False                     # the two loci do not meet
    if len(pts) < 1:
        return None
    try:
        r1 = _contained_at(A, B, pts[0], rnd, deadline, digits, self_check=False)
        r2 = _contained_at(B, A, pts[0], rnd, deadline, digits, self_check=False)
    except _Fail:
        return None
    return bool(r1 or r2)


# ---------------------------------------------------------------------------------------------------------------
# lists
# ---------------------------------------------------------------------------------------------------------------

def _may_contain(A, B):
    """containment found at generic members may be used for a drop: B has no restriction on its free constants, or
    the two items carry the same restrictions (genuine copies), and B has no restriction in words that was not
    read"""
    if B.unread:
        return False
    if not B.fam_sig or A.fam_sig == B.fam_sig:
        return True
    # A is one function up to translation: its members differ by a shift of z, which leaves first-integral values
    # unchanged and moves exponential scalings K along exp(nu*z0) (never 0); the matched values were checked
    return all(str(s) in _TRANSLATION for s in A.free) and not A.fam_sig


def _direct_assignment(P):
    """if the equalities can be solved one after another for parameters of degree one with a numeric coefficient
    (after substituting the earlier ones and removing factors that the inequalities declare nonzero), the
    parameters fixed by the locus as expressions in the others ({Symbol: expr}); otherwise None"""
    nonzero = set()
    for g in P.neqs:
        for f in _factors(g):
            nonzero.add(sp.expand(f))
            nonzero.add(sp.expand(-f))
    sol = {}
    rest = list(P.eqs)
    for _ in range(len(rest) + 1):
        progress = False
        for g0 in list(rest):
            g = sp.expand(sp.numer(sp.together(g0.xreplace(sol) if sol else g0)))
            if g == 0:
                rest.remove(g0)
                progress = True
                continue
            try:
                _c, fl = sp.factor_list(g)
            except Exception:
                return None
            fl = [f for f, _m in fl if f.free_symbols and sp.expand(f) not in nonzero]
            if len(fl) != 1:
                continue
            f = fl[0]
            pick = None
            for q in sorted(f.free_symbols & set(P.params), key=str):
                if q in sol:
                    continue
                try:
                    pq = sp.Poly(f, q)
                except Exception:
                    continue
                co = pq.all_coeffs()
                if pq.degree() == 1 and co[0].is_number and co[0] != 0:
                    pick = (q, sp.together(-co[1] / co[0]))
                    break
            if pick is None:
                continue
            q, v = pick
            sol = dict((k, sp.together(val.xreplace({q: v}))) for k, val in sol.items())
            sol[q] = v
            rest.remove(g0)
            progress = True
        if not rest:
            return sol
        if not progress:
            return None
    return sol if not rest else None


def _canon_conditions(P, assign=None):
    """canonical form of the parameter conditions.  With a direct assignment: the assigned values and the
    irreducible factors of the inequalities after substitution (a factor that becomes zero marks the conditions as
    inconsistent).  Otherwise: equalities as a reduced Groebner basis (grevlex) of their numerators when that is
    cheap, else as sorted primitive numerators; inequalities as the set of their irreducible factors up to sign."""
    def prim(g):
        g = sp.expand(sp.numer(sp.together(g)))
        if g == 0:
            return g
        try:
            gp = sp.Poly(g, *P.params)
            g = gp.primitive()[1].as_expr()
            if sp.Poly(g, *P.params).LC().could_extract_minus_sign():
                g = -g
        except Exception:
            pass
        return g
    if assign is not None:
        vals = tuple(sorted((str(k), sp.srepr(sp.factor(v))) for k, v in assign.items()))
        neq = set()
        for g in P.neqs:
            h = sp.numer(sp.together(g.xreplace(assign)))
            if sp.expand(h) == 0:
                neq.add("inconsistent")
                continue
            for f in _factors(h):
                neq.add(sp.srepr(prim(f)))
        return ("direct",) + vals, tuple(sorted(neq))
    eqs = [prim(g) for g in P.eqs]
    eqs = sorted(set(sp.srepr(g) for g in eqs if g != 0))
    gb = None
    if P.eqs and sum(len(str(g)) for g in P.eqs) < 400:
        try:
            G = sp.groebner([sp.numer(sp.together(g)) for g in P.eqs], *P.params, order="grevlex")
            gb = sorted(sp.srepr(prim(g)) for g in G.exprs)
        except Exception:
            gb = None
    neq = set()
    for g in P.neqs:
        for f in _factors(g):
            neq.add(sp.srepr(prim(f)))
    return (tuple(gb) if gb is not None else ("list",) + tuple(eqs)), tuple(sorted(neq))


def _canon_key(P):
    """a key that two items share only if they are the same text after renaming their free constants (the
    translation included) and their root constants, with the same root equations, the same restrictions on the
    free constants and the same canonical conditions.  Items with equal keys denote the same set of functions."""
    if not P.ok:
        return None
    try:
        frees = [x for x in P.free if str(x) not in _TRANSLATION]
        trans = [x for x in P.free if str(x) in _TRANSLATION]
        roots = list(P.root_syms)
        if len(frees) > 3 or len(roots) > 3:
            return None
        best = None
        assign = _direct_assignment(P) if P.eqs else {}
        A0 = assign or {}
        root_e = dict((r, P.root_exprs[r].xreplace(A0)) for r in roots)
        expr0 = P.expr.xreplace(A0)
        fam0 = [g.xreplace(A0) for g in P.fam_neqs]
        for pf in itertools.permutations(frees):
            for pr in itertools.permutations(roots):
                sub = {}
                for k, x in enumerate(pf):
                    sub[x] = sp.Symbol("_c%d" % k)
                for k, x in enumerate(trans):
                    sub[x] = sp.Symbol("_t%d" % k)
                for k, x in enumerate(pr):
                    sub[x] = sp.Symbol("_r%d" % k)
                parts = [sp.srepr(expr0.xreplace(sub))]
                parts += [sp.srepr(sp.expand(root_e[x]).xreplace(sub)) for x in pr]
                parts += sorted(sp.srepr(sp.expand(g).xreplace(sub)) for g in fam0)
                key = tuple(parts)
                if best is None or key < best:
                    best = key
        return (P.kind, best, _canon_conditions(P, assign if P.eqs else None), bool(P.unread))
    except Exception:
        return None


def _pref_key(P, i):
    return (P.nconds, P.expr_len, i)


def copies(found, param_names, limit_s=20.0):
    """indices of items of `found` that repeat another item.  An item is dropped only if an item that is kept
    denotes a set of functions containing it on a locus containing its locus (decided by same-kind comparison).
    Returns {"drop": [indices], "why": {index: "same as <id> ..."}, "undecided": [(i, j)]}."""
    t_end = time.time() + float(limit_s)
    param_names = [str(p) for p in param_names]
    preps = [_prepare(it, param_names) for it in found]
    rnd = random.Random(20261006)
    n = len(found)
    # cheap first pass (no numerics): items that are the same text after renaming the constants, with the same
    # root equations, restrictions and canonical conditions; the preferred one of each group is kept
    first_drop, first_why, first_kept = [], {}, {}
    groups = {}
    for i in range(n):
        if time.time() > t_end:
            break
        k = _canon_key(preps[i])
        if k is not None and not preps[i].unread:
            groups.setdefault(k, []).append(i)
    gate_refused = []
    for k, idx in groups.items():
        if len(idx) < 2:
            continue
        keep = min(idx, key=lambda i: _pref_key(preps[i], i))
        for i in idx:
            if i == keep:
                continue
            # direct check: every condition of the kept item, as written, at the points of i's locus
            try:
                pts_i = _points_of(preps[i], rnd, t_end)[0]
            except (_Deadline, _Fail):
                pts_i = []
            ok, why_g = _conditions_hold(preps[keep].conds_written, param_names, pts_i)
            if not ok:
                gate_refused.append((i, keep, why_g))
                continue
            first_drop.append(i)
            first_kept[i] = keep
            first_why[i] = "same as %s: the same expression after renaming the constants, with the same " \
                           "conditions" % found[keep].get("id")
    rel = {}                                       # (i, j) -> True / False / None : set(i) inside set(j)
    why = {}
    undecided = []
    pts_cache = {}

    def pts(i):
        if i not in pts_cache:
            pts_cache[i] = _points_of(preps[i], rnd, t_end)[0]
        return pts_cache[i]
    pairs = []
    gone = set(first_drop)
    for i in range(n):
        for j in range(n):
            if i == j or not preps[i].ok or not preps[j].ok or i in gone or j in gone:
                continue
            if found[i].get("kind") != found[j].get("kind"):
                continue
            pairs.append((i, j))
    # cheap pairs first: equal numbers of free constants, then by size
    pairs.sort(key=lambda ij: (len(preps[ij[0]].free) != len(preps[ij[1]].free),
                               preps[ij[0]].elliptic or preps[ij[1]].elliptic, ij))
    loc_ok = {}
    try:
        for (i, j) in pairs:
            if time.time() > t_end:
                break
            try:
                with mpmath.workdps(60):
                    p = pts(i)
                    loc_ok[(i, j)] = _locus_in(preps[i], preps[j], p) if p else None
            except _Fail:
                loc_ok[(i, j)] = None
    except _Deadline:
        pass
    for (i, j) in pairs:
        if loc_ok.get((i, j)) is not True:
            if loc_ok.get((i, j)) is None and (i, j) in loc_ok:
                undecided.append((i, j))
            continue
        if time.time() > t_end:
            undecided.append((i, j))
            continue
        try:
            v, w, _n = _contains(preps[i], preps[j], rnd, t_end, 30, ptsA=pts(i))
        except _Deadline:
            undecided.append((i, j))
            continue
        except Exception as exc:
            v, w = None, "error: %s" % str(exc)[:120]
        if v is True and not _may_contain(preps[i], preps[j]):
            v, w = None, "%s excludes some values of its free constants (%s) that %s may use" % (
                found[j].get("id"), "restriction not read" if preps[j].unread else "restrictions differ",
                found[i].get("id"))
        rel[(i, j)] = v
        why[(i, j)] = w
        if v is None:
            undecided.append((i, j))
    # drop i if some kept j contains it: strictly, or equally and j is preferred
    def dominated_by(i):
        out = []
        for j in range(n):
            if rel.get((i, j)) is True:
                eq = rel.get((j, i)) is True
                if eq and _pref_key(preps[j], j) > _pref_key(preps[i], i):
                    continue
                out.append(j)
        return out
    order = sorted(range(n), key=lambda i: _pref_key(preps[i], i) if preps[i].ok else (9999, 0, i))
    kept = set(range(n))
    drop, reasons, kept_by = [], {}, {}
    # first pass: items that are not dominated are kept for sure
    dom = dict((i, dominated_by(i)) for i in range(n))
    changed = True
    dropped = set()
    while changed:
        changed = False
        for i in order:
            if i in dropped:
                continue
            ks = [j for j in dom[i] if j not in dropped]
            if ks:
                dropped.add(i)
                changed = True
    for i in sorted(dropped):
        ks = [j for j in dom[i] if j not in dropped]
        if not ks:
            continue                                   # its witnesses are all dropped: keep it
        # confirmation: the containment again, at other parameter points and with more digits
        j = None
        for jj in ks:
            if time.time() > t_end:
                break
            try:
                v2, _w2, _n2 = _contains(preps[i], preps[jj], random.Random(31337 + 101 * i + jj), t_end, 36)
            except Exception:
                v2 = None
            if v2 is True:
                j = jj
                break
        if j is not None:
            # direct check: every condition of the kept item, as written, at the points of i's locus
            try:
                ok, why_g = _conditions_hold(preps[j].conds_written, param_names, pts(i))
            except (_Deadline, _Fail):
                ok, why_g = False, "no points"
            if not ok:
                gate_refused.append((i, j, why_g))
                j = None
        if j is None:
            for jj in ks:
                undecided.append((i, jj))
            continue
        eq = rel.get((j, i)) is True
        drop.append(i)
        kept_by[i] = j
        reasons[i] = "same as %s%s: %s" % (found[j].get("id"), "" if eq else " (contained in it)",
                                           why.get((i, j), ""))
    kept -= set(drop)
    for i in first_drop:
        drop.append(i)
        reasons[i] = first_why[i]
        kept_by[i] = first_kept[i]
    drop.sort()
    for i, j, _w in gate_refused:
        if i not in drop:
            undecided.append((i, j))
    return {"drop": drop, "why": reasons, "undecided": sorted(set(p for p in undecided if p[0] not in drop)),
            "kept_by": kept_by, "refused": [(i, j, w) for i, j, w in gate_refused if i not in drop]}


def same_lists(found_a, found_b, param_names, limit_s=20.0):
    """two lists that both claim to be complete for the same equation: do they denote the same set of
    functions?  Constant items without conditions are ignored.  Each item of either list must be reproduced, at two
    points of its locus and for every admissible root, by an item of the other list whose conditions hold there.
    Returns {"equal": True | False | None, "only_in_a": [ids], "only_in_b": [ids], "pairs": [(id_a, id_b)],
    "why": str}."""
    t_end = time.time() + float(limit_s)
    param_names = [str(p) for p in param_names]

    def usable(lst):
        return [it for it in lst if not (it.get("kind") == "constant" and not it.get("conditions"))]
    LA = usable(found_a)
    LB = usable(found_b)
    PA = [_prepare(it, param_names) for it in LA]
    PB = [_prepare(it, param_names) for it in LB]
    rnd = random.Random(77)
    pairs = []
    only_a, only_b = [], []
    unknown = []

    def covered(X, Ys, rev):
        if not X.ok:
            return None, []
        try:
            ptsX, _note = _points_of(X, rnd, t_end)
        except _Deadline:
            return None, []
        if len(ptsX) < 2:
            return None, []
        partners = []
        verdict = True
        chosen = _choose_points(ptsX, 1)
        if chosen is None:
            return None, []
        for pt in chosen:
            try:
                with mpmath.workdps(80):
                    brs = _branches(X, pt)
            except _Fail:
                return None, partners
            for br in brs:
                hit = None
                undecided_here = False
                for k, Y in enumerate(Ys):
                    if not Y.ok:
                        undecided_here = True
                        continue
                    with mpmath.workdps(60):
                        try:
                            inside = _in_locus(Y, pt)
                        except Exception:
                            undecided_here = True
                            continue
                    if not inside:
                        continue
                    X1 = _Prepared()
                    X1.__dict__.update(X.__dict__)
                    X1.roots = []
                    X1.root_syms = []
                    X1.f = _fixed_branch(X, br)
                    X1.fam_neq_f = [_fixed_fam(f, len(X.params), br) for f in X.fam_neq_f]
                    try:
                        ok = _contained_at(X1, Y, pt, rnd, t_end, 30, self_check=(len(partners) == 0))
                    except _Fail:
                        undecided_here = True
                        continue
                    except _Deadline:
                        return None, partners
                    if ok:
                        hit = k
                        break
                if hit is None:
                    verdict = None if (verdict is None or undecided_here) else False
                    if verdict is False:
                        return False, partners
                else:
                    partners.append(hit)
        return verdict, partners
    for i, X in enumerate(PA):
        v, ps = covered(X, PB, False)
        if v is True:
            for k in sorted(set(ps)):
                pairs.append((LA[i].get("id"), LB[k].get("id")))
        elif v is False:
            only_a.append(LA[i].get("id"))
        else:
            unknown.append(LA[i].get("id"))
    for k, Y in enumerate(PB):
        v, ps = covered(Y, PA, True)
        if v is True:
            for i in sorted(set(ps)):
                if (LA[i].get("id"), LB[k].get("id")) not in pairs:
                    pairs.append((LA[i].get("id"), LB[k].get("id")))
        elif v is False:
            only_b.append(LB[k].get("id"))
        else:
            unknown.append(LB[k].get("id"))
    if only_a or only_b:
        eq = False
        why = "items without a counterpart: %s" % ", ".join(str(x) for x in only_a + only_b)
    elif unknown:
        eq = None
        why = "not decided for: %s" % ", ".join(str(x) for x in unknown)
    else:
        eq = True
        why = "every item of each list is reproduced by an item of the other list"
    if unknown and eq is False:
        why += "; not decided for: %s" % ", ".join(str(x) for x in unknown)
    return {"equal": eq, "only_in_a": only_a, "only_in_b": only_b, "pairs": pairs, "why": why}


def _fixed_branch(X, br):
    np_ = len(X.params)
    f = X.f

    def g(zv, *args):
        return f(zv, *(list(args[:np_]) + list(br) + list(args[np_:])))
    return g


def _fixed_fam(f, np_, br):
    def g(*args):
        return f(*(list(args[:np_]) + list(br) + list(args[np_:])))
    return g
